---
agility: 1
ancestry:
  - Undead
  - Soulless
ev: '12'
file_basename: Lithgekh
file_dpath: Monsters/Undead/Statblocks
free_strike: 5
intuition: 3
item_id: lithgekh
item_index: '11'
item_name: Lithgekh
level: 10
might: 0
presence: -1
reason: 5
roles:
  - Horde Hexer
scc:
  - mcdm.monsters.v1:monster.undead.statblock:lithgekh
scdc:
  - 1.1.1:2.8.1:11
size: 1M
source: mcdm.monsters.v1
speed: 6
stability: 1
stamina: '55'
type: monster/undead/statblock
---

###### Lithgekh

|              Undead, Soulless              |              -               |      Level 10       |       Horde Hexer       |         EV 12          |
| :----------------------------------------: | :--------------------------: | :-----------------: | :---------------------: | :--------------------: |
|              **1M**<br/> Size              |       **6**<br/> Speed       | **55**<br/> Stamina |  **1**<br/> Stability   | **5**<br/> Free Strike |
| **Corruption 10, poison 10**<br/> Immunity | **Fly, hover**<br/> Movement |          -          | **-**<br/> With Captain |  **-**<br/> Weakness   |
|              **0**<br/> Might              |     **+1**<br/> Agility      | **+5**<br/> Reason  |  **+3**<br/> Intuition  |  **-1**<br/> Presence  |

<!-- -->
> 🏹 **Heartstopper (Signature Ability)**
>
> | **Magic, Ranged, Strike** |               **Main action** |
> | ------------------------- | ----------------------------: |
> | **📏 Ranged 15**          | **🎯 One creature or object** |
>
> **Power Roll + 5:**
>
> - **≤11:** 9 corruption damage; I < 3 frightened (save ends)
> - **12-16:** 12 corruption damage; I < 4 frightened (save ends)
> - **17+:** 14 corruption damage; I < 5 frightened (save ends)
>
> **Effect:** A creature frightened this way takes a bane on any ability that targets undead.

<!-- -->
> ❗️ **Mystic Battery (1 Malice)**
>
> | **Magic, Ranged** |      **Free triggered action** |
> | ----------------- | -----------------------------: |
> | **📏 Ranged 20**  | **🎯 The triggering creature** |
>
> **Trigger:** A creature within distance uses a magic ability.
>
> **Effect:** Any damage dealt by or Stamina regained from the ability is halved. The lithgekh regains Stamina equal to the remaining damage dealt or Stamina gained.

<!-- -->
> ⭐️ **Devour Magic**
>
> Each ally within 10 squares of the lithgekh gains an edge on magic abilities.
