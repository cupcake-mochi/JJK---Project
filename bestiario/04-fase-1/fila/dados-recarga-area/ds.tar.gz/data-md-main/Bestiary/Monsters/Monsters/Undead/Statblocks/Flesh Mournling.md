---
agility: 1
ancestry:
  - Undead
ev: '6'
file_basename: Flesh Mournling
file_dpath: Monsters/Undead/Statblocks
free_strike: 2
intuition: 2
item_id: flesh-mournling
item_index: '31'
item_name: Flesh Mournling
level: 4
might: 3
presence: -1
reason: 0
roles:
  - Horde Defender
scc:
  - mcdm.monsters.v1:monster.undead.statblock:flesh-mournling
scdc:
  - 1.1.1:2.8.1:31
size: '2'
source: mcdm.monsters.v1
speed: 6
stability: 2
stamina: '35'
type: monster/undead/statblock
---

###### Flesh Mournling

|                  Undead                  |          -          |       Level 4       |     Horde Defender      |          EV 6          |
| :--------------------------------------: | :-----------------: | :-----------------: | :---------------------: | :--------------------: |
|             **2**<br/> Size              |  **6**<br/> Speed   | **35**<br/> Stamina |  **2**<br/> Stability   | **2**<br/> Free Strike |
| **Corruption 4, poison 4**<br/> Immunity | **-**<br/> Movement |          -          | **-**<br/> With Captain |  **-**<br/> Weakness   |
|            **+3**<br/> Might             | **+1**<br/> Agility |  **0**<br/> Reason  |  **+2**<br/> Intuition  |  **-1**<br/> Presence  |

<!-- -->
> 🗡 **Multiarm Strike (Signature Ability)**
>
> | **Melee, Strike, Weapon** |               **Main action** |
> | ------------------------- | ----------------------------: |
> | **📏 Melee 2**            | **🎯 One creature or object** |
>
> **Power Roll + 3:**
>
> - **≤11:** 5 damage
> - **12-16:** 7 damage
> - **17+:** 9 damage
>
> **Effect:** The target can't shift until the end of their next turn.
>
> **1 Malice:** This ability targets one additional target.

<!-- -->
> ❇️ **Horrid Wail**
>
> | **Area, Magic** |               **Main action** |
> | --------------- | ----------------------------: |
> | **📏 5 burst**  | **🎯 Each enemy in the area** |
>
> **Power Roll + 3:**
>
> - **≤11:** 2 psychic damage
> - **12-16:** 3 psychic damage; I < 2 frightened (save ends)
> - **17+:** 4 psychic damage; I < 3 frightened (save ends)
>
> **Effect:** A target who is still frightened this way at the end of the encounter can't take a respite activity during their next respite.

<!-- -->
> ⭐️ **Arise**
>
> The first time the mournling is reduced to 0 Stamina by damage that isn't fire damage or holy damage and their body isn't destroyed, they instead have 10 Stamina and fall prone.

<!-- -->
> ⭐️ **Immutable Form**
>
> The mournling's shape can't be changed by any external effect.
