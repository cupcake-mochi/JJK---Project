---
agility: -2
ancestry:
  - Undead
  - Soulless
ev: '12'
file_basename: Bonecage
file_dpath: Monsters/Undead/Statblocks
free_strike: 4
intuition: 3
item_id: bonecage
item_index: '03'
item_name: Bonecage
level: 10
might: 5
presence: -1
reason: -2
roles:
  - Horde Controller
scc:
  - mcdm.monsters.v1:monster.undead.statblock:bonecage
scdc:
  - 1.1.1:2.8.1:03
size: '3'
source: mcdm.monsters.v1
speed: 6
stability: 5
stamina: '55'
type: monster/undead/statblock
---

###### Bonecage

|              Undead, Soulless              |            -            |      Level 10       |    Horde Controller     |         EV 12          |
| :----------------------------------------: | :---------------------: | :-----------------: | :---------------------: | :--------------------: |
|              **3**<br/> Size               |    **6**<br/> Speed     | **55**<br/> Stamina |  **5**<br/> Stability   | **4**<br/> Free Strike |
| **Corruption 10, poison 10**<br/> Immunity | **Climb**<br/> Movement |          -          | **-**<br/> With Captain |  **-**<br/> Weakness   |
|             **+5**<br/> Might              |   **-2**<br/> Agility   | **-2**<br/> Reason  |  **+3**<br/> Intuition  |  **-1**<br/> Presence  |

<!-- -->
> 🗡 **Ribcage Chomp (Signature Ability)**
>
> | **Melee, Strike, Weapon** |                 **Main action** |
> | ------------------------- | ------------------------------: |
> | **📏 Melee 2**            | **🎯 Two creatures or objects** |
>
> **Power Roll + 5:**
>
> - **≤11:** 9 damage; M < 4 grabbed
> - **12-16:** 12 damage; M < 5 grabbed
> - **17+:** 14 damage; grabbed
>
> **Effect:** The bonecage can have up to four size 1 targets grabbed at once. Any creature grabbed by the bonecage takes a bane on the Escape Grab maneuver, and the bonecage has damage immunity 5 against that creature's abilities. When the bonecage is force moved, any creature or object they have grabbed moves with them.
>
> **3 Malice:** While grabbed this way, a target can't teleport or be teleported.

<!-- -->
> 🔳 **Labyrinth of Bone (5 Malice)**
>
> | **Area, Magic, Ranged**           |               **Main action** |
> | --------------------------------- | ----------------------------: |
> | **📏 Four 10 x 1 lines within 3** | **🎯 Each enemy in the area** |
>
> **Effect:** The bonecage can put up to two 90-degree bends in each of the lines. Each target makes an Agility test.
>
> - **≤11:** 9 damage
> - **12-16:** 7 damage
> - **17+:** 4 damage
>
> **Effect:** The area is difficult terrain for enemies. The effect ends at the end of the encounter or when the bonecage uses this ability again.
