---
agility: 2
ancestry:
  - Fey
  - Humanoid
  - Shadow Elf
ev: '12'
file_basename: Shadow Elf Knightfell
file_dpath: Monsters/Elves Shadow/Statblocks
free_strike: 5
intuition: 3
item_id: shadow-elf-knightfell
item_index: '02'
item_name: Shadow Elf Knightfell
level: 4
might: 0
presence: 2
reason: 0
roles:
  - Platoon Defender
scc:
  - mcdm.monsters.v1:monster.elves-shadow.statblock:shadow-elf-knightfell
scdc:
  - 1.1.1:2.27.1:02
size: 1M
source: mcdm.monsters.v1
speed: 5
stability: 0
stamina: '70'
type: monster/elves-shadow/statblock
---

###### Shadow Elf Knightfell

| Fey, Humanoid, Shadow Elf |            -            |       Level 4       |    Platoon Defender     |         EV 12          |
| :-----------------------: | :---------------------: | :-----------------: | :---------------------: | :--------------------: |
|     **1M**<br/> Size      |    **5**<br/> Speed     | **70**<br/> Stamina |  **0**<br/> Stability   | **5**<br/> Free Strike |
|    **-**<br/> Immunity    | **Climb**<br/> Movement |          -          | **-**<br/> With Captain |  **-**<br/> Weakness   |
|     **0**<br/> Might      |   **+2**<br/> Agility   |  **0**<br/> Reason  |  **+3**<br/> Intuition  |  **+2**<br/> Presence  |

<!-- -->
> 🏹 **Suffusing Strike (Signature Ability)**
>
> | **Magic, Ranged, Strike** |               **Main action** |
> | ------------------------- | ----------------------------: |
> | **📏 Ranged 3**           | **🎯 One creature or object** |
>
> **Power Roll + 3:**
>
> - **≤11:** 8 corruption damage
> - **12-16:** 12 corruption damage; R < 2 taunted (EoT)
> - **17+:** 15 corruption damage; R < 3 taunted (EoT)

<!-- -->
> ❗️ **Trick of the Eye**
>
> | **Magic, Melee** | **Triggered action** |
> | ---------------- | -------------------: |
> | **📏 Melee 2**   |      **🎯 One ally** |
>
> **Trigger:** An enemy within distance makes a strike against the target.
>
> **Effect:** The target takes half the damage and the knightfell takes the other half.

<!-- -->
> ⭐️ **Of the Umbra**
>
> The knightfell ignores concealment created by darkness. While the knightfell is in direct sunlight, they have damage weakness 3. While the knightfell has concealment, they have damage immunity 3.
