# Estado atual do projeto

## Retomada atual — v0.331, 02/10/2026

**Concluído:** integração ao livro de Evocador, Incursor, seis Trilhas e capítulo de Invocações; nome Malabarista; cinco ajustes do Bastião pedidos nos itens 4.1–4.5. Fontes atuais em `caminhos/05-Edicao-Integrada/` e `invocacoes/05-Edicao-Integrada/`. O histórico abaixo conserva decisões anteriores, inclusive a suspensão do Evocador, **superada nesta versão por autorização expressa**.

**Fila que fica aberta, na ordem de trabalho:**

| Item | Próximo trabalho | Limite já decidido |
|---|---|---|
| 1 | Revisão textual integral com os livros de referência que o Mizuki fornecer | melhorar consulta e compreensão; registrar toda mudança de regra separadamente |
| 2 | Revisão ampla de nomes do sistema, Caminhos e habilidades | substituir nomes confusos e provisórios; Malabarista já aprovado, demais renomes exigem discussão |
| 3 | Outras pequenas mudanças nas classes — restante do item 4 do pedido | os cinco ajustes do Bastião estão aplicados; não supor novos ajustes aprovados |
| 4 | Diagramação, imagens, exemplos de mesa e elementos artísticos | definir direção visual e começar por um capítulo piloto antes de redesenhar o livro |
| 5 | Origens em outro ambiente e fichas no Claude | receber o resultado e conciliar com a v0.331; não sobrescrever trabalho externo |
| 6 | Pendências documentadas das invocações e das duas novas classes | consultar relatório e notas originais preservadas na integração |
| 7 | Avaliar novamente calibração e equilíbrio com os seis Caminhos | conservar por ora os números de inimigos da v0.330; não declarar equilíbrio comprovado |

**Pendências específicas preservadas:** quantidade do kit inicial ampliado; troca de Trilha e aquisições em duplas; repertório quando o atributo cai; corpos excedentes ao fim do combate; comandos, preparo e estados que cruzem as exceções das Trilhas; procedimentos gerais de Agarrar, Derrubar, Empurrar e Estudar. As regras específicas aprovadas do Pugilista e do Assassino seguem seus próprios textos. Colisões de Reflexo e Sentença Final ficam para a revisão de nomes.

**Retomar por esta seção.** Os itens antigos da fila são registros; quando divergirem, a decisão posterior da v0.331 é a atual. O relatório desta integração fica em `sistema/01-pesquisa/integracao-v0.331/RELATORIO.md`.

---

> **Continuidade de 29/09 — ordem mais recente de Mizuki:** o Git foi posto em dia — as v0.277 a v0.287 subiram num commit só, e a entrega como recorte da v0.287. O planejamento das Invocações virou o primeiro lote de desenvolvimento, que fica no HD, em `/media/mizuki/HD Externo II/Claude/invocacoes-pos46/`, e deu o §47 na v0.288 (o invocador apagado não derruba a sustentação), o §48 na v0.289 (quando ele morre, as entidades saem de campo), o §49 na v0.290 (cada entidade tem a própria ficha, e o limite é um teto de corpos), o §50 na v0.291 (uma básica por corpo por ciclo), o §51 na v0.292 (uma Bônus redireciona todas as entidades em campo, cada uma com a própria intenção de básica), o §52 na v0.293 (o limite de ataques por turno conta só a atuação com dano; a condição Média ou Pesada só vem de especial comandada), o §53 na v0.294 (a entidade só entra em campo no turno do invocador), o §54 na v0.295 (e só é recolhida no turno dele), o §55 na v0.296 (aparece colada no invocador, e na troca no lugar de quem sai), o §56 na v0.297 (a entrada e a troca custam a Ação Bônus), o §57 na v0.298 (o recolhimento também), o §58 na v0.299 (as manifestadas antes da luta começam em campo), o §59 na v0.300, fechado na v0.301 (a energia das especiais: do invocador, e da reserva própria de quem tem técnica, de 1 + ⅓ da Essência por nível, meio a meio) e o §60 na v0.302 (o conjunto rende até uma Rotina e meia por rodada, com preço), o §61 na v0.303 (a vida da entidade sai da fórmula de ficha, com 5 no nível 1 e 3 por nível, mais a Constituição), o §62 na v0.304 (sem supor Trilha, o teto de base é 2 entidades em campo), o §63 na v0.305 (o limite de base é 2, as duas atacam, e quem leva uma tem dano parelho com quem leva duas), o §64 na v0.306 (uma entidade completa até meia Rotina, e duas até dois terços), o §65 na v0.307 (a ficha da entidade é a da peça 15 antiga), o §66 na v0.308 (a Defesa com a metade do dono, e o traje no lugar), o §67 na v0.309 (cada entrada paga a Classe do nível da entidade em PE), o §68 na v0.310 (tudo que depende de nível segue o da entidade, até o do invocador), o §69 na v0.311 (a especial custa 3 × a Classe do nível da entidade, como um feitiço), o §70 na v0.312 (a manifestação dura até o fim da cena, e o fim do combate a encerra), o §71 na v0.313 (toda invocação exige uma troca para ser obtida, e o preço é a troca somada ao que já cobra), a correção dele e o §72 na v0.314 (o espaço dá a entidade no nível do invocador; a reserva recupera como o PE), o §73 na v0.315 (a morte definitiva, a volta com metade da vida, e a vaga da lista de ritual que se perde), o §74 na v0.316 (ficam `Desligada` o corpo amaldiçoado e a domada sem técnica), o §75 na v0.317 (a `Desligada` é um objeto no campo, fora do teto), o §76 na v0.318 (a cura: a de pé se cura, a zero só pela entrada, e o corpo amaldiçoado não se cura por energia amaldiçoada), os §§77 a 84 na v0.319 (os cinco tipos, em dois eixos, com a carga do talismã, a técnica e o nível parado da domada, e o modo inativo dos corpos amaldiçoados), o §85 na v0.320 (a volta da caída custa o dobro do PE da entrada), o §86 na v0.321 (o destino das entidades quando o invocador morre, por origem), o §87 na v0.322 (o efeito que repete numa `Desligada` continua), o §88 na v0.323 (a manutenção com o invocador apagado), os §§89 a 105 na v0.324 (o construtor da entidade, e o domar), os §§106 a 109 na v0.325 (o reparo, sem limite de entidades, e o atalho de domar e o criar, fora do capítulo). Em 29/09 o Mizuki mandou focar nas Invocações até terminar ("temos q terminar tudo de invocação"); a fila das Invocações fechou; o que sobra é do Evocador e das Trilhas (o que sobe a básica, abre Famílias e dá Livres) e a volta do capítulo ao livro, que é decisão dele; o traje, o talismã em campo e o que a entidade carrega fecharam na v0.328 (§§111 a 113), e o que ela leva quando sai de campo na v0.330 (§114); a fila do sistema fechou a cura da Origem `Corpo Amaldiçoado` na v0.326 (o mesmo reparo das invocações, no descanso curto) o peso na v0.327 (o talismã pesa `0,5` de `Volume`, e cada leve vale `0,1`, sem arredondar) e a imunidade dela a `Envenenado` na v0.329, sem medição; o que sobra na fila é o que já estava aberto antes. Fichas de personagem ficam para depois.

Atualizado em 30/09/2026, na v0.330 (última peça fechada: **Ritual**, a peça 27, na v0.262, com o `conferir-ritual.py` e sete checagens; antes dela, o **Bestiário**, a peça 26, na v0.198; antes dela, **Sem Técnica, a peça 25, na v0.168**; antes dela, **Dano de alma e Integridade, na v0.145**). Este arquivo existe para retomar o trabalho — inclusive em conversa nova — sem recontextualizar tudo. Leia ele inteiro antes de mexer em qualquer coisa: ele tem a seção *"Onde estamos, e o que falta"* no fim, que é o ponto de retomada.

**Versão v0.331.** Fases 0 a 3 fechadas; Fase 4 (mecânica) em andamento, **vinte e sete peças escritas** e **vinte e sete validadores**.

**Continuidade atual:** resistência pontual aprovada e integrada em Claude 2; o próximo ensaio está em `bestiario/05-sukuna/ENSAIO-integracao-grade-v286.md`. PV-base aprovado como referência da cura e das partes destrutíveis; no nível 30, cura de ação 78 e partes de 157 PV. Sukuna concluído na v0.287, com a política de débito corrente aprovada. O planejamento das Invocações virou o primeiro lote de desenvolvimento, no HD, e deu os §§47 a 109 da v0.288 à v0.325; a fila das Invocações fechou; o que sobra é do Evocador e das Trilhas (o que sobe a básica, abre Famílias e dá Livres) e a volta do capítulo ao livro, que é decisão dele; o traje, o talismã em campo e o que a entidade carrega fecharam na v0.328 (§§111 a 113), e o que ela leva quando sai de campo na v0.330 (§114); a fila do sistema fechou a cura da Origem `Corpo Amaldiçoado` na v0.326 (o mesmo reparo das invocações, no descanso curto) o peso na v0.327 (o talismã pesa `0,5` de `Volume`, e cada leve vale `0,1`, sem arredondar) e a imunidade dela a `Envenenado` na v0.329, sem medição; o que sobra na fila é o que já estava aberto antes. O histórico abaixo permanece para consulta.


> ## A v0.330 deu o §114 às Invocações: o que a entidade leva quando sai de campo
>
> **O que ela veste vai junto, e do que segura vai o que é dela** ("A, mas o que segura vai junto caso seja arma dela ou por exemplo, resto cai"); *o resto cai no lugar. A pergunta aberta é a volta do capítulo ao livro.*

> ## A v0.329 deu à Origem Corpo Amaldiçoado a imunidade a `Envenenado`
>
> **O personagem Corpo Amaldiçoado é imune a `Envenenado`**, *como já era o corpo amaldiçoado das Invocações (§77). Sem medição, por decisão dele: "n precisa validar mt, so deixa ali, todo mundo ja sabe desse conhecimento, é quase como flavor". A peça 9 §5 e o capítulo das Origens ganharam a linha.*

> ## A v0.328 deu os §§111 a 113 às Invocações: o talismã em campo, o traje e o que a entidade carrega
>
> **O talismã continua pesando com a entidade em campo** ("vc n perde o talisma, so tira a invocação dentro"). **O traje é um item normal**, *que qualquer entidade veste, e a proteção dele entra no lugar da metade do dono, como o uniforme entra no lugar do cobrir-se no personagem; a Defesa da entidade topa em `19`, e a do personagem em `20`.* **E a entidade só carrega o que tem nas mãos**, *a não ser por característica própria de armazenamento ou de carregar personagens, como o Nue. A pergunta aberta é o que ela veste ou segura quando sai de campo.*

> ## A v0.327 fechou o item 21 da fila: o peso do talismã, e o dos leves
>
> **O talismã guardado pesa `0,5` de `Volume`** ("pode por o talismã como meio mesmo"), *e cada item leve vale `0,1`, sem arredondar — antes, nove leves pesavam zero. O item partia de premissa errada: o peso existe desde a v0.256, na peça 14 §6.6.*

> ## A v0.326 fechou o item 20 da fila: a cura do Corpo Amaldiçoado
>
> **O personagem Corpo Amaldiçoado se conserta pelo mesmo reparo das invocações** ("A"): *no descanso curto, `Entalhador` ou `Forja`, metade da vida máxima. A `Energia Reversa` não o cura, e nada mais o proíbe de ser curado — "uma técnica poderia por exemplo, ser focada na narrativa de engenharia". O próximo é o item 21, a regra de peso.*

> ## A v0.325 fechou a fila das Invocações: os §§106 a 109
>
> **O reparo do corpo amaldiçoado entrou no capítulo, e duas coisas saíram dele por decisão do Mizuki.** *O corpo amaldiçoado se repara no descanso curto, por `Entalhador` ou `Forja` ("nem tudo precisa ser feito de madeira"), em metade da vida máxima; não há limite de quantas entidades se tem ("n plenejo limitar isso"); o atalho de domar sem luta é da técnica que doma, e criar é do sistema de criação — os dois registrados para quando existirem.*

> ## A v0.324 deu o construtor às Invocações: os §§89 a 105
>
> **A regra que guiou o pacote foi do Mizuki: "os valores n podem ser iguais ao de um invocador", e o turno com uma especial e uma básica fica "parelho a um classe de um emanador do mesmo nivel".** *São o construtor da entidade: o kit sai do Fundamento, com uma definição de menos de duas linhas, e é menor que o do invocador em tudo — a básica é a Classe 0 do jogador com metade dos dados, em d6 (1d6, 2d6 do 5, 3d6 do 17); metade das Classe 0 e dos espaços, sem marcos; oito passivas nos marcos, na Classe liberada; a especial é como o feitiço do jogador, com menos pontos (2 a 16 contra 3 por Classe) e o efeito uma Classe abaixo, para a especial com a básica da outra ficar em 85% a 90% do feitiço de um Emanador do mesmo nível; seis Famílias Fechadas e uma Livre; Liberação, Técnica Máxima e Expansão só na domada com técnica, reduzidas; e domar é derrotar e, fora da luta, um Teste de Resistência de Espírito contra a CD do invocador. Cada número foi medido contra o jogador e contra a Vanguarda e o Emanador antes de ir a ele.*

> ## A v0.323 deu o §88 às Invocações: a manutenção com o invocador apagado
>
> **A resposta do Mizuki foi "Vamos de B, mas se for uma passiva que n seja 'desligavel', ai C depois A".** *O efeito com manutenção que se pode desligar acaba quando o invocador apaga, e a entidade continua agindo pelo §47; a passiva que não se desliga continua, e paga da reserva da domada e, sem ela, do PE do invocador. As sobras fecharam; o próximo é o construtor.*

> ## A v0.322 deu o §87 às Invocações: o efeito que repete numa `Desligada` continua
>
> **A resposta do Mizuki foi "A".** *O dano que repete soma com o que passou do zero e pode destruí-la pelo limiar; a área que exige presença a alcança e nunca a destrói; a cura que repete não pega; a duração corre. Cair não limpa. No lote de desenvolvimento, a dívida do arquivo de pendências da bancada também fechou: os dez campos que as decisões resolveram saíram dele.*

> ## A v0.321 deu o §86 às Invocações: o destino depois da morte do invocador
>
> **A resposta do Mizuki foi "A".** *O §48 tinha deixado o destino "candidato a depender do vínculo", e os tipos agora existem: a entidade de técnica some com o dono, e o corpo de técnica autônomo fica, com o mestre; a de criação fica no mundo como objeto; e a maldição domada fica livre, volta a ser maldição, com o mestre, e outro invocador pode domá-la. O invocador morto não traz ninguém de volta.*

> ## A v0.320 deu o §85 às Invocações: a volta da caída custa o dobro
>
> **A resposta do Mizuki foi "B e ainda falta coisas nos tipos, shikigami para técnica tá recebendo nada, ele fica como base então? eu acho uma boa".** *Cair rendia mais que recolher ferida: a caída voltava com metade da vida pelo PE da entrada, o dobro da cura do sistema por PE (peça 11). Com a volta pelo dobro do PE, ela rende de 4,3 a 6,5 de vida por PE, na altura da cura; recolher e pôr de volta continua pela entrada simples. O shikigami de técnica fica como a base dos cinco tipos.*

> ## A v0.319 deu os §§77 a 84 às Invocações: os cinco tipos
>
> **O Mizuki pediu o balanço: "temos a obra, numeros do sistema e seus defeitos, que tal a gente buscar balanceamento em meio a ese termo e ver oq eles ganham entre si?".** *Em oito respostas, os tipos viraram cinco, em dois eixos — origem (técnica, criação, maldição domada) e corpo (shikigami, corpo amaldiçoado). A técnica é a base; o talismã guarda uma carga do descanso longo e entra pela metade; só a domada tem técnica, e ela não sobe com o dono; o corpo amaldiçoado só se cura por técnica ou reparo, é imune a `Envenenado` (que vale no máximo `1,07×`, por ser condição de nicho) e, não autônomo, não tem alma; o de criação tem a vida extra; e os dois corpos têm o modo inativo. O sistema não tem regra de peso, que o talismã vai usar, e isso foi para o item 21 da fila de agora.*

> ## A v0.318 deu o §76 às Invocações: a cura numa entidade
>
> **A resposta do Mizuki foi "A - Sim, menos a corpo amaldiçoado, pq é um corpo... feito de peças né, energia amaldiçoada ja n cura ela".** *A entidade de pé se cura como qualquer corpo; a que está a zero só volta pela entrada, com metade da vida; e o corpo amaldiçoado não se cura por energia amaldiçoada, nem de pé. A Origem `Corpo Amaldiçoado` não tem essa regra escrita, e foi para o fim da fila de agora, no item 20. No lote de desenvolvimento, os casos da `Desligada` e da queda que o §46 deixou pendentes foram trocados de uma vez, e a entrada da caída passou à regra do §73.*

> ## A v0.317 deu o §75 às Invocações: a `Desligada` é um objeto no campo, fora do teto
>
> **A resposta do Mizuki foi "B, ele n ta ativo e pode fazer nada, n faz sentido contar, meio que o caso do mechamaru ele precisa levar esses por ai pra conseguir 'funcionar'".** *Ela ocupa o lugar dela, pode ser carregada, morre de vez pelo limiar do §73, não atua, não recebe ordem e não projeta nada, religa pela entrada com metade da vida e sai no fim do combate; o teto conta só as entidades ativas. No lote de desenvolvimento, o caso do teto que ficava indeterminado passou a aceitar a entrada.*

> ## A v0.316 deu o §74 às Invocações: quem fica `Desligada`
>
> **A resposta do Mizuki foi "Só as domadas no caso de você não ter uma técnica pra tal (como geto), ou as criadas, em ALGUNS casos. Shikigamis são mantidos em talismas, ent da pra recolher, ja corpos amaldiçoados, n, igual o mechamaru, ela desliga apenas".** *Ficam `Desligada` ao cair o corpo amaldiçoado e a maldição domada de quem não tem técnica para recolhê-la; o talismã, a domada com técnica, a lista de ritual e o espaço recolhem.*

> ## A v0.315 deu o §73 às Invocações: a morte definitiva, e a vaga da lista de ritual que se perde
>
> **A resposta do Mizuki foi "A - MAS, no caso do ritual, é como megumi, perdeu da lista e n tem ganho de volta, perdeu uma da lista de 10".** *A entidade morre de vez se um único golpe causar a vida máxima inteira dela ou se o que passa do zero for maior que metade; dano em área nunca destrói. A morta não volta: na lista de ritual a vaga se perde, e no espaço de feitiço a troca se refaz no nível seguinte. A que só caiu volta pela entrada com metade da vida, cheia no descanso longo.*

> ## A v0.314 corrigiu o §71 e deu o §72 às Invocações
>
> **A correção do Mizuki: "mude para nivel do invocador e que ela sobe junto do nivel dele, diferente das outras opções tirando ritual q tbm sobe".** *O espaço de feitiço dá a entidade no nível do invocador, e ela sobe junto, como a da lista de ritual.* **O §72: "A, evita exploit"** — *a reserva recupera como o PE; cheia a cada manifestação, a entrada viraria recarga.*

> ## A v0.313 deu o §71 às Invocações: toda invocação exige uma troca, e o preço fecha
>
> **A resposta do Mizuki foi "invocações precisam de uma troca, ou vc doma, ou vc cria [...] ou vc tem um feitiço de ritual com uma lista de invocações que você vai 'domando' (megumi), OU poderiam custar slot de feitiço, 1 Slot da uma invocação nv2 [...] ai mistura isso com A e perfeito".** *A entidade obtida por espaço de feitiço conhecido começa no nível 2 e sobe com o invocador, se ele quiser; a troca pode ser refeita a cada nível. O preço da parte das entidades é essa troca somada ao que já cobra — manifestação, fragilidade, Bônus e a volta paga —, e a condição de preço do §60 fecha por decisão dele.*

> ## A v0.312 deu o §70 às Invocações: a manifestação dura até o fim da cena, e o fim do combate a encerra
>
> **A resposta do Mizuki foi "Sigamos com A, mas caso de uma cena va para uma cena de combate, ela n é desinvocada, apenas no fim do combate, a n ser que o invocador pague novamente".** *Todo combate que acaba encerra a manifestação, e o relógio da cena só decide fora de combate; num dia de três lutas, o invocador paga uma manifestação por entidade por luta. A conta seguinte mostrou que esse PE paga de um quinto a um terço do dano a mais das entidades, e o preço do resto é a pergunta que espera o Mizuki.*

> ## A v0.311 deu o §69 às Invocações: a especial custa um feitiço da Classe da entidade
>
> **A resposta do Mizuki foi "A proximo".** *A especial custa 3 × a Classe do nível da entidade em PE, como um feitiço da mesma Classe, e se reparte pelo §59; com a entidade no nível do invocador, atacar ou comandar custa o mesmo PE com a mesma Padrão.*

> ## A v0.310 deu o §68 às Invocações: tudo que depende de nível segue o da entidade
>
> **A resposta do Mizuki foi "A e continue".** *A vida, o PE da entrada e a parte do dano, medida na Rotina do nível dela, seguem o nível da entidade, que vai até o do invocador; acerto, Defesa, Teste de Resistência e CD seguem a ficha. Sem isso, uma entidade de nível 2 custaria 1 PE, teria 14 de vida e bateria como a de nível 30.*

> ## A v0.309 deu o §67 às Invocações: cada entrada paga a Classe do nível da entidade
>
> **A resposta do Mizuki foi "A, mas acredito eu que como as invocações vão ter niveis e n necessariamente precisam seguir o nivel da ficha do personagem, os custos deveriam ser parelhos em relação a isso".** *Manifestar, trocar e voltar depois de cair pagam PE, e recolher não; o preço é a Classe do nível da entidade, pelas faixas da tabela de progressão, e não a maior Classe do invocador. As entidades têm nível próprio, e o que mais ele governa é a pergunta seguinte.*

> ## A v0.308 deu o §66 às Invocações: a Defesa da entidade, e o traje no lugar
>
> **A resposta do Mizuki foi "A, esse bônus podendo ser anulado caso ela venha a usar algum tipo de revestimento ou traje, igual personagem mesmo".** *A Defesa fica 10 + Destreza dela + metade da Essência ou da Inteligência do dono; com revestimento ou traje, a proteção dele entra no lugar, como num personagem, e as duas não somam. Sem traje, ela fica mais fácil de acertar que o personagem que investiu no fim da campanha, e isso entra no preço do §60.*

> ## A v0.307 deu o §65 às Invocações: a ficha da entidade é a da peça 15 antiga
>
> **A resposta do Mizuki foi "A e a gente repagina oq parecer necessario, depois a gente segue".** *Os cinco atributos pela peça 2, acerto, Teste de Resistência e CD com a maestria do dono, e Defesa com metade da Essência ou da Inteligência do dono; a Constituição do §61 sai daí.* **O que a conta achou para repaginar foi a Defesa:** *contra a tabela do inimigo de hoje, ela fica até dois pontos abaixo da do personagem que investiu, do nível 15 em diante, porque a ficha antiga é de antes de a proteção andar com o refino.*

> ## A v0.306 deu o §64 às Invocações: uma entidade completa meia Rotina, duas completam dois terços
>
> **A resposta do Mizuki foi "n precisa ser igual, duas invocação VAO ser mais fortes que uma normalmente mesmo, mas n poderia ter uma discrepância tão grande [...] podemos colocar que duas invocações ou mais, completam até 2/3 de uma rotina, enquanto uma completa meia rotina".** *Com o invocador, o conjunto vai até 1,5 Rotina com uma e 1⅔ com duas, razão de 0,9; isso revê o §60 para quem leva duas. Dois terços de Rotina são de 7,4 a 11,1 vezes o que uma Trilha soma a um personagem, e a condição de preço do §60 continua.*

> ## A v0.305 deu o §63 às Invocações: as duas atacam, e uma entidade tem dano parelho com duas
>
> **A resposta do Mizuki foi "eu concordo com A, que seria as duas atacando, mas sim devemos futuramente calcular a questão do dano [...] uma invocação TEM q ter um dano parelho com um invocador de duas por balanceamento, n pode ter uma discrepancia tão grande".** *O limite de base é 2, e na base ele não barra nenhuma básica. Com dano fixo por básica, quem leva uma ficaria em 1,25 Rotina contra 1,5 de quem leva duas; a regra que faz os dois parelhos é a pergunta seguinte.*

> ## A v0.304 deu o §62 às Invocações: sem supor Trilha, cabem 2 entidades em campo
>
> **A pergunta dele achou o furo da recomendação: "essa pergunta cita a questão de 'trilha', então já estamos calculando considerando que ela vai vir existir, né?"** *A conta não dependia de Trilha, mas a recomendação contava com um teto que cresceria por ela, e as Trilhas de invocação que existiram eram do Evocador.* **A resposta: "A - e fica 2 no máximo base mesmo".** *A conta das Invocações não supõe Trilha ou Caminho que ainda não existe, e o teto de base é 2 em campo, do nível 1 ao 30. Com o limite de teste 2, nenhuma básica fica sem dano na base.*

> ## A v0.303 deu o §61 às Invocações: a vida da entidade é de ficha, com 5 no nível 1 e 3 por nível
>
> **A resposta do Mizuki, na terceira rodada, foi "ele ganha 5 no nv1, +3 por nivel, oq faz ele ter mais ou menos que o invocador é a constituição, mas nunca vai ter mais que um invocador com a mesma quantidade de con", e a confirmação, "Continuemos".** *A Constituição da entidade entra nas duas partes da fórmula da peça 1; com a mesma Constituição, ela fica o nível abaixo do Emanador, e com mais Constituição pode passar dele.* **A validação:** *no nível 30, com Constituição 2 a 4, a entidade aguenta de 2,69 a 3,75 golpes do chefe da tabela, e quatro de Constituição 3 somam 2,9 personagens de vida. O Evocador não volta com esta decisão.*

> ## A v0.302 deu o §60 às Invocações: o conjunto rende até uma Rotina e meia por rodada
>
> **A resposta do Mizuki foi "Vamos de B, mas não podemos deixar o invocador tão na frente dos outros personagens em rotina, deve ser levado com cuidado".** *A meia Rotina a mais é de 5 a 8 vezes o que uma Trilha soma (peça 14 §4: 6% a 9% da Rotina).* **Ficou como teto, não piso, e só vale com preço:** *nenhum número da ficha, do teto, do limite ou do custo das especiais se aprova sem mostrar o que o invocador paga por ela. A peça 6 §4 do principal, que diz uma Rotina, fica como está até a integração.*

> ## A v0.301 fechou o §59: 1 + um terço da Essência por nível, e o custo meio a meio
>
> **A resposta do Mizuki foi "A e continuamos, e pode ficar o 1 + um terço de PE ali, ficou bom".** *A reserva é, por nível da criatura, 1 + ⅓ da Essência, que a validação aprovou em toda Essência; a parte do invocador é metade do custo, com o ímpar para ele.* **O lote 3 começa pela meta do conjunto:** *a peça 6 §4 do principal diz "Você e todas as suas invocações somados entregam uma Rotina", escrita para a arquitetura anterior, e a pergunta é se ela vale para o subsistema novo.*

> ## A v0.300 deu o §59 às Invocações: a energia das especiais
>
> **A resposta do Mizuki foi "Seria B, MAS...":** *a entidade com técnica pode ter reserva própria; mesmo com ela, a especial consome também energia do invocador, com a parte dele igual ou menor; a reserva é, por nível da criatura, 1 + uma fração da Essência; esgotada, tudo sai do invocador.* **A fração e a parte ele deixou para a validação:** *com metade da Essência, a reserva reprova a partir da Essência 5, e com um terço passa em toda Essência; a parte do invocador só se separa quando o custo da especial existir.*

> ## A v0.299 deu o §58 às Invocações: as entidades manifestadas antes da luta começam em campo
>
> **A resposta do Mizuki foi "A - já foi até discutido antes, pode continuar".** *Tinha sido discutido na peça 15 da arquitetura anterior, Q4, com a cena do Megumi com o lobo fora de combate: fora de combate a ação não custa nada.* **A pergunta não devia ter sido feita sem citar isso;** *a arquitetura anterior não volta como regra, mas a intenção dele registrada lá vale. A pergunta seguinte é a da energia das especiais, a pauta que ele deixou na decisão 8 do registro da r5.*

> ## A v0.298 deu o §57 às Invocações: recolher sem pôr outra no lugar também custa a Ação Bônus
>
> **A resposta do Mizuki foi "A".** *Entrar, trocar e recolher custam a mesma Bônus — uma regra só para dois mestres —, e como a troca custa o mesmo, quem tem reserva saudável troca.* **A pergunta seguinte é se a entidade pode começar a luta em campo:** *pela conta dela, começando da reserva, a primeira rodada não tem ataque das entidades.*

> ## A v0.297 deu o §56 às Invocações: a entrada e a troca custam a Ação Bônus
>
> **A resposta do Mizuki foi "B mesmo".** *Pela conta da pergunta, a Bônus enche o teto de teste em 2 turnos, dentro da luta de 3 rodadas, e deixa a troca sair junto com a especial, uma por turno, o que segura o revezamento de entidades feridas.* **A primeira intenção de quem entra sem trocar continua sendo outra Bônus.** *A pergunta seguinte é com que ação se recolhe sem pôr outra no lugar.*

> ## A v0.296 deu o §55 às Invocações: a entidade aparece colada no invocador, e na troca no lugar de quem sai
>
> **A resposta do Mizuki foi "C - talvez coisas da invocação ou habilidades de trilhas/classes permitir a distancia, tecnica e afins, mas por base C".** *Na troca, a nova assume o posto da que sai, e a posição do conjunto não muda por causa da troca.* **Distância maior pode vir da própria invocação, de Trilha, de Caminho ou de técnica, como concessão.** *A pergunta seguinte é com que ação a entidade entra.*

> ## A v0.295 deu o §54 às Invocações: a entidade só é recolhida no turno do invocador
>
> **A resposta do Mizuki foi "A".** *No turno do inimigo, a entidade fica e aguenta o golpe; recolher antes de um golpe mortal teria virado uso fixo da Reação antes de a queda ter consequência duradoura.* **A queda do §46 e a morte do §48 não são recolhimento.** *A pergunta seguinte é onde a entidade aparece ao entrar.*

> ## A v0.294 deu o §53 às Invocações: a entidade só entra em campo no turno do invocador
>
> **A resposta do Mizuki foi "A, definitivamente / E futuramente podemos fazer os caminhos mexerem nisso".** *Fora do turno, nenhuma entidade entra, e a vaga aberta no turno do inimigo fica vazia até o turno dele; a entrada é ato do invocador, e a troca segue a mesma regra.* **A conta da pergunta mostrou que entrar fora do turno daria a primeira básica na mesma virada, com menos exposição**, *e deixaria a entrada no turno quase sem motivo. Recolher fora do turno é a pergunta seguinte.*

> ## A v0.293 deu o §52 às Invocações: o que conta no limite de ataques, e a condição Média ou Pesada só por especial
>
> **No turno do invocador, conta só a atuação da entidade que causa dano.** *Ficam fora a especial comandada ("seria no máximo 3 ataques"), a condição sem dano e as ações comuns sem dano — `Agarrar`, `Derrubar`, `Provocar` ("todas as ações mais comuns, n necessitariam realmente de contar pro limite") —, e o que acontece fora do turno do invocador ("Não conta").* **A dúvida dele no ponto da condição achou um furo:** *o `Provocar` é exatamente uma condição por TR sem dano, e a recomendação o punha no limite.* **A resposta fechou com uma regra dele:** *"Condições médias e pesadas PRECISAM ser uma ação especial, que tal? ai da pra gente seguir na B".* O número do limite continua pendente.

> ## A v0.292 deu o §51 às Invocações: uma Bônus redireciona todas as entidades, cada uma com a sua intenção
>
> **A resposta do Mizuki foi "da pra mandar em TODAS, mas n precisa ser a mesma ordem pra todas, contanto que seja básica, claro".** *Revê duas frases da r5 §4 — a mesma intenção para até X destinatárias, e um comando por intenção diferente.* **O motivo foi um limite que não estava registrado:** *"a gente vai impor o limite de quantas podem atacar no mesmo turno". A ideia estava na pesquisa (Capacidade de Comando) e na base de 23/09, e o que o limite conta é a pergunta seguinte.*

> ## A v0.291 deu o §50 às Invocações: uma básica por corpo por ciclo
>
> **A resposta do Mizuki foi "A - Caminhos/Trilhas a gente talvez aumente, mas mantenha um".** *A quantidade não cresce com o nível: a entidade cresce pela ficha, e o conjunto pelo teto do §49. Um aumento vindo de Caminho ou Trilha ficou pendente.* **A pergunta seguinte é o X da r5 §4**, *quantas entidades uma Bônus de redirecionamento alcança.*

> ## A v0.290 deu o §49 às Invocações: cada entidade tem a própria ficha, e o limite é um teto de corpos
>
> **A resposta do Mizuki foi a B, com condição: "Se achar que é sim possível a gente fazer a B, vamos por ela, mas teremos de tomar cuidado".** *Ele achou o buraco da capacidade repartida — "uma invocação de 200 de vida sobrevive bem no final do jogo, mas 4 de 50 não" —, e a r5 já segura a parte perigosa da B: a especial ativa custa a Padrão do invocador, e a coletiva é uma.* **A pergunta seguinte é quantas básicas cada corpo tem**, *porque pelo §49 elas multiplicam com o teto.*

> ## A v0.289 deu o §48 às Invocações: quando o invocador morre, as entidades saem de campo
>
> **A resposta do Mizuki foi "e a escolha é A".** *No estágio 4 de dano de alma, ou na morte que a narrativa decidir, as entidades saem na hora pelas regras de saída do §46, e a que não recolhe fica `Desligada`; o destino duradouro delas continua pendente, candidato a depender do vínculo.* **Com ele, as duas perguntas de sustentação do plano fecharam**, *e as outras do lote 2 o próprio §46 mandou esperar o construtor.*

> ## A v0.288 deu o §47 às Invocações: o invocador apagado não derruba a sustentação
>
> **A resposta do Mizuki foi "Continua A".** *A entidade segue a rotina, o Movimento e as respostas pela intenção que tinha, e cumpre as ordens recebidas antes, sem comando novo; a morte do invocador continua pendente, e é a pergunta seguinte.* **O §47 mora em `invocacoes/DECISOES-A-PARTIR-DO-46.md`**, *e o lote de desenvolvimento que o preparou — a candidata na revisão 7, a bancada e os testes — fica no HD, fora do repositório.* **A mesma sessão pôs o Git em dia:** as v0.277 a v0.287 subiram num commit só.

> ## A v0.284 fechou quatro divergências da auditoria da fase 2, e nenhum preço mudou
>
> **O capanga da régua de condição passou a ser o do manual, `27`, e nenhum dos treze níveis de condição se moveu** *— a peça 19 dizia `73`, "do manual", e o manual nunca publicou esse número.* **O `Emboscador` não sobe de `Grande` e o `Reforço` só se paga com mais de um inimigo, agora na peça 26**; *o `Baluarte` saiu dessa frase, porque na grade ele serve sozinho.* *A fase 0 e a tabela de trabalho do bestiário ganharam nota do que mudou.* **O item 19 espera duas respostas do Mizuki:** *a resistência a um tipo só, com a pesquisa de sete sistemas feita, e a leitura da resposta sobre o Evocador.* *O porquê está na entrada da v0.284 do `CHANGELOG`.*

> ## A v0.283 fechou o ritual para o `Manejo` e a `Kata`, e a caixa da Extensão parou de dizer o que continua
>
> **Quem monta a técnica em `Manejo` ou em `Kata` não compra a aptidão de Ritual** *— "N da pra fazer ritual em estilo nem tecnica marcial", e "estilo" é o `Manejo`. Desde a v0.276 os capítulos 42 e 43 mandam ler as duas onde qualquer capítulo escreve feitiço, e sem a linha o ritual abria para as duas rotas pela letra.* **Na caixa da Extensão saiu "A Técnica Marcial e as aptidões continuam"** *— "se n ta citado, n precisa ficar deixando claro"; a reversa e as aptidões seguem liberadas.* **Nenhum número mudou.** *O porquê está na entrada da v0.283 do `CHANGELOG`.*

> ## A v0.282 refez os inimigos: a escada virou a grade da fase 2 do bestiário
>
> **A categoria é a dificuldade da luta, e o N é para quantas pessoas do nível ela é feita, de `×1` a `×6`** *— "os inimigos n deveriam passar da necessidade de 6 players". A vida é `rodadas × N × a saída de um personagem`, o golpe é `a pressão × o golpe-base`, e o inimigo age N vezes; as rodadas são as dele, `2 · 2,5 · 3 · 4 · 5`, e a pesquisa de quatro sistemas e de `15.283` combates de 5e confirmou a ordem e o tamanho.* **O que ele carrega — `Intervenção`, `Recarga`, resistência, Expansão, cura de Reação — se paga na vida, e o golpe não muda** *— "um dragão que tem baforada n tem dano reduzido em comparação a um inimigo que tenha so ataques do mesmo nd".* **O `Capanga ×N` é um esquadrão de `2N` corpos com meio golpe; no `×1` e no `×2` a condição que tira ação dá um TR no começo do turno; e o desvio da tabela por nível se paga na vida.** *A peça 26 e o `conferir-bestiario.py` foram reescritos — a peça de antes está no arquivo morto —, o manual foi à v7.40, e o gerador de inimigo, o livro de inimigos e as seis prontas foram refeitos na grade. As decisões e as contas estão em `bestiario/09-fase-2/`. Sobram o Sukuna na grade e as onze divergências da auditoria, itens 18 e 19 da fila.*

> ## A v0.281 fechou o item 12: a ação virou `Ação Atacar`, e o grupo de armas virou categoria
>
> **A leitura dos outros três Caminhos, sem conta ("2 - B"), levou quatro perguntas, e as respostas entraram no livro.** *`Ação de Atacar` virou `Ação Atacar` no livro, nas peças e nos validadores — "tem diferença entre 'Atacar' e a 'Ação Atacar', que nem dnd", e a tabela de ações do capítulo 11 já chamava a ação de `Atacar`; a Estocada e o Condutor Armado passaram a escrever categoria, com `(Grupo das Armas)` onde a escolha é feita; o `Esquivar` passou a dar vantagem no TR Físico, porque o TR de Destreza não existe; e a terceira pendência da v0.4, a do nível 15 do Emanador, fechou sem frase nova — "evita da galera ir até a pagina do construtor".* **O item 12 fechou sem medir o resto** *— "n precisa tanto" —, e o índice de entregas continua o da coleção anterior: essa sobra virou o item 17 da fila.* **Segue o item 8, o máximo dos inimigos.**

> ## A v0.280 fechou duas pendências da v0.4, e o `Combatente Amaldiçoado` fica como está
>
> **O `Oportunista` vale para um ataque do feitiço ou para o primeiro TR de uma criatura, até o fim do seu próximo turno** *— "2 - A".* **No `Contra a Parede`, a metade da maior Classe arredonda para baixo, e o feitiço se paga normalmente** *— "Ele n custa PE […] o custo desse 'feitiço que acompanha', é o custo do feitiço mesmo".* **O piloto do Bastião ficou de registro, em `sistema/01-pesquisa/medicao-v04/`, e o `Combatente Amaldiçoado` não muda** *— "3 - A": "você está calculando cogitando muitas coisas, n precisa tanto".* *As duas frases estão no livro e na tabela `Pendências da v0.4 decididas` da peça 6 §2, que a 10.5 do `conferir-catalogo.py` compara com o quadro de cada entrega.* **E o feitiço vem depois do primeiro golpe, e não pode ser crítico** *— "Depois do primeiro golpe e n crita".* **O item 12 segue como leitura dos outros três Caminhos, sem conta** *— "2 - B": regra ambígua e texto que brigue com o resto do sistema, trazidos como pergunta.*

> ## A v0.279 declarou três exceções do Bastião à cerca da peça 5
>
> **`Ainda de Pé` (cura), `Duro de Matar` e `Casca Grossa` (desconto de dano) furam a cerca, e ficam como exceção declarada** *— "1 - A", como o Socorrista na v0.271, que só estava no livro e agora está na peça 5 também.* **A sub-checagem 10.4 do `conferir-catalogo.py` varre o capítulo 8 e cobra que toda cura e todo desconto esteja declarado.** *Achado lendo o Bastião para a medição da coleção v0.4 (item 12), que segue com o piloto do Bastião — "2 - A".*

> ## A v0.278 fechou o item 11 sem mudar nada
>
> **O teto de atributo fica em `6`, para todo mundo, e a rota `Corpo` não ganha incentivo novo** *— resposta do Mizuki, "A", sobre o parecer da v0.264: as duas vertentes não mudam a luta entre personagens, e o ganho delas é só descontar a Defesa do inimigo, por oito peças.* **Segue o item 12, medir as fatias da coleção v0.4.**

> ## A v0.277 fez do `Calado` uma condição de nicho, e o nível dele continua `Média`
>
> **Ele só cala o que precisa de voz**, *no personagem e no inimigo, e o bloco do inimigo não ganha campo: quem decide é o texto da habilidade — "cala apenas se o inimigo tiver algum selo que necessite de voz ou habilidades do tipo, é uma condição de nicho".* **O nível fica `Média` pela conta:** *contra quem usa voz ele tira uma ação, `2,32×` em `Média`, e em `Leve` daria `4,06×`, acima do filtro de `3,00×`.* **E o inimigo sem voz não paga o `1,20` da imunidade:** *o `Calado` só não tem o que calar nele.* *O item 16 da fila fechou.*

> ## A v0.276 pôs a troca de nome no livro inteiro, e o `Calado` alcançou as cópias da v0.176
>
> **O `Manejo`, a `Kata`, a `Ruptura`, o `Ōgi` e o `Auge` valem em todo capítulo** *— "leia também": a regra vale para o seu e para o de qualquer um, porque o `Quebranto`, o `Anátema` e a `Leitura` falam do feitiço dos outros.* **O Restringido ganhou a exceção:** *o que ele não conjura é energia, e a `Kata` é o corpo.* **O `Calado` corta a `Kata` só se ela precisar de voz ou de ferramenta que precise de som**, *e as cinco cópias dele passaram a dizer "Selo que envolva voz", a redação que o Mizuki escreveu no livro na v0.176 e que não tinha chegado à peça 19, ao glossário nem ao manual.* **O manual do Fundamento foi à v7.39.** *O preço do `Calado` nessa redação não foi medido: item 16 da fila.*

> ## A v0.275 deu o §46 às Invocações: a zero PV, a invocação sai de campo
>
> **Era o ponto em que o subsistema tinha parado.** *Ela para de atuar e sai pelas regras de saída que a r5 já tinha — a ordem pendente e a preparação se encerram, sem devolução —, a queda não é substituição, e a que o vínculo não deixa recolher fica no lugar, `Desligada`.* **Morte definitiva, volta, cura e preço continuam pendentes.** *A decisão mora em `invocacoes/DECISOES-A-PARTIR-DO-46.md`, porque o pacote em `invocacoes/03-INVOCACOES/` fica como chegou. As Invocações seguem fora do livro.*

> ## A v0.274 comparou as quatro anti-domínio, e a revisão delas fechou
>
> **Nenhuma ficou dominada** *— em todo perfil, nível e cena medidos, nenhuma deixa passar sempre no máximo o que outra deixa, custando no máximo o mesmo PE e chegando antes ou junto.* **A Cesta é a mais barata e a que mais segura sozinha com Essência `4` ou mais; o Simples não cai por golpe e cobre o grupo; a Pétala, com Essência maior que a do dono, não deixa passar nada; a Extensão nunca deixa, e custa de `1,4` a `7,2` vezes o PE das outras.** *A tabela está na peça 11 §6.5, em "As quatro lado a lado".*
>
> **Quando a Cesta cai, ou o Simples cai pelo voto, o Acerto que te alcança na hora é a mais** *— "chegando no começo do turno do inimigo vc vai receber novamente".* **O bestiário passou a arredondar para cima o `1,5 ×` da Extensão** *(`125%` e `34%` no nível 30, `300%` e `76%` no 2), e três sobras da v0.273 foram consertadas: a tabela do dia da Extensão e o que quem conjura perde passaram a começar no gate, o nível 18.* **Segue a Parte C, as Invocações no zero PV.** *O porquê está na entrada da v0.274 do `CHANGELOG`.*

> ## A v0.273 reescreveu a Extensão de Domínio, e a rodada 3 dos anti-domínio fechou
>
> **A terceira das três que faltavam:** *quem usa a Extensão fica imune a tudo o que a Expansão faz, em qualquer degrau — completa, incompleta ou sem barreiras —; a técnica que encosta nela é anulada até `1/3 do refino + 1`, e acima disso você leva `3/4`; ela não cai por golpe; erguer custa a maior Classe, toda vez; o gate foi para o nível 18, com requisito de história; e o Corpo Amaldiçoado não compra, porque nunca tem técnica inata e a Extensão é um domínio vazio.* **Enquanto ela está de pé você não usa feitiço nem `Manejo`**, *e a Técnica Marcial, a reversa e as aptidões continuam — as duas últimas "por enquanto".* **Falta a comparação das quatro.** *O porquê está na entrada da v0.273 do `CHANGELOG`.*

> ## A v0.272 reescreveu a Pétala, e erguer passou a custar a maior Classe
>
> **Rodada 3 do item 6, a segunda das três que faltavam:** *a Pétala rebate o que toca, energia contra energia, e o dano do Acerto sai da Essência de quem a usa contra a do dono da Expansão — maior, não fere; igual, leva `1/4`; menor, leva metade —; o que a Expansão traz por contato e não é dano ela anula sempre; cai pelo teste do `Carregar` a cada golpe, de qualquer um, sem a queda na hora; e com arma corpo a corpo empunhada contra-ataca quem a acertou, por `3` PE.* **Erguer a Cesta, o Simples ou a Pétala custa a maior Classe em PE, toda vez**, *e a Pétala passou a `1` PE por rodada. A `Extensão de Domínio` é a próxima, com as respostas do Mizuki já dadas. O porquê está na entrada da v0.272 do `CHANGELOG`.*

> ## A v0.271 fechou as decisões que a v0.270 deixou
>
> **A perícia fixa do Bastião passou a `Provocar`**, *como a v0.4 escreve, e a Kaori trocou `Intimidação` por ela.* **A frase dos Limites voltou, com o Socorrista como exceção declarada**, *e ninguém cura outra pessoa com Energia Reversa — a `Sutura` saiu e não tem sucessora.* **Três nomes da v0.4 mudaram no livro:** *`Eco` virou `Eco Amaldiçoado`, o `Impulso` do Catalisador virou `Impulso Energético` e a `Sobrecarga` virou `Sobre Carregar Energia`; o resto das colisões da triagem foi aprovado.* *Os renomes moram numa tabela da peça 6 §2, e a coleção em `caminhos/` fica como chegou. O porquê está na entrada da v0.271 do `CHANGELOG`.*

> ## A v0.270 pôs os Caminhos da coleção v0.4 no livro, e tirou o Evocador e as Invocações da edição jogável
>
> **Bastião, Vanguarda, Emanador e Guia, com as doze Trilhas e as três rotas do Batedor, entraram no capítulo 8 exatamente como a coleção v0.4 escreve**, *e ela passou a ser a dona do texto deles, em `caminhos/`. A base dos Caminhos não mudou; o degrau do nível 23 é novo nos quatro.* **O equilíbrio da v0.4 não foi medido** *— o Mizuki mandou implementar sem medir e pôr a medição na fila, e os `DESENHO-*.md` e a peça 17 ficaram como o registro com preço da coleção anterior.* **O Evocador e as Invocações saíram do livro até o subsistema fechar**, *com as fontes antigas em `invocacoes/museu/` e o desenvolvimento em `invocacoes/`. No livro de duas colunas, o capítulo 8 sai em coluna única. O porquê, as colisões de nome e os conflitos para ele decidir estão na entrada da v0.270 do `CHANGELOG`.*

> ## A v0.269 trocou a regra de queda do Domínio Simples, e a Cesta Oca passou ao teste do Carregar
>
> **Terceira volta do Mizuki sobre a conta do Simples:** *ele aguenta `3` rodadas de Expansão, `4` se a Essência de quem segura for maior que a do dono e `2` se for menor; cada Acerto que ele segura gasta uma, a começar pelo de abrir, e pede o teste do `Carregar`, em que a falha tira uma rodada, nunca abaixo de metade da Essência. Erguer de novo na mesma Expansão não tem recarga, mas custa a Ação Padrão e aguenta metade.* **O refino ficou só no raio e no gate.** *Na Cesta, o teste dos golpes passou de Vigor para o do `Carregar`. O voto, o gate, os `2` PE, a queda na hora e o que ele anula continuam os da v0.268. O porquê está na entrada da v0.269 do `CHANGELOG`.*

> ## A v0.268 reescreveu o Domínio Simples, e a Cesta Oca perdeu a recarga
>
> **Rodada 3 do item 6, a primeira das três que faltavam:** *ele cai por um relógio contra a Expansão — metade da Essência (mínimo 1) mais uma rodada, menos uma por ponto de refino que o dono dela tem acima do seu, **fórmula trocada na v0.269** —, golpe no dono não o derruba, e quando ele cai a Expansão alcança na hora quem ele protegia. Os pés viraram o voto do iniciante (refino 4; com refino 5 ele anda com você), o PE são `2` fixos, e lá dentro a Expansão não alcança ninguém.* **Contra refino 10 nenhum Simples segura até o fim**, *que é o Gojo perdendo o dele para o Sukuna.* *A Cesta ganhou a mesma queda na hora e perdeu a recarga. O porquê está na entrada da v0.268 do `CHANGELOG`.*

> ## A v0.267 reescreveu a Cesta Oca, e ela virou a base da revisão dos anti-domínio
>
> **Rodada 2 do item 6, com as decisões do Mizuki em cima da conta:** *o preço deixou de ser o turno inteiro e passou a ser as duas mãos presas no símbolo (Desarmado vale); ela levanta com Reação quando uma Expansão abre ou Ação Bônus no turno; e ela **cai pelos golpes em você** — Vigor contra a CD de quem te feriu, falhas acumulando até metade da Essência, como na corrida. A Expansão não a quebra enquanto você segura; soltando, cada Acerto letal conta uma falha; depois de cair, recarga de metade da Essência em rodadas.* **Ela segura quase tudo cedo e cede tarde, e deixou de ser inquebrável.** *As outras três passam por revisão com ela de base. O porquê está na entrada da v0.267 do `CHANGELOG`.*

> ## A v0.266 corrigiu na peça 11 o que ela atribuía à obra, e nenhuma regra se moveu
>
> **Rodada 1 da revisão dos anti-domínio, só texto:** *os "quatro preços" deixaram de "vir da obra" (só o da `Extensão de Domínio` vem), o raio de 2,21 m é o da Miwa, o Kusakabe alarga o raio na obra e a aptidão não faz isso de propósito, o Gojo parou de usar a `Pétala` depois de pegar o domínio, e ela "não para o que não é Acerto" em vez de "ataque físico" — nas peças 11 e 25.* **As regras questionadas ficam para a rodada 2, que começa pela `Cesta Oca`.** *O porquê está na entrada da v0.266 do `CHANGELOG`.*

> ## A v0.265 conferiu a pesquisa dos anti-domínio, e nenhum número do sistema se moveu
>
> **A rodada foi atrás de drawback e de como cada uma cai, e depois passou o `H` por uma verificação cega** — *`3.254` linhas novas em `01-pesquisa/anti-dominios/` (`I` a `N`), `34` páginas do mangá lidas quadro a quadro, `118` afirmações conferidas contra a fonte.* **Nenhuma das quatro tem relógio próprio: todas caem por fora.** **E duas coisas da v0.264 caíram:** *`中和` como subtração só tem cena na **Extensão** — a Cesta e o Simples protegem inteiro até cair —, e "a Extensão dilui o Acerto" perdeu a base: o Fanbook diz que ela neutraliza, e não há cena.* **As divergências com a peça 11 passaram de oito para catorze** — *seis frases da peça atribuem à obra o que ela desmente.* *O porquê está na entrada da v0.265 do `CHANGELOG`.* **⚠ Tudo isso está no branch `claude/jjk-anti-dominios-research-59hjly`, fora do `main`.**

> ## A v0.264 foi a campo nos quatro anti-domínio, e nenhum número do sistema se moveu
>
> **`6.023` linhas de nota de campo entraram em `01-pesquisa/anti-dominios/`**, *e a peça 11 ficou exatamente como estava.* **A premissa da revisão estava metade errada:** *a casca não é a variável — é a diferença de saída (`出力`) entre quem defende e quem abriu.* **O diálogo do cap. 227 virou fonte primária** e fecha quatro coisas: *o gatilho da `Pétala` é **contato**, o eixo é **simples contra complexo**, o `出力` é a variável, e a função dela é **comprar tempo**.* **E `中和` é termo químico — subtração com piso, não interruptor.** *As **oito** divergências entre a peça 11 e a fonte estão registradas na seção do item 6 da fila, e nenhuma foi aplicada: as quatro primeiras são conserto de fato, as quatro últimas mexem em preço.* *O porquê de cada uma está na entrada da v0.264 do `CHANGELOG`.*
>
> ⚠ **Corrigido na v0.265:** *o `中和` como subtração só tem cena na `Extensão`, e as oito divergências são catorze — ver o bloco de cima.*

> ## A v0.263 fechou duas das três pontas da v0.262, e aplicou a v0.216 em quinze lugares
>
> **O treino tem dois graus desde a v0.212** — *a especialização da peça 11 §3 —, e a peça 4 dizia "binário por ora".* **O ofício é da Origem desde a v0.216, e a peça 7, a Kaori e três capítulos do livro diziam que era do Caminho** — *o capítulo 8 dava mais dois em cada Caminho.* **A faixa de perícia treinada saiu do validador e passou a morar na peça 7 §7, julgando só a rota de base**, *e a Aura ganhou linha na `Base por Classe` com o raio da Explosão (manual v7.38).* **A ponta 3, a ficha, espera o commit das rodadas pendentes de lá** — *item 9 da fila.* *O porquê de cada uma está na entrada da v0.263 do `CHANGELOG`.*

> ## 🆕 A v0.222 consertou duas coisas que a v0.221 deixou passar, e as duas são do §6.5 da peça 26
>
> **1 · O orçamento de uma ação sai do golpe IMPRESSO.** *A tabela e a checagem `9.1` aplicavam o `0,923` DEPOIS da média do golpe cru; o texto da própria seção sempre disse "o golpe entra aqui como a ficha imprime ele".* **`9` das `35` células andaram `0,1`, e a maior ação do sistema foi de `15,0` para `14,9` pontos.** *Os `62%` do teto do jogador não mudaram.*
>
> **2 · O golpe saiu do cabeçalho do bloco** — *ele mora no ataque, em `Ações`, com o alcance junto.* **E `Ações Múltiplas` passou a contar na linha de seis entradas nomeadas.** *Como se nomeia o ataque foi medido em sete sistemas: é a arma ou a parte do corpo, e **nenhum** sistema põe "Ataque de" no nome.*

**A v0.221 trocou a escada de inimigo inteira, e ela veio medida de fora.** *O projeto do Bestiário, fora deste repositório, refez a máquina de montar inimigo entre 08/09 e 10/09 e mandou a conta pronta; esta versão é a execução, em oito commits.*

> **A escada viva é `Capanga` · `Ameaça` · `Desastre` · `Catástrofe` · `Calamidade`**, *com as ações declaradas — `1` · `1` · `3` · `5` · `6` — e o `Capanga` num esquadrão de oito, com a vida saindo do dano do grupo.* **`Ronda` virou `Ameaça` e `Alcateia` virou `Desastre`, com os mesmos números; a `Calamidade` de seis virou `Catástrofe`, a de oito entrou por cima, e a `Dupla` morreu.**
>
> **O degrau morreu como moeda:** *resistência, imunidade e Expansão multiplicam o fator da categoria, e o câmbio de um chefe foi de quatro capangas para oito.* **A tabela `Inimigos` do manual passou a publicar o capanga da escada.**
>
> **E o gerador de inimigo imprime as seis prontas no molde de bloco do 5e**, *com o tamanho e a área natural levados para a peça 26 junto com validador.* **A peça 15 passou a medir a morte do shikigami contra a escada viva**, *e o Mizuki decidiu registrar a régua frouxa: nenhum golpe único destrói o corpo forte.*
>
> **⚠ Os blocos das versões abaixo, da v0.198 à v0.206, falam a escada morta.** *Eles ficam como estavam, porque são o registro de cada versão; as três linhas que descreviam uma regra dela como viva estão marcadas.* **A peça 26 §4 é a dona da escada de hoje.**

**A v0.207 deu ao capítulo de Invocações o passo a passo que o Fundamento tem para feitiço.** *O capítulo publicava a máquina inteira e nove montagens prontas, e o leitor via o resultado sem ver a conta — `12` pontos, cabe no nível 6, e de onde vem o `12` nenhuma linha mostrava.*

> ***Um exemplo e não três, e quem decidiu foi a conta.*** *Rodando a mesma invocação nas três Trilhas, **cinco de doze linhas da ficha mudam e sete não** — e o bolso impede que seja a mesma invocação nas três, porque o `Servo` tem `18` pontos no nível 6 contra `12` das outras duas.* **Seriam três bichos, e não três ângulos do mesmo.** *Em tamanho, um exemplo cresce o capítulo em `11%` e três em `32%`.*
>
> **O exemplo é a `Carranca`** — `Servo`, `maldição domada`, nível 6, `Graúdo` + `Chamariz` + `Escalada` gastando os `18` exatos. *As três entradas não apareciam em montagem publicada nenhuma, e o bolso de `18` é a única conta do capítulo que não está em célula nenhuma: a tabela do `Servo` publica os níveis 2, 10, 18 e 30.*
>
> **⚠ E o exemplo destampou uma pergunta que o capítulo nunca teve de responder:** *a régua da `Carranca` é `165` e metade disso é `82,5`.* **`65%` das `812` combinações de tipo, nível e Constituição dão régua ímpar**, e o único exemplo que o capítulo tinha caía num caso redondo. ***A conta fechou sem regra nova:*** *dano é inteiro, então passar de `82,5` e passar de `82` matam a partir do mesmo `83`, e arredondar para cima a peça 1 §5.4 já proíbe.*
>
> **A montagem NÃO foi copiada para a peça 15**, e isso é decisão — copiar criaria a segunda fonte que a lição nº 9 existe para evitar. *O preço é que cada número dela nasce dentro da sub-checagem `17.1`, de documento dono, com a derivação do bolso do `Servo` provada contra os quatro níveis publicados antes de ser aplicada ao nível 6.* **Dez perturbações acendem e dois contra-testes de prosa ficam verdes.**
>
> ~~**⚠⚠ E o glossário aponta para o capítulo errado desde a v0.170.** *Aquela versão pôs `Sem Técnica` como capítulo 11 e o livro foi de 17 para 18; a coluna `Cap.` nunca foi bumpada.* **Trinta e uma linhas, todas do capítulo 11 para cima, todas erradas por exatamente um** — as propriedades de arma mandam para `Bênçãos e Lapidação` e os `Traço` de invocação mandam para `Ferramenta Amaldiçoada`. *Registrado e **não** consertado: a numeração tem dono — a lista `CHAPTERS` do `build.py` — e nenhum validador compara a coluna com ela.*~~ ***FECHADO na v0.210***, *com a checagem `10.8` do `conferir-repositorio.py` comparando a coluna `Cap.` com a lista `CHAPTERS`.*

**A v0.206 abriu a coluna de capanga da `Classe 1`, e para abrir foi preciso consertar a linha antes — o conserto é de UM ponto de vida.** *A seção `Inimigos` do manual escreve a própria regra: o chefe tem cerca de três vezes o dano de rodada do grupo em vida, "e é isso que faz a luta contra ele durar três rodadas".* **Seis das sete linhas cumprem isso exato; a do nível 2 publicava `115` contra os `114` que a regra pede.**

> **⚠⚠ E um ponto de vida custava uma rodada inteira do chefe.** *Com `115` a luta dura `3,03` rodadas, rodada é inteira na mesa, e o chefe age quatro vezes: o encontro cobrava `89%` da vida do grupo contra os `68%` das outras seis* — **no nível em que o personagem tem `19` de vida.** *A faixa virou `105 a 123`, e o manual foi para a `v7.25`.*
>
> ***Decisão do Mizuki: a coluna abre***, com o capanga em `28` de vida e `6` de dano. *Quatro deles cobram `71%` contra os `67%` do chefe sozinho, o corpo dura `0,74` rodada sob o foco do grupo contra `0,75` no nível 30, e as quatro sub-categorias saem `67 · 58 · 57 · 64%` contra `68 · 58 · 56 · 62%`.* **A razão que fechou a coluna na v0.199 media um corpo de `17` de vida que saiu com a tabela da v0.201.**
>
> **⚠⚠ E o bloco impresso estava com TRÊS números da v0.199** — *a sub-categoria cobrando `28 · 30 · 33 · 35%` contra os `68 · 58 · 56 · 62%` da peça, uma nota dizendo que repartir o encontro o encarece quando a v0.201 mediu o contrário, e quatro `Ronda` em `0,62 ×` contra `0,75 ×` a `0,77 ×`.* **Os três moravam inline no `make.js`, o único arquivo do subsistema que nenhuma checagem lia.**
>
> **⚠ E o bloco `7` do `conferir-ficha.py` pulava quatro das sete faixas em silêncio**, porque o §4.1 da peça publica três níveis. *Hoje ele diz quantas comparou, e uma segunda guarda alcança as sete pela derivação do capanga.*
>
> **⚠ A guarda nova nasceu larga demais, e quem achou foi o próprio arnês:** *a linha do §7.1 que **descreve** a perturbação contém a frase que a guarda procura, e ela leu a descrição como declaração.* **Hoje ela procura fora de tabela.**

**A v0.205 fechou o `§6.5`, e ele não virou catálogo de traços — virou o câmbio do catálogo do JOGADOR para a ficha do inimigo.** ***Decisão do Mizuki:*** *"dá pra deixar ser que nem do sistema pra player, mas rebalancear."*

> **Três portas, e nenhuma inventa moeda.** *A técnica paga no **orçamento de feitiço** de uma ação — o golpe dividido por `4,5`, com piso na `Classe 1` do manual —, a aptidão paga na **cota de dano por rodada** pelo câmbio de `1` PE por rodada = `5,14` de dano, e o que dá vida efetiva paga em **degrau de categoria**, que o §6.3 já vendia.*
>
> **O rebalanceamento é de quatro para um:** *a mesma aptidão come `16%` da cota de uma `Alcateia` e `65%` da de uma `Ronda`, e no nível 2 a `Extensão de Domínio` custa `193%` de uma `Ronda`* — **então uma maldição daquele nível que a carregue tem de ser pelo menos uma `Dupla`.** ***⚠ Escada morta na v0.221 — a cota de hoje está na peça 26 §6.5.***
>
> **⚠ E contar por LUTA em vez de por rodada ligada estava errado**, porque as quatro anti-domínio valem zero contra grupo que não abre domínio. *O jogador liga quando precisa; o inimigo cobrado por luta pagaria pelas rodadas em que ela não fez nada.*
>
> **A condição do inimigo se resolveu sem moeda nova**, e a razão é dele: *"se for seguir próximo da criação de ficha normal, um feitiço em área vai ter menos dados para poder comprar condição."* **O Fundamento já cobra por área e por condição em ponto de feitiço** — *e a `Dupla` do nível 30 monta `24,2` pontos numa ação, contra o teto de `24` do jogador naquele nível.*
>
> **A ação fora do turno saiu de graça com número:** *`0,94 ×` a `1,07 ×` sobre `81` durações de luta, média `1,01 ×`, e pior que ficar no turno em `29` dos `81` pontos.* **O `Guia do Mestre` manda contar o dano de fora do turno DENTRO do dano por rodada** — *a fonte diz a mesma coisa que a conta.*
>
> ***E recusar Teste de Resistência ficou de fora, por decisão dele:*** *"o inimigo não vai ter Resistência Lendária, ele precisa passar no teste."* **O preço existia — `1,20 ×` de dano efetivo, que é meio degrau —, e a porta é que não.**
>
> **⚠⚠ E um erro de voz estava vivo desde a v0.203, escondido dentro de um código de saída que já era `1`.** *A `Circulação` entrou no livro com dois rótulos de negrito longos demais, e o `conferir-voz.py --estrito` sai `1` de propósito por dois títulos que você renomeou a mão* — **então um erro novo ali dentro não move o código.** *E o `subir.sh` não roda o de voz.* ***Fechado na v0.252:*** *os dois títulos viraram exceção declarada na `REGRA-DE-VOZ.md`, o `--estrito` sai `0`, e o `subir.sh` passou a rodar o `conferir-voz.py`.*
>
> **⚠⚠ E a tabela de puladas do `README` estava parada na v0.199, em quatro colunas.** *Ela dizia **cinco** validadores enquanto este arquivo e o `LEIA-ME` diziam seis, e as contagens de checagem do `conferir-dano`, do `conferir-manual` e do `conferir-nomes` estavam todas velhas.* **A checagem `9` do `conferir-repositorio.py` não alcança aquela tabela**, porque ela confere contagem de checagem e a coluna `pula` não é isso.

**A v0.204 fechou a Expansão de Domínio de inimigo, e ela dobra quantos personagens ele exige.** *`Ronda` vira `Dupla`, `Dupla` vira `Alcateia`, e as duas de cima passam do topo da escada — uma `Calamidade` com Expansão exige **doze** feiticeiros.* ***⚠ Escada morta na v0.221 — a Expansão hoje multiplica o fator por `1,92`, no §6.4 da peça 26.***

> **A primeira forma da regra proibia a `Calamidade` de ter domínio, e o Mizuki achou:** *"não faz sentido um Sukuna da vida não ter expansão, ele seria Calamidade, não?"* **Ela media só para baixo e, não achando degrau abaixo, concluía que não podia.** *A conclusão não segue: o que falta ali é o número do encontro maior, e ele existe porque a categoria mede pessoas.*

**A v0.201 triplicou a pressão do chefe, e ela foi medida contra dois sistemas de fora antes de qualquer coisa.** *O chefe do nível 30 saiu de `72` para `219` de dano por rodada e de `1155` para `945` de vida; o manual foi para a `v7.23`.*

> **A régua é a mesma nos três sistemas: quanto o chefe come do grupo por rodada, quanto come de UMA pessoa, e quantas ele derruba numa luta.** *O `Guia do Mestre` de 2014 dá `21,3%` a `22,5%` · `85%` a `90%` · `2,56` a `2,70`; o chefe solo do Pathfinder 2e dá `22,9%` · `92%` · `~2,8`.* **Aqui dava `7,4%` · `30%` · `1,09`, e hoje dá `22,5%` · `90%` · `2,70`.**
>
> **A metade que faltava estava onde o livro não diz, mas mostra:** *o `Guia do Mestre` manda tirar a média do dano "para as três primeiras rodadas de combate", e essa é a única duração que ele declara.* **Conferida por um segundo caminho — um Guerreiro e um Ladino do `Livro do Jogador` de 2024, sem magia, já entregam metade daquilo.**
>
> ***⚠ E o `3,3 ×` da v0.199 estava alto:*** *ele lia o topo da faixa do d20 contra o valor único daqui.* **Meio contra meio era `2,64 ×` a `2,99 ×`.**
>
> **Duas regras novas, as duas com fonte de fora:** *o chefe entrega `90%` da vida de um personagem por rodada, e a vida dele é `3 ×` o dano de rodada do grupo — o que põe a luta em três rodadas.* **E o capanga virou derivação: quatro têm a vida do chefe e cada um bate o golpe dele**, com o câmbio fechando na aritmética — os dois lados entregam nove golpes.
>
> ***Decisão do Mizuki: não repreçar a régua de condição, e trocar o que ela mede.*** *"Tem que considerar que o boss também vai poder aplicar condições."* **O nível de uma condição passou a sair das AÇÕES que ela nega — meia é `Leve`, uma é `Média`, uma e meia é `Pesada` —, e o teste virou o filtro de dominância de `3,00×`.** *As treze mantêm os treze níveis publicados, a pior fica em `2,67×`, e nenhum preço se moveu.*
>
> **⚠⚠ E a régua nova destampou o que a velha escondia:** *com o chefe de `72`, as treze ficavam entre `0,00×` e `1,18×` —* **comprar condição era o pior negócio da mesa.**
>
> ***Decisão do Mizuki sobre a cura:*** *"é pra aguentar 1-2 ataques, nunca foi feita para deixar full alguém que recebeu o dano todo da rodada."* **Toda régua defensiva passou a se medir contra o GOLPE do chefe e não contra a rodada**, e isso conserta quatro dos cinco efeitos colaterais sem mover um preço — *porque o golpe do chefe novo é quase exatamente a rodada do chefe velho, `73` contra `72`.*
>
> **A vida do grupo ganhou dono, e ela não tinha:** *a ficha real, média dos cinco Caminhos com Constituição `3`.* **A peça 26 usava dois modelos em seções vizinhas.**

**A v0.200 pôs um dado no clash de domínios, e o manual foi para a v7.22.** *Refino igual e Acerto do mesmo tipo passam a rolar `1d12` cada: separou por `4` ou mais, o maior conquista; não separou, cai na corrida como antes.*

> **O dado não leva bônus porque não sobrou nada para somar nele.** *Refino já empatou — é o que a pergunta 3 quer dizer —, maestria vem do nível e o atributo da técnica bate no teto de `6` antes do primeiro clash da campanha, pelas três rotas.* **E `1d12` com margem `4` é a única combinação que cai na metade exata: `72` de `144`.**
>
> **A medida que abriu isso:** *a barreira cai antes do relógio em `17` dos `19` pares empatados, então onde tem grupo de fora a corrida já funciona.* **O buraco era o duelo** — sem ninguém batendo na barreira, o desempate era ordem de iniciativa, e ele agora é o dado. *Rolar uma vez e não a cada rodada é decisão do Mizuki: a cada rodada o choque resolveria em `88%` até a terceira, e o grupo de fora deixaria de decidir.*
>
> ***Decisão do Mizuki: o perdedor perdeu a saída de furar a barreira e sair.*** *"Não teve exemplos disso no anime e a obra não aborda assim."* **A fuga fica só onde ela já estava** — a incompleta, que ao se sobrepor faz a barreira do completo deixar de prender —, *e esse parágrafo teve de ser escrito por extenso, porque ele apontava para a saída que saiu.*

**A v0.200 unificou a paleta do projeto e fechou dois buracos no livro.** *A `Neve Saturado` — escolha do Mizuki entre cinco pares de páginas de teste — entrou nos quatro geradores de uma vez, e com ela morreu a divergência de duas paletas que a v0.199 tinha descoberto e deixado de pé.*

> **O nível 7 do Emanador dizia o próprio nível duas vezes**, uma em cada entrega, e lado a lado isso lia como dois níveis diferentes. *O rótulo virou cabeçalho das duas, e a `Modelagem` deixou de estar em aberto no `DESENHO-caminhos.md`.*
>
> **E o clash de domínios não estava no livro.** *A regra existe no manual do Fundamento desde a v7 e o capítulo parava na barreira; entrou como `Domínios sobrepostos`, com as três perguntas, a corrida e a incompleta que entra e não pode vencer.*
>
> **A varredura atrás de outros buracos fechou em zero:** *nenhum termo aparece três vezes ou mais no manual e nunca no livro.*

> **⚠ A v0.199 tinha prometido esta versão para a pressão do chefe, e ela escorregou para a v0.201.** *O trabalho segue registrado na peça 26 §8, com a medida feita: `3,3 ×` de diferença contra a tabela do `Guia do Mestre`.*

**A v0.199 deu ao Bestiário o bloco impresso, e a última pergunta do Mizuki abriu a versão seguinte.** *`05-material/bloco-de-inimigo.docx` tem a ficha em branco, um exemplo e as tabelas — e ele foi refeito três vezes, porque a primeira era planilha de construção e um bloco de monstro é lido, não montado.*

> **A tabela de inimigo do manual ganhou a linha da Classe 1, e o eixo dela mudou de nome.** *As seis linhas caem em seis faixas de Classe diferentes, e a coluna do grupo é `2,90 ×` a Rotina — constante dentro da faixa.* **Então cada linha vale para a FAIXA, e os 23 níveis sem linha sempre tiveram uma.** *Manual na v7.21, e a faixa mais baixa saía sem capanga por decisão —* ***aquilo foi revertido na v0.206***, *quando a linha do nível 2 foi consertada e o corpo do fundo passou a se comportar como os de cima.*
>
> **A ficha ganhou quatro linhas — atributos, características, pacto e resistência —, e a resistência ganhou moeda:** *resistir a `Físicos` vale `1,43 ×` de vida efetiva e custa **um degrau de categoria**.*
>
> **E a sub-categoria é ideia do Mizuki:** *a categoria diz o tamanho e ela diz a forma —* `sozinho` `100%` · `com um apoio` `75%` · `com dois` `50%` · `bando` `25%`, **com a fração saindo do câmbio e não de escolha.**
>
> ~~**⚠⚠ E fica aberta a maior:** *a pressão do chefe é `3,3 ×` menor que a do d20.*~~ ***FECHADA na v0.201***, e a diferença medida meio a meio era `2,64 ×` a `2,99 ×`. **A régua de condição não foi repreçada: ela trocou de pergunta.**

**O `Bestiário` fechou na v0.198, e é a peça 26.** *Ele era o único item da fila da mecânica desde a v0.168, e estava no fim dela desde a v0.36 com uma linha só.* **A lista dos "nove números" que a v0.159 levantou estava incompleta:** *faltavam três que a mesa rola toda rodada — a Defesa do inimigo, o acerto dele e a CD dele —, e nenhum tinha dono em documento nenhum.*

> **Os três derivam sem escolha, e é por isso que a peça 1 §6 e a peça 19 §2.5 já fechavam sem eles escritos.** *Defesa `14` a `20`, acerto `+4` a `+10`, CD `12` a `18`, nível a nível.* **Ele acerta o alvo difícil em `50%` a `55%` e o TR treinado dele falha `35%`** — os mesmos números que a peça 1 §6 publica do lado do jogador, e a checagem `2` cobra que os dois lados da mesma rolagem não discordem.
>
> **A categoria é ideia do Mizuki, e o eixo dela é quantos personagens o inimigo exige.** *`Ronda` `1` · `Dupla` `2` · `Alcateia` `4` · `Calamidade` `6`, com fator `personagens ÷ 4` sobre a linha do manual.* **As ações saem de `personagens − 1`, piso `1`, e a `Alcateia` cai exatamente no `3` que a régua da peça 19 exige como piso** — a checagem `4` lê aquele piso em vez de guardar cópia. ***⚠ Escada morta na v0.221 — as ações hoje são declaradas pela categoria, no §4.2 da peça 26.***
>
> **⚠ O grau fica como rótulo de ficção, e parear grau com grau reprova pela peça 12 §2.** *Dois feiticeiros de grau 2 podem ser nível 5 e nível 25.* **Mas o levantamento da obra devolveu a fronteira de graça:** *o que separa uma maldição de grau 2 de uma de semi-grau 1 é **saber usar técnica**, e isso a ficha já carrega.*
>
> **Um chefe vale quatro capangas**, medido por simulação de fogo concentrado e reconstruído pelo método dos dois eixos do `Guia do Mestre`. *A conta óbvia — vida vezes dano — dá `10`, e dez capangas no nível 30 cobram `158%` da vida do grupo.*

**A v0.198 saiu com quatro consertos na vizinhança do inimigo antes da peça, e o primeiro é o que a sustenta.** *As `3` ações do chefe estavam escritas dentro do `conferir-dano.py`, com a peça 19 dizendo que o dono era o manual — e a frase do manual diz o contrário: ele **perde** a ação três vezes por rodada.*

> **O número está certo por outro caminho: ele é o PISO da banda de condição.** *Com `2` o `Lento`, o `Calado`, o `Enfeitiçado` e o `Atordoado` passam do teto do próprio tier.* **A checagem `12` cobra as duas direções, e escrever `4` acende igual a escrever `2`.**
>
> **E a tabela de puladas estava errada em três das cinco linhas, nos dois documentos** — na coluna `de quantas`, não na `pula`. *É a mesma tabela cuja história a seção dela conta: a v0.38 escreveu lendo a saída, a v0.40 achou, e a lição foi "leia do código".* **Ela foi lida do código, e depois o código mudou** — contagem lida do dono uma vez é retrato. *Hoje a sub-checagem `9.1` relê rodando cada um com o `python-docx` bloqueado, e ela é a segunda checagem do projeto em que o dono é o código.*

**A v0.189 fechou três itens da fila, e nenhum fechou do jeito que a fila dizia.** *Uma pergunta estava mal feita, uma decisão citava uma regra que diz o contrário dela, e uma dívida estimou o próprio tamanho sem conferir.*

> **O `Absorver` do Bastião contra a Reação de cobrir-se:** *ele evita de `2,79 ×` a `3,79 ×` o que ela evita, em todo nível, e é de graça.* **Não é dominância — aquele filtro mede coisa que o jogador escolhe entre, e ninguém escolhe entre essas duas —, e não são a mesma peça com dois nomes:** *o que as separa é o relógio, contador de dia contra dreno de PE.* ***Decisão do Mizuki: declarar e não mexer***, com o `Muro` do nível 19 comendo `86%` das rodadas de Reação do dia.
>
> **O `Não Sou Gente` REPROVOU, e ele nunca podia ter sido escrito.** *A lista `Limites` do manual e do capítulo 9 do livro põe "imunidade completa a um tipo de dano ou condição" entre o que nenhuma Passiva paga pode fazer; a caixa que a v0.39 citou fala de **furar** imunidade, que é o lado do ataque.* **Cento e quarenta e nove versões de decisão tomada e nunca aplicável.**
>
> **O `Desarmado` fica em `3,45`, e a régua passou a dizer o que ela mede.** *A dívida afirmava que repreçar mexeria no manual inteiro; a Melhoria `Condição` cobra pelo nível, o nível sai da banda, e ele ocupa `22%` do teto da `Leve`.* **Ele é a única das treze que uma compra feita antes da campanha desliga inteira, e isso ficou escrito** — *o molde do piso, se um dia pesar, é o `−2` na iniciativa que o `Surdo` ganhou.*
>
> **Três checagens novas, todas guardando relação entre dois donos, todas com o estado oposto declarável** — *sem ele o contra-teste não existe e a checagem fica trivialmente verdadeira.* **Sub-blocos nos três, então a contagem não se move.**

**A v0.188 varreu a fila contra o estado real, e o que ela escondia era maior que o que ela listava.** *Dos onze itens, **três já estavam fechados**, e só um deles a fila desconfiava; **fora dela apareceram mais dois fechados e quatro pontas soltas**, a mais velha com cento e quarenta versões.* **E a varredura destampou que a checagem escrita na v0.187 não acendia na frase que ela existia para pegar.**

> **O reconhecedor procurava `falta nela é escrita e não peça` e a peça escreve *"O que falta nela é escrita**,** e não peça"*.** *Uma vírgula, e ela passou verde na própria linha.* **A seção 8 da peça 13 dizia o contrário do §10 dela**, num arquivo que um validador varre inteiro toda vez.
>
> **A âncora saiu da prosa e foi para a tabela:** *a célula da vaga passou a declarar o estado do ALVO, e a checagem `6` cobra isso.* **O reconhecedor da `6.1` virou família de promessa, e passou a aceitar as duas declarações da enumeração** — sem a oposta ela só podia ser satisfeita de um jeito, e o contra-teste dela não teria como existir.
>
> **Os cinco fechados:** *sacar arma (peça 3 §3.2, v0.122), os pontos de feitiço do Emanador (peça 6 §9, v0.131), a penalidade de arma sem treino (peça 19 §6, v0.104), a `Cicatriz` sem mecânica (peça 1 §5.5, v0.171) e a máquina de criação do `Sem Técnica` (peça 25, v0.168).* **⚠ O pior deles é de tabela e não de prosa:** *a tabela de rotas daqui publicava `+ Sem Técnica → não` com a peça 9 §6 publicando `sim` desde a v0.168.*
>
> **E entrou a checagem `5.1` do `conferir-repositorio.py`:** *alguma linha viva diz que uma peça não existe, ou que uma pendência espera por ela, quando ela está na pasta?* **A lista sai do nome do arquivo, então peça nova entra na varredura sozinha** — e o par de testes que prova isso é a mesma frase ficando verde sem o arquivo e vermelha com ele.

**A v0.186 escreveu as três montagens por Trilha, que a peça 15 devia desde a v0.53.** *A Q6 que as bloqueava fechou na v0.63, e elas ficaram **123 versões** como aviso que não falhava o validador — de propósito, porque escrever as três era escolha de sabor do Mizuki e não conserto.*

> **`Servo` = `Agarrar` + `Interpor` · `Matilha` = `Agarrar` + `Arrastar` · `Coro` = `Fisgada`.** *As três gastam o orçamento inteiro do nível 2, e o do `Servo` é `12` porque a concessão dele é o da ficha mais metade — não é montagem mais cara, é bolso maior.*
>
> **Cada uma mostra a concessão da Trilha, e não só o orçamento.** *O `Interpor` só faz sentido num corpo que aguenta o golpe; a `Matilha` agarra e arrasta com cinco de uma vez; e a `Fisgada` do `Coro` prende à distância para o golpe do dono entrar atrás.* **Elas moram em tabela própria**, separadas das seis do material — *aquelas são shikigami montados com o catálogo, estas são a montagem que a Trilha pede.*
>
> **O aviso virou conferência.** *A checagem 17 confere as três contra o orçamento do nível 2, com o do `Servo` derivado da concessão e nunca lido, e compara os arranjos com o capítulo 16.* **Nove perturbações acendem.**

**A v0.182 passou a peça 15 pela passada de texto, e o que ela achou não era tamanho.** *A peça tinha ficado em quatro camadas depois de duas reescritas seguidas — o princípio novo, um ⚠ citando o velho, um argumento marcado como história, e as tabelas da v0.181 —, e quem abrisse ela em conversa nova lia as quatro como se fossem uma.*

> **Doze lugares estavam desatualizados** — *dez descrevendo o mecanismo que morreu na v0.180, um com um número de antes da v0.67, e um cobrando dívida que a v0.181 já tinha pago.* ***Três das frases em tempo presente moravam numa seção cujo título já dizia que o mecanismo tinha morrido:*** **o rótulo cobria o bloco, e o corpo dele seguia em tempo presente.** *Foi assim que elas atravessaram a varredura da v0.181, que existiu só para isso.*
>
> **E o §5 tinha divergido do código.** *Ele especificava duas checagens que não existem — o tamanho da devolução e o piso da venda — e **não especificava a `30`, a Defesa da invocação**, que nasceu na v0.180 e passou duas versões sem espec.*
>
> ***Decisão do Mizuki: apagar, e não encolher.*** *"Por que alguém leria algo que não existe?"* **A peça é dona da decisão; o CHANGELOG é dono do porquê.** *Ela saiu de `18.998` para `18.407` palavras, e nenhum número de regra se moveu — as 26 diferenças do `guard_numeros.py` foram lidas uma a uma contra a linha que as carregava.*
>
> ~~**⚠ Dois achados desta passada ficaram anotados e não viraram trabalho.** *O `±10%` do ponto de ficha é lido pela checagem 10, impresso, e nunca comparado com nada — cegueira anterior a esta versão, medida com controle. E o `RASCUNHO-trilhas.md` ainda descreve a régua de morte da peça 15 como se ela lesse a **vida máxima** do corpo, que a v0.178 trocou por escala fixa.*~~ ***OS DOIS FECHARAM:*** *o `RASCUNHO-trilhas.md` na v0.183, e o `±10%` na v0.185, com a sub-checagem `10.1` do `conferir-invocacoes.py`.*

**A v0.180 tirou a ficha da invocação de cima da ficha do invocador.** ***Objeção do Mizuki:*** *"não faz sentido utilizar acerto, defesa e atributos do invocador — o invocador vai querer invocações que fazem o que ele não faça."*

> **A fórmula da peça 1 já separava ritmo de valor, e ninguém tinha lido assim:** `Ataque = d20 + atributo + maestria`. **A maestria é o ritmo, o atributo é o valor** — trocar o atributo do dono pelo dela dá ficha própria sem tocar no ritmo, que é a única coisa que a lição nº 1 proíbe.
>
> **A invocação passou a ter os cinco atributos, com o orçamento da peça 2:** nove pontos, teto `3` na criação, `+1` por marco, teto `6`. *Ela só usava três porque as outras duas não tinham onde entrar com a ficha derivada; com Teste de Resistência próprio, entram.* **Com três atributos existiria um arranjo só — `3·3·3` —, e um arranjo único não é escolha.**
>
> **A Defesa dela é `10 + Destreza dela + metade da Essência ou da Inteligência do dono`**, escolhida na montagem. *Ideia do Mizuki, e o número dele fechou exato: a Defesa dela bate com o alvo difícil do personagem em quatro dos cinco níveis medidos.* **Sem ela o inimigo acertaria `75%` no nível 30, contra `55%` num personagem.**
>
> **⚠ O deslocamento morreu inteiro, e com ele a única ponte entre as duas moedas do subsistema.** *Quatro checagens trocaram de assunto — a 8, a 10, a 18 e a 30 —, todas com o motivo escrito no código.* **As seis montagens de shikigami foram refeitas na v0.181**, com arranjo de atributo cada uma, e a checagem 17 confere a soma, o teto e o atributo principal. ~~*Segue aberta só a promessa antiga: três invocações já montadas, uma por Trilha, prometidas desde a v0.53.*~~ ***FECHADA na v0.186***, com tabela própria no §3.7 e no capítulo 16.

**A v0.179 fechou as duas pendências que a v0.176 deixou anotadas, e nenhuma era o que a anotação dizia.**

> **O `Conhecimento Antigo` fica em `Desliga`.** *A anotação queria mover ele para `Ajusta` porque "o `Desliga` apaga o que chega em você".* **Essa frase já descrevia um catálogo mais estreito que o real:** o `Ferro Velho` apaga cansaço e diz no próprio texto que *"cansaço não é uma coisa que acontece com você"*, e o `Sangue que Não é Sangue` apaga precisar comer e dormir. *E `Ajusta` era impossível: ele exige relógio, e este Legado é `sempre`.* **A glosa foi alargada na peça 13 §5 e no capítulo 7 do livro, que publicava a mesma frase estreita para o jogador.**
>
> **A atração de objeto amaldiçoado não tem Legado que a desligue, e não vai ter.** *A vaga livre do catálogo é do Corpo Amaldiçoado, e gastá-la com um alvo emprestado deixaria aquela Origem sem alvo próprio para sempre.*
>
> **⚠ E um cabeçalho mentia dentro do próprio arquivo:** *o `conferir-legados.py` dizia "Nove checagens" e tinha dez no código.* **A checagem 9 do `conferir-repositorio.py` lê do código e compara com DOCUMENTO — e o cabeçalho de um validador não é documento**, então ela nunca alcançou este. *Ele só apareceu porque a checagem nova nasceu com número repetido.*

**A v0.178 tirou a régua da morte de dentro do corpo da invocação, e o livro passou a publicar os três números que faltavam para ela jogar.**

> **O `Coro` perdia a Trilha em definitivo no primeiro acerto de inimigo comum**, porque a régua se media contra a vida máxima daquele corpo e o corpo dele vale meia Rotina — o mesmo que um golpe de rotina. **Hoje a régua é `5 ×` a fórmula do tipo, escala fixa para qualquer corpo**, e o `Coro` não ganhou vida nenhuma: ele cai igual e volta.
>
> **O livro não publicava o dano do `Investir`, a vida do `Servo` e da `Matilha`, nem o orçamento do `Servo`.** *O dano nunca tinha sido multiplicado em documento nenhum — a peça dizia "entrega a cota da Rotina" e parava ali.* **Ele é `d6` arredondando o número de dados para baixo**, porque para o mais perto ele fura o teto de uma Rotina.
>
> **A Constituição valia `5 × o nível` num corpo de invocação e `1 × o nível` numa ficha**, porque ela entrava na fórmula e o multiplicador da Trilha multiplicava ela junto. **Hoje o corpo forte é `2,5 × (base + 2 × nível) + Con × nível`**, e ele fica em `101%` da curva da Vanguarda em Con `0`, `3` e `6`. *A vulnerabilidade da `Matilha` a área desceu de `×2` para `×1,5` no mesmo pacote, e o par ficou melhor que qualquer um dos dois sozinho.*
>
> **⚠ Duas coisas ficam abertas e são o trabalho da próxima versão.** *A objeção do Mizuki à Q3 da peça 15 — "não faz sentido utilizar acerto, defesa e atributos do invocador" —, e a **Constituição da invocação sem preço e sem dono**: o §3.3 diz que o jogador a compra com pontos, e o limite do orçamento diz que nada pode dar vida direto.*

**A v0.172 fechou as duas perguntas em aberto da peça 12, e a v0.196 represou a curva dela.**

> **A curva saiu de uma missão por nível para três, com passo de `+2` a cada três níveis e teto em dezessete.** *O nível 20 custa `143` missões padrão em vez de `63`, e a campanha inteira custa `307` em vez de `145`.* **A duas mesas por semana — a cadência que a Guilda declara — isso põe o nível 20 em `15,5` meses e o 30 em `23,4`**, contra os `6,8` que a curva anterior entregava.
>
> **O §3.0 novo deriva os cinco números**, e o §4.1 deriva a coisa que nunca tinha dono: **quanto vale a missão típica de cada faixa**, `106,25` e `240`. *A peça descrevia uma mistura que valia `125` e o validador usava `106`, e nada comparava os dois desde a v0.32.*
>
> ***⚠ E a curva CRUA fica fora da faixa que as catorze respostas desenharam, de propósito.*** *O teto delas é `14` meses até o nível 20 e a curva entrega `15,5`.* **O §5.3 é a outra metade da decisão: uma mesa de dobro por mês devolve o nível 20 para `13,9`.** *A checagem 3 do `conferir-xp.py` mede a curva COM a compensação recomendada — se a recomendação deixar de bastar, ela acende.*
>
> **⚠ Duas consequências ficam registradas.** *O teto de um nível por missão **deixou de morder** — nenhuma combinação de nível e tamanho entrega dois níveis —, e a peça 12 §3.1 declara isso em vez de argumentar como se ele mordesse.* **E o vão entre quem joga uma e quem joga duas mesas por semana chega a `13` níveis por volta do mês `23`**, medido e deixado sem regra por decisão do Mizuki: *o livro mede, mostra e sugere.*
>
> ***A peça 12 não tem item de decisão*** — os do §10 são todos de playtest, e o maior deles é se o vão de `13` níveis aparece de verdade.

> **A conversão de mestragem é o §6.2:** *uma mensalidade do seu Grau a cada **vinte** mesas mestradas, fechando sozinha na vigésima.* **Os dois números são derivados** — o valor é a linha do §6.1, e o `20` é `3 ÷ 0,15`: a taxa mais pesada do levantamento sobre a fatia que o §6.1 dá ao catálogo mundano.
>
> **A propriedade que sustenta a trava é que a fração não depende do tamanho da campanha.** *Ganho e folha crescem no mesmo relógio, então a mestragem entrega `taxa ÷ 20` da folha e o tempo cai fora da conta.* **`15%` a três mesas por mês, `10%` a duas, `5%` a uma.**
>
> **A lista de feitos do limiar é o §7.1, com oito entradas fechadas.** *A palavra final do mestre é sobre **se** um feito aconteceu, nunca sobre **quais** são.* **Cada entrada cita um estado que a ficha ou o registro da missão carrega depois da mesa** — nível, `0` de vida, estágio de alma, tamanho declarado antes, grau escrito na ferramenta.
>
> **⚠ O filtro que escolheu as oito é da peça 10, e ele vale para toda lista fechada do projeto:** *entrada de lista fechada é **pergunta sobre o mundo** — a mesma resposta serve para qualquer mesa; **pergunta sobre a cena que aquele mestre dirigiu** fica de fora.* **Três das oito propostas reprovavam nele e foram trocadas.**
>
> **⚠ E não existe grau de maldição.** *A escada `grau 4 a grau 1, mais o especial` é de **ferramenta** (peça 16 §3) e de **patente** (peça 12 §6.1); a tabela de inimigo do manual é `nível do grupo → vida e dano`.* ~~**É decisão que o BESTIÁRIO herda:** se o inimigo ganhar grau, o feito 1 do §7.1 volta à forma original.~~ ***FECHADO na v0.198:*** **a peça 26 §2 deixa o grau como rótulo de ficção, e o feito 1 fica como está.**

**A v0.171 fechou quatro itens da fila pequena, e o quarto virou uma peça de economia.**

> **A `Cicatriz` ganhou mecânica depois de cento e trinta e quatro versões:** *vantagem em `Intimidação`, desvantagem em `Persuasão`, as duas `Essência`.* **Teto `1`, porque vantagem não empilha**, e ela **não vem** se quem fechou o ferimento foi a sua própria `Energia Reversa` — o que na prática só acontece pelo `Insistir`. *Quatro formas numéricas foram medidas e as quatro reprovam, cada uma numa régua que o projeto já tinha.*
>
> **O dinheiro entrou, e é o iene.** *A escada de salário por patente é da peça 12 §6.1 e sai do canon — o salário do Gojo é o de um ministro, `¥29,61M`/ano, dividido por `12` e por `2⁴`.* **A tabela de preços é da peça 14 §6.5, e ela vem com uma prova:** *toda entrada de equipamento já é travada por atributo e por treino, então o preço é a terceira trava e a única que só sabe atrasar.* **A criação passou a ter passo de equipamento** — `Traje` 1 da instituição, de graça, e dinheiro para o resto. *Eram `¥75.000`, e a v0.175 dobrou para `¥150.000` — uma mensalidade cheia.*
>
> **⚠ E o `Grau` passou a gatear o que a instituição controla, sem reverter a peça 16 §2.2:** *aquela seção mede o eixo de USO, e o gate de `Estigma` continua sendo de nível.* **O que entrou é o eixo de AQUISIÇÃO, e a espiral não fecha porque o teto de poder continua no nível.**
>
> **Dois donos que não existiam ganharam casa.** *`Vantagem não empilha` estava publicada no livro e em peça nenhuma — a peça 14 apontava para a peça 4 §5, onde só morava o caso de dois ajudantes; hoje ela é regra daquele §5.* **E o `33,9` da peça 11 §6 era número órfão desde a v0.78:** *ele não reconstruía de nada, e virou `36,0`, derivado do golpe de chefe do manual vezes o acerto da peça 1 §6.*
>
> *Ela parou numa pergunta de duas metades — o formato da lista de feitos e a forma da conversão de mestragem.* **As duas foram respondidas na v0.172.**

**A v0.170 pôs `Sem Técnica` no livro**, como o capítulo **11**, e o Manual da Guilda foi para **18 capítulos**.

> **⚠ Acrescentar capítulo no meio custa mais do que parece, e o custo não é o texto: são as referências cruzadas.** *`38` delas, em treze arquivos — os capítulos `11` a `17` viraram `12` a `18`.* **E a checagem 10.3 só alcança as que carregam o título junto; as `44` que dizem só `capítulo N` ficam por conta de quem escreve.** *O argumento inteiro está no CHANGELOG da versão.*

**A v0.169 é limpeza, e o que ela deixa em pé são dois números com dono.** A lista branca da checagem 7.2 tem **base `146`, folga `5`, teto `151`**, com as `146` classificadas por família. E a contagem de capítulos do livro ganhou dono — o `README.md` do projeto — e checagem na 7.3, contra as duas cópias do README da entrega.

> **A paginação do livro continua sem dono, e isso é decisão.** *Ela não é propriedade de documento nenhum: é do artefato construído.* **O conserto foi tirar as cópias, e não inventar um dono para elas** — hoje ela aparece uma vez só, na linha do recorte da entrega.

**A v0.168 fechou `Sem Técnica`, a nona rota de Origem, e ela é a peça 25.** Estava na fila desde a v0.122.

> **A máquina é o Fundamento inteiro**, no molde da peça 20 e sem número novo. *Dois renomes — o `feitiço` é o `Manejo`, a Técnica Máxima é o `Auge` — e uma subtração: a Expansão de Domínio não existe nesta rota.* **A `Liberação Máxima` fica:** o argumento da peça 20 era *"esta rota não tem técnica inata"*, e esta escreve Fundamento — ela tem técnica, só não tem técnica **inata**.
>
> **Toda ficha começa com uma aptidão aberta — a semente —, sem gate e sem gastar marco, e ela é o assunto do seu Fundamento.** *Três portas: `Domínio Simples`, `Energia Reversa` e uma `Aptidão Própria`.* **Quem tem a semente `Energia Reversa` soma `1/3 do refino` em toda rolagem de cura sua**, e curar os outros continua fora da criação, na Trilha `Sutura`.
>
> **⚠ A banda da semente é `Classe Passiva 2` e `3`, e ela é DERIVADA.** *A escada de gate da peça 11 §5 produz sozinha quanto cada altura antecipa — `4,0` níveis na `CP 1`, `9,3` na `2`, `17,3` na `3` —, e só `CP 2` e `3` passam no filtro de `3,00×`: `1,86×` contra `4,33×`.* **A escada de gate é a escada de Classe Passiva, então o corte não foi escolhido.**
>
> *E o §7 daquela peça é onde a forma da máquina se decide: sem ela a rota vive entre `17,7%` e `51,6%` da Rotina, e o vão do dia vai de `4,06` a `6,43` fatias conforme o PE do Caminho.* **Vão que cresce com o PE quer dizer que a máquina tem de gastar PE**, senão ela não é neutra entre os cinco Caminhos.

**A v0.167 tirou duas cegueiras da triagem de nomes**, e as duas já tinham custado nome. Ela lia as 52 armas e **não as treze categorias**, e a lista de vocabulário dela não tinha `Defesa`, `Aptidão`, `Rotina`, `Sequela`, `Cicatriz` nem `Bloquear`. Hoje ela deriva as categorias do catálogo e lê o glossário do livro — `136` termos —, as duas com guarda de contagem.

> **Três dos cinco `Estilos da Pegada` estavam batizados duas vezes**, e viraram `Volteio` · `Couraça` · `Mão Nua`. *Nenhum preço se moveu.* **E a ordem do `UNIVERSO` virou ordem de autoridade:** quando duas fontes reivindicam o mesmo nome, a primeira vence — antes era a última, e acrescentar fonte mudava em silêncio a razão publicada.

**A v0.166 tirou a cura do `Classe 0`.** Não era mudança de regra: a tabela `Cura` do manual sempre começou na Classe 1, e quem abria o buraco era a `Base por Classe`, que juntava `Cura, Apoio e Onda` numa linha só. *Um `Classe 0` com Forma `Cura` entregava `27` de cura por rodada, de graça, em aliado — `1,06` Trilha.* **Manual na v7.19.**

> *Curar terceiro é o degrau raro do material, e a peça 11 §6 põe ele na Trilha `Sutura`, no nível 11 dela.* **Área em `Classe 0` é intencional e ficou de fora** — `Explosão`, `Cone` e `Linha` têm coluna `Classe 0` na mesma tabela, e nada as contradiz.

**A v0.164 fechou as doze entregas do Evocador, e com elas as quinze Trilhas.** `Servo`, `Matilha` e `Coro` estavam paradas desde a v0.82.

> **A `Matilha` ganhou um dial que só ela pode ter, ideia do Mizuki.** *Com cinco corpos em pool a `50%`, "quantos acertam" é `96,9 · 81,3 · 50,0 · 18,8 · 3,1%` — o degrau de três cai em `50,0%` exatos.* **A Trilha inteira é esse dial andando.**
>
> **Duas Trilhas monocromáticas na mesma coluna sempre dominam uma à outra**, e a dominância entre `Matilha` e `Coro` ficou **declarada**: o eixo que separa as duas mora na outra matriz, cinco corpos contra atacar-e-comandar. *A checagem 15 do `conferir-catalogo.py` reconta a matriz e só aceita declaração que nomeie o eixo de fora.*
>
> ~~**⚠ E um nome ficou batizado duas vezes:** *`Casco` é Bênção e é rota da `Sintonia` do Evocador.*~~ ***FECHADO na v0.184:*** **a rota da `Sintonia` virou `Parrudo`**, e o `Casco` fica com a Bênção. *Renomear a rota custava três lugares e a Bênção custava oito — e o sentido de `Casco`, `"o golpe entra e não derruba"`, descreve a Bênção e não invocação com mais vida.*

**A v0.163 fechou as duas pendências de Invocações.** *Com o dono caído, quem fica de pé tem Ação Padrão e comanda como sempre; a invocação agir sozinha é recusada pela conta, porque ela dobraria o dano por rodada.* **A vida cheia da invocação volta no descanso longo**, derivado da peça 10 §3 — o respiro não devolve vida.

**A v0.162 tirou do manual dois graus de cobertura que este sistema não tem.** *`cobertura leve` é do GURPS 4e e `meia cobertura` é o half cover do D&D 2014; os dois apontam para obstrução parcial, que aqui é a `Parcial`.* **A escada daqui é `Parcial` `+2` · `Boa` `+5` · `Total`, na peça 19 §5**, e a tradução fiel não move preço.

> ***A escada NÃO foi comprimida, e a medida foi a pedido dele.*** *O acerto daqui topa em `+10` contra o `+11` do d20, então a cobertura morde mais forte.* **Mas `+2/+5` é a mais próxima das três:** `5,3` pontos percentuais da mordida do d20, contra `6,8` do `+2/+4` e `12,9` do `+1/+4`. **Manual na v7.16.**

**A v0.161 matou o `sete`, e ele tinha sobrevivido setenta e duas versões à decisão que o aposentou.** *A v0.89 pôs a rota pura de Refino em `10` aptidões, e quatro lugares continuaram publicando `7`.* **E `meio a meio` nomeava três rotas diferentes** — a linha daqui foi alinhada com a curva da peça 11 §3: `2` Corpo · `3` Refino · `2` Leque.

> **⚠ E isto importava para o `BESTIÁRIO`, que fechou na v0.198 e é a peça 26.** *Este arquivo era o dono declarado do refino do inimigo — hoje é a peça 26 §3, que lê a curva da peça 11 —, e o chefe herda a curva do `meio a meio`.* **O refino dele entra vivo na cascata do clash do manual v7.19, e não é enfeite de tabela.** *A contagem de aptidões saiu da conta na v0.173, junto com a rolagem.*

**A v0.160 tirou a checagem 7.4 do rótulo e pôs ela no conteúdo.** *A versão da entrega passou a sair da linha `Recorte da vN.NN` do `README` dela dentro do commit, e não da mensagem.* **A mensagem continua sendo lida e virou a segunda metade da comparação:** rótulo que discorda do conteúdo sai como aviso, e não como erro — mensagem de commit já feito não se conserta sem reescrever história.

**A v0.159 fechou as duas linhas que faltavam no inimigo, e elas eram o mesmo trabalho.** *As duas pendências pediam "valor sugerido por nível", e nenhuma das duas tem valor por nível:* **a Integridade do inimigo é a vida máxima dele, e a Reação é o mesmo slot que a peça 3 §3 dá a qualquer ficha.** O que faltava não era um segundo valor — era um segundo lugar de marcar.

> **⚠⚠ E NÃO existe ficha de inimigo, apesar de três documentos falarem dela.** *O manual não tem bloco de inimigo: a seção `Inimigos` é uma tabela de nível → vida e dano, mais prosa.* **Montar um inimigo pede nove números com quatro donos** — o manual, a peça 19, a peça 1 e este arquivo. ~~***Juntar os nove é o `BESTIÁRIO`, e ele é peça.***~~ ***FECHADO na v0.198, e eram DOZE e não nove:*** *a Defesa do inimigo, o acerto dele e a CD dele não estavam nesta lista, e nenhum dos três tinha dono.* **Hoje a ficha inteira é a peça 26 §3.**
>
> *Decisão medida: o chefe não ganha uma segunda Reação por ter três ações.* **A `Brecha` dispara `0,16` vez por combate**, e uma Reação por rodada nunca acaba contra isso. **Manual na v7.15.**

**A v0.158 deu peça, conta e validador ao dano na arma**, e ele estava sem os três desde a v0.147 — morava só no livro, em dois capítulos, e nenhum validador alcançava.

> ***Decisão do Mizuki: o refino `10` passa a dar `4d6` em vez de `3d6`.*** *Palavras dele: "isso incentiva a galera a querer pegar refino, e isso é bom, dá peso para as outras opções."* **A linha de graça do marco entrega `8` dos `10`, então o `10` é o único degrau que exige ter escolhido Refino — e ele passou a ser o maior**, `+6,5` contra `+2,5` dos outros três. *Só o `10` se move, e é isso que salva o degrau do nível 7 dos cinco Caminhos, medido em refino passivo `8`.*
>
> **⚠ E o `4d6` faz a exclusão do crítico virar carga.** *A peça 1 §5.2 exclui dado de aptidão do crítico; se ele dobrasse, o `Incapacitado` iria a `114%` do teto da `Leve` — com o soco, sem precisar de arma `d12`.* **Na v0.151 aquela linha era folga; hoje ela é o que segura a condição dentro da banda.**
>
> **A trava da §2 da peça 11 passou a dizer de que ela é feita.** *Ela é de orçamento, com duas condições medíveis: o dano de refino não sobe o pico da rodada, e a rodada em que ele cai fica abaixo da Rotina do nível.* **A §6.9 é a dona das duas medidas.**
>
> **E as treze Manhas foram remedidas com UM ataque por rodada**, que é o mundo do nível 2 ao 6: *banda `0,53`–`1,06`, dominância `2,00×`, média `0,80`.* ***Decisão do Mizuki: declarar e não mexer*** — repreçar contra o nível 2 põe a dominância em `3,76×` e reprova.

***A v0.155 fechou a dívida do vão do nível 7, aberta desde a v0.147 — e o diagnóstico não era o que a dívida dizia.*** **O ataque extra não virou letra morta: o VÃO é que deixou de ser um número.**

> **Na forma da v0.82 o físico e o conjurador faziam a mesma Ação Padrão e o físico tinha uma coisa a mais** — subtração limpa, e dava um golpe simples. *A v0.147 devolveu o ataque extra à Ação de Atacar, e a Ação de Atacar não inclui o feitiço de Toque: o físico passou a **escolher**, e a subtração virou comparação entre duas decisões.* **Medido, o ataque extra vale de `0,53` a `1,68` fatia conforme refino e Manha — dispersão de `3,2×` dentro do mesmo Caminho, contra `2,36` publicado.**
>
> **A taxa que faltava não era pergunta de playtest: estava no bloco 1 do `conferir-orcamento.py`.** *`10,5` rodadas de luta por dia, e o poço de PE diz quantas cabem — Bastião conjura `48%`, Vanguarda `67%`, Emanador `76%`.* **O resto é onde o ataque extra vive.**
>
> ***Decisão do Mizuki: o nível 7 ganha uma segunda metade, e ela não pode ser dano*** — *qualquer coisa que ande junto do ataque herda a dispersão.* **`Ainda de Pé` no Bastião (`1d8 + metade do nível` de cura, `1×` por cena, sem custo de ação) e `Não Pega` na Vanguarda (o `Evasion` do 5e como Reação, desligado pelo `Incapacitado`).** *Totais `1,93` e `2,10` contra `2,36` dos outros três, com a diferença **declarada**.*
>
> **⚠⚠ O custo de ação da `Ainda de Pé` foi escolhido por medida:** *a Reação do Bastião está tomada pelos outros três degraus dele e a Ação Bônus pelas três Trilhas — a `Fagulha` põe um `Classe 0` de `27` ali toda rodada.* **Curar `19,5` gastando aquilo dá saldo `−7,5`.**
>
> **Entrou a checagem 6 do `conferir-manual.py`**, que lê os três totais e falha se a diferença passar de `0,50` fatia. *Ela pegou um arredondamento meu na primeira rodada, e o arnês pegou dois defeitos fora do código — uma base **falsamente verde** (a cópia não tinha o `.docx` no caminho, então o validador pulou tudo e saiu `0`) e um contra-teste incoerente.*

***A v0.154 mexeu em cinco Manhas por leitura dele***, e o `Gancho` parou de ser sobre mover — dar alcance à Manha reprova pela peça 14, e fechar a distância entrega zero porque o turno base já dá `9 m` divisíveis. *Banda `0,53`–`1,18`, dominância `2,22×`, com a checagem 13 do `conferir-catalogo.py` em cima.*

***A v0.153 fechou a dívida de texto do livro, e o que a destravou foi reconstruir a DEFINIÇÃO em vez de escolher entre os números.*** **Três versões mediram a mesma coisa e acharam três coisas — `209`, `4`, e uma contagem descartada —, porque o par publicado na v0.141 nunca teve definição escrita.**

> **O primeiro trabalho não era consertar texto: era descobrir por que `4` não era `6`.** *A cópia abandonada da v0.138 tem o livro daquela versão inteiro, e medida com o mesmo filtro ela dá **exatamente o mesmo que hoje** — então nada foi consertado de passagem na v0.147 nem na v0.148.* **A explicação era a outra, e ela foi reconstruída: vinte e seis recortes rodados sobre o mesmo texto, e o capítulo 12 cai em `4`, `6`, `7` ou `8` conforme o que se chama de entrada.**
>
> ***O par da v0.141 reproduz EXATO — `9` entradas, `12` rótulos, `6` no capítulo 12 — com uma definição TORTA:*** *a entrada se qualifica por ter rótulo longo dentro da **caixa de regra**, e os rótulos são contados na **seção inteira** dela.* **Uma metade do par medida por um recorte e a outra por outro, e é isso que a fez irreproduzível por três versões.**
>
> **Endireitada — toda entrada, rótulo na seção inteira — o mesmo texto dava `11` entradas e `14` rótulos.** *É essa que foi publicada, e os catorze foram pagos: cada um virou `**nome do efeito.**` mais a regra.* **O pior era o `Assombro`, com `24` palavras — a regra inteira em negrito, no lugar em que o nome deveria estar.**
>
> **Entrou o `ROTULO-LONGO` no `conferir-voz.py`, e ele lê DOIS números da `REGRA-DE-VOZ.md`.** *O de rótulos é a dívida — hoje `0`; o de entradas é **guarda** — `53`; o reconhecedor conta `53` desde a v0.239, e a declaração só foi corrigida depois da v0.251.* ***Sem a guarda, renomear uma tabela faz o reconhecedor achar zero entrada, logo zero rótulo, e a checagem passa verde para sempre sem ter conferido nada.***
>
> **⚠ E o recorte de seção nasceu com o defeito da v0.151, de novo:** *ele fechava a `###` só na próxima `###`, e não em `##`.* **Duas das quatro primeiras acusações eram o corpo de uma entrada vazando três seções adiante**, e só apareceram porque o número não fechava.
>
> **⚠⚠ O arnês pegou dois defeitos meus, e os dois estavam nas PERTURBAÇÕES.** *A regressão do `Assombro` não fechava o `**`, então o rótulo sumia em vez de voltar e ela saía **verde** pelo motivo errado; e o contra-teste da célula mexia na primeira coluna, que é a lista de entradas, então ele acendia a guarda em vez de testar a célula.* **Perturbação que não reproduz o defeito não prova nada, e as duas pareciam certas lendo.**

***A v0.152 pagou a primeira das quatro dívidas de preço, e ela encolheu antes de ser paga.*** **A dívida dizia "os onze `Estigma` nunca foram preçados uns contra os outros", e duas coisas do próprio projeto dizem que essa conta não existe.**

> **A peça 11 §4 diz que a escada de Classe não mede tamanho** — *"ela não mede quanto, mede o quê"* — **e o §7 da peça 16 diz que o jogador nunca escolhe entre elas:** *o `Estigma` é entregue pelo mestre, num ritmo que põe grau 3 por volta do nível 10 e grau 1 por volta do 26.* **A v0.144 já media do jeito certo — "a pior razão contra os irmãos de Classe 2" — e não registrou que aquilo era a regra.**
>
> **Com o corte certo, sobraram duas coisas, e as duas eram grandes.**
>
> ***O `Bojo` reprovava por `7,85×` dentro da própria Classe.*** *Ele entregava PE em vez de dano e por isso nunca tinha passado por conta nenhuma — mas o projeto tem essa moeda com dono, `1` PE por rodada vale `1,01` fatia, pela peça 5 §4.* **`21` de PE por luta no nível 30 dão `5,73` fatias, contra `1,28` do `Quebranto` e `0,73` do `Avulsa`.** ***Decisão do Mizuki: arrancar*** — *"não sei ao certo como balancear"*. **O catálogo ficou em dez e não foi recomposto.**
>
> ***O `Anátema` não estava sem número: estava sem TEXTO.*** *Uma frase — "o contato dela anula técnica amaldiçoada" — num `Classe 3` permanente, sem dizer o quê anula, por quanto tempo, nem se "contato" exige acertar.* ***Decisão do Mizuki:*** **o contato ignora e anula energia amaldiçoada, e como Reação ela anula um feitiço que vem em você, com um Teste de Resistência Físico contra a CD do conjurador.** *A trava é o que segura a entrada: `2,41×` o `Quebranto` com ela, `3,70×` sem.*
>
> **⚠⚠ E a checagem nova acendeu na primeira rodada, num lugar que não era o esperado.** *O `Anátema` entregava `9,03×` o `Contrapeso` dentro da `Classe 3` — mas até o `Quebranto` reprovava contra aquele piso, em `3,76×`.* ***Quando o piso reprova a régua, o suspeito é o piso.*** **O `Contrapeso` vale `+2,0` para quem tem Força `0` a `2` e zero para quem tem Força `3`: ele é condicional à ficha.** *Decisão do Mizuki: ele sai da tabela de preços, e fica declarado sem moeda ao lado do `Insondável`.*

***A v0.151 mexeu em duas linhas de regra que o Mizuki leu e estranhou, e as duas estavam mesmo erradas.*** **O `Incapacitado` era uma condição `Leve` a um `d12` de estourar a própria banda, e o `Cerca` era a única linha de Controle que prendia um alvo sem dizer como aquilo acaba.**

> **O `Incapacitado` dizia *"todo ataque corpo a corpo CONTRA você é crítico"*.** *Como crítico é acerto, a frase lê como acerto automático — e não era isso que a mesa jogava.* ***Decisão do Mizuki: fica "todo ataque corpo a corpo QUE ACERTAR você é crítico"***, que é a forma da fonte, o `Paralisado` do PHB 2024.
>
> **⚠⚠ E o `11,00` publicado da v0.103 à v0.150 não era nenhuma das duas leituras: era metade de uma.** *Ele é `2 golpes × 5,5` de dado extra — conta o dado dobrado em 100% dos golpes, o que só faz sentido se o crítico sempre acertasse, e cobra zero pelo acerto garantido, que sozinho vale `11,50`.* **O preço passa a ser `4,95`, derivado de `2 × (acerto − chance de 20 natural) × dados dobrados`.** *E a frase "segunda mais barata das treze" era falsa desde a v0.103: com `11,00` ela era a quinta.*
>
> ***⚠⚠ O que decide a banda não é o número — é o ESCOPO do crítico.*** *Com só o dado da arma o ganho é `32%` do teto da `Leve`; somando o dano na arma do refino `10` ele vai a `93%`, e com arma `d12`, `99%`; com um `Classe 0` junto do ataque, `190%`.* **A regra da v0.25 era uma LISTA de três exclusões, e o sistema criou duas fontes de dado que ela não nomeava** — o dano na arma do `cobrir-se` (v0.147) e o `Classe 0` da `Fornalha`. *A peça 1 §5.2 passou a dizer **"dobra só os dados do que rolou o acerto"**, e a lista virou exemplo.* ***Palavras dele:*** *"dobrar dado de dano é mt coisa"*.
>
> ***⚠⚠ E o segundo eixo do escopo é QUAL ROLAGEM entra, achado por ele na mesma leva.*** *O sistema tem três rolagens de ataque, e o **feitiço de Toque sai a `1,5 m` e é de conjuração** — "corpo a corpo" sem a linha de exclusão é a palavra que dois mestres leem diferente.* **Um feitiço de Toque `Classe 7` dobrado vale `48,60` de dano por rodada, acima do teto da `Pesada`, vindo de uma condição `Leve`; um `Classe 3` já a joga para `Média`.** *A linha ficou escrita nas quatro cópias, com a sub-checagem `2.1` do `conferir-dano.py` em cima dela.*
>
> **O `Cerca` — Melhoria de Controle, `Leve` — dizia só *"o alvo não consegue se aproximar de você"*.** *Pelo eixo que a régua sabe medir, metros negados, ele vale `5,40` e é `Leve` certinho; pelo eixo que ela não mede, contra um chefe corpo a corpo, ele não custa 9 metros e sim o turno — `24,00` por ação negada, e `72,00` pelas três, contra um teto de `Pesada` de `46,29`.* **Todo vizinho dele tem portão e ele não tinha nenhum.**
>
> ***Decisão do Mizuki: o molde do `Santuário` do 5e*** — *acaba assim que você causar dano ao alvo, inclusive o dano do próprio feitiço que comprou a Melhoria.* **Com isso ela para de combinar dano e proteção na mesma ação, e passa a viver no feitiço que gastou tudo em Controle — que é o que o bônus de Controle já premia.**
>
> **Duas checagens novas, e as duas leem fenômeno e não marcador.** *A `10` do `conferir-atributos.py` cobra o escopo do crítico da **linha de regra** do §5.2, e não da seção — a prosa ali repete as mesmas palavras.* **A `5` do `conferir-manual.py` seleciona as linhas de Controle que seguram um alvo além do instante pelo texto do próprio manual, e cobra que as três nomeiem a saída** — `Terreno`, `Anteparo`, `Puxa` e `Desarma o Feitiço` ficam de fora sozinhos, sem estarem nomeados no validador.
>
> **⚠ E o arnês achou dois defeitos meus antes de eles irem para o commit.** *O recorte da linha de regra pegava "o primeiro bloco de citação da seção", e a seção tem outros — tirar o `>` da primeira linha fazia o recorte pular para o resto e a perturbação saía VERDE.* **E a âncora do dado do soco tinha o valor dentro do padrão:** *`` teto é `d10` ``.* **Trocar o dado para `d12` fazia a âncora sumir e acender pelo motivo errado** — lição nº 8 em miniatura, numa âncora.

***A v0.144 fechou as duas marcas simples do livro, e a segunda mudou de tamanho no meio.*** **Sintonizar uma ferramenta custa um descanso curto**, e o `Avulsa` ganhou gatilho e relógio.

> **A sintonização estava aberta desde a v0.55 — oitenta e oito versões —, e o livro mandava combinar com o mestre.** *Fechada na peça 16 §1.1, no molde do PHB 2024, e **três dos números que essa regra precisaria ter já tinham dono**: o tempo é um descanso curto (peça 10), o teto é estrutural (o §5 daquela peça, mãos mais dois apoios), e o custo em PE é zero — obrigatório, porque a ferramenta é a rota de quem **não tem** energia.*
>
> ***Decisão do Mizuki: o padrão é descanso curto, e a mesa pode subir para longo.*** **Escrito como variante declarada, com o efeito medido ao lado** — no molde da tabela de ritmo de entrega daquela peça, e não como *"acordo com o mestre"*. *Com o curto, a ferramenta achada no meio da missão entra na luta seguinte; com o longo, ela serve na próxima missão.*
>
> **⚠ Uma cláusula do PHB foi lida e RECUSADA:** *lá, desfazer a sintonização não vale se o item for **amaldiçoado**.* **Aqui toda ferramenta é amaldiçoada, e a palavra quer dizer outra coisa** — lá é *maligno*, aqui é *feito de energia amaldiçoada*. *Importar tornaria toda ferramenta permanente, e a Maki troca de arma o tempo todo.*

> ***E o `Avulsa` não era "só um relógio".*** *O prompt previa o molde da `Classe Passiva 2` — `maestria`× por cena.* **Ele reprova por dois lados que só apareceram na conta:** *vale `1×` do nível 7 ao 9, que é onde a Classe 2 abre e onde o filtro de dominância acusa; e do 26 em diante pede `4` usos contra um teto de `3,7` Reações por luta, virando letra morta.*
>
> ***Decisão do Mizuki: `2×` por cena.*** **É o único relógio que passa no filtro de `3,00×` em todo nível e ainda morde de verdade.** *O gatilho reusa máquina que existe: o ataque de oportunidade dispara quando alguém **sai** do seu alcance, e este quando alguém **ataca** você dentro dele.*
>
> **⚠⚠ E a medida destampou uma dívida, que a v0.152 pagou com o escopo trocado.** *Ela estava escrita como "os onze `Estigma` nunca foram preçados uns contra os outros", e essa comparação a peça 11 §4 proíbe.* **O `2×` do `Avulsa` foi escolhido justamente por passar contra o `Quebranto` medido no melhor caso dele, e o repreço não moveu este número.*

> ***E as marcas de "isto ainda não existe" ganharam CONTAGEM COM DONO, porque cinco contagens deram cinco números.*** *O prompt de retomada dizia quatro, o CHANGELOG da v0.136 dizia cinco, a varredura à mão desta conversa disse oito, e o regex acha sete.* **Nenhuma delas tinha validador.**
>
> **Hoje a `REGRA-DE-VOZ.md` declara o número e a FRONTEIRA — o que conta e o que não conta —, e o `conferir-voz.py` reconta e falha nas duas direções:** *marca nova que entra sem ninguém ver, e marca fechada sem o número descer junto.* **São `7`.** *Vaga declarada e variante de mesa não contam, e o motivo está escrito ao lado do número.*

***O `PETRIFICADO` SAIU na v0.139, e são treze condições.*** **Decisão do Mizuki:** *"ela segue um balanceamento que não planejo ter no sistema"*. **Seis `Leve`, duas `Média`, cinco `Pesada`**, e o manual do Fundamento foi para a **v7.12**.

> **Ele era a mais cara da régua da peça 19** — `19,73` fatias, `217%` do teto da `Pesada` —, e o argumento que ele carregava (*condição acima do teto é mais de uma condição escrita como uma*) **passou para o `Impedido`**, que é o `Cego` inteiro mais deslocamento `0`.
>
> **⚠⚠ E a tentativa de refazer o corte de degraus REPROVOU, com o resultado que parecia melhor.** *Com treze, a busca exaustiva acha uma partição de `2,44×` contra os `4,26×` publicados — subindo o `Lento` e o `Incapacitado` para `Média`.* **Ela quebra a checagem 3, que é o invariante da peça:** *o `Lento` vale `14,70` e o `Incapacitado` valia `11,00` contra um teto de `Leve` de `15,43` — os dois cabiam em `Leve` pela conta, e cobrar `Média` por eles é cobrar caro.* **A v0.151 refez o `Incapacitado` para `4,95`, e isso só reforça:** *ele passou a caber em `Leve` com `68%` de folga.* ***A partição não é escolha livre: a banda obriga ela.*** **A busca mediu espalhamento, que é livre; a peça mede banda, que é derivada.**
>
> **E a Restrição `Lento` virou `Atrasar` na mesma versão**, porque o nome era duas regras ao mesmo tempo: a Restrição de Ação Completa e a condição de deslocamento pela metade. *A condição fica com o nome.* **Nenhum número mudou — os 35 feitiços prontos, o `Ampliar` e as três Liberações Máximas passaram no `pac7.py` depois da troca.**
>
> **⚠ E o fecho achou treze lugares ainda escrevendo `catorze`, com os 22 validadores verdes e `PULADA = 0`.** *Prosa não tem dono: a checagem 9 do `conferir-repositorio.py` confere contagem de arquivo, não contagem escrita em frase.* **Junto foi a paginação do `.pdf` do manual, publicada como `46` no `README` e aqui quando ela é `49` desde antes da v0.137.**

***PACTOS FECHOU na v0.134, e é a peça 22.*** **A quinta camada de personagem, e a última que faltava ter régua** — o Passo 8 da peça 8 prometia ela desde a v0.21, o que dá cento e treze versões.

> **Quatro formas, e só uma tem teto.** *Permanente, temporário, `Promessa` e de restrição.* **O permanente é o único que atravessa mesa**, e o teto dele é `metade da Essência` arredondando para baixo, sem piso — `0 · 0 · 1 · 1 · 2 · 2 · 3` na escala inteira.
>
> **⚠ E a exceção ao arredondamento da peça 1 §5.4 é de UMA linha, e não de duas.** *Aquela seção já escreve o limite do próprio piso — "ele existe para o caso em que a conta produziu 0,4, não para desfazer um zero escrito".* **Essência `0` dá zero pela conta, e o piso já não a alcançava; só a Essência `1` é exceção de verdade.** *Uma linha é mais barata de declarar do que duas, e o texto que declarava as duas cobrava por uma que a peça 1 já resolvia sozinha.*
>
> **O teto por pacto é `0,50` fatia, e ele é DERIVADO:** a camada de `1,50` dividida pelos três pactos do pior caso, que é a Essência no teto. *`2,54` de dano por rodada, que é `21%` de um golpe simples no nível 30.* **O orçamento não existe para preçar pacto — existe para fazer com que preçar pacto em dano não valha a pena.**
>
> **⚠⚠ E indo escrever apareceu que duas das quatro coisas que um pacto pode dar precisam de tratamento OPOSTO.** *A decisão da v0.133 lista PE, aptidões, feitiços e estilos.* **PE tem preço em fatia — `1` PE por rodada vale `1,01`, pela peça 5 §4 — e passa pelo teto. Aptidão NÃO tem preço, e não pode ter:** *a régua de "uma aptidão a mais" é a que matou a Trilha `Repertório` na v0.81, porque ela vale a Trilha inteira para quem nunca escolhe Refino e um sétimo para quem sempre escolhe.* **Fica escrito com todas as letras para ninguém tentar de novo.**
>
> **⚠ E o `estilo` não era o que eu estava medindo.** *Eu preçei os estilos de luta do `Executor`, que custam de `0,33` a `0,79` fatia, e três dos cinco estouram o teto de um pacto.* ***Correção do Mizuki: são os do `Estilo da Sombra`, e só `Sem Técnica` alcança eles.*** **Aquela peça não existe, então o §3.5 escreve um contrato em vez de um número** — no molde do teto de Defesa da peça 14 §3, em que a peça que chega depois obedece.
>
> **O catálogo leva os exemplares da obra mais as ideias de restrição, e nenhum dos dois é lista fechada.** *A fonte rendeu quatro exemplares que o rascunho não tinha — `Mostrar a mão`, que é a forma temporária mais comum da obra inteira; o Yuta com os superiores, que prova que a segunda parte pode ser uma instituição; e o Kenjaku com os feiticeiros antigos, que é literalmente o Pacto que a peça 21 §3 tinha achado e mandado para cá.* **São oito exemplares e oito ideias.**
>
> **⚠ E a lista do amigo tinha oito, e não nove.** *O rascunho dizia "as nove ideias" no título e a tabela tinha oito linhas.* ***Confirmado com o Mizuki: eram oito mesmo.***
>
> **O `conferir-pactos.py` tem catorze checagens e nenhum valor escrito dentro.** *A checagem 2 é o par declarado, e ela mede RELAÇÃO: o `0,50` é recalculado como `camada ÷ (teto de atributo ÷ 2)`.* **Dezessete perturbações acendendo a checagem dona e três contra-testes verdes**, em cópia isolada, com a base conferida antes de cada uma e o `diff` conferido. *O contra-teste que importa muda a camada e o teto juntos, de forma coerente, e a checagem 2 fica verde de propósito.*
>
> **⚠ E a checagem 9 nasceu medindo o marcador em vez do fenômeno.** *Ela perguntava se as palavras `acerto`, `Defesa` e `perícia` aparecem numa linha de proibição — e aparecem, porque o §3.4 é essa linha.* **Pôr uma entrega de `+1` de Defesa noutra seção saía VERDE.** *Hoje ela procura a promessa e não a proibição.*

***A pendência mais velha da peça 6 fechou na v0.131, e ela estava aberta desde a v0.14 — cento e dezessete versões.*** **Como a `Torrente` cobra o segundo feitiço da rodada, contra a regra de ouro nº 6.**

> **As três coisas que a pendência afirmava reprovaram.** *Não existe moeda nova — ela cobra em PE, no preço que o manual já dá para a Melhoria `Rápido`. Não é o mesmo defeito da invocação — aquilo é **corpo** a mais, e corpo multiplica. E o conserto de lá não serve:* **no nível 30 o teto somado deixa `14` de folga, e a regra de ouro nº 6 sozinha já permite um `Classe 0` de `27`.** *Ele é mais apertado que a regra que ia vigiar.*
>
> **A `Torrente` usa a Ação Padrão e a Ação Bônus que a ficha já tem, e o número de feitiços por rodada trava em DOIS, em todo nível, para sempre.** *Não existe a escada que o teto somado foi escrito para segurar.* **O que ela é de verdade: a primeira coisa do sistema que faz a regra de ouro nº 6 trabalhar** — a peça 6 §3 já media que ninguém alcança o segundo feitiço pelo Fundamento.
>
> **⚠⚠ E a medida cobrou preço: o `Acelerar` do nível 2 estava publicado em ZERO fatia.** *Ele libera a Ação Padrão, e um `Classe 0` de `27` cabe nela — o que o CHANGELOG da v0.81 já preçava em `5,31` fatias por rodada, ou `2,87` à taxa de `54%` do relógio dela.* **A varredura do `Classe 0` fantasma daquela versão listou cinco entregas recalculadas e essa não entrou.**
>
> ***Decisão do Mizuki: corrigir o preço e o estouro fica.*** **A Trilha foi de `4,65` para `7,52` de `5,00` — `+50%`, abaixo do piso da `Brasa`, que está entre `+41%` e `+88%` e ficou.** *E a dominância inverteu de sentido sem ninguém mexer no desenho: era o `Explosivo` sobre a `Torrente` por `1,20×`, virou a `Torrente` sobre o `Explosivo` por `1,35×`, dentro do filtro de `3,00×`.*
>
> **⚠ A `Vazão` não entregava nada nos níveis 11 e 12.** *O `Classe 0` cresce por faixa de nível e ela cresce por Classe: no nível 11 o teto dela é `13` de dano e o `Classe 0` já é `18`.* ***Decisão dele: cláusula de piso*** — o teto nunca fica abaixo do `Classe 0`. **Custa `0,00` fatia no nível 30.**
>
> **E a exceção ganhou ponteiro.** *A regra de ouro nº 6 era publicada como absoluta em cinco lugares e a exceção morava num sexto que nenhum deles citava.* **Entrou a §6.1 da peça 3 e uma linha no capítulo 2 do livro, `O Turno`.** *Este ponteiro dizia "capítulo 11" até a v0.139, lendo o prefixo do arquivo `11-o-turno.md` como número de capítulo — e o capítulo 11 de verdade é `Aptidões e Refino`, que não tem uma ocorrência de `Torrente`.*
>
> **Entrou a checagem 12 do `conferir-catalogo.py`, e o buraco dela é de outra espécie:** *toda checagem de cópia deste projeto compara número contra número; esta pergunta se o número **existe**.* **O `(a base)` daquela célula aparecia uma vez no `DESENHO-trilhas.md` inteiro.** *Cinco perturbações acendendo e três contra-testes verdes. A contagem foi de `204` para `205`.*

***A v0.135 fechou três achados do Mizuki lendo, e nenhum deles era de Pactos.*** *Os três encostam na rota que não tem energia amaldiçoada, e o terceiro abriu um buraco que ninguém tinha visto.*

> **As Passivas da Técnica Marcial não tinham exemplo.** *A tabela do §3 da peça 20 dizia `igual` e parava ali, e os exemplos do Fundamento são todos de energia amaldiçoada.* **Entrou a §3.3 daquela peça e a seção `Passivas` do capítulo 10, com sete exemplos.** *Dois deles — o `Raiz` e o `Leitura` — já estavam publicados dentro das duas Técnicas Marciais prontas, e em lugar nenhum como exemplo.*
>
> **A `Defesa sem Armadura` desligava demais.** *O livro dizia que ela sai de cena quando entra Traje ou Revestimento, e ela tem três linhas.* ***Achado dele: só a proteção cai.*** **As outras duas vêm de não ter energia amaldiçoada, e uniforme não dá energia a ninguém.**
>
> **⚠⚠ E o que atravessa é VOCÊ, e não o que você carrega.** *Ferramenta e objeto amaldiçoado emanam energia, e é o que eles emanam que a barreira lê:* **o restringido entra na `Cortina` e o equipamento amaldiçoado dele fica de fora.** *Escrito na peça 9 §5, que é a dona das duas linhas.* **Contra Expansão não vale — o Acerto garantido lê alvo, e item não é alvo.**
>
> **A saída é o `Bocado`, Classe Passiva 1, na peça 20 §3.3** — o item vive dentro do corpo e para de emanar, e você saca ou guarda **dois** itens de graça por turno.
>
> **⚠⚠ A altura dela não foi escolhida: ela estava escrita há doze versões.** *A peça 3 §3.2 fechou na v0.122 dizendo que "uma Passiva ou aptidão pode dizer que o segundo saque sai de graça, e ela cabe na Classe Passiva 1".* **Aquela linha ficou doze versões sem exemplar, e este é o primeiro.** *Quarto exemplar do mesmo padrão em vinte versões — o projeto procurando um número que já tinha dono.*
>
> **⚠ E a triagem matou dois nomes, um deles dando `LIVRE`.** *`Segunda Natureza` saiu `OCUPADO` — é Passiva no manual — e virou `Aliança`.* **`Bolso` saiu `LIVRE` e reprovou por SENTIDO: o projeto usa "bolso" para o orçamento de PE em dez lugares.** *Colisão de sentido continua fora do alcance da triagem.*
>
> *A checagem 13 do `conferir-marcial.py` mede a relação e não o `2`: quatro perturbações acendendo e um contra-teste verde.*

***Decisão do Mizuki na v0.130: as DUAS variantes ficam, e o `--duas` continua sendo opção do `build.py`.*** *Não é pendência — é escolha declarada. O que ela custa está escrito abaixo.*

> | | páginas | o que ela é |
> |---|---|---|
> | `-A-atual` | **256** | o que estava publicado na v0.125. Snapshot guardado a mão, não se regera |
> | *(sem sufixo)* | **248** | a mesma, com as quebras de página consertadas e o sumário em duas colunas |
> | `-C-duas-colunas` | **141** | corpo em duas colunas a 9,4pt com entrelinha 1,45, e grade de 5+ colunas em largura inteira |
>
> **A geometria da C foi medida em três manuais do hobby, e não escolhida:** *Guia do Mestre 5e em A4, Caldeirão de Tasha e PHB 2024 — `83%`, `92%` e `92%` das páginas em duas colunas, com corpo entre `9,1` e `9,3pt`.* **A mancha copiada é a do Guia do Mestre, que é o único dos três em A4.**
>
> > **⚠ O preço de manter as duas é procedimento:** *toda mudança de texto obriga rodar os **dois** builds, e a entrega tem de escolher qual das duas publica.* **Hoje ela carrega a de coluna única**, e é essa que vai para `finalizado/livro/`. *Se um dia a escolha fechar, ela vira uma linha do `build.py` e a outra some.*
>
> **⚠ E o WeasyPrint 69 não implementa `column-span: all`**, medido com caso mínimo. *Por isso a tabela larga é tirada do fluxo de colunas no `build.py`, em `segmenta_colunas`, e não pelo CSS.*

***A v0.129 leu o livro inteiro com os olhos, e as três frases do Mizuki eram amostra de três famílias que apareceram em 15 dos 20 capítulos.*** *`79.711` para `76.870` palavras, em três passadas, e nenhum número de regra se moveu.*

> **As três famílias:** *metáfora no lugar da regra* (a Vanguarda "comprando aço"), *aviso escrito de trás para frente* ("nada disto morde"), e *contabilidade do projeto vazando para o livro* ("oito das nove rotas já rodam").
>
> ***Decisão dele, e ela abriu uma quarta:*** *"todo canto q tiver apresentação de informação, 'é balanceado por isso', comparativo e afins (…) pode REMOVER"*. **A régua do `REMOCOES-material-de-mestre.md` é de v0.106 e a v0.125 só a tinha aplicado em dois capítulos; esta aplicou nos outros dezoito.**
>
> **⚠⚠ E a leitura achou duas frases que tinham virado MENTIRA, sem ninguém mexer nelas.** *O capítulo 6 dizia "a Trilha ainda não entrega número" enquanto o capítulo 8 tem `19` blocos de nível escritos; e o capítulo 7 dizia que o segundo Legado do Reencarnado sai do `Destranca` ou do `Ajusta`, cinco versões depois de a v0.124 escrever o `Usado`, que é `Desliga`.* **Nenhuma regex acha as duas: as duas estão gramaticalmente perfeitas e falam de um estado do projeto que era verdade quando foram escritas.**
>
> ***É a terceira vez que este projeto registra o mesmo:*** *a v0.125 mediu duas réguas contáveis que passaram nos dois capítulos errados, a v0.126 cortou uma família e deixou o resto dela, e agora a v0.129 acha, lendo, o que as duas passadas deixaram.* **Decidir se uma frase é fato mal-vestido ou enfeite continua fora do alcance do validador, e a `REGRA-DE-VOZ.md` já declara isso.**

***As duas listas de perícia da Restrição Celestial FECHARAM, e ela é a primeira Origem com lista por RAMO.*** **`corpo pela técnica` tira quatro do poço Inteligência + Essência; `sem energia` tira quatro do de Destreza + Força.** *O Corpo Amaldiçoado ganhou a dele a dedo, no molde das cinco principais — decisão do Mizuki, porque ele não tem dois ramos para separar.*

> | Origem | lista |
> |---|---|
> | **Restrição Celestial · corpo pela técnica** | `Sentir Energia` · `Tecnologia` · `Ocultismo` · `Percepção` |
> | **Restrição Celestial · sem energia** | `Atletismo` · `Acrobacia` · `Furtividade` · `Pontaria` |
> | **Corpo Amaldiçoado** | `Atletismo` · `Percepção` · `Ocultismo` · `Intimidação` |
>
> ***O ramo sem energia é a primeira lista física do projeto:*** *das vinte e três perícias, só a `Furtividade` aparecia numa lista de Origem.* **O poço dele tem exatamente cinco, e a lista leva quatro — sai a `Prestidigitação`.**
>
> **⚠⚠ E o arnês achou que a lista de Origem morava DENTRO do validador.** *O `conferir-pericias.py` carregava as cinco escritas à mão e a mensagem de erro dele dizia "e a peca 09 diz quatro" — ele afirmava a regra da peça e guardava o dado dele mesmo.* **Hoje ele lê da peça, com guarda de contagem de `8` listas.** *Mesmo defeito que a v0.42 consertou para os ofícios, na peça vizinha.*
>
> **⚠ E o contra-teste que importava saía VERDE:** *a peça nega `Sentir Energia` ao ramo sem energia com todas as letras, e o poço a excluía **por acaso**.* **Entrou a checagem 5.1.1, que lê a negação do texto da peça em vez de guardá-la.** *Oito perturbações conferidas em cópia isolada, contra-teste incluído. A contagem não se moveu — sub-bloco conta para o bloco pai.*

***O LIVRO ALCANÇOU A FONTE na v0.124, e ele estava cinco versões atrás.*** **Dois capítulos entraram — `Técnica Marcial` como o 10 e `Bênçãos e Lapidação` como o 12 —, e o Manual da Guilda foi de 15 para 17 capítulos.**

> **E a v0.125 cortou os dois ao molde do resto do livro, por achado do Mizuki lendo o PDF:** *frase de efeito abrindo o mecânico, texto inicial sem regra dentro, e tabela mostrando o que o jogador não precisa ver.* **Os dois capítulos foram de `5.597` para `3.785` palavras, e o livro fechou em `79.362` palavras e `256` páginas.**
>
> ***E as duas réguas contáveis que eu tinha passavam:*** *prosa antes da primeira regra dava `0` e `116`, contra máximo `128` nos já polidos; proporção de prosa solta dava `56%` e `55%`, contra mediana de `48%`.* **O defeito era de espécie e não de quantidade — que é o que a `REGRA-DE-VOZ.md` já declara fora do alcance do validador.**

> ***As duas posições são decisão do Mizuki, e a conta foi levada medida:*** *colar a Técnica Marcial no Fundamento custava `44` mudanças de número contra `9` no fim de "O personagem".* **Ele pagou a mais cara pelo argumento do leitor** — quem monta Corpo Amaldiçoado lê o Fundamento, vê que não serve, e a alternativa está na página seguinte. *O prefixo dos arquivos-fonte tem folga, então nenhum arquivo foi renumerado; o que desloca é o número impresso do capítulo, e ele desloca do 10 em diante.*

> **⚠⚠ E apareceu um achado que não estava na lista de dívidas: a v0.117 mudou a base de acerto e o livro ficou com a fórmula velha em CINCO lugares.** *A lista da v0.123 media termo ausente; isto é número publicado errado.* **O mais claro é o `CD de feitiço | 13` do capítulo de criação: `13` é `10 + 2 + maestria`, a CD que aquela versão aposentou** — um número solto onde as linhas vizinhas são fórmula. *Junto com ele, o Teste de Resistência com `+2` em dois lugares, o parágrafo dizendo que a maestria fica FORA do Teste de Resistência, e as três linhas de ataque sem o `+ 1`.*

> **Entrou a checagem 10 do `conferir-repositorio.py`, com seis sub-blocos e onze perturbações conferidas.** *A checagem 7 pergunta se o **recorte** da entrega está atualizado; a 10 pergunta se o **conteúdo** do livro bate com as peças.* **São perguntas diferentes, e até aqui só uma tinha dono — a mesma forma do achado da v0.121, por outra porta.** *A contagem foi de `202` para `203` checagens.*
>
> *A 10.1 é a lição nº 9 na forma mais crua que este projeto já teve:* **`build.py`, `build_docx.py` e `conferir-voz.py` carregavam a ordem dos capítulos cada um por conta, e nada comparava os três.** *Capítulo novo entra em um e some dos outros dois.*
>
> **⚠ E três perturbações saíram VERDES na primeira rodada, pelo mesmo defeito: elas eram menores do que o conjunto que a checagem mede.** *Trocar uma ocorrência de `Lapidação` num livro que tem `43`; renomear um capítulo quando o piso conta `69` referências.* **É a família do achado da v0.122 — `diff` que pergunta "mudou?" em vez de "a minha mudança entrou?".**

> ~~**⚠ Fica uma pergunta aberta na peça 11: a `cobrir-se` portada das Bênçãos não herda a Reação.**~~ ***FECHADA na v0.165: ela herda.*** *Decisão do Mizuki, e ela não inventa número — é a mesma substituição da proteção, refino por Lapidação, com o mesmo `1,5 ×` e o mesmo custo de `2` PE.* **O que segurava a pergunta era o lado da economia, e ele abriu na v0.120**, quando `PE` passou a ler `Pontos de Esforço`. *O texto de antes fica abaixo:*
>
> **A pergunta era de regra e não de sabor: a `cobrir-se` portada das Bênçãos não herdava a Reação.** *A do feiticeiro tem duas metades — proteção passiva, e a Reação de `1,5 × refino` de Redução de Dano por `2` PE. A §6.8 porta só a primeira, e não diz nada da segunda.* **O livro foi escrito fiel à fonte; inventar a Reação lá seria pôr no livro um número que peça nenhuma é dona.** *A rota tem `PE` para gastar desde a v0.120, então a porta está aberta pelo lado da economia.*

***A TÉCNICA MARCIAL FECHOU na v0.122, e é a peça 20.*** **As rotas de Origem foram de `6/9` para `8/9`** — Corpo Amaldiçoado e Restrição Celestial pelo ramo sem energia. *A nona é `Sem Técnica`, e **decisão do Mizuki: ela tem criação própria e vem depois**.*

> **Ela é o Fundamento com o corpo no lugar da energia, e não tem número novo nenhum.** *Pontos são `3 × Classe`, o PE é o mesmo número, o que sobra de ponto vira `1d8`.* **O que muda é a criação: onde o Fundamento escreve um Selo, ela escolhe três grupos de arma ou uma ferramenta sob medida.**
>
> **Três renomes:** *`feitiço` virou **`Kata`** (型), `Liberação Máxima` virou **`Ruptura`**, e `Técnica Máxima` virou **`Ōgi`** (奥義).* **A Expansão de Domínio não ganhou substituto — ela não existe nesta peça, e a negação é da peça e não da Origem.** *O Corpo Amaldiçoado TEM energia, então a decisão da v0.118 sozinha não alcançava ele.*
>
> **O Selo virou equipamento, e é isso que resolve ferir maldição:** *toda Kata passa pelo equipamento, e o equipamento é ferramenta de grau 4.* **Sobra o golpe simples, e aí depende do objeto** — decisão do Mizuki, declarada numa linha da ficha na criação.
>
> **⚠ E o Selo-equipamento põe a ficha inteira atrás de uma condição de nível `Leve`.** *Contra uma marcial de arma única, o `Desarmado` valeria `19,4×` o preço que a peça 19 publica, contra um filtro que reprova em `3,00×`.* **É por isso que os grupos são TRÊS** — a Kata vale com arma de qualquer um deles, e a condição tira uma.
>
> **E três grupos não dão Manha.** *Três Manhas médias somam `2,93` fatias, que é `97,6%` de um Caminho inteiro entregue antes do nível 3.*

> **⚠⚠ E a triagem era cega para o catálogo de Legados inteiro.** *`77` de `97` nomes saíam `LIVRE`, porque o `conferir-nomes.py` carregava uma lista escrita à mão com **catorze** — os que moravam na peça 9 antes de a peça 13 existir, na v0.39.* **Ela quase deixou `Talhe` — que é Legado do Feto — ser batizado de novo nesta versão.** *Consertado: ele lê do dono, no mesmo molde que já usava para as perícias.*

> **⚠⚠ A entrega ficou CINCO versões sincronizada no disco e não commitada, e nenhum validador acusava.** *O último commit do repositório do PDF era o recorte da v0.115, com quinze arquivos parados.* **A checagem 7.1 compara md5 e responde *"o recorte está atualizado?"* — a resposta era sim.** *Ela nunca perguntou se ele tinha sido commitado, e são perguntas diferentes.* **Achado pelo Mizuki, perguntando se não ia commitar no outro repositório também.**
>
> *Fechado pela **checagem 7.4** da v0.121: ela lê o git da `finalizado/`, acusa mudança pendente, e compara a versão do último commit contra o topo do `CHANGELOG`.* **Ela PULA em vez de falhar quando não consegue ler o git**, e o rodapé diz que pulou.

***Decisão do Mizuki na v0.120: `PE` passa a ler de dois jeitos — `Pontos de Energia` e `Pontos de Esforço`.*** *A sigla é a mesma no livro inteiro, e nenhuma regra pergunta qual das duas você tem.* **Isso fecha a última pergunta que a Técnica Marcial ia herdar:** *ela atende duas rotas com economias diferentes — o Corpo Amaldiçoado tem energia, a Restrição Celestial sem energia não —, e a alternativa era inventar uma moeda com nome próprio.* **Aí toda habilidade de Caminho que cobra `PE` precisaria de segunda redação, e são quatro Caminhos com kit que cobra PE.** *Com uma sigla só, nenhuma precisa.*

> **✔ O repreço do catálogo FECHOU na v0.119, e ele era menor do que parecia.** *A v0.117 mudou três constantes de preço, e a v0.118 registrou o escopo como "as 90 entradas da peça 17".* **Medido: são SETE entradas.**
>
> | entrada | antes | depois |
> |---|---|---|
> | `Punho` nv2 `Engate` · nv27 segundo soco | 1,70 | 1,81 |
> | `Punho` nv11 `Derrubado` | 0,56 | **0,46** |
> | `Punho` nv27 vantagem | 0,28 | 0,34 |
> | `Estocada` nv27 `Ferrão` | 1,33 | **1,61** |
> | `Brasa` — vantagem no Classe 0 | 1,12 | 1,19 |
> | Manha `Encaixe` | 1,00 | 1,06 |
>
> **O `Derrubado` é o único que DESCE** — a falha de Teste de Resistência caiu de `45%` para `35%` contra o alvo treinado, e essa queda é maior que a subida do acerto. *Nos totais: `Punho` `4,94` → `5,12`, `Estocada` `5,02` → `5,30`.*
>
> **O que encolheu o escopo foi separar as taxas que SÃO o acerto das que só parecem.** *O `75%` do `Revide` é a chance de um ataque inimigo te alcançar — economia de ação do chefe. O `50%` do `Talho` e do `Palmo` é taxa de cenário. Os `60/28/44%` das outras Manhas são gatilhos próprios.* **Nenhum deles se move.**
>
> ***Decisão do Mizuki: medir e NÃO aplicar.*** *As três Trilhas continuam dentro da banda que o projeto já aceita — a `Brasa` está entre `7,06` e `9,42` e ninguém reclamou.* **A conta fica no `CHANGELOG` da v0.119; os números publicados ficam como estão.**
>
> **E fica uma pergunta que a v0.119 não responde:** *a fatia (`5,08`) foi calibrada contra dano evitado e não se move; mas o **orçamento** de `5` fatias por Trilha foi fixado como fração do que o personagem faz, e o que ele faz subiu com o acerto novo.* **Se o orçamento subir junto, os três estouros somem sozinhos** — e mexer nele reabre a v0.73 inteira.

**A v0.118 escreveu as Bênçãos como CONTRAPARTE, e o Mizuki corrigiu o que a v0.116 tinha entendido errado.** *Aquela versão delegou as duas vagas gratuitas inteiras para fora do catálogo — proteção para o uniforme, o resto para a ferramenta — e concluiu "doze entradas, nenhuma gratuita".* **O ponto nunca foi espelhar nem delegar: era ser a contraparte, com o mesmo peso e o mesmo lugar na ficha.**

> **Catorze Bênçãos: duas grátis na Lapidação `1` e doze pagas.** *A FORMA espelha o catálogo de aptidões espaço por espaço, mesmo o conteúdo não espelhando quase nada.*
>
> **`Cobrir-se`, portada sem inventar número:** `1/3 da Lapidação + 1`, a mesma fórmula com outro recurso. *Não move o teto de Defesa da peça 14 §3 — é a mesma função na mesma faixa —, e fecha o buraco que aquela peça registrava desde a v0.48.*
>
> **`Estímulo Muscular`, conteúdo novo:** escolha uma perícia e um Teste de Resistência na criação; **`1×` por cena, e `2×` na Lapidação `10`**, cada uso dando vantagem. ***Decisão do Mizuki: ela não nasce valendo zero***, porque o `canalizar` em golpe vai ganhar mecânica quando a Técnica Marcial chegar.
>
> *Ela chegou a ser escrita como `1/5 da Lapidação, mínimo 1` — que é a mesma coisa vestida de fórmula, porque o piso carrega a `1` à `9` e o divisor só age no `10`.* **Letra morta, no mesmo molde do arredondamento do `Servo` da v0.68.** *Se um dia precisar escalar de verdade, o divisor é `1/4`.*

**Os três números saem de regra que já existe:** *frequência é eixo legal para o refino escalar (peça 11 §2); "uma perícia nomeada, um Teste de Resistência nomeado" é literalmente a forma que a peça 10 §5 declara segura para `por cena`; e o piso de `1` é o arredondamento da peça 1 §5.4.*

> **⚠ E "escolha um atributo" reprovou com número.** *Era a forma mais elegante, e o quadro da peça 7 §2 a derruba: Força `1` perícia, Destreza `4`, Essência `7`, Inteligência `11`, Constituição `0`.* **Espalhamento de `11` para `0` numa entrada gratuita.**

**Entrou o SEXTO formato de gate: requisito de atributo.** *Ele existe para as doze pagas se separarem dentro de uma Origem só, e o preço dele está medido na peça 1 §5 — uma ficha tem `16` a `23` pontos e enche dois ou três atributos de cinco.* **A trava: uma Bênção gateada num atributo não pode somar aquele atributo na rolagem dela** — ou você paga para destravar, ou usa na conta, nunca os dois.

> **E o atributo do gate decide a FORMA da entrada, não só quem entra.** ***Achado do Mizuki:*** *habilidades gateadas em Constituição não podem envolver perícia.* **O quadro da peça 7 §2 obriga:** Inteligência tem `11` perícias, Essência `7`, Destreza `4`, **Força `1` e Constituição `0`.** *Quanto menos perícias o atributo tem, mais a entrada tem de ser **feito** em vez de rolagem — e numa gateada em Constituição, feito é a única forma possível.*
>
> **O levantamento externo concorda:** *em D&D os dois feats de Constituição — `Tough` e `Durable` — não tocam em teste de perícia nenhum: são vida, salvaguarda de morte e recuperação.* **E a obra pede o mesmo** — a Restrição Celestial do Toji é `sheer physical prowess`, não perícia. *A trava fica escrita: **uma Bênção gateada em Constituição ou em Força não pode ser bônus, vantagem ou rerrolagem numa perícia.***

***E o ramo mudou de nome: `energia pelo corpo` virou `sem energia`.*** *O nome antigo prometia corpo, e com gate de atributo um restringido de Inteligência alta é ficha legítima.* **O que a Origem fixa é a perda, não o que você constrói em cima dela.** *O outro ramo continua `corpo pela técnica`, e a assimetria é de propósito.*

**A `Bênção Própria` é a mesma máquina da `Aptidão Própria`:** *uma vez na ficha inteira — dos dois lados —, `Classe Passiva 1 ou 2, nunca 3`, sem valor numérico próprio.*

> **E o tamanho das duas listas é derivado, não fixo — o Mizuki já registrou que pretende acrescentar aptidões ao catálogo do feiticeiro.** *As doze pagas saem de uma conta só: a rota pura precisa de `10`, e o catálogo carrega `+2` de folga.* **Se o catálogo do feiticeiro crescer, a folga cresce e o piso de `10` não se move.**

**As doze Bênçãos pagas foram escritas, e o catálogo fechou.** *`Ímpeto` · `Casco` · `Faro` · `Presilha` · `Vulto` · `Sem Pegada` · `Antecipar` · `Assombro` · `Vigília` · `Campo` · `Esteio` · `Bênção Própria`.* **Cinco gates, um por atributo — o teto que a conta permite.**

> **A rota pura de Lapidação não escolhe `Corpo` nenhuma vez, então ela tem `16` pontos de atributo e o arranjo `6/6/4/0/0`: passa em três gates de cinco.** *Ela precisa de `10` picks de `12`, e com cinco gates ela alcança exatamente `10`.* **Acima de cinco ela deixa de fechar** — gatear as doze a deixaria em `7`.

> ***Decisão do Mizuki: cinco gates, separação máxima e folga zero***, contra a alternativa de três, que devolveria a folga de duas entradas mas deixaria dois atributos sem cor.

> **⚠ A triagem reprovou cinco dos onze nomes que eu tinha escolhido.** *`Passo`, `Trava` e `Peso` são Melhoria e Tema no manual; `Fôlego` mora dentro de `Roubo de Fôlego` e `Fundo` dentro de `Limpa Fundo`.* **E o `Sem Rastro` também caiu: `Rastro` é Melhoria.** *Trocados por `Ímpeto`, `Presilha`, `Assombro`, `Vigília`, `Esteio` e `Sem Pegada`, os seis conferidos livres nas duas direções.*

***E o `cobrir-se` deles carrega duas coisas que o do feiticeiro não carrega:*** **barreira de energia não os segura, e o Acerto garantido de uma Expansão completa não os alcança.** *Em troca — e a troca é declarada — **quem não tem energia nunca tem Expansão de Domínio**.* **Isso não passou por régua de preço: é decisão do Mizuki, e é o que a Restrição é na obra.** *A `Liberação Máxima` e a `Técnica Máxima` ganham substituto quando a Técnica Marcial chegar; a Expansão não ganha.*

> **⚠⚠ E a v0.118 achou que a contagem de checagens estava mentindo para baixo.** *O `conferir-aptidoes.py` tinha dois blocos numerados `6` desde a v0.104, e a checagem nova da Lapidação nasceu como um segundo `7`.* **O extrator usa `set()`, então número repetido é comido em silêncio — e a guarda que existia procurava BURACO, que repetição não abre.** *A contagem real era `190` e não `188`.* **Entrou a guarda `0` da checagem 9, e os blocos do `conferir-aptidoes.py` foram renumerados de `1` a `9`.**

**A v0.116 fechou as três pendências que a v0.115 levantou, e as três fecharam por medida em vez de por decisão.** *O gate Origem × Caminho não era gate; o catálogo das Bênçãos não podia espelhar; e a regra de Pactos já tinha três quartos escritos, no manual.* **E a pergunta do Mizuki sobre as rolagens de conjuração destampou uma frase errada que estava em três documentos desde a v0.9.**

**A v0.117 refez a base de acerto do sistema, e o que a destravou foi uma observação de mesa do Mizuki:** *"a Defesa vai estar chegando em picos de 20-22"*. **Ele está certo, e a peça 1 media contra um alvo de Defesa 17.**

> **⚠⚠ O acerto derivava `−15pp` na campanha, e nenhum validador via.** *A peça 11 §6 diz que a proteção de cobrir-se é `1/3 do refino + 1`, e a peça 14 §3 deriva o teto de Defesa em `20` somando os `4` dela no refino `10`.* **O `conferir-atributos.py` segurava a proteção em `1` — o valor do nível 2 — desde a v0.8.** *Com o alvo certo, a Defesa cresce `+6` na campanha (Destreza `+3`, proteção `+3`) e o acerto crescia `+3`: `50%` no nível 2 e `35%` no 30.*
>
> **É a lição nº 1 pela terceira vez, e a própria peça denunciava:** *o §7 dela lista "atributo, **proteção**, equipamento" como o que tem de entrar no teste.* **O conserto da v0.8 trouxe o atributo e parou ali.** *Uma frase certa ao lado de um teste que não a obedece sobrevive muito mais que uma frase errada.*

***Decisão do Mizuki, e a conta fecha nas duas metades:***

| | antes | agora |
|---|---|---|
| ataque corpo a corpo | `d20 + Força` | **`d20 + Força + maestria`** |
| ataque à distância | `d20 + Destreza` | **`d20 + Destreza + maestria`** |
| ataque de conjuração | `d20 + 2 + maestria` | **`d20 + atributo da técnica + maestria`** |
| CD de feitiço | `10 + 2 + maestria` | **`8 + atributo da técnica + maestria`** |
| Teste de Resistência | `d20 + atributo (+2 se treinado)` | **`d20 + atributo + maestria`**, e a maestria só se treinado |

**A maestria virou a marca do treino, e ela aparece dos dois lados de cada rolagem.** *No acerto, o `+6` do alvo é involuntário — a proteção sobe sozinha na linha de graça do marco. Na CD, o `+6` do alvo é comprado: a maestria só entra no Teste de Resistência que a ficha treinou.*

> **O `8` da CD não é escolha de gosto: ele É a chance de quem treinou.** *`8 + atributo + maestria` contra `d20 + atributo + maestria` deixa exatamente `8` no dado, e `d20 ≥ 8` é `65%` — o mesmo que o `+2` fixo entregava.* **Quem treinou resiste hoje o que resistia antes; a mudança inteira caiu no TR que ninguém treinou**, que sai de `55%` plano para `60% → 45%`.

***Decisão do Mizuki: isso é o preço de não treinar, e é para doer.*** *Toda ficha treina dois Testes de Resistência de quatro, e os outros dois viram o lugar por onde um chefe entra — cada vez mais, conforme a campanha anda.* **E vale para arma também: sem treino você não soma a maestria E rola com desvantagem.**

> **Buff plano não deriva, e é isso que responde à observação sobre escudo e feitiço de Defesa.** *Um `+1` de escudo vale `+1` no nível 2 e `+1` no 30 — mesmo com `+4` por cima, o topo do que existe, a deriva continua `0` e o acerto só cai de `55%` para `35%` em todo nível.* **Buff plano é calibragem de quanto um acerto vale; só a proteção de cobrir-se cresce, e foi ela que puxou a maestria.**

**A técnica declara um atributo na criação — qualquer um dos cinco — e ele não muda.** *Com isso o `2 + maestria` morreu, a "troca do `2` por um atributo" deixou de existir como mecanismo, e o `Estopim` do `Explosivo` ganhou referente de graça.* **O acerto passa a ser `55%` do nível 2 ao 30, com uma oscilação irredutível de `5pp` no meio** — a proteção sobe a cada quatro níveis e a maestria a cada oito.

> **⚠ Declarado e mandado para o playtest: Constituição é a escolha ótima de técnica de quem só conjura.** *Todo Caminho tem um atributo que já faz dois trabalhos, mas o segundo trabalho da Constituição vale para todo mundo.* **Não quebra número — o acerto continua em `55%` —, mas apaga a cor da escolha.**


**A v0.116 fechou as três pendências que a v0.115 levantou, e as três fecharam por medida em vez de por decisão.** *O gate Origem × Caminho não era gate; o catálogo das Bênçãos não podia espelhar; e a regra de Pactos já tinha três quartos escritos, no manual.*

**A v0.114 pôs `livro/` no recorte da checagem 7** — *o `.pdf` publicado podia envelhecer sem ninguém acusar, e foi o que aconteceu na v0.112.* **O recorte foi de 29 para 31 arquivos; a contagem de checagens não mudou.**

**A v0.113 marcou nove blocos do livro como `.aviso`** — *decisão de mesa, desambiguação e consequência de rota deixaram de parecer regra.* **Ficaram 253 caixas de regra e 9 de aviso.** *A fila da revisão do livro está vazia.*

**A v0.112 achou que o `.pdf` e o `.docx` publicados do livro estavam três versões atrasados** — *sem as condições reescritas, sem o capítulo 11 reordenado, sem o vocabulário novo e sem a regra de `vida temporária`.* **Nenhum validador acusa: o recorte da checagem 7 não inclui `livro/`.** *Regerados e copiados.* **E o segundo estilo de caixa, o `.aviso`, entrou pronto e sem uso — marcar os oito candidatos é decisão do Mizuki.**

**A v0.111 mediu o capítulo 9 antes de quebrar e descobriu que ele não precisa ser quebrado** — *o PHB tem dois capítulos acima de `35%` do livro, e o Fundamento é `21%`.* **Tirando os catálogos de consulta, ele tem `10.132` palavras de leitura corrida, praticamente iguais ao capítulo 7.** *O item saiu da fila como não-trabalho.* **E toda entrada do CHANGELOG passou a fechar com `→ Continua em`.**

**A v0.110 fechou a fila da revisão do livro.** *Três exemplos inline, três habilidades com efeitos separados em linha própria, e a confirmação de que o alvo previsto — 38 seções e 6 habilidades — era `3` e `3` na prática.* **Sétimo caso do mesmo erro de contagem, e o padrão está logo acima das pendências.**

**A v0.109 leu as 74 habilidades de Trilha e Caminho uma a uma e achou que `vida temporária` tinha três grafias** — *`Aprumo` e `Crosta` diziam "PV temporário", a Melhoria `Rasga Escudo` dizia "pontos de vida temporários"*, **e as três ficavam de fora da regra que a v0.108 tinha acabado de escrever.** *Unificadas. O `Aterro` também passou a dizer que não depende do `Alicerce`, informação que a fonte já tinha e a transposição perdeu.*

**A v0.108 escreveu a regra de `vida temporária`, que oito efeitos usavam e nenhum documento definia, e passou o livro por uma revisão de vocabulário medida contra o D&D 2024 e o GURPS 4e.** *A regra mora na peça 1 §5.1.1; a revisão do livro está registrada em `05-material/livro/ESTADO-revisao.md`.*

**A v0.107 fechou as duas divergências que a revisão do livro registrou na v0.106 e ninguém tinha investigado, e as duas moravam onde o bilhete não dizia.** *Ele chamou as duas de "bug do sistema, não do livro" e apontou para `03-mecanica/`.* **Uma está lá — a coluna de Passivas da peça 11 §4, errada em duas das três linhas. A outra estava no gerador do manual**, e consertar ela levou o Fundamento para a **v7.11**.

> **⚠⚠ A linha da Classe Passiva 3 daquela coluna dizia `—` — nenhuma Passiva permanente no manual — e o manual lista três.** *`Escama`, `Afinidade` e `Reserva Profunda`, e a `Escama` é da v0.26: a mesma que este documento discute na seção "Marcado para o playtest".* **A coluna existe como PROVA de que a escada de formato foi lida do manual; uma prova que contradiz o que ela cita prova o contrário.** *A linha da 2 também estava curta — cinco de sete.* **Ganhou a checagem `4k` do `conferir-manual.py`, com guarda e contra-teste, e a contagem de checagens não se moveu.**

> **E a regra de ouro nº 5 do Fundamento não estava em `03-mecanica/` nenhum.** *A dona é `manual/gerador/partE.js`, e a tabela publicava "Liberação Máxima custa a rodada inteira, e você só tem as que o nível deu" — **sem o piso de `Classe 3 ou mais`**, que o mesmo manual escreve em outros três lugares.* **Quem lesse só a tabela aprovaria uma Liberação Máxima de Classe 1** — e é a tabela que a seção diz que o checklist do mestre segue "exatamente".

**E o `conferir-ficha.py` voltou a conferir a checagem 3.** *A v0.105 tirou a coluna de ofício da tabela de Caminhos da peça 8 e o regex continuou pedindo seis colunas: ele não casava com nada, e o validador falhava com "nao consegui ler a tabela" — travando o `subir.sh` inteiro.* **O campo `oficio` dos `CAMINHOS` do `dados.js` saiu junto, porque nada no gerador lia ele.**

**A v0.104 é a versão das dez condições no degrau errado.** *A `Condição Menor` e a `Condição Maior` do manual viraram uma Melhoria só, chamada `Condição`, e o preço dela é o **nível** da condição escolhida.* **O espalhamento dentro de um degrau caiu de `17,00×` para `4,26×`, que é o piso de qualquer corte em três degraus** — a busca exaustiva diz que nenhum outro faz melhor, e o filtro do projeto reprova a partir de `3,00×`. *Manual na v7.10, com dois feitiços prontos mudando: `Palma Trovejante` `5d8 → 6d8` e `Vala Comum` `9d8 → 11d8`.*

**E ela pagou a dívida mais velha da peça 13: as cinco vagas de `Desliga` que estavam destravadas desde a v0.59 e a v0.103.** *O que as segurava não era trabalho — era a trava do formato, que proibia encostar em qualquer coisa com preço.* ***Decisão do Mizuki: a trava passou a "apaga o que ninguém comprou, e ENFRAQUECE o que alguém comprou — nunca imunidade"***, com o degrau do relógio saindo do nível da condição. **Sobraram duas vagas, e as duas esperam peça que não existe.**

**A penalidade de arma está escrita**, na peça 19 §6: sem treino, desvantagem na rolagem; sem o requisito de Força, `−3 m` de deslocamento. *As duas somadas custam `33,8` vezes o que a arma entrega — é porta fechada, não preço.* **Três documentos apontavam para ela.**

**A v0.103 escreveu a peça de dano e condições, e a régua que ela existia para ter não precisou ser inventada — ela estava na tabela de custo do manual.** *Vinte e seis lugares em oito documentos esperavam por ela, e metade dela já estava escrita: três seções da peça 1 declaradas, no próprio texto, como guarda provisória.* **Os catorze tipos de dano, a cobertura e as catorze condições mudaram de casa, e a peça 1 ficou com ponteiro.**

> **⚠⚠ E o achado: o `Punho` nunca estourou.** *Aquela Trilha estava publicada em `6,09` de um orçamento de `5,00`, com o estouro de `22%` aceito por decisão dele — e o próprio desenho marcava o `Derrubado` do nível 11 como "não reconstrói de lugar nenhum".* **Ele reconstrói: era o `Derrubado` PERMANENTE, e o texto da entrega escreve dois portões que o preço não lia.** *Com os dois — acertar (`75%`) e o alvo falhar o Teste de Resistência (`45%`) — o degrau vale `0,56` fatia e não `1,71`, e a Trilha fecha em `4,94`.* **Decisão dele: corrigir o preço e deixar assim.**

> **⚠ E quatro decisões de estouro citavam o `Punho` como precedente.** *O `Batedor` nas três rotas, a `Brasa`, a `Torrente` e o `Explosivo`.* **Nenhum número delas se moveu — o que se moveu foi qual precedente elas citam.** *O maior estouro aceito do projeto passa a ser a `Brasa`, entre `41%` e `88%`.*

> **A régua, em uma linha:** até a v0.103 o manual cobrava `Média` por qualquer uma das nove `Condição Menor` e `Pesada` por qualquer uma das cinco `Maior` — **e a conta diz que elas valem de `0,00` a `19,73` fatias, um espalhamento de `17` vezes contra um filtro de dominância que reprova a partir de `3,00`.** *Cada uma ganhou nível — `Leve`, `Média` ou `Pesada` —, e tirar uma custa `1` ponto de energia por nível.* **Na v0.104 as duas Melhorias viraram uma, chamada `Condição`, e o preço dela passou a ser o nível:** *dez das catorze estavam no degrau errado, e o espalhamento caiu de `17,00×` para `4,26×`, que é o piso de qualquer corte em três degraus.*

> **O número pulou de `0.99` para `0.100` e não para `1.00`.** ***Decisão do Mizuki:*** *`1.0` costuma querer dizer pronto para usar, e `04-playtest/` tem zero sessões, o quick-start não existe e faltam três Trilhas.* **O `1.0` fica reservado para quando alguém tiver jogado.**

**A v0.93 fechou três pendências pequenas, e a primeira era grande por dentro.** *As duas entregas em minúscula viraram `Disparo Carregado` e `Acelerar`; o `Classe` solto da peça 11 eram **treze** lugares e não os oito contados; e o `.pdf` do manual saiu da v7.4 para a v7.8 e parou de ser exportado a mão.* **⚠ E o achado: a minúscula do `carregar` não era descuido — `Carregar` sai `OCUPADO` na triagem, é Restrição no manual.** *A pendência ficou catorze versões descrita pelo sintoma, e o sintoma não diz o que precisa ser feito.*

**A v0.92 fechou a `Aptidão Própria`, e com ela o catálogo inteiro: as catorze entradas têm regra, gate e validador.** *Ela estava listada como "falta a régua do `Efeito Próprio`" desde a v0.3.* **⚠⚠ E a régua nunca precisou ser escrita — ela é do manual, está numa tabela de Melhorias, e ninguém tinha aberto:** *"Em quantas cenas por arco isso vai importar? Uma cena: Leve. Metade: Média. Quase toda: Pesada. **Na dúvida, Pesada.**"* **É o terceiro exemplar do mesmo defeito em doze versões** — o Classe 0 da v0.80 e a ação `Mirar` da v0.86 são os outros dois: *o projeto procurando um número que já tinha dono.*

> **E as três faixas caem exatamente nos três degraus da escada de Classe Passiva da §4:** *uma cena/Leve na Classe Passiva 1, metade/Média na 2, quase toda/Pesada na 3.* **A escada da peça mede FORMA e a do manual mede FREQUÊNCIA, e as duas caem nos mesmos três degraus** — condicional dispara pouco, reativo com limite dispara em parte, permanente dispara sempre. *Com isso a trava que já estava escrita ganhou número: `Classe Passiva 1 ou 2, nunca 3` quer dizer que uma `Aptidão Própria` importa em **no máximo metade das cenas** de um arco.*

> **Cinco requisitos, no molde da `Regra Própria` do manual, com um trocado.** *A simetria não veio — ela existe lá porque a `Regra Própria` **impõe uma regra ao mundo**, e uma `Aptidão Própria` só muda o que você faz.* **No lugar entrou "não é atalho": ela não repete uma das treze do catálogo com outro nome nem entrega uma que o seu gate não alcança.** *Sem isso, alguém escreve a `Energia Reversa` com outro nome e pula o gate de refino 7.*

> **O que faz ela sobreviver a sete mesas é uma linha: a ficha carrega a RESPOSTA da pergunta de frequência, e não só o texto.** *E o desempate do manual entra com o sinal a favor da mesa — na dúvida é Classe Passiva 3, e a `Aptidão Própria` não alcança a 3, então **a dúvida reprova a proposta**.* **É o único lugar do sistema em que "não sei" tem resposta escrita, e ela é "não".**

> **⚠ E a checagem do `por cena` da peça 10 acusou na primeira edição, pela segunda vez.** *Escrever a aptidão acrescentou três usos na pasta e a peça publicava `93`.* **De `93` para `96`** — a v0.83 tinha feito o mesmo caminho de `91` para `93`. *Lição nº 1 fazendo o trabalho dela duas vezes.*

**A v0.91 fechou o catálogo de aptidões: a `Barreira Simples` e a `Cortina` eram as duas últimas sem número, e estavam assim desde a v0.3.** ***O Mizuki chegou com o problema pelo nome antes de qualquer conta:*** *"se não vira uma vida extra paia"* — **e a conta concorda.** *Dano evitado converte `1` pra `1`, então uma barreira que o inimigo precisa quebrar **evita a própria vida**: `200` de vida seriam `9,84` fatias numa luta de `3,3` rodadas, contra uma Trilha inteira de `5,00`.*

> **⚠ E gastar a rodada inteira levantando NÃO gateia.** *Era a primeira ideia dele.* **Sobram `2,3` rodadas com a barreira de pé — `70%` da luta — e o câmbio fica a favor de quem levanta: uma rodada sua no nível 30 vale `108` de dano e você a troca por uma barreira que absorve `200`.** *O que gateia é `1 minuto`, que são dez rodadas contra `3,3`.* **E ele resolve de graça o problema multi-mestre: uma regra do tipo "não dá para levantar em combate" obriga sete mesas a decidirem o que é estar em combate.**

> **`Barreira Simples`, sem gate:** domo de raio `6 m`, ancorado no lugar, bloqueia passagem e linha de efeito, **`5 × refino` de vida** — abaixo dos `70` da maior parede que um feitiço monta, de propósito. **`Cortina`:** cobre um lugar, esconde de quem não é feiticeiro, carrega **uma condição sobre quem atravessa**, **`20 × refino` de vida**. *As duas caem quando você fica `Inconsciente`, que é da obra e encaixa no que a v0.88 renomeou.*

> **⚠⚠ E entrou o QUINTO formato de gate, que a v0.90 tinha recusado uma versão antes.** ***Decisão do Mizuki: a `Cortina` exige a `Barreira Simples`, e nada mais*** — *"só isso já força a gastar dois marcos aqui"*. **A diferença precisou ser escrita: no kokusen as três são alternativas e o requisito seria pedágio; aqui a `Cortina` é a `Barreira Simples` maior, e isso é escada.** *A regra: a aptidão exigida tem de ser a mesma coisa em tamanho menor e servir sozinha.* **E ele é o único dos cinco formatos que cobra MARCO** — nível o tempo paga, refino a linha passiva paga, Origem a criação paga.

> **O extrator de gate da v0.90 tinha um buraco que o formato novo abriu:** *`exige a Barreira Simples` não produzia token nenhum dos dois lados, e a comparação título-contra-catálogo passava **trivialmente**.* **Um formato de gate inteiro sem ninguém conferindo as duas cópias.** *Corrigido, com a guarda de contagem subindo de onze para treze.*

**A v0.90 fechou a terceira de kokusen, que virou a `Kokusen Constante`.** *Ela era contada entre as onze fechadas com o gate escrito como **a definir** e sem nome nenhum.* **E indo fechar ela apareceu um buraco: ninguém tinha escrito se as três de kokusen empilham** — procurado nas dezessete peças e nos três desenhos, zero ocorrências. ***Decisão do Mizuki: empilham.*** **A `Constante` sobe a base para `3 × refino` e a vantagem da `Melhorado` rola em cima dela — `51%` no d100 no refino 10, contra `36%` só com a `Melhorado`.** *Sem empilhar, a terceira seria `17%` pior pelo mesmo preço de um marco: entrada morta ocupando vaga.* **Nenhuma exige a outra**, porque criar um gate de *"ter pego a de antes"* seria o quinto formato — e foi uma pergunta de leitor dele, na v0.65, que derrubou uma mecânica inteira exatamente por isso.

> **O gate é `refino 5`, sem gate de nível, e ele é derivado.** *Assim ela abre no nível 10 para quem sempre escolhe Refino, e a `Melhorado` só no 14 — **quatro níveis em que ela é a única das duas disponíveis**.* **Sem isso ela nunca compensaria escolher:** quem pode pegar ela já pode pegar a `Melhorado`, que ganha em todo refino. *`Pleno` foi recusado fora da triagem, tendo saído `LIVRE`: ele entra no campo de `Liberação Máxima` e `Técnica Máxima`.*

> **⚠ E a trava do kokusen media a ENTRADA enquanto a peça fala da FICHA.** *Com as três empilhadas a ficha chega a `+4,64%` de dano por rodada — `0,46×` um ponto de atributo —, e a trava velha só olhava a base em `0,18×`.* **A comparação certa é POR MARCO: a pilha custa três marcos, e três marcos de `Corpo` comprariam `+30%` — `6,5×` mais.** *Continua sendo escolha pelo grito e não pela planilha.*

> **⚠ E a checagem do gate duplicado só olhava UMA das catorze entradas.** *O gate mora no título da seção e na linha do catálogo; a comparação estava escrita no braço para a `Energia Reversa`.* **Perturbando o gate da `Constante` no catálogo, o validador saía verde — treze das catorze não tinham ninguém comparando.** *Generalizada para as onze que têm seção própria, de mão única e com guarda de contagem.*

> **O catálogo passou de nove entradas escritas com número para dez, e a rota pura de Refino da v0.89 pede exatamente dez.** *Ela fecha sem folga nenhuma até `Barreira Simples` e `Cortina` entrarem.*

**A v0.89 fechou a troca do marco, que era o único problema de design que tinha sobrado.** *A escolha de `Refino` promete **"mais um de refino, e uma aptidão"** e entregava só a aptidão nos marcos 22, 26 e 30.* **A causa medida: a linha de graça do marco entrega `8` dos `10` de refino sozinha** — sete marcos a `+1` mais o refino 1 do começo —, **então a metade "mais um de refino" da escolha só tem `2` pontos de espaço para caber na campanha inteira.** *Quem escolhe `Refino` nos sete pagaria `15` e para em `10`.* ***Decisão do Mizuki: no teto, a escolha leva DUAS aptidões*** — a rota pura vai de `7` para `10`. **E os outros dois eixos não desperdiçam nada:** o `Corpo` ganha `14` pontos contra um teto somado de `30` nos cinco atributos, e o teto de Passivas do `Leque` sobe uma vaga por escolha.

> **A forma da comparação não muda, e é isso que fecha.** *Cortando o par aptidão/Passiva dos dois lados, o marco sempre compara `+1` atributo contra alguma coisa contra `+1` feitiço.* **Antes do teto essa alguma coisa é `+1` de refino; a partir dele é uma aptidão a mais.** *A régua de "uma aptidão a mais" continua não existindo — o que muda é que esta comparação não depende dela, porque quem leva a segunda já escolheu esse eixo cinco vezes.*

> **⚠⚠ E as duas alternativas foram medidas e reprovaram, com a conta escrita.** *Subir o teto de `10` para `15` acende **dois contratos** na hora: a proteção de `cobrir-se` passa a crescer `+33` contra `+3` de um atributo, e o kokusen sobe a `9,1%` de dano por rodada. Mais `31` fórmulas usando refino como variável em sete arquivos.* **Baixar o refino passivo move a tabela de gates inteira do §5.**

> **A checagem 5.2 é a segunda metade da 5 por outro eixo.** *A 5 mede o FIM da campanha e saía verde com o meio quebrado — nos totais a rota de `Refino` liderava o refino com `10` contra `8`.* **A 5.2 mede marco a marco, e as componentes são QUATRO e não cinco:** aptidão e Passiva entram na mesma, que é o que a peça 11 afirma. ***Contra-teste: rodando a regressão com as duas separadas, ela sai verde*** — é por isso que ninguém viu isto em dezessete versões.

> **E o Classe 0 fantasma sobreviveu num validador por ser só impresso.** *O `conferir-aptidoes.py` carregava `CLASSE_0 = 4.5`, o número que a v0.80 matou em todo o resto do projeto.* **A coluna dizia `35%` da Rotina no nível 2 quando é `69%`.** *Agora sai da tabela do manual, como cópia vigiada.* **Display errado ensina número errado do mesmo jeito.**

**A v0.88 fechou quatro dívidas antigas de uma vez, e a mais velha delas não era o que estava escrito.** *A troca de `Caído` por `Inconsciente` estava marcada desde a v0.82 como colisão entre o estado de 0 de vida e a condição de quem foi derrubado — e a condição de derrubado **já tinha nome no manual: `Derrubado`**, com tier de preço e dois feitiços prontos usando ela.* **O único lugar do projeto que a chamava de `Caído` era a Manha `Abalo`, e isso era REGRESSÃO:** a v0.74 já tinha achado e fechado exatamente essa colisão no `Punho`, e oito versões depois ela voltou por outra porta. **O `Abalo` passa a aplicar o `Derrubado`, e o estado de 0 de vida virou `Inconsciente` em onze lugares**, aplicando a decisão do Mizuki de três versões atrás. *Nenhum número se moveu.*

> **⚠⚠ E o que deixou isso acontecer é buraco de validador: a triagem era cega para as doze condições do manual.** *Elas moram dentro de uma frase de prosa — `"Aplica uma: …"` — e a extração do `conferir-nomes.py` lê primeira coluna de tabela.* **Onze das doze voltavam `LIVRE`**, e a única que não voltava era `Lento`, por acidente, porque ela também é Restrição. ***O exemplar mais constrangedor é o `Incapacitado`: ele saía `LIVRE` enquanto a peça 1 §5.5 gastava um bullet explicando que ele é condição nomeada do manual.*** **Agora as doze são lidas do `.docx`, com guarda de contagem.**

> **E a peça 6 parou de publicar duas coisas erradas.** *O `Repertório` — Trilha abandonada na v0.81 — ainda estava na §2, e ele sobreviveu em **sete** lugares e não em três: a peça, a **ficha do gerador**, dois validadores, o rascunho de Trilhas, a nota histórica da peça 5 que dava o motivo errado, e três pendências do desenho escritas como abertas.* **O nome ficou `LIVRE` de novo, de propósito.** *E o §9 publicava o calendário de Caminho `7 · 15 · 23 · 29` como fato fechado, dezoito versões depois de ele virar `2 · 7 · 15 · 30`.* **A citação histórica do §3.1 NÃO foi apagada — ganhou a linha que diz que foi superada.**

> **`Quick Draw` virou `Descarga`, e o sistema não tem mais nenhum nome em inglês.** *Decisão do Mizuki entre quatro candidatos que passaram na triagem; `Rajada` e `Estopim` morreram nela antes, e `Pente` morreu por sentido depois de sair `LIVRE`.* **A escada da rota `Arma de Fogo` fica `Ferrolho` · `Mirar` · `Descarga` · `Dobro`.**

> **Duas checagens novas, e dez perturbações conferidas em cópia isolada.** *A checagem 10 do `conferir-catalogo.py` compara toda cópia viva do calendário de Caminho contra o `DESENHO-caminhos.md`, que é o dono, **e em dois eixos**: uma pergunta se o valor bate, a outra se o valor morto sumiu. E ela tem guarda de contagem, porque checagem que para de conferir em silêncio é a lição nº 8 por outra porta.* **A triagem ganhou o veredito `MORTO`**, que não mata o candidato — o projeto reaproveita nome de propósito — mas impede reaproveitar sem saber.

**A v0.86 escreveu a ação `Mirar`, que era entregue em SEIS degraus do `Batedor` e não tinha regra em lugar nenhum.** *Ela atravessou da v0.74 à v0.85 assim — treze menções no desenho, todas concedendo, nenhuma definindo —, e quem achou foi o `conferir-catalogo.py` da versão anterior, indexando os degraus que a citam.* ***Decisão do Mizuki:*** **Ação Bônus, vantagem no próximo tiro com arma de projétil, e só se você não se deslocou nesta rodada nem vai se deslocar.** *É a forma do `Steady Aim` do Ladino do 5e; as duas outras formas comuns já estavam gastas aqui — consertar a penalidade de faixa de alcance é o nível 2 das três rotas, e mexer em cobertura não dá, porque **cobertura não existe como regra** neste sistema.*

> **⚠ Ela estoura o degrau em `5,3×`, e o estouro é decisão dele.** *Vantagem em um dos dois ataques vale `27,00` de dano na rodada; abrir mão do deslocamento de `9 m` devolve `5,40`; sobram **`4,25` fatias num degrau de `0,80`**.* **O gate de movimento corta `20%` do preço — não é decorativo, mas vantagem é o número mais caro do sistema.** ***"Você tá inflando demais essa habilidade, garanto para você"*** — *a mesma frase que segurou a `Brasa` na v0.81.* **Nenhum número publicado se moveu.**

> **E ele cria três dominâncias novas, declaradas.** *Com o atirador parado em metade das rodadas, as três rotas vão de `4,52`–`4,82` para **`5,95`–`6,09`** contra um teto de `5,00` — `+19%` a `+22%`, que é **exatamente o tamanho do `Punho`**.* **As três passam a dominar a `Estocada` por `1,19×` a `1,21×`**, mesmo tamanho da dominância `Explosivo` sobre `Torrente` que já estava aceita, e dentro do filtro de `3,00×`. *Ninguém domina o `Executor`, que é o único com coluna de defesa, e as três rotas não se dominam entre si.*

> **⚠ E entrou a TERCEIRA taxa sem medida do `Batedor`: em quantas rodadas o atirador fica parado.** *As outras duas já estavam declaradas — faixa longa e colado.* **Esta sozinha decide `2,12` fatias:** a `100%` as três rotas vão a `8,07`–`8,21` e a dominância sobe para `1,64×`.
>
> ***Decisão do Mizuki na v0.103: ela sai da fila de perguntas.*** *A taxa fica declarada onde ela mora — no desenho de Trilhas, junto das outras duas —, com o tamanho escrito, e não é pergunta que o projeto faça a ninguém.* **Quem responde é a mesa, e `04-playtest/` está vazia.**

**A v0.85 deu dono à contagem, e o primeiro validador do projeto passou a LER OS `DESENHO-*.md`.** *Até aqui nenhum alcançava aqueles três arquivos, e é por isso que o nível 27 da `Estocada` passou três versões com a tabela cobrando `1,33` fatia e o bloco de regra entregando `5,31`.* **A peça 17 é um índice: quantas entradas existem, como cada uma se chama, onde o texto dela mora — e nada mais.** *Ela não guarda preço e não guarda texto de mesa; os dois continuam sendo dos desenhos, que são os donos.* ***Decisão do Mizuki: rota de Trilha conta como entrada própria e menu dentro de degrau não conta*** — então o `Batedor` entra com `12` e a `Pegada` do `Executor` e a `Sintonia` do Evocador entram com `4` cada. **Com a regra escrita a contagem virou `89` e não `81`, e os nomes que faltam viraram `21` e não `17`.** *As quatro a mais estavam escondidas dentro de uma linha só do `Batedor`.*

> **A checagem 6 é a que a peça existe para ter:** um bloco de regra não pode prometer permanência onde a linha de preço cobrou condição. **Oito perturbações conferidas em cópia isolada**, com a base passando antes e o `diff` conferido em cada uma — e a que mais importa é a regressão da `Estocada`, que acende. *As checagens 5 e 6 se medem por eixos diferentes de propósito: apagar o bloco acende a 5, reescrever o bloco acende a 6.*

> **E o índice rendeu um buraco antes de existir: a ação `Mirar` não tem regra em lugar nenhum.** *Ela é entregue no nível 11 das três rotas do `Batedor` e estendida no 27 das três — seis degraus, entre `1,60` e `2,04` fatias cada.* **Nem a lista de ações da peça 3 §3.1 nem o desenho dizem o que ela faz ou que slot ela gasta.** *E a triagem devolve o nome como `fraco`: ele está a uma letra de `Mira`, que é Família no manual.* **É buraco de regra, e não de nome.**

**A v0.84 escreveu as doze entregas do Guia em texto de mesa e batizou mais sete do Emanador.** *O Guia era o único Caminho sem uma entrega jogável — as doze existiam só como linha da tabela de preço — e virou o único com os três completos.* **`Elo`: `Nó` · `Repasse` · `Partilha` · `Trança`. `Sutura`: `Agulha` · `Enxerto` · `Pulso` · `Cerzido`. `Perímetro`: `Chão` · `Sentinela` · `Encalço` · `Portão`.** ***Decisão do Mizuki: tirar condição custa `1` PE por nível dela*** — a regra preça pelo nível, então ela não depende da lista de condições que não existe, e a exaustão da peça 10 já tem três degraus numerados. **De 48 entregas de Trilha, `11` tinham nome e agora são `30`; faltam `17`.**

> **⚠⚠ E uma Trilha estava entregando `4×` o preço dela.** *O nível 27 da `Estocada` tinha a tabela com dois gates (`1,33` fatia) e o **bloco de regra** dizendo "carrega **sempre** um Classe 0" (`5,31` fatias — mais que a Trilha inteira).* **A v0.81 repreçou e consertou só a tabela, e a mesa lê o bloco.** *`Torrente`, `Brasa` e `Explosivo` foram varridas junto e as três batem.* **Nenhum validador alcança os `DESENHO-*.md`, e é por isso que ela passou três versões assim.**

**A v0.83 deu casa à lista de ações: ela é a peça 3 §3.1.** *Aquela peça tinha os quatro slots do turno e nenhuma ação nomeada, e o `Ajudar` morava na peça 4 §5 sem custo de ação declarado desde a v0.22.* **As doze do 5e de 2024 foram lidas na fonte** — oito já existiam aqui, entraram `Influenciar` (que cabe sem adaptação, porque **Essência é o Carisma deste sistema**) e `Preparar`, e o `Search` e o `Study` viraram `Vasculhar` e `Estudar`. ***Decisão do Mizuki: o `Ler o Ambiente` fala do LUGAR e nunca de criatura, e os outros dois falam da criatura*** — sem essa linha uma Ação Bônus dominava duas Ações Padrão. **`Agarrar` e `Derrubar` deixaram de ser ação própria e viraram opção do `Atacar`**, como no 2024, porque como ação própria elas ficavam mortas. **Cinco checagens novas no `conferir-acao.py`, com oito perturbações conferidas.**

**A v0.82 fechou a dívida de linha de base que a v0.81 marcou com `⚠⚠ LIMPAR ANTES DO PDF`, e ela NUNCA FOI DÍVIDA.** *Era uma frase que ninguém tinha escrito, e a própria peça 6 §3.1 já registrava a resposta como "anotado, não decidido".* **O ataque extra do nível 7 é um golpe SOLTO por rodada e não exige a Ação de Atacar** — ele acontece junto do que a Ação Padrão fez, inclusive quando ela conjurou. ***Achado do Mizuki, e por pergunta e não por conta:*** *"já é um ataque extra, é uma mecânica forte, não acho que precisa disso."* **Zero número se moveu:** o vão continua `9 · 10 · 11 · 12`, o nível 7 continua de graça nos cinco Caminhos, e o `Arremate` e o `Resquício` continuam como estavam.

> **A alternativa reprova por DOMINÂNCIA e não por orçamento**, e é isso que fecha o argumento. Com o ataque extra preso à Ação de Atacar, **dois golpes rendem `23` no nível 30 e um Classe 0 grátis rende `27`** — a entrega de nível 7 de dois Caminhos perderia para o botão que toda ficha já tem, ninguém usaria a Ação de Atacar, e o físico e o conjurador terminariam idênticos em `60,50` por rodada. **A checagem `4h` do `conferir-manual.py` guarda a FORMA, com sete perturbações; a `4f` guarda o número.**

**E as TREZE MANHAS entraram, fechando o nível 2 da Vanguarda** — o `DESENHO-manhas.md` na raiz. *A régua veio antes do catálogo e reprovou sete das oito propriedades de maestria do 5e de 2024: `+1` no acerto vale `10,80` de dano por rodada aqui, então vantagem vale `54,00` contra um degrau de uma fatia.* **As treze caem entre `0,68` e `1,18` fatia, dominância `1,74×`.** **O Evocador saiu da fila** — o §6 do `RASCUNHO-trilhas.md` tem cabeçalho de parada, e ele **não** foi para o `99-arquivo/` porque nada ali morreu.

**A v0.81 fechou os dois avisos que a v0.80 deixou na régua de Trilhas, e a resposta dos dois é "não muda nada, e agora dá para provar".** *O vão corrigido não move o preço de nenhuma das onze Trilhas fechadas — o ponto de chegada é o mesmo (`99 + 7` e `94 + 12` dão os mesmos `106`), e o que mudou foi o tamanho do degrau de graça.* **E o teto que morreu não tem substituto: as outras quatro travas não reprovam em orçamento nenhum de `1×` a `8×`, e os três candidatos testados ou têm dono no playtest ou só acendem a `10,45×`.** ***Decisão do Mizuki: o teto fica declarado como decisão de design — `4×`, que é `27,7%` da ficha para a camada — em vez de vestido de conta.*** *O `+18%`, como contra-teste, reprovaria a partir de `3×`: existia teto, era ele, e era o único.*

**E o Classe 0 fantasma tinha sobrado num lugar que a guarda da v0.80 não alcançava.** *A peça 6 §5 preçava um Classe 0 em `4,50` para justificar o PE do Bastião, e o argumento **inverte** com a tabela certa — um Classe 0 rende `27` no nível 30 contra `12` do golpe simples.* **A guarda daquela versão tinha um buraco de uma linha: ela lia `**negrito**` como nota histórica, porque negrito começa com `*`.** *Hoje `>` e `*` sozinho são história e `**` é afirmação viva, mais a checagem **4g**, que guarda o número morto e não só a frase morta — sete perturbações conferidas, e a base pegou uma cópia suja na primeira tentativa.*

> **Um achado de graça: o modelo de combate do manual reconstrói.** A coluna *dano do grupo por rodada* da tabela de inimigo é **`2,90 ×` a Rotina** nas seis linhas, e com isso o modelo reproduz os `3,7` e os `2,7` rodadas que a v0.73 publicou, com zero parâmetro livre. **Ele produz a primeira pergunta de mesa deste orçamento com número em cima:** no orçamento de hoje o chefe deixa de conseguir derrubar a ficha mais frágil concentrando fogo, e a virada é entre `2×` e `3×`.

**E indo consertar as pendências pequenas, a v0.81 achou que CINCO entregas publicadas foram calculadas a partir do Classe 0 fantasma.** *A v0.80 corrigiu a tabela e repreçou só o `Arremate`; as outras foram calculadas **a partir** do `4,50` e nunca refeitas.* **As três Trilhas foram repreçadas com o Mizuki: `Torrente` de `5,37` para `4,65`, `Estocada` de `4,58` para `5,02`, e `Brasa` de `5,03` para uma faixa de `7,06` a `9,42` — com o estouro aceito e declarado, no molde do `Punho`.** *As três matrizes continuam limpas.*

> **A regra nova que sai daí, e ela é do sistema:** um Classe 0 causa `27` no nível 30 e a fatia é `5,08`, então **"ganha um Classe 0 por rodada" vale `5,31` fatias contra um orçamento de Trilha de `5,00`.** *Nenhuma entrega pode conceder isso sem relógio ou gate.* **E no nível 30 um Classe 0 e um Classe 2 num alvo causam os dois `27`** — toda entrega que "sobe o Classe 0 para Classe 2" vale zero em dano onde a fatia mede.

**E o buraco de texto mais caro que a v0.80 deixou aberto FECHOU.** *Decisão do Mizuki: **a Ação de Atacar não inclui o feitiço de Toque** — canalizar e atacar são ações diferentes e não cabem no mesmo turno, e a `Fornalha` é a única exceção.* **Está escrito na peça 6 §3.1, com a tabela dos três turnos.** *Ele valia um fator de `2,6×` na `Brasa`, e a resposta veio da mesa e não da conta — que é exatamente o que a v0.80 previu.*

**A v0.80 é uma versão de conserto, e o conserto é de linha de base.** *O projeto preçava um feitiço de **Classe 0** em `4,50` de dano desde a v0.14, e esse número não existe no manual.* **O manual tem tabela própria para ele — `2d8 · 3d8 · 4d8 · 5d8 · 6d8` por faixa de nível, então `27` no nível 30 —, e nenhum documento do projeto e nenhum validador abriam ela.** *Ela era a **quarta** tabela compartilhada com o manual e a única sem dono declarado; hoje o dono é o manual.* **O estrago estava na coluna "conjurador" da peça 6 §3, que saía `5` pontos alta em todo nível**, e com ela o **vão `físico − conjurador`** — que paga o degrau do nível 7 dos cinco Caminhos. **O vão passou de `4 · 5 · 6 · 7` para `9 · 10 · 11 · 12`, e ele é exatamente um golpe simples.** *Efeito colateral bom: os cinco Caminhos passam a receber a mesma coisa no nível 7 — antes Bastião e Vanguarda ganhavam `11,50` e os outros três `7,00`.* **E a frase que explicava a Rotina — *"ela já é feitiço + Classe 0"* — é falsa: a Rotina é `floor(3,5 × Classe)` dados, o meio exato entre bater num alvo e espalhar, e ela fecha nas sete Classes.** *Duas checagens novas no `conferir-manual.py` (4e e 4f) com seis perturbações conferidas.*

**A permissão do `Arremate` foi APLICADA na v0.80** — a peça 6 §3.1 deixou de proibir três rolagens de ataque, com o motivo do Mizuki escrito e o número da vida junto (o Emanador tem `212` no nível 30 contra `243` da Vanguarda e `305` do Bastião). **O `Coro` herda, e nele custa `0%` em dano.** *E medindo nível a nível apareceu que o pior nível é o **11**, com `+20%` sobre o físico, e não o 30 com `+11%`.* **O nível 7 do Emanador foi refeito: a `Voz Grossa` morreu e virou o `Resquício`** — um Classe 0 na Ação Bônus quando a Padrão foi feitiço que não causa dano. *Ela morreu porque rebaixava o Classe 0 de `27` para `12`, e porque não existia na rodada em que o Emanador conjura.* **O `Arremate` repreçou para `3,74` de `5,00` e o nível 27 dele ficou VAGO, com `1,26` fatia.**

**DOZE Trilhas escritas de quinze, e o EMANADOR FECHOU na v0.81 — faltam só as três do Evocador.** *A terceira do Emanador é o **`Explosivo`**, em `5,57` de `5,00`: rerrolar `1` e `2` nos dados quando o feitiço for o único da rodada, somar o atributo no dano, gastar `a Classe` em PE por vantagem no ataque, e `+metade da Classe` em dados `1×` por cena.* **O `Repertório` foi ABANDONADO** — a ficção dele só se preçava por *"uma aptidão a mais"*, e essa régua não existe nem pode existir; e as duas colunas vazias do Caminho não aguentam uma Trilha inteira. ***Declarado: o `Explosivo` domina a `Torrente` por `1,20×`, e a causa é falta de coluna e não sobra de número.*** **A Vanguarda fechou na v0.76 e a matriz dela na v0.77; o GUIA fechou inteiro na v0.77** — Caminho preçado contra as três fatias e as três Trilhas em `4,78` · `4,51` · `4,74`, com matriz limpa. *A matriz da Vanguarda entra com **cinco** linhas e não três, porque as três rotas do `Batedor` são três fichas diferentes, e ela sai limpa: a única dominância é a `Arma de Fogo` sobre a `Estocada`, aceita e declarada desde a v0.75.* *E a régua de PV temporário fechou na v0.76: **`1` de PV temporário = `1` de dano evitado**, e o mesmo vale para resistência e redução — a conversão de PONTO do manual (`3` por ponto) é a moeda de montar feitiço e não serve para preçar entrega de Trilha.* **O soco tem dado, dono e validador desde a v0.74** — `d4 · d6 · d8 · d10` pela maestria, sem categoria e sem propriedade, na **peça 14 §5.0.6**; e os **catorze tipos de dano** estavam em guarda provisória na peça 1 até a peça de dano e condições existir — **desde a v0.103 eles são a seção 4 da peça 19**. **A régua de Trilhas mora no `03-mecanica/RASCUNHO-trilhas.md` §3, fechou na v0.61 e foi REFORMULADA na v0.68** — o preço saiu da entrega e foi para a Trilha inteira, e cada entrada passou a declarar a taxa de disparo. *A v0.62 fechou a dívida que ela destampou (**"cena" tem definição**, na peça 10 §5, com validador em cima), e a **v0.63 fechou a Q6 de Invocações** — a peça 15 não deve mais nada.* Manual do Fundamento na **v7.8**, com a Expansão de Domínio escrita, e o catálogo de aptidões **fechado, com as catorze entradas** — a **`Energia Reversa` fechou na v0.78**, na seção 6 daquela peça. **Dá para montar uma ficha de nível 2, jogar uma missão inteira e recuperar entre elas** — por seis das nove rotas de Origem, e agora sem nenhum buraco de regra que morda nessa faixa.


## Retomada de 28/09/2026 — o Evocador sai da média

**Decisão do Mizuki:** "remove, porque não temos evocador". A calibração de dano dos inimigos usa os quatro Caminhos jogáveis com Constituição 3. O chefe de nível 30 passa de 219 para 226 de dano nominal por rodada; a regra dos quatro golpes continua, com cada golpe arredondado separadamente. Os PV e demais características dos Caminhos não mudam.

A retirada foi propagada à tabela do manual, ao gerador de inimigos, às contas das peças 1, 19 e 26 e às tabelas do livro de inimigos. As seis prontas foram regeneradas; arredondamentos podem conservar os números de uma ficha. Resistência pontual foi aprovada na continuidade: até dois tipos fixos no total não descontam PV; grupos completos continuam cobrados. A revalidação corrige a força das conclusões da pesquisa anterior; ela está em `bestiario/09-fase-2/pesquisa/REVALIDACAO-resistencia-2026-09-28.md`.

A tabela antiga de cura da peça 26 foi marcada como registro histórico: ela inclui Energia Reversa curando outra pessoa, opção ausente da edição atual. Não foi criada porta de cura nem refeita essa composição por suposição.

**Próximo:** executar no Claude o planejamento das Invocações (r5 + §46), ainda fora do livro. Sukuna integrado na v0.287; validação e limites na entrada correspondente do CHANGELOG.

## Como retomar

Leia nesta ordem: este arquivo → `../logs/CHANGELOG.md` (de cima para baixo, a entrada do topo é a mais recente) → a peça de `03-mecanica/` que for mexer. O CHANGELOG carrega o **porquê** de cada decisão, que é o que não dá para reconstruir sozinho.

Antes de mexer em número, rode os validadores. Eles falham alto se algo quebrar.

```
cd 03-mecanica
python3 conferir-atributos.py     # acerto, defesa, TR, perícia, vida, PE máximo, deriva
python3 conferir-acao.py          # régua das Restrições, dominância, Adianta
python3 conferir-pericias.py      # quadro de perícias, listas de Caminho e Origem, colisão
python3 conferir-descanso.py      # piso, exaustão, arredondamento, magnitude, empilhamento, relógios
python3 conferir-nomes.py         # todo nome batizado, projeto → manual
python3 conferir-manual.py        # vocabulário e números importados, manual → projeto
python3 conferir-aptidoes.py      # a trava do refino, as três rotas do marco, o kokusen
python3 conferir-expansao.py      # os gates da Expansão, a ordem, o preço em espaços
python3 conferir-orcamento.py     # o somatório: todos os drenos de PE ao mesmo tempo
python3 conferir-xp.py           # a curva, o abismo que fecha, e os alvos da Guilda
python3 conferir-equipamento.py  # o fundo de cada arma, a dominancia, o teto de Defesa
python3 conferir-criacao.py      # a ficha de exemplo contra as fórmulas, e o que a criação cita
python3 conferir-ficha.py        # a ficha de 05-material contra os catálogos das peças
python3 conferir-legados.py      # os três formatos, a cota de Desliga, as vagas e os totais
python3 conferir-invocacoes.py   # o teto somado, o catálogo, a régua, a morte e o orçamento
python3 conferir-ferramenta.py   # o fundo, o gate herdado, a escada de grau, o teto na ficha
python3 conferir-catalogo.py     # o índice das 102 entradas contra os três DESENHO da raiz
python3 conferir-progressao.py   # as nove colunas da tabela de progressão contra os donos
python3 conferir-dano.py         # a régua de condição, as treze, os tipos de dano e a cobertura
python3 conferir-alma.py         # a Integridade com Essência, os quatro estágios, o TR e a exceção
```

**Três naturezas diferentes, e vale saber qual é qual.** Onze conferem **regra** — *a fórmula deriva certo?*. *(O `conferir-equipamento.py` faltava nesta lista desde a v0.48 e entrou na v0.58 — o `subir.sh` sempre o rodou, porque varre por glob; quem rodasse à mão pelo documento rodava um a menos.)* O `conferir-criacao.py` confere **instância** — *a ficha publicada na peça 8 obedece à fórmula?* —, e nasceu na v0.34 porque os dois erros daquela versão passaram por baixo de todos os outros: a peça 8 é a única que produz uma ficha inteira, e ela envelhece toda vez que outra peça mexe num número. O `conferir-ficha.py` confere **material**, que é a cópia que vira personagem em sete mesas. E o `conferir-legados.py`, o décimo terceiro, confere **catálogo**: ele recalcula a tabela de totais da peça 13 e falha se o escrito não bater com o contado. O `conferir-invocacoes.py`, que entrou na v0.58, faz as quatro naturezas de uma vez — regra, catálogo, instância e **busca exaustiva** —, porque a peça 15 é máquina de construção e não lista.

O quinto tem um modo de triagem, para rodar **antes** de batizar qualquer coisa:

```
python3 conferir-nomes.py --candidatos Vulto Matilha Bigorna
```

**O sexto entrou na v0.26 e olha a direção que faltava.** O `conferir-nomes` pergunta *"esse nome que eu batizei já significa alguma coisa no manual?"*; o `conferir-manual` pergunta *"o manual usa alguma palavra que este sistema não tem?"*. Foi por não existir que o `Bônus de Treinamento` e o `Habilidade/Sabedoria` sobreviveram tanto tempo. Ele também confere que a **tabela de PE, a de inimigo e a coluna Rotina** — que estão copiadas dentro das peças e dos outros validadores — continuam batendo com o `.docx`.

**SEIS precisam de `python-docx`** — `conferir-bestiario`, `conferir-dano`, `conferir-manual`, `conferir-nomes`, `conferir-pericias` e `conferir-progressao` —; sem ele eles **pulam** as checagens que leem o manual, em vez de falhar, e saem com código 0.

| validador | pula | de quantas | o rodapé avisa? |
|---|---|---|---|
| `conferir-bestiario` | 4 — a grade, o dado, o Capanga e o §6.5 (este em quatro sub-blocos) | 11 | **sim** |
| `conferir-dano` | 1 — as treze contra o manual | 14 | **sim** — `OK, mas 1 checagem(ns) PULARAM` |
| `conferir-manual` | **8 — todas.** Sai no `except ImportError` antes da primeira | 8 | avisa, e sai antes do rodapé |
| `conferir-nomes` | 3 (as checagens 1, 3 e 4) | 6 | sim, **desde a v0.101** |
| `conferir-pericias` | 1 (a que bate contra o Fundamento) | 8 | sim, **desde a v0.101** |
| `conferir-progressao` | 1 (a checagem 7) | 8 | **sim** |

> **⚠⚠ E três das cinco linhas desta tabela estavam erradas até a v0.198, na coluna `de quantas`.** *`conferir-dano` dizia `10` e tinha `11`, `conferir-manual` dizia `4` e tinha `8`, `conferir-nomes` dizia `5` e tinha `6`.* **A coluna `pula` estava certa nas cinco; o que envelheceu foi o total, porque os validadores ganharam bloco e ninguém remediu.** *O `conferir-manual` é o caso mais claro: o rodapé dele já imprime **"As oito checagens foram PULADAS"**, então o código dizia `8` enquanto os dois documentos diziam `4`.*
>
> **É a mesma tabela cuja história a seção acima conta, e o defeito é o mesmo com a idade trocada:** *a v0.38 escreveu os números lendo a saída, a v0.40 achou, e a lição que ficou foi "leia do código".* **Ela foi lida do código — e depois o código mudou.** *Contagem lida do dono uma vez é retrato, e retrato envelhece: o que faltava era alguém reler.*
>
> **Hoje quem relê é a sub-checagem `9.1` do `conferir-repositorio.py`**, e ela mede as duas colunas rodando cada validador com o `python-docx` bloqueado, em vez de copiar o número daqui. *É a segunda checagem do projeto em que o dono é o código.*

> **⚠ Eram três até a v0.96, e viraram cinco sem ninguém subir a contagem.** *O `conferir-atributos` entrou na v0.97, quando o caminho de pulada dele foi consertado, e o `conferir-progressao` entrou na v0.99 junto com a peça 18.* **Lido do código e conferido bloqueando o import.** *O `README` dizia três num parágrafo e **dois** no comentário do `pip install`, nove linhas acima — duas cópias, duas respostas, dentro do arquivo que publica a lição nº 9.*

> *Até a v0.39 esta linha dizia "os dois últimos" e "4, 2 e 1", e nenhuma das duas coisas era verdade.* São três, não dois, e eles não são os últimos da lista. E o `conferir-manual.py` estava escrito como o que pula menos quando é o único que **não confere absolutamente nada** sem a biblioteca: ele sai no `except ImportError` antes da primeira checagem. **Número documentado a partir da saída do programa, e não do código, envelhece assim.**

> **O que mudou na v0.38:** rodar de outro diretório **não** faz mais ninguém pular checagem. Os cinco que abrem arquivo do manual resolvem por `__file__`, e de `/tmp` a saída sai idêntica com zero puladas. O `README` e o `LEIA-ME` diziam o contrário desde a v0.28 e foram corrigidos. **Continue rodando de `03-mecanica/`** — o `subir.sh` faz assim —, mas o motivo agora é hábito e não defeito. **A pulada que sobrou é a do `python-docx`, e essa é real.**

## As sete skills, e onde elas moram

**Procedimento:** `rpg-da-guilda` · `pesquisa-antes-de-propor`
**Assunto:** `design-mecanicas-rpg` · `balanceamento-simulacao` · `playtesting-rpg` · `redacao-acessivel-rpg`
**Sobre a conversa:** `gasto-de-modelo` — o veredito de uma linha sobre que modelo a tarefa pedia

Estão na conta e disparam sozinhas. A **`rpg-da-guilda`** entrou na v0.37: ordem de leitura, de onde rodar os validadores, o que a triagem de nomes não pega, como escrever arquivo neste mount, o arnês de perturbação e como fechar versão.

A **`pesquisa-antes-de-propor`** entrou na v0.38, e ela existe por um defeito medido: *a linha "pesquise antes de inventar" já estava na `rpg-da-guilda`, enterrada num bullet de uma lista de oito, e não disparava.* Ela troca o lembrete por **gatilho** — sete casos em que a busca externa é obrigatória antes de entregar — e traz junto a metade que ninguém escreve: **o que não se pesquisa fora.** Número que um documento do projeto é dono se lê do dono; buscar fora cria a segunda fonte, que é a lição nº 9 entrando por outra porta.

As duas guardam **procedimento e nunca conteúdo** — apontam para o `README.md` em vez de copiar as lições.

**A pasta `sistema/skills/` é cópia de trabalho — editar lá não altera a skill instalada**, e as duas divergem sozinhas. **Ao mudar uma skill, mude nos dois lados** — nenhum validador alcança essa camada.

> **E na v0.40 a migração de conta provou que isso não é aviso teórico: as cinco que estavam instaladas divergiam, todas.** A `rpg-da-guilda` instalada ainda carregava o aviso que a v0.38 aposentou — *"rodados de outro lugar eles pulam checagem em silêncio"* —, que é justamente o motivo errado que aquela versão saiu para tirar de circulação.
>
> **E a deriva mudou de direção.** Na v0.37 o repositório é que estava atrás da instalada, e a conclusão registrada foi *"migrar pelo repositório levaria o gatilho velho"*. Desta vez foi o contrário, nas cinco. **Não existe um lado que seja confiável por natureza** — o que existe é a data da última vez que alguém sincronizou, e ela não está escrita em lugar nenhum.

> **E a v0.93 mediu a deriva se separando por CAMADA, o que nenhuma das anteriores tinha visto.** A instalada estava na frente **só na descrição** — seis das sete ganharam uma frase de fronteira mandando mesa e lore para a `mizuki-copiloto-do-mestre` —, e a pasta estava na frente **só no corpo**, em quatro das sete. *Nenhum dos dois lados estava velho por inteiro; cada um era dono de uma metade do arquivo.* **A regra do merge saiu disso e é mecânica: corpo da pasta, descrição da instalada.**
>
> **E a `rpg-da-guilda` da pasta carregava dois pontos cru no YAML da descrição** — `nesse repositório: escrever` —, que um parser estrito recusa. *A instalada já tinha o conserto, com vírgula e aspas.* **O carregador de verdade aceita os dois**, então era risco adormecido e não defeito vivo; ficou com aspas nas duas.

> **E a v0.66 viu os dois sentidos ao mesmo tempo.** A `rpg-da-guilda` instalada estava **39 linhas atrás da pasta** — sem o caminho de commit e sem a seção de como falar com o Mizuki, as duas fechadas com *"aplicada nos dois lados"* —, enquanto as de assunto estavam empatadas com a pasta e as duas atrás do CHANGELOG. **Não é uma direção de deriva; são duas, e elas convivem.**

**⚠ E um defeito que não é deriva — mas ele ACABOU na v0.93, e o parágrafo fica porque o motivo dele continua valendo.** *Medido de novo: as seis pastas de apoio estão instaladas e batem byte por byte com as da pasta de trabalho.* **O que segue abaixo é o que era verdade da v0.66 até a v0.92:** as quatro skills com pasta de apoio estavam instaladas só com o `SKILL.md`. A `design-mecanicas-rpg` manda ler `sistema/skills/design-mecanicas-rpg/references/matematica-de-dado.md`, a `balanceamento-simulacao` manda importar `sistema/skills/balanceamento-simulacao/scripts/dados.py`, a `playtesting-rpg` aponta para `sistema/skills/playtesting-rpg/assets/casos-sonda.md` e a `redacao-acessivel-rpg` para `sistema/skills/redacao-acessivel-rpg/references/checklist-de-revisao.md` — **e nenhuma dessas pastas existe do lado instalado.** *Medido na v0.66, contra as skills de sistema da mesma conta, que trazem as pastas delas normalmente.*

> **Ponteiro pendurado é pior que texto velho.** Texto velho dá conselho errado e dá para desconfiar dele; ponteiro pendurado manda abrir arquivo que não existe, e quem está seguindo a skill conclui que ela quebrou. **Toda reinstalação tem de levar as pastas junto** — o `LEIA-ME` dizia o contrário desde a v0.3 e foi corrigido.

## O sistema em uma página

**Base:** d20. Ficha começa no nível 2, teto lendário no 30.

**Maestria** = 1, +1 a cada oito níveis (chega a 4). É o único número que cresce com nível.

**Cinco atributos**, escala 0–6, o número é o modificador: Força, Destreza, Constituição, Inteligência, Essência. **Inteligência sabe; Essência percebe** — Sentir Energia e Percepção moram em Essência desde a v0.16.

**Quatro Testes de Resistência:** Físico (Força ou Destreza, travado na criação), Vigor (Constituição), Intelecto (Inteligência), Espírito (Essência).

```
Ataque corpo a corpo = d20 + Força + maestria
Ataque à distância   = d20 + Destreza + maestria
Ataque de conjuração = d20 + atributo da técnica + maestria
Defesa               = 10 + Destreza + proteção
Pontos de vida       = (inicial do Caminho + Con) + (por nível do Caminho + Con) × (nv − 1)
Pontos de energia    = PE por nível do Caminho × nível   (sem atributo, sem inicial)
Integridade          = 20 + (Essência + 5) × (nível − 1)   (sem Caminho, sem Constituição)
CD de feitiço        = 8 + atributo da técnica + maestria
Teste de Resistência = d20 + atributo do TR + maestria (só se treinado)
Perícia              = d20 + atributo + maestria (só se treinado)
Crítico              = 20 natural, e dobra os dados (só onde há rolagem de acerto)
Ofício               = d20 + o atributo que a situação pede + maestria (só se treinado)
Turno                = Ação de Movimento (9 m) + ação padrão + ação bônus + reação
                       Sacar ou guardar UM item é grátis; do segundo em diante
                       custa a Ação de Movimento inteira (peça 3 §3.2)
Iniciativa           = d20 + Destreza
Arredondamento       = para o lado que não te favorece. Custo sobe, ganho desce,
                       e o que você ganha nunca fica abaixo de 1
```

| Caminho | dado | vida no nv 1 | vida por nível | PE por nível | soma |
|---|---|---|---|---|---|
| Bastião | d12 | 12 | 7 | 4 | 11 |
| Vanguarda | d8 | 8 | 5 | 5 | 10 |
| Guia | d8 | 8 | 5 | 5 | 10 |
| Evocador *(fora da edição jogável desde a v0.270)* | d6 | 6 | 4 | 6 | 10 |
| Emanador | d6 | 6 | 4 | 6 | 10 |

**A trava da vida:** média dos dados **+ 3 de Constituição ≈ 8**, que é o que o manual supõe. Não é a média dos dados sozinha — esse foi o erro da v0.18. A soma vida+PE quase igual nos cinco é o que faz a troca ser sabor em vez de degrau de poder.

**A regra que governa tudo:** numa rolagem disputada, os dois lados precisam crescer no **mesmo ritmo**. Atributo investido cresce +3 na campanha; maestria cresce +3. Por isso nada deriva.

**Caminho e Trilha:** degrau de Caminho em `2 · 7 · 15 · 23 · 30`, entrega de Trilha em `2 · 11 · 19 · 27`. *O dono é a coleção v0.4, em `caminhos/`.*

**Progressão:** marcos nos níveis 6, 10, 14, 18, 22, 26 e 30. Cada marco dá **+1 atributo, +1 refino e +1 espaço de feitiço** de graça, mais **uma escolha de três** — **Corpo** (outro atributo), **Refino** (outro refino e uma aptidão) ou **Leque** (outro feitiço e uma Passiva). Teto de atributo 6, de refino 10.

**O refino é a métrica das aptidões**, e ele entra no texto delas como variável. Ele cresce +7 a +9 na campanha, então **não pode aparecer contra quem cresce +3** — fora acerto, CD, defesa, TR e dano; dentro custo, frequência, escopo e disputa contra outro refino.

**Cinco camadas de personagem:** Origem → Caminho → Técnica → Refino e Aptidões → Pactos.

**Feitiços conhecidos** = `2 + (nível ÷ 2)`, mais um por marco. Três no nível 2, dezesseis no 20. **O manual não conta feitiço desde a v7.7** — essa contagem tem um dono só, e é este documento.

**Vinte e três perícias e onze ofícios.** Perícia tem atributo fixo; ofício não — o atributo muda com o que você faz. O Caminho dá **duas perícias fixas + cinco livres**; a Origem dá mais duas perícias e **dois ofícios livres**. Nove de vinte e três, 39%.

**Feitiço de Toque** = os dados da Classe e nada mais (é o feitiço, e não soma arma nem Força). **Golpe simples** = arma + Força (é o Classe 0 físico). Um feitiço de Toque por turno; ataque extra é sempre simples.

**Invocações:** o invocador e todas as invocações somados entregam **uma** Rotina. A máquina inteira é a **peça 15**; o teto é da peça 6 §4. *Fora da edição jogável desde a v0.270, com o Evocador; o desenvolvimento novo mora em `invocacoes/`.*

## Onde cada coisa está

| Arquivo | Conteúdo |
|---|---|
| `00-fundacao/pitch-de-design.md` | os três pilares e as restrições do projeto |
| `01-pesquisa/dossie-de-metodologia.md` | a seção 8 lista as dez travas de arquitetura |
| `02-esqueleto/arquitetura.md` | o que o Fundamento resolve e os buracos em volta |
| `03-mecanica/01-atributos-acerto-defesa.md` | de onde vem o número — e a **seção 5.5, o `Inconsciente`**, que é a máquina de estado de 0 de vida |
| `03-mecanica/02-economia-de-atributos.md` | escala, criação, crescimento, teto |
| `03-mecanica/03-economia-de-acao-e-iniciativa.md` | turno, iniciativa, régua das Restrições |
| `03-mecanica/04-pericias-e-testes.md` | dificuldade, fail-forward, ataque de oportunidade |
| `03-mecanica/05-caminho-e-combate-sem-feitico.md` | Força, e por que uma arma sozinha não cabe |
| `03-mecanica/06-caminhos-e-trilhas.md` | a base dos cinco Caminhos e o argumento de cada um; desde a v0.270 o texto dos quatro que não são o Evocador é o da coleção v0.4 |
| `03-mecanica/07-pericias-e-oficios.md` | o quadro completo e as listas de cada Caminho |
| `03-mecanica/08-criacao-de-personagem.md` | **os oito passos, e uma ficha inteira de exemplo** |
| `03-mecanica/09-origens.md` | as cinco Origens, a sub-origem e as duas especiais |
| `03-mecanica/10-descanso-e-recuperacao.md` | os dois descansos, ambiente propício, exaustão e os quatro relógios |
| `03-mecanica/11-aptidoes-e-refino.md` | o eixo do controle: o refino, o terceiro eixo do marco, o catálogo, o Limiar e — **desde a v0.158, na §6.9** — o **dano na arma**, com a exceção de dano da §2 escrita e as duas condições dela |
| `03-mecanica/12-experiencia-e-progressao.md` | a curva de XP em degraus, o teto de um nível por missão, o retorno decrescente e o limiar do nível 20 |
| `03-mecanica/13-legados.md` | **a régua de magnitude e o catálogo de 81 entradas**, nos três formatos (Destranca · Ajusta · Desliga), com a cota de Desliga e as vagas declaradas |
| `03-mecanica/14-equipamento.md` | proteção, escudo, **as 52 armas** com fundo `3/5`, treino, requisito de Força e a divisão simples/marcial |
| `03-mecanica/16-ferramenta-amaldicoada.md` | **a camada por cima da arma**: a escada de grau, o `Estigma`, o gate herdado da peça 11, o `Desgaste`, o teto na ficha e as onze entradas |
| `03-mecanica/conferir-ferramenta.py` | as **dezenove** checagens da peça 16, e o par declarado entre a 3 e a 9. *A 19 entrou na v0.152: ela mede dominância **dentro** da Classe, que é o único corte que a peça 11 §4 autoriza, e lê os preços de uma tabela com dono só.* *A 17 entrou na v0.144: ela lê a promessa de limite de uso do próprio título da Classe 2 e cobra ela de cada entrada, com o teto de Reações por luta lido da peça 1* |
| `03-mecanica/15-invocacoes.md` | **o sistema de criação de invocação**: a casa de iniciativa, o pool da Matilha, a ficha própria dela, o custo, a morte, o retorno e o catálogo de 19 entradas |
| `03-mecanica/conferir-atributos.py` | acerto, defesa, TR, perícia, vida, PE máximo e a deriva contra o nível |
| `03-mecanica/conferir-acao.py` | a régua das Restrições, a dominância entre elas e o `Adianta` |
| `03-mecanica/conferir-pericias.py` | o quadro de perícias, as listas de Caminho e de Origem, e a colisão |
| `03-mecanica/conferir-descanso.py` | o piso, a exaustão, o arredondamento, a magnitude, o empilhamento e — **desde a v0.62** — a **escada de relógios**: os quatro degraus têm gatilho escrito, o `por cena` tem definição própria, e os dois totais publicados são recontados da pasta em vez de guardados |
| `03-mecanica/conferir-legados.py` | **catálogo**: recalcula a tabela de totais da peça 13 e falha se o escrito não bater com o contado |
| `03-mecanica/conferir-equipamento.py` | o fundo de cada arma, a dominância **uma vez por rota de proteção — e são três**, e o teto de Defesa derivado dos três donos |
| `03-mecanica/conferir-nomes.py` | o vocabulário do manual, extraído do `.docx`, contra todo nome que o projeto batizou |
| `03-mecanica/conferir-manual.py` | a direção contrária: o manual contra o vocabulário e os números do projeto |
| `03-mecanica/conferir-aptidoes.py` | as **doze** checagens da peça 11: a trava do refino, as três rotas do marco, o teto de Passivas, o kokusen, o **dano na arma** e as **contagens de aptidão**. *A 10 entrou na v0.158 e lê a exceção do teto como **relação** — em que refino ela dispara, quais faces, e se ela acrescenta um dado —, para que reverter o valor de forma coerente saia verde. A 11 é da v0.161: ela reconstrói quantas aptidões cada rota leva e compara com os **nove** lugares que publicam o número, e amarra as **três** cópias do `meio a meio`* |
| `03-mecanica/conferir-expansao.py` | os gates da Expansão, a ordem entre os degraus, o preço em espaços, a fragilidade da curva, o clash, a concentração na corrida e o degrau sem barreiras |
| `03-mecanica/conferir-orcamento.py` | o somatório: todos os drenos de PE ao mesmo tempo, e se todo preço tem número |
| `03-mecanica/conferir-xp.py` | a curva, o abismo que fecha, e se a regra ainda entrega o tempo que a Guilda pediu |
| `03-mecanica/conferir-criacao.py` | **a instância, não a regra**: a ficha de exemplo da peça 8 contra as fórmulas, a proteção da aptidão gratuita, a Trilha na criação e se o catálogo citado existe |
| `03-mecanica/conferir-ficha.py` | **o material contra a regra**: as 23 perícias, os 11 ofícios, os 5 Caminhos, as 15 Trilhas, as Famílias e as constantes do nível 2 que a ficha imprime, contra as peças donas |
| `03-mecanica/conferir-invocacoes.py` | as **trinta e quatro** checagens da peça 15, sem um número guardado dentro dele — e a busca exaustiva das 5.429 montagens que gastam o orçamento cheio no nível 30 |
| `03-mecanica/17-catalogo-de-entregas.md` | **o índice das 102 entradas** — 68 entregas de Trilha, 20 degraus de Caminho e as 14 Manhas —, com a regra de contagem e o ponteiro de onde o texto de cada uma mora |
| `03-mecanica/conferir-catalogo.py` | as **dezesseis** checagens da peça 17, e **o primeiro validador que sai da pasta**: ele lê os três `DESENHO-*.md` da raiz |
| `03-mecanica/18-progressao.md` | **a tabela de progressão** — o que se ganha em cada nível, do 1 ao 30, numa tabela só. Nove das dez colunas são cópia com dono declarado; a décima, o tamanho da lista de feitiços, nasce aqui |
| `03-mecanica/conferir-progressao.py` | as **oito** checagens da peça 18: cada coluna reconstruída a partir do dono, a fórmula dos espaços contra a tabela da peça 11, e a cópia de três fichas da peça 2 |
| `03-mecanica/19-dano-e-condicoes.md` | **a régua de condição** — quanto vale cada uma das treze, em dano por rodada e em nível —, mais as treze condições, os catorze tipos de dano e a cobertura, que vieram da peça 1 |
| `03-mecanica/conferir-dano.py` | as **catorze** checagens da peça 19 (a 14, o `Calado` nas cinco cópias, é da v0.276), e a nona sai da pasta: ela bate as duas entregas publicadas que aplicam condição contra a régua. *A décima primeira entrou na v0.104, com a penalidade de arma.* **A 12 e a 13 são da v0.198:** *a 12 mede as ações do chefe como **piso** — com uma a menos, quatro condições saem da banda —, e a 13 recalcula a régua inteira contra o capanga em vez do chefe. E a sub-checagem `1.1` compara a tabela de âncoras da peça com a lista do validador, que eram duas listas de catorze sem ninguém comparando* |
| `03-mecanica/20-tecnica-marcial.md` | **a rota de criação de quem não escreve Fundamento**: a máquina herdada, as duas rotas — três grupos de arma, ou uma ferramenta sob medida —, o Selo que virou equipamento, e os três renomes `Kata`, `Ruptura` e `Ōgi` |
| `03-mecanica/conferir-marcial.py` | as **catorze** checagens da peça 20, e o par declarado entre a 3 e a 9: uma pergunta se a rota recebe demais, a outra se ela é frágil demais |
| `03-mecanica/21-objeto-amaldicoado.md` | **a peça de vocabulário**: onde as quatro coisas que carregam energia amaldiçoada se separam, a **atração** e o selo que a inverte, o `Kiko`, e os três resultados de encarnação que já eram três Origens |
| `03-mecanica/conferir-objeto.py` | as **doze** checagens da peça 21, e o par declarado entre a 3 e a 8: uma pergunta se ela republica o que já tem dono, a outra se o que ela criou tem dono |
| `03-mecanica/22-pactos.md` | **a quinta camada de personagem**: as quatro formas de pacto, o teto de quantidade do permanente, o orçamento como teto de dano, o catálogo de exemplo da obra e as oito ideias de restrição |
| `03-mecanica/conferir-pactos.py` | as **catorze** checagens da peça 22, e a segunda é o par declarado: o teto por pacto não está escrito nela, é `camada ÷ (teto de atributo ÷ 2)` — ela mede relação e não constante |
| `03-mecanica/23-bloquear.md` | **rolar para se defender**: o `2d10 + (Defesa − 11)`, por que o dado não é o d20, o `Aparar` e a `Brecha`, o invariante do modificador único, e a única condição que desliga |
| `03-mecanica/24-dano-de-alma.md` | **a máquina de alma inteira**: a Integridade com Essência dentro, os quatro estágios, o acoplamento com a vida, a exceção que atravessa o corpo, e o Teste de Resistência de Espírito que a v0.7 decidiu e ninguém aplicou |
| `03-mecanica/conferir-alma.py` | as **treze** checagens da peça 24. *A 12 entrou na v0.159 e lê o manual: a caixa de `Integridade` tem de nomear os dois lados, e a seção `Inimigos` tem de mandar anotar a barra.* *A 13 entrou na v0.228: a metade do inimigo é a mesma na peça 26, no manual e no gerador, e o limite de um terço do `Cisão` sai dela.* *A 1 reconstrói a curva a partir de **três** donos independentes — a peça 24, o teto de atributo da peça 2 e a curva original lida do manual — e a 4 é a única do projeto que mede **consequência**: se o estágio 4 sumir da campanha, nenhuma outra checagem acusaria* |
| `03-mecanica/conferir-bloquear.py` | as **oito** checagens da peça 23. *A 8 entrou na v0.159 e mede a Reação do inimigo como **relação** contra a peça 3 §3, com o `0,16` disparo por combate recalculado da enumeração.* **A checagem 1 é a única do projeto que existe para sustentar um número de OUTRA peça:** ela recalcula a neutralidade por enumeração das `2.000` combinações, e é dela que o preço do `Incapacitado` na peça 19 depende — `4,95` desde a v0.151 |
| `03-mecanica/25-sem-tecnica.md` | **a rota de criação de quem tem energia e não tem técnica inata**: a semente — uma aptidão aberta na criação, em `Classe Passiva 2` ou `3` —, as três portas, os renomes `Manejo` e `Auge`, o buff de `1/3 do refino` na cura da rota da Shoko, e por que a Expansão de Domínio não existe aqui |
| `03-mecanica/conferir-sem-tecnica.py` | as **treze** checagens da peça 25, e nenhum valor de regra mora dentro dela. *A 5 é a que decide a peça: ela não guarda os `9,3` nem os `17,3` — lê a escada de gate da peça 11 §5, simula as três rotas de marco e recalcula a antecipação de cada altura, então mexer na escada de forma coerente move a banda junto e sai verde de propósito* |
| `03-mecanica/26-bestiario.md` | **a máquina de montar inimigo**: a ficha de vinte linhas com dono declarado, a tabela por nível da Defesa, do acerto e da CD, a grade de cinco degraus de dificuldade por `×1` a `×6` pessoas, o esquadrão do `Capanga`, o que o inimigo carrega pago na vida, e o grau como rótulo de ficção |
| `03-mecanica/conferir-bestiario.py` | as **onze** checagens da peça 26, e nenhum valor de regra mora dentro dela. *A 2 é a que decide a peça: ela não guarda a Defesa nem a CD do inimigo — reconstrói as duas das fórmulas da peça 1 §5 e cobra que elas devolvam, do lado do inimigo, os mesmos `50%` a `55%` de acerto e `65%` de resistência que a peça 1 §6 publica do lado do jogador.* **A 5 não guarda o câmbio: ela roda a simulação de fogo concentrado aqui dentro**, nos seis níveis da tabela do manual |
| `03-mecanica/27-ritual.md` | **o Ritual**: a escada de `2 · 6 · 10` pontos, a CD que rola `Ocultismo` contra `8` + Classe − Destreza, a lista própria de dezesseis, e a matriz Forma × Melhoria. *A peça inverte a regra da obra — o padrão do sistema é omitir, e ritualizar é desfazer a omissão.* |
| `03-mecanica/conferir-ritual.py` | as **sete** checagens da peça 27. *A `5` é a que ele pediu: ela não julga se a Melhoria anula Restrição — exige que cada uma DECLARE com quais ela não entra, inclusive "nenhuma". Pega erro de omissão, e achou a segunda trava na primeira rodada.* |
| `05-material/gerador-ficha/` | o gerador da ficha (Node: `node make.js`), e os dois `.docx` que ele produz |
| `05-material/gerador-inimigo/` | **o gerador do bloco de inimigo** (Node: `node make.js`), e o `bloco-de-inimigo.docx` de quatro páginas que ele produz — as tabelas que o mestre copia, o bloco em branco e um exemplo preenchido. *O `dados.js` dele não é autoridade de nada: o bloco `7` do `conferir-ficha.py` compara com a peça 26* |
| `conferir-repositorio.py` | a árvore, as referências mortas, os números que moram em mais de um documento, os **ponteiros de seção** — todo `peça N §M` citado tem de apontar para seção que existe, desde a v0.54 —, o **mapa** desta tabela contra a pasta, a **entrega** contra a fonte, a **pendência morta** desde a v0.100 — nenhum item de "Em aberto" pode pedir coisa que já existe —, e, **desde a v0.102**, a **contagem de checagens de cada validador, lida do código** |
| `99-arquivo/` | material morto, com LEIA-ME próprio. Não leia de lá para escrever peça nova |
| `caminhos/` *(na raiz)* | **a coleção v0.4 dos Caminhos**: o texto do Bastião, da Vanguarda, do Emanador e do Guia e das doze Trilhas, com as ideias reservadas e as notas. *Dona do texto desde a v0.270, sem preço medido* |
| `invocacoes/` *(na raiz)* | **o subsistema de Invocações em desenvolvimento**, fora da edição jogável: a candidata r5, as pesquisas, e no `museu/` o capítulo de Invocações e a seção do Evocador que saíram do livro |

**Duas peças foram parcialmente substituídas e trazem o aviso no topo:** as seções 3 e 4 da peça 4 saíram para a peça 7, e a seção 3 e o quadro de Caminhos da peça 5 saíram para a peça 6.

O manual do Fundamento **v7.41** (`manual/Fundamento-MANUAL-v7.docx`) é o subsistema de técnica e feitiço, já validado. `manual/gerador/` traz o gerador (Node: `npm install docx && node make.js`) e `manual/matematica/` os validadores `pac7.py` e `v7.py`. **O `.pdf` está na mesma versão do `.docx`, exportado junto desde a v0.93**, e ele deixou de ser exportado a mão: sai do `soffice --headless`. *Desde a v0.246 ele usa as fontes de métrica instaladas em 14/09 — Carlito no lugar da Calibri e Gelasio no da Georgia.* **A contagem de páginas, parágrafos e tabelas saiu daqui na v0.263:** *esta linha dizia `49` páginas, `366` parágrafos e `90` tabelas, e o manual da v7.37 já tinha `50`, `410` e `95`. Contagem de artefato não tem dono, e copiada ela só envelhece.*

**Quem é dono da versão do manual:** a primeira linha de `manual/gerador/COMO-USAR.txt`. Toda outra cópia — a capa em `partA.js`, este arquivo, o `README.md`, o `LEIA-ME.md` e o `arquitetura.md` — é cópia, e o `conferir-repositorio.py` falha se alguma divergir. *Ele nasceu na v0.33, depois de a capa do manual passar três versões dizendo 7.5.*

### O manual não é lei, e saber disso muda como se lê

*Registrado na v0.26.* Os limitadores, exemplos e tabelas do manual foram calibrados quando o sistema em volta era outro. **Servem de base para continuidade; não valem ao pé da letra.** Dez decisões do projeto estão penduradas em quatro tabelas dele, e as quatro não são iguais:

| tabela | dono | o que ela segura |
|---|---|---|
| **PE** — *"quantas vezes você lança"* | **o projeto** | o 6 do Emanador, a fórmula do PE máximo, o orçamento de missão. Mudou o 6? Regere a coluna |
| **Rotina** — dano por rodada por Classe | **o manual** | o feitiço de Toque, o ataque extra, o conserto da invocação, os 10% do crítico. Ela é a **régua**, não uma medida: mudar a Rotina reprecifica os quatro de uma vez |
| **Classe 0** — dano por faixa de nível | **o manual** | a linha do conjurador da peça 6 §3, o vão que paga o degrau do nível 7 dos cinco Caminhos, o `Resquício`, e os degraus de Trilha que põem um Classe 0 num slot |
| **Inimigo** — chefe e capanga por nível | **o playtest** | a trava de vida inteira. É a única das quatro que afirma algo sobre o mundo — que um combate dura ~3,5 rodadas — e ninguém é dono dela até alguém jogar |

> **A do Classe 0 entrou na v0.80, e ela entrou porque estava faltando.** *As outras três estão listadas aqui desde a v0.26; essa nunca foi listada, nenhum documento do projeto citava ela, e nenhum validador abria ela.* **O projeto preçava um Classe 0 em `4,50` fixo — número que não existe no manual — enquanto a tabela dele diz `2d8 · 3d8 · 4d8 · 5d8 · 6d8` por faixa de nível.** *Cinquenta e uma versões, e o que a achou não foi validador nenhum: foi ir ler a regra pendurada num termo antes de aceitar o preço dele, que é a lição nº 6.*
>
> **A lição que sai daí e que não estava escrita: uma tabela compartilhada sem dono declarado não é "ainda não decidida" — é uma que vai divergir e ninguém vai notar.** *Vale varrer o manual atrás da quinta.*

O `conferir-manual.py` falha se os dois lados divergirem, e a mensagem dele **nomeia o dono** em vez de acusar o projeto. Divergência ali é pedido de decisão.

## Pendências, da mais urgente à menos

> **A fila do LIVRO não mora aqui.** *A passada de termos da v0.108 deixou quatro itens em
> ordem — gatilho e duração nas 74 habilidades, exemplo inline em ~38 seções, a terceira camada
> em seis blocos, e o que sobrou da passada de voz.* **Eles estão em
> `05-material/livro/ESTADO-revisao.md`, na seção *A fila, em ordem de quem retoma*.** *Aqui
> ficam só as pendências de mecânica.*
>
> ⚠ **E fica registrado um padrão que custou quatro diagnósticos naquela versão:** *medir o
> marcador em vez do fenômeno.* **Quatro contas sobre o livro deram números altos e todas
> estavam erradas** — o regex procurava `Exemplo:` e o texto escrevia `**Exemplo.**`; a conta
> de exemplos ignorava a exemplificação sem marcador; a de "22 seções enterram a tabela" só via
> um dos três formatos de regra, e o número real era zero. ***Quando um número sobre um
> documento deste projeto parecer alto demais, o primeiro suspeito é o filtro, não o
> documento.***


1. ~~**Nome do sistema.**~~ **`Projeto - M`, decidido na v0.94.** *Aberto desde a v0.1; era a pendência mais velha que o projeto tinha.*
2. ~~**Se a perícia livre da Origem devia ser da lista também.**~~ ***FECHADA na v0.130, por decisão do Mizuki: ela fica livre.*** *A segunda perícia da Origem continua vindo da ficção, com o mestre aprovando na leitura — "foi filho de médico, tem Medicina".* **É o único lugar da criação em que um número depende de julgamento, e o custo está aceito e declarado:** dois mestres podem aprovar coisas diferentes. *A troca é a Origem ter espaço de ficção na ficha, e ela vale mais que o fecho do filtro.*
3. ~~Quantas Trilhas um personagem acumula, e em que níveis.~~ **Fechada na v0.55, na v0.60 e na v0.65:** uma por ficha, entregas em `2 · 11 · 19 · 27`. **A Trilha é fechada — não se pega emprestado das vizinhas —, e nos níveis 11, 19 e 27 dá para TROCAR de Trilha, com troca total.** **O degrau de Caminho mudou na v0.70 e é `2 · 7 · 15 · 30`** — três fatias nos níveis 2, 15 e 30, e o nível 7 de graça porque ele vale o vão `físico − conjurador` e é correção de base.

   > **O calendário novo custa vão e seca, e o preço está aceito e medido.** Contra o antigo `7 · 15 · 23 · 29`, o vão máximo entre entregas vai de **5 para 8 níveis** (entre o 19 e o 27) e a seca vai de **24 para 31 missões** (entre os marcos 22 e 26). *Quem carregava as duas métricas era o degrau do nível 23.* **Decisão do Mizuki na v0.71: fica, e o resto do sistema carrega o vão pelas camadas de cima.** O que se compra com ele é identidade de Caminho no nascimento, junto com a Trilha, e um capstone no 30 — o formato do Paladino de 2024, que a auditoria da v0.69 conferiu em `3 · 7 · 15 · 20`.
4. ~~**Como a Trilha Torrente cobra o segundo feitiço da rodada**, contra a regra de ouro nº 6.~~ ***FECHADA na v0.131, e as três afirmações dela reprovaram na medida.*** *Aberta desde a v0.14.* **Ela cobra em PE, no preço que o manual já dá para a Melhoria `Rápido` — não existe lista de pontos à parte.** *E o conserto da invocação não serve: no nível 30 o teto somado deixa `14` de folga, e a regra de ouro nº 6 sozinha já permite um `Classe 0` de `27` — ele é mais apertado que a regra que ia vigiar.* **A razão é estrutural: invocação põe corpo, e corpo multiplica; a `Torrente` usa as duas ações que a ficha já tem, e trava em dois feitiços para sempre.** *A medida está na peça 6 §9; o preço, no `DESENHO-trilhas.md`.*
5. ~~**O que Elo, Sutura e Perímetro entregam** que valha o golpe por rodada que o Guia não tem.~~ **Fechada na v0.61, com número:** valem **o vão `físico − conjurador` da peça 6 §3**, e ele chega como o degrau de Caminho do nível 7 — o mesmo lugar em que Bastião e Vanguarda recebem o ataque extra. Os cinco Caminhos empatam em `+6%` da Rotina no nível 30. *A ficção de cada uma continua sendo a Q5 de Trilhas.*
6. ~~**Se a curva de dano deve cruzar a coluna Rotina.**~~ **FECHADA na v0.73: sim, ela cruza, e por decisão.** *Ficou aberta desde a v0.27.* No nível 2 o conjurador está +38% e o físico +69% acima da Rotina; no nível 30 o físico terminava **2% abaixo**. **Com o orçamento dobrado duas vezes — a fatia é `5,08`, o Caminho leva `3` fatias e a Trilha leva `5` —, ele termina em `+35,8%` acima**, e a camada de Caminho mais Trilha vale **`27,7%`** do que o personagem faz.

   > **A dívida acoplada, com o número corrigido na v0.74: a tabela de inimigo do manual NÃO subiu.** A v0.73 registrou `36%`, e aquele número é o `+35,8% da Rotina` copiado com a base trocada — a base de antes era `98%` da Rotina. **Com a base certa dá `+38,3%`, e mesmo isso é teto e não valor**, porque supõe que as `8` fatias inteiras viram dano. A matriz do Bastião diz que não viram: o `Muro` põe `0,00` em dano, e um grupo de `Muro` **estica** a luta. **Redevirar quando as nove Trilhas que faltam estiverem preçadas** — o dono daquela tabela é o playtest, e `04-playtest/` continua vazia.

   > **A trava que veio junto, e sem ela a decisão não vale:** a magnitude **nunca pode vir de uma ação a mais por rodada.** O `+18%` da peça 6 §3.1 não é um teto de dano — é a medida de uma montagem de **três ações** que aquela seção reprova, e o que ela recusa é o mecanismo. *Eu li aquele número como teto disponível antes de conferir, que foi o segundo piso-lido-como-teto da mesma sessão.*
   >
   > **Contra-teste rodado:** `3×` o orçamento dá `+23%` e `4×` dá `+31%`, e as duas reprovam. O teto prático é `21` de dano por rodada. *Os dois números do topo eram 21% e 16% até a v0.60, e eles saíam de a peça 6 §3 estar lendo a coluna errada do manual — com a `Rotina` de verdade o abismo do topo quase fecha sozinho, e o que sobra é meia dúzia de pontos percentuais.*

### O estado de 0 de vida entrou na v0.37, e na v0.88 ele virou `Inconsciente`

*A peça 1 ganhou a **seção 5.5**, e ela fecha a pergunta nº 5 do `pitch-de-design.md` — aberta desde a v0.1.* A 0 de vida você escolhe **Aguentar** (apaga, janela de 3 rodadas, cura de `20%` da máxima te levanta, e cada dano recebido tira uma rodada) ou **Insistir** (fica de pé, cada rodada custa 1/8, 1/4 e 1/2 da vida máxima). Levantar dá uma **Sequela**, que encurta a janela da próxima queda; **na segunda queda vem uma Cicatriz**. O fim da janela é o **estágio 4 de dano de alma**, que o manual já escrevia e que ninguém alcançava. Seis checagens novas no `conferir-atributos.py`, com oito perturbações conferidas.

> ~~**A dívida: uma Cicatriz não tem mecânica, só nome.**~~ ***FECHADA na v0.171, e não na peça que a dívida esperava.*** **Ela é vantagem em `Intimidação` e desvantagem em `Persuasão`, as duas `Essência`, e mora na peça 1 §5.5.** *Teto `1`, porque vantagem não empilha, e ela **não vem** se quem fechou o ferimento foi a sua própria `Energia Reversa`.* **A `Energia Reversa` não limpa Sequela** — a segunda metade da pergunta fechou junto.
>
> > **A dívida esperava a peça de dano e condições, e a resposta não veio de lá.** *A peça 24 §6.3 mediu o recorte na v0.145 e devolveu a `Cicatriz` para a peça 1: ela é consequência de cair a `0` de vida, e não de condição nem de dano de alma.* **Por isso ela não entra na régua da seção 2 da peça 19, e não é entrada de catálogo** — a troca acontece dentro de um poço só, sem preço em fatia. *O §7 daquela peça registra o fecho.*
>
> ***E este bloco ficou dezessete versões dizendo "o que precisa ser resolvido quando aquela peça chegar", com a peça 19 no disco desde a v0.103 e a dívida paga desde a v0.171.*** *Achado na v0.188.* **O topo deste mesmo arquivo já publicava a mecânica da `Cicatriz` — duas cópias do estado do projeto, a setecentas linhas uma da outra, e a de baixo envelheceu.**

*Resolvida na v0.20:* a colisão do Grau. O manual, o PDF e as fontes já usam **Classe** — 0 ocorrências de "Grau" no `.docx`, `pac7.py` e `v7.py` passando.

*Resolvido na v0.21:* **Sentir Energia**. O achado da v0.20 dizia que ela falha no teste do bônus automático, e a decisão foi aceitar conscientemente — sempre vai existir perícia melhor que outra, e as pessoas escolhem por querer ser únicas. Deixou de ser problema aberto e virou decisão registrada.

*Resolvidas na v0.24:* os **nomes das Trilhas** — os seis que colidiam viraram **Batedor · Executor · Sutura · Perímetro · Servo · Matilha**, e o `conferir-nomes.py` falha se algum voltar. E o **Coro**: dono e invocação agem no mesmo turno, e não custa nada, porque o orçamento dividido é teto de saída e não de número de ações.

*Resolvidos na v0.26:* os **quatro buracos de regra** da v0.24 — arredondamento, o que conta como luta, a fórmula do PE máximo e o texto da exaustão. Mais a **Passiva Casca**, que morreu e virou a **Escama**; o **requisito e o preço do Kokusen Melhorado** (aptidão, refino 5 e nível 14); a definição de **resistência**; e os dois órfãos que apareceram no caminho — a **Fraqueza** com Habilidade e Sabedoria, e o **Carregar** contra a **Concentração** apontando para testes diferentes.

## O marco ganhou um terceiro eixo: o Leque

*Decidido depois da v0.26, e ele muda a peça 2.* A escolha de marco era **atributo ou refino**. Agora são três, uma por eixo da ficha — **corpo, controle e técnica**.

> **Passivo, em todo marco:** +1 atributo, +1 refino e **+1 espaço de feitiço**, gastável onde você quiser.
> **A escolha, uma das três:** mais atributo · mais refino e uma aptidão · **Leque: +1 feitiço, que só pode ser feitiço, e uma Passiva de graça.**

**Por que ele existe.** Passiva custa espaço de feitiço conhecido, e a Expansão de Domínio também — 2 pela incompleta, 3 pela completa. Sem uma rota que devolva espaço, quem monta técnica funda fica sem lista: pela conta antiga, três Passivas de Classe 2 mais a Expansão completa chegavam ao **nível 20 com dois feitiços**, e cinco Passivas de Classe 3 mais Expansão eram **impossíveis em qualquer nível** — 18 espaços numa ficha de 16. **O teto de "cinco Passivas pagas" do manual já era letra morta.**

**A linha passiva do marco sozinha conserta isso**, sem dobrar a lista:

| montagem | nv14 | nv20 | nv26 | nv30 |
|---|---|---|---|---|
| só feitiço | 12 | 16 | 21 | 24 |
| 3 Passivas Classe 2 + Expansão completa | 3 | **7** | 12 | 15 |
| 5 Passivas Classe 3 + Expansão completa | 0 | 0 | **3** | 6 |

A montagem típica sai de dois feitiços no nível 20 para sete, e a mais pesada que existe — cinco Passivas de Classe 3 mais a Expansão completa, 18 espaços — passa a caber **a partir do nível 22**, em vez de nunca.

**E as três escolhas se auto-equilibram.** `+1 feitiço + 1 Passiva` empata com `+1 refino + 1 aptidão` porque Passiva e aptidão vivem na mesma escada de Classe; o que sobra dos dois lados é `+1 feitiço` contra `+1 refino` — e **refino não vale nada para quem não tem aptidão**. Quem escolhe Leque não quer refino, e quem escolhe refino não quer Passiva. As três compram coisas que não se substituem.

**O nome passou pela triagem, e dois candidatos morreram nela.** *Técnica* está dentro de **Sem Técnica** (a Origem) e de **Técnica Máxima** (o manual); *Repertório* já é Trilha do Emanador. **Leque** está livre nos dois lados — e é a palavra que o próprio Mizuki usou para descrever o que a rota compra.

**A fórmula dos feitiços, fixada:** `2 + (nível ÷ 2)`, arredondando para baixo. Isso dá **3 no nível 2** — dois de toda ficha mais o do próprio nível 2, que é o que confundia os dois documentos — e **12 no nível 20**. A prosa do manual diz treze; ela vira **doze, mais um por marco**, e entra na v7.7.

**O teto de Passivas: a grátis traz a própria vaga.** Cada escolha de Leque sobe o máximo em 1, e a Passiva concedida ocupa essa vaga nova. Então o teto vai de 5 a **12**, e as **pagas continuam sendo cinco** — exatamente as cinco que o manual sempre teve. O teto não cresce de verdade; ele só abre lugar para o que a rota concede.

E o que essa ficha paga por isso, no nível 30:

| rota | atributo | refino | aptidões | Passivas | feitiços a mais |
|---|---|---|---|---|---|
| sempre atributo | **14** | 8 | 0 | 5 | 0 |
| sempre refino | 7 | **10** | **10** | 5 | 0 |
| sempre Leque | 7 | 8 | 0 | **12** | **7** |
| meio a meio | 9 | 10 | 3 | 7 | 2 |

Doze Passivas e sete feitiços é o que a rota **compra** — zero aptidões, refino parado no 8 e metade dos pontos de atributo de quem foca corpo. Não é bônus por cima.

> **⚠ As três primeiras linhas são cópia da tabela da peça 11 §3, e o dono é ela.** *A quarta é só daqui: as três puras não descrevem ninguém, e a mistura é quem a mesa joga.* **A checagem 11 do `conferir-aptidoes.py` compara as duas contra a regra**, que é o que faltava — foi por isso que a célula de aptidões da rota pura passou da v0.89 à v0.160 dizendo `7`.
>
> ***De onde sai o `10`:*** *a decisão da v0.89 é "no teto, a escolha de Refino leva DUAS aptidões".* **A linha de graça põe o refino em `10` no marco 22, então os marcos 22, 26 e 30 pagam em aptidão** — `1·2·3·4` nos quatro primeiros e `+2` em cada um dos três últimos. *O `7` era a contagem de antes, uma por marco.*
>
> ***E o `meio a meio` foi alinhado à curva da peça 11***, que é `3` escolhas de Refino e não `2`. *Ele publicava `10` de atributo e `2` aptidões, que é uma rota diferente com o mesmo nome — e o `conferir-atributos.py` deriva a Defesa do alvo difícil da curva da peça.* **Duas rotas com um nome só é o que a lição nº 9 chama de divergência antes de ela acontecer.**

## Expansão de Domínio, clash e três decisões soltas

> **O argumento de projeto das aptidões e do refino saiu daqui nesta versão** e está na **seção 10 da peça 11**, inteiro. Ele descrevia uma peça que fechou na v0.27, e este documento é lido no começo de toda conversa — 24 KB de argumento de peça pronta faziam ele não caber numa leitura só. O que sobrou abaixo é o que **não** é da peça 11: a Expansão, que mora no manual, e três decisões que atravessam outras peças.

### O clash de expansões — publicado na v0.173, e ele saiu da rolagem

***O dono é o manual, na v7.19, seção 7.*** *Da v0.27 à v0.172 a regra existia só aqui e no rascunho, e os dois afirmavam que a v7.7 do manual a citava — ela não citava, e nenhuma peça, nem o livro, tinha ela.*

> **Enquanto dois domínios sobrepostos estão de pé, nenhum dos dois acerta garantido. Quem conquista sai de quatro degraus: mais refino · Acerto que não causa dano · `1d12` separando por `4` · a corrida.**

**A cascata é derivada, e nenhum número novo entrou.** *A corrida é o desempate: os dois seguem de pé, e o primeiro que perder o domínio — barreira derrubada por fora, duração vencida, ou falhas de concentração demais — ou chegar a `0` de vida recebe o Acerto do outro.* **Quem perde recebe o Acerto sem escolha** — *a saída de abrir buraco caiu na v0.200 —, **e desde a v0.225 segurar o domínio na corrida pede teste de Vigor contra a CD do rival**: *o jogador a cada dano, o inimigo uma vez por jogador por rodada, e o domínio cai quando as falhas chegam a metade da Essência.*

> **⚠ A rolagem `1d10 + quantidade de aptidões + metade do nível` FOI REVERTIDA**, e com ela as taxas de vitória que este documento publicava. *O levantamento externo da v0.173 achou que a obra resolve o empate por corrida e não por rolagem, e a corrida amarra em três estados que já tinham dono — vida da barreira, duração e `0` de vida.* **O argumento da reversão está no CHANGELOG da v0.173.**

**O refino decide sozinho do marco 10 ao 22** — `5·7·9·10` do especialista contra `4·6·7·9` do chefe, que herda a curva do meio a meio. *Do marco 26 em diante os dois estão no teto `10` e o refino para de separar:* **é aí que a segunda e a terceira pergunta passam a valer, e elas cobrem `59%` dos pareamentos capazes de clash.**

**O inimigo carrega refino na ficha dele**, como vida e dano, no padrão do ambiente propício: **valor sugerido pelo nível na tabela, e a palavra final do mestre em cima dele.**

> **⚠ E isto ficou MAIS BARATO para o `BESTIÁRIO` na v0.173.** *Enquanto a rolagem existia, a contagem de aptidões do inimigo era modificador de rolagem viva e tinha de ser preenchida para todo inimigo com domínio.* **Hoje a cascata lê refino e o tipo do Acerto, e nenhum dos dois é contagem** — o BESTIÁRIO perdeu um número da lista dele.

### Três decisões que saíram junto, e que não são da peça de aptidões

**A Trilha vem no nível 2, e já rende ali.** Três lugares do material diziam que ela *"não afeta o nível 2, afeta a primeira subida"* — e o motivo da confusão é o mesmo dos feitiços: **toda ficha nasce no nível 2**, e o nível 1 é quem ainda está entrando no mundo jujutsu, civil ou sem técnica desperta. A Trilha é identidade, como o Caminho, e nasce com o personagem.

> **Aplicado na v0.34, e ficou sete versões parado.** A decisão está escrita aqui desde a v0.27 e terminava em *"corrigir na peça 6, na peça 8 e aqui"* — e os três continuavam dizendo o contrário. Este documento chegou a se contradizer sozinho: esta seção dizia que a Trilha vem no 2, e duas tabelas mais abaixo diziam que ela não afeta o 2. **Decisão registrada não é decisão aplicada**, e nada no projeto conferia a diferença.

**A Expansão de Domínio tem duas peças: Acerto e Efeito.** O **Acerto** é o que a expansão garante que acontece; o **Efeito** é o que ela permite fazer lá dentro. A incompleta resolve o Acerto por rolagem; **a completa, com barreira, resolve por acerto garantido** — e isso já é palavra do manual, que resolve feitiço por *Acerto · Teste de Resistência · Automático*.

| | Acerto | Efeito |
|---|---|---|
| Megumi, incompleta | buffa todas as invocações | permite invocar todas elas |
| Hakari | todos recebem a informação da expansão | o pachinko, e a regeneração |
| Higuruma | ninguém no ambiente pode causar dano | o julgamento, e as punições |
| Gojo | a enxurrada de informação | tocar em outros para poupá-los |
| Sukuna | clivar e desmantelar acertam | alcança todos no ambiente |
| Yuta | os feitiços das espadas acertam | todas as técnicas copiadas, em forma de espada |
| Jogo | queima todos no ambiente | amplifica a técnica |
| Mahito | ninguém desvia do toque | alcança todos no ambiente |
| Dagon | os shikigami acertam | amplifica a técnica |

**E isso fecha um laço que ninguém tinha visto:** se a expansão completa sempre acerta, os **anti-domínio serem aptidões baratas é o que a torna sobrevivível**. Se fossem raros, o acerto garantido seria opressivo. A decisão de pôr todos no catálogo por marco foi tomada antes de a expansão ter forma, e é a peça que faz as duas funcionarem juntas.

> **⚠ São TRÊS desde a v0.165, e o argumento acima ficou mais forte e não mais fraco.** *A `Extensão de Domínio` saiu da categoria — ela não é uma anti-domínio, ela serve como uma — e era justamente a única Classe Passiva 3 das quatro.* **A resposta barata que sustenta este laço é a `Cesta Oca de Vime`, de Classe Passiva 1 e sem gate, e ela não se moveu.**

**As Bênçãos de Corpo, para quem não tem energia.** A Restrição Celestial pelo ramo da Maki não tem energia amaldiçoada — sem PE, sem feitiço de Toque, sem Sentir Energia — então não tem aptidão nem refino. Ela ganha **a mesma máquina com outra métrica**: as aptidões se chamam **Bênçãos** e o refino se chama **Lapidação**.

> **Corpo Amaldiçoado saiu deste balde na v0.38, e o motivo é canon.** A frase acima incluía os dois. Mas *cadáver amaldiçoado de mutação abrupta produz a própria energia* — é literalmente o que a mutação concede, cerca de três meses depois de ele acordar. **O que ele não tem é técnica, não energia.**
>
> Então ele é **misto**: PE, aptidões e refino como qualquer feiticeiro, e **Técnica Marcial** no lugar do Fundamento, porque não existe técnica inata para escrever. A Maki é a única sem energia nenhuma, e as Bênçãos são só dela.
>
> *Decidido com o Mizuki na v0.38 e **aplicado na peça 9 na v0.39**, junto com as outras mudanças que a peça 13 devia àquela peça.* A entrada de Corpo Amaldiçoado hoje diz *"você tem energia amaldiçoada: cadáver de mutação abrupta produz a própria, uns três meses depois de acordar"*, com PE, aptidões e refino normais e Técnica Marcial no lugar do Fundamento. Andar em parede e em água, deslocar-se no ar, *fast steps* — o físico no lugar do energético. Os dois nomes passaram pela triagem e estão livres nas duas direções.

Isso é a camada de aptidão da **Técnica Marcial**, que o material já descreve como *"paga com o corpo e com ferramenta amaldiçoada"* — e foi o que destravou duas das três rotas de Origem que não rodavam até a v0.122. *A terceira era `Sem Técnica`, e ela fechou na v0.168.*

### Sem Técnica precisava de máquina de criação própria — e a máquina acabou não sendo própria

*Decidido na v0.38, e os dois lados vieram de levantamento. **Fechado na v0.168, na peça 25.***

**O `arquitetura.md` diz que Sem Técnica precisa de "um sistema próprio, paralelo ao Fundamento". Pelo material, precisava de menos do que isso — e por outro motivo, de mais.**

| rota, na leitura da v0.38 | o que ela virou na v0.168 |
|---|---|
| **Aptidão** | **Energia Reversa não é técnica inata** — é manipulação de energia amaldiçoada, e é por isso que quem não tem técnica consegue usar. *Virou a semente `Energia Reversa`; o raro nela — curar **os outros** — ficou fora da criação, na Trilha `Sutura`* |
| **Estilo da Sombra** | **anti-domínio**, e a arma é o jeito mais comum, não o requisito. A técnica central foi aprendida em um mês por quem não usa espada, e o líder atual da escola derrubou as restrições dela. *Virou a semente `Domínio Simples`* |

**Metade já existia:** as quatro anti-domínio entraram na v0.29 e a **seção 6.5 da peça 11** já trata o Domínio Simples como aptidão pura, sem lâmina. **E a `Energia Reversa` saiu da lista de pendentes na v0.78** — ela está escrita na seção 6 daquela peça, com gate e teto.

> **A rota não podia ser "os outros menos o Fundamento".** Se fosse só subtração, ela ficaria atrás de todo mundo e ninguém escolheria por vontade — escolheria por castigo. **Ela precisava de uma máquina de construção com a mesma dignidade que o Fundamento tem.**
>
> ***E a saída foi que a dignidade não precisava ser imitada: ela podia ser a mesma.*** *O §7 da peça 25 mede o vão da rota sem máquina — `4,06` a `6,43` fatias, conforme o PE do Caminho — e mostra que fechar aquilo pede uma ação que escala com a Classe e cobra a taxa cheia de PE.* **Isso já tem nome, e é o Fundamento.** *O que sobra de trabalho novo é uma aptidão aberta na criação, e ela não custa número: custa a Expansão de Domínio.*

~~*A prosa da peça 9 chama o Estilo da Sombra de "técnica de espada e corpo", e isso ficou mais estreito que a própria mecânica do projeto. Corrigir quando a peça sair.*~~ **Corrigido na v0.168, nos quatro lugares** — a peça 9, a peça 13 e o capítulo 25 do livro em dois pontos.

### A Expansão de Domínio, escrita — manual v7.7

### Três pendências mencionadas em commit — levantadas na v0.115, FECHADAS na v0.116

*O Mizuki pediu para verificar três pontos que sabia terem sido citados em versões passadas sem aparecer nesta lista. A v0.115 achou os três; a v0.116 fechou os três, e **nenhum deles fechou por decisão de sabor** — os três tinham resposta em conta ou em contagem.*

**1 · As Bênçãos — não espelham, e não é escolha.** *A pergunta era se o catálogo das Bênçãos copia o das aptidões entrada por entrada ou tem lista própria.* **Das catorze aptidões, treze são construídas em cima da energia amaldiçoada e a décima quarta é formato e não conteúdo** — só a `Aptidão Própria` atravessa. *A contagem está na **peça 11 §6.8**, com o kokusen e a `Pétala` conferidos na fonte.* **Lista própria, doze entradas, todas custando um marco**, e o tamanho é derivado: a rota pura de Lapidação precisa de dez, igual à de Refino.

> **E metade do buraco já estava tapada, em duas peças que ninguém tinha somado.** *`canalizar energia` — ferir maldição — é a **ferramenta amaldiçoada** da peça 16; `cobrir-se de energia` é o **uniforme** da peça 14, que já roda a dominância por uma rota chamada literalmente `sem energia nenhuma`; e as anti-domínio são o `Anátema` e o `Quebranto`, também da peça 16.* **Três peças responderam pedaços desta pergunta em versões diferentes sem saber.**

> **⚠ E a decisão da v0.38 nunca tinha sido aplicada.** *Este documento dizia "aplicado na peça 9 na v0.39"; o que a v0.39 aplicou foi a outra metade, a do Corpo Amaldiçoado.* **As palavras `Bênção` e `Lapidação` não existiam em peça nenhuma.** *Agora existem, na peça 9 §5, com a escada de Lapidação `1` a `10` e os degraus herdados da peça 11 §5.*

**2 · Pactos — três das quatro formas já tinham dono, e o dono é o manual.** *A peça 8 Passo 8 prometia "a regra completa" desde a v0.21.* **`Restrição` cobre "a minha técnica fica maior sob uma condição"; `Regra Própria` cobre "a minha técnica impõe uma regra ao mundo" — e o manual escreve `contrato` e `dívida` com essas palavras, com um exemplo pronto de Dívida; `Legado` cobre "eu troquei uma coisa antes da campanha".** *Sobra uma: **pacto entre dois personagens, fechado durante o jogo**, que é a forma que atravessa mesas e por isso a mais perigosa.*

> **⚠ E a trava que estava escrita ali era cópia.** *Os cinco requisitos — "uma frase, verificável, simétrica, sem dano direto, com limite" — **são a lista da `Regra Própria` do manual**, na ordem.* **E já tinha divergido em uma palavra: a do manual diz "com limite POR CENA".** *A peça 8 passou a apontar em vez de repetir, e ficaram escritas as quatro travas de projeto que qualquer régua futura tem de obedecer.*

**3 · O gate Origem × Caminho — não era gate.** *A pergunta era "veto ou desaconselhado, e espera a Técnica Marcial ou fecha antes".* **As duas metades caíram na medição.** *Não existe Caminho barato em PE — os cinco entregam, e o menor é o `4` do Bastião —, então a contradição é com os cinco e não com o Emanador.* **E o que quebra tem dono e validador: com a coluna de PE valendo zero, a soma `vida + PE` da peça 6 §5 vai de `10`–`11` para `7 · 5 · 5 · 4 · 4`** — espalhamento `3` contra a tolerância `2` do `conferir-atributos.py`, e o Bastião passa a entregar `1,75×` o Emanador na única moeda que ainda paga.

> **A saída é a quarta, e não estava na pergunta: a coluna não some, ela troca de moeda.** *Quem não tem energia gasta o mesmo número por nível na máquina da Técnica Marcial.* **A soma volta a `10` e `11`, os cinco Caminhos continuam abertos, e não há o que vetar.** *E fecha ANTES da Técnica Marcial porque é contrato SOBRE ela — o molde do teto de Defesa da peça 14 §3, em que ninguém escreve o número e a peça que chega depois obedece.*
>
> **As três saídas que a pergunta oferecia reprovaram, e estão medidas na peça 9 §8.** *Veto por Caminho passa raspando e custa dois dos cinco Caminhos; veto global é pior; e "desaconselhar" é o problema de design nº 3 e nº 5 desta lista, os dois abertos pelo mesmo motivo.*
>
> **A peça 6 e a peça 9 passaram a se citar.** *Era esse o buraco: nenhuma das duas mencionava a outra, então a combinação nunca tinha sido conferida.*

*Decidido depois da v0.26.* Ela **não é aptidão** e não mora nesta peça: mora no manual, no molde de uma Passiva, **comprada trocando espaços de feitiço conhecido**, com gate duplo de nível e refino, em dois degraus.

| degrau | preço | gate | quem passa no nível do gate |
|---|---|---|---|
| **incompleta** | 2 espaços | nível 10 e **refino 4** | especialista e meio a meio; generalista entra no 14 |
| **completa** | **3 no total** (+1 de upgrade) | nível 14 e **refino 5** | especialista e meio a meio; generalista entra no 18 |

*Fixados e validados. O `conferir-expansao.py` afirma os dois.* O `CHANGELOG` da v0.27 registrou refino 4 e **6**, e a versão anterior desta seção registrou refino 3 e 5 — os dois estavam meio certos, e a conta separou.

**No nível 10 as três rotas estão coladas — refino 5, 4 e 3, sem buraco entre elas.** Então qualquer gate que barre o generalista pega o meio a meio com folga zero. Isso não é escolha de número: é o formato da curva, e só dá para escolher **quem raspa**. O refino 4 barra o generalista e deixa o meio a meio na beirada; era isso ou não barrar ninguém.

**No nível 14, refino 5 e refino 6 separam exatamente as mesmas rotas** — só o generalista fica de fora nos dois. Eles diferem só na direção em que quebram, e o validador mediu: com **5**, a curva caindo um ponto **não move ninguém**; com 6, ela tira a completa do meio a meio. Com 5 o risco é a curva *subir* e o generalista entrar no 14 — e isso a checagem 1 acusa em voz alta. **O 5 é imune para o lado que dói e barulhento para o lado que não dói.**

**E "barrado" quer dizer atrasado, não trancado.** O generalista chega à incompleta no nível 14 e à completa no 18 — quatro níveis atrás do especialista nos dois degraus. Ele paga em tempo o que não pagou em marco, e o validador falha se alguma rota deixar de chegar.

**O preço sai do mesmo bolso das Passivas, e é aí que ele morde:**

| | nv10 | nv14 | nv22 | nv30 |
|---|---|---|---|---|
| espaços na lista | 9 | 12 | 18 | 24 |
| a incompleta é | 22% | 17% | 11% | 8% |
| a completa é | **33%** | 25% | 17% | 12% |

Quem pega a incompleta mais duas Passivas de Classe 2 gasta **dois terços da lista no nível 10** e exatamente metade no 14. *Correção:* a versão anterior desta seção dizia *"dois feitiços são 33% da lista no nível 10"* — aquilo foi calculado com a fórmula velha de feitiços conhecidos, antes de a v0.27 fixar `2 + (nível ÷ 2)` e a linha passiva do marco. Com nove espaços no nível 10, dois são 22%.

**A resposta é mais barata que a ameaça, e isso é o que faz o acerto garantido caber.** A **Cesta Oca de Vime** não tem gate de nível nem de refino — *pede ser Reencarnado ou treinado em `História`* —: custa **uma escolha de marco, e a primeira acontece no nível 6** — quatro níveis antes de qualquer um poder comprar a incompleta. Não é preciso ser do eixo do controle; é preciso gastar uma escolha nele, uma vez na campanha inteira. **As duas rotas puras que nunca escolhem Refino terminam sem resposta anti-domínio nenhuma**, e isso é propriedade da rota, não defeito do gate.

*Corrigido na v0.29:* esta frase dizia **Domínio Simples**, e ele subiu para Classe 2 (nv10 · 10 · 14). A resposta do nível 6 é a Cesta Oca, e ela responde **menos** — anula o Acerto e não o Efeito. **O argumento continua de pé**, porque o que a peça 11 chamou de opressivo foi o acerto que nunca falha, e não o Efeito. A resposta barata cobre o que precisava cobrir, e só isso.

**E nenhuma das quatro serve contra a Expansão incompleta.** Ela não tem acerto garantido — o Acerto dela rola —, então você se defende dela com Defesa e Teste de Resistência como de tudo o mais. É canon: o Reggie usou Cesta Oca dentro do domínio incompleto do Megumi e levou porrada dos shikigami do mesmo jeito.

**O que custa para usar, fixado na v0.28 e com o custo de abrir revisado na v0.174:**

| | incompleta | completa |
|---|---|---|
| abrir | `6 × maior Classe` de PE | `6 × maior Classe` |
| desconto nos feitiços lá dentro | `1/3 do refino` | `metade do refino` |
| ação | a rodada inteira, nas duas | |
| duração | `metade do refino` em rodadas, mínimo 1 | |
| barreira | não tem | `50 × metade do refino`, só por fora |

**A escada de custo fecha:** feitiço do topo `3×` < Técnica Máxima `5×` < as duas Expansões, em `6×`. E a incompleta passar da Máxima é de propósito — a Máxima é **dada** no nível 17 para toda ficha, e a incompleta é **comprada** sete níveis antes, por dois espaços de lista e um gate que barra uma rota.

> **⚠ A completa desceu de `8×` para `6×` na v0.174, por retorno de mesa** — *"acharam muito caro o custo da Expansão"*, e a conta concordou: abrir a completa comia **`55%` do PE do dia de um Bastião**, e hoje come `41%`. **As duas passaram a abrir pelo mesmo PE, e isso é decisão e não descuido:** *o manual já escrevia que a completa "paga só a diferença — um espaço a mais, no molde da Regra Própria", e cobrar `+2×` de PE por cima era uma segunda cobrança que a régua invocada não previa.* **O degrau de cima continua se pagando em espaço — `+1`, de dois para três — e em gate: nível 14 e refino 5, contra 10 e 4.**

**O desconto quase virou lucro.** Duração é também quantos feitiços saem lá dentro, então desconto × duração compete com o custo de abrir. Com `6 × Classe` e desconto de refino cheio, o saldo fica **negativo do nível 20 em diante** — você abre o domínio e termina com mais PE. As combinações escolhidas ficam entre +11 e +27 em todo nível, e a margem não encolhe. **E o desconto precisa de piso:** sem *"nenhum feitiço custa menos de 1 PE"*, o refino alto zera as Classes baixas e o PE deixa de existir dentro do domínio.

**O Acerto acontece quando você abre, e de novo no começo de cada turno seu.** Um relógio só, o do portador — as alternativas punham o proc no turno dos alvos, e *"começo da rodada dos alvos"* não é momento definido num sistema de iniciativa individual. **E se algum dia o custo cair para Ação Bônus, a regra de ouro nº 6 já resolve sozinha:** *feitiço em Ação Bônus ou Reação só permite mais um de Classe 0 no turno*.

**O Rescaldo** — a técnica queima quando o domínio acaba, de qualquer jeito: desfeito por vontade, expirado ou estilhaçado. Isso é **preço e não risco**, porque acontece em todo uso. `Queima` morreu na triagem (é Melhoria do manual, e causa dano), e `Empurrão` e `Estilhaço` também estão ocupados. **A porta de saída é a aptidão `Regravação`, desde a v0.239.**

**A barreira cai em ~2,4 rodadas** de saída cheia contra uma duração de 3 a 5 — dá para derrubar de fora dentro do próprio tempo, que é o que faz a decisão de atacar ou esperar existir. Por dentro não quebra. O mestre pode declarar exceção.

**O clash fechou na v0.173, e o dono é o manual v7.19.** *O modelo de push gradual do rascunho reprovou como mecanismo de resolução — a velocidade dele é a diferença de refino, e ela é zero em `59%` dos pareamentos capazes de clash. O rascunho foi para `99-arquivo/`, e **nenhum dos seis números dele foi escrito**.*

**E há uma consequência de vocabulário:** se a Expansão entra no manual, **o manual passa a usar "refino"**, que é termo do projeto. É a direção contrária do problema que a v0.26 consertou, e é de propósito — mas o `conferir-manual.py` precisa saber, senão a próxima varredura vai tratar refino como palavra estranha.

## Problemas de design abertos

Nenhum validador pega estes — eles vieram de rodar os testes da skill de design contra o material.

1. ~~**O Legado tem teto de quantidade, não de magnitude.**~~ **Fechado na v0.39, pela peça 13.** *Ficou aberto da v0.24 até lá.* A régua é de **três formatos travados nos próprios termos**, e não escada de preço: `Ajusta` mexe em número e carrega relógio da escada da peça 10, com a largura do gatilho escolhendo o degrau; `Desliga` só apaga o que ninguém comprou; `Destranca` é zero no dado e precisa de gatilho do jogador. **Os quatro que a régua reprovou saíram, e três deles com destino escrito:** o *Irmãos* ganhou gatilho do jogador, o *Instinto Bruto* perdeu a metade morta e ficou só contra Intuição — que é Inteligência, e aí é troca de verdade —, e o *Alcance Impossível* morreu por ser técnica, que a peça 9 proíbe Origem de conceder. **O quarto, o *Não Sou Gente*, saiu com uma promessa em vez de um destino, e a promessa reprovou na v0.188:** *o `Limites` do manual não deixa Passiva paga dar imunidade completa.*
2. ~~**O Guia pode estar dominado pela Vanguarda.**~~ **FECHADO na v0.61, e ficou aberto da v0.20 até lá.** *Reformulado na v0.24*, quando a classificação que faltava foi escrita na peça 6 §3.1 — **Bastião e Vanguarda pelo Caminho; Arremate e Coro pela Trilha; o Guia por nenhuma rota** —, e a dominância virou uma pergunta com número: *o que Elo, Sutura e Perímetro entregam que valha um golpe por rodada?* **A Q3 de Trilhas respondeu: eles valem o vão, e o vão é o degrau de Caminho do nível 7.** O ataque extra saiu do nível 6 para o 7 na mesma versão, e a leitura que destravou tudo foi medir a base — **o conjurador está a −8% da Rotina e o físico a −2%: ninguém está acima, e o ataque extra é correção de base e não bônus.**
3. ~~**O ofício não passa no filtro do multi-mestre.**~~ **FECHADO, e ele já estava — o registro é que ficou para trás.** *A peça 7 §5 publica o **atributo padrão de cada um dos onze**, com a perícia irmã ao lado: `Condução` Destreza, `Forja` Força, `Herbalismo` Inteligência, `Instrumento` Essência, e assim por diante.* **O conserto que este item pedia — "tabela com o atributo padrão de cada um" — é literalmente a tabela que está lá.** *Achado na v0.130, varrendo a fila: décimo primeiro caso de decisão aplicada e não desregistrada neste projeto.* **O mestre continua podendo mudar o atributo quando a situação pedir; o que ele não precisa mais é decidir do zero.**
4. ~~**A escolha de refino no marco paga mal, e três marcos pagam zero.**~~ **FECHADO na v0.89, e ficou escrito como aberto até a v0.98.** *Entrou na v0.41.* *Achado pelo Mizuki na passada de Equipamento, e a conta confirmou pior do que o palpite.* O refino **passivo chega a 8** sem escolha nenhuma; sete escolhas de marco compram **+2**, e o teto 10 é alcançado no **nv22**. Do nv22 em diante a escolha *"refino e uma aptidão"* vira **só a aptidão**, enquanto *atributo* e *Leque* continuam valendo cheio — três marcos com um dos três eixos pela metade.

   | o que o +2 de refino compra | refino 8, de graça | refino 10, sete escolhas |
   |---|---|---|
   | proteção de cobrir-se | 3 | 4 |
   | RD da Reação | 12 | 15 |
   | desconto e duração do domínio | 4 | 5 |

   **A rota se paga pela quantidade de aptidões, não pela magnitude do refino** — e isso contradiz a frase que abre a peça 11, *"o refino é a métrica das aptidões"*. Como as aptidões usam o refino como variável, o valor de cada uma também quase não muda entre 8 e 10.

   > **O conserto foi o terceiro dos três que estavam propostos aqui: escolha diferente depois do teto.** ***Decisão do Mizuki na v0.89: no teto, a escolha de Refino leva DUAS aptidões***, e a rota pura vai de `7` para `10`. **Está aplicado na peça 11 §3**, e a checagem 5.2 do `conferir-aptidoes.py` passou a medir marco a marco — a 5 media o fim da campanha e saía verde com o meio quebrado. *As outras duas alternativas foram medidas e reprovaram, com a conta escrita na entrada da v0.89 do CHANGELOG: subir o teto de `10` para `15` acende dois contratos, e baixar o refino passivo move a tabela de gates inteira.*
   >
   > **⚠ Este item ficou nove versões escrito como aberto depois de fechar**, contradizendo a linha de abertura deste mesmo arquivo, que desde a v0.89 diz que ele era *"o único problema de design que tinha sobrado"*. *Achado na v0.98, e é a lição de que decisão registrada não é decisão aplicada — desta vez aplicada à lista que registra as decisões.*

5. ~~**⚠⚠ A troca do `2` fixo por um atributo não tem versão que funcione.**~~ **FECHADO na v0.117**, e não pelo lado que a pergunta esperava: *o `2` morreu junto com o mecanismo, e o acerto passou a levar maestria para acompanhar a proteção que cresce do outro lado.* **O `Estopim` do `Explosivo` ganhou referente sem ninguém mexer no preço dele.**
6. **"O mestre declara o que foi uma luta" é discricionariedade que vira número.** *Aceito de propósito na v0.26*, e é a única coisa da peça 10 sem lista fechada por baixo — a declaração muda quantos degraus de exaustão o grupo acumula, e isso muda quanto PE o respiro devolve. A aposta é que ninguém está em melhor posição de dizer se aquilo foi uma luta do que quem acabou de dirigir a cena. Se dois mestres divergirem no playtest, o conserto é o do ambiente propício: fechar a lista.

   > ***MEDIDO na v0.259, a pedido do Mizuki, e a aposta se sustenta melhor do que o texto acima dizia.*** *A pergunta certa não é "os dois mestres contam igual?" — é **"duas fichas idênticas que jogaram a mesma sessão terminam o dia em estados diferentes?"**, e essa tem número.*
   >
   > **A divergência vive numa janela de três degraus de largura, e ela é fechada dos DOIS lados.** *Abaixo de `4` lutas contadas ninguém pega degrau nenhum, então discordar não separa nada; e a partir de `6` o teto empata os dois — quem conta `6`, `8`, `11` ou `18` fica no degrau `3` igual.* **Só entre `4` e `6` a contagem move a ficha.**
   >
   > **Numa discordância realista a separação é de `1` a `2` degraus.** *Numa sessão de `5` cenas de combate, um mestre contando `4` e outro `5` separam `1` degrau e `0` pontos percentuais de PE; contando `3` e `5`, separam `2` degraus e `10` pontos percentuais.* **A separação máxima de `3` degraus exige discordância total** — *um mestre chamando `0` de luta e o outro chamando as `6`, na mesma sessão* —, e isso não é divergência de julgamento, é de regra não lida.
   >
   > ***E o achado que importa: quem faz o filtro multi-mestre passar é o TETO DE TRÊS.*** *A peça declara um motivo para ele — transformar a espiral em decisão —, e ele tem um segundo que ninguém tinha escrito: **ele satura a discordância**. Sem teto, dois mestres que contassem `5` e `12` separariam sete degraus; com ele, separam zero.* **O §4 da peça 10 passou a escrever as duas metades.**
   >
   > **A divergência também não atravessa a mesa no caso normal**, *porque a exaustão **zera** no descanso longo em ambiente propício e o §7 da peça fecha a missão na escola.* **Ela só persiste em missão de campo que vira a noite fora** — *e ali ela é a espiral que o teto já segura.*
   >
   > **Fica aberto, e é menor do que o item parecia:** *o mestre pode **tirar** um degrau quando a ficção pedir, e essa é uma segunda discricionariedade, que anda em cima do resultado já contado.* **Ela só anda para o lado do jogador** — *o mestre nunca acrescenta degrau fora da regra* —, então ela não pode piorar uma ficha, só melhorar. *Continua sendo pergunta de playtest, e continua sem número.*

7. **A remodelagem das invocações e do Evocador.** *Anunciada pelo Mizuki na v0.246 como a revisão das invocações, e confirmada em 19/09/2026: "as invocações e o evocador vai ser remodelado".* **A v0.251 fechou a CD dos efeitos e deixou três coisas para ela**, *e a v0.258 mexeu em duas:*

    - ~~*a invocação com arma — quem a treina, e se o dado da arma soma ao `Investir`*~~ — ***FECHADA na v0.258, e as duas metades eram derivadas:*** *o dado **não soma**, porque o `Investir` já entrega a cota inteira da Rotina e a melhor arma de tiro somaria `314%` dela no nível 2, contra o teto de uma Rotina que é a trava mais dura da peça 15; e a invocação **nunca tem treino**, porque não tem Caminho, o que cai na penalidade de empunhar sem treino da peça 19 §6.* **A CD continua não mudando com a arma — só o acerto segue o atributo dela.** *A remodelagem pode mexer nas duas; o que ela não precisa mais é destravar a mesa.*
    - *as quinze entradas do catálogo, das vinte, que têm texto diferente entre o livro e a peça — a `Montaria` e o `Remoto` mudam regra.* **Continua aberta.**
    - *a `Voz`, cuja troca no nível 7 para `metade da maestria` não muda número nenhum, porque o piso de `1` a deixa em `+1` até o nível 25.* **Continua aberta.**

    **E a v0.258 pôs uma quarta na fila dela, por decisão do Mizuki:** *a **invocação que não obedece** — a Rika e o Mahoraga, que a peça 15 §3.4 e §3.6 dizem **duas vezes** que "precisam de tratamento antes de a peça fechar", e ela fechou na v0.58 sem o tratamento.* **É a única das três marcas do capítulo 16 que sobrou**, *e ela é desta fila porque uma invocação que age sozinha mexe justamente no teto de uma Rotina.*

    **Nada disso trava a mesa:** a CD, o atributo e o Teste de Resistência de cada efeito já estão escritos.

8. ~~**Força sem peso.**~~ **FECHADO na v0.256.** *Levantado pelo Mizuki em 19/09/2026: "Dar equivalencia de peso pro sistema, não da pra n ter sistema de peso nele".* **Hoje o livro só diz que a Força serve para "carregar" (a tabela dos atributos, capítulo 1), e não existe escala de peso em lugar nenhum:** *a Forma `Efeito` tem escala de área e de gente, e a Força aparece como requisito de arma e de `Traje`, mas nada diz quanto peso um valor de Força levanta, arrasta ou arremessa.* **Cuidado com o nome: `Carregar` já é Restrição e ação.**

   > ***DECIDIDO pelo Mizuki em 19/09/2026 (conversa da v0.253), e ainda NÃO aplicado.*** **1 · Pra que o peso serve:** *só o limite do quanto se consegue carregar e os requisitos de arma e uniforme; "de resto n vai servir pra mais nada, igual DnD 2024".* **Sem degraus de carga e sem penalidade por item.** **2 · A curva:** *ele mandou pesquisar a comunidade e ver a opção que mais gostam; se não desse conclusão, seguir o Pathfinder, e misturar com o D&D: a ficha calcula os itens em Volume, e existe o cálculo em quilos para o que não tiver Volume registrado, por decisão do mestre.*
   >
   > **A pesquisa de comunidade NÃO deu conclusão, e isso está dito aqui.** *Achei duas conversas pequenas no fórum EN World (dez respostas cada, uma delas sem ser enquete): as preferências se dividem entre peso em quilos, Volume abstrato do Pathfinder e casas de item (slots), e o ponto em comum é que ninguém quer somar peso item a item; blogs dizem que o peso do D&D é "ignorado na maioria das mesas" e que o Volume do Pathfinder "é feito pra ser usado", mas são fonte fraca. O Reddit não é alcançado pela busca.* **Então vale a regra dele: seguir o Pathfinder, misturado com o D&D.**
   >
   > **O que os três sistemas dizem, lido dos PDFs dele:** *D&D 2024, Médio: carrega Força × `7` kg e arrasta, empurra ou levanta Força × `13,5` kg (o dobro), e passar do que carrega limita o deslocamento a `1,5` m.* *Pathfinder 2e: sem penalidade até `5` mais o modificador de Força em Volume, máximo `10` mais o modificador; item de `2,5` a `5` kg é Volume `1`, menos de meio quilo é desprezível, e `10` itens leves valem Volume `1`; a pessoa Média tem Volume `6`, o que dá uns `12` kg por Volume, o dobro ou mais do que o item.* *GURPS 4e: Base de Carga é ST × ST ÷ `10` kg, em cinco degraus até `10` vezes a Base.* **Achado: o Volume do Pathfinder não é linear com o quilo (item `2,5–5` kg, pessoa `~12` kg), então o quilo do modelo misto precisa de um fator escolhido.**
   > **A calibração do sistema:** *a peça 2 diz Força `1–2` = pessoa comum, `3` = bom, `6` = o topo humano; isso põe o topo em D&D Força `20` (carrega `140` kg, arrasta `270`) e o comum em `70` kg.* **Falta:** *o limite em Volume por Força, o fator kg por Volume, o Volume de cada item do catálogo de arma e de uniforme (hoje eles têm só "requer Força", que continua), e o campo na Ficha Pessoal.*
   >
   > ***DECIDIDO pelo Mizuki em 19/09/2026, segunda rodada.*** **1 · O fator é `12` kg por Volume, e o limite fica em `60` a `132` kg** *(Volume `5 + Força`, de Força `0` a `6`; arrastar, empurrar e levantar é o dobro).* *"Num geral a força vai mais ajudar a definir kit e afins."* **E isso deve permitir tirar o limite de armas de grau, e a sintonização junto, "já que arma vai ter peso, já vai ser o limite necessário".** **2 · Os requisitos de Força de arma e de uniforme ficam INDEPENDENTES do Volume.** *"O peso (volume) de cada item/arma vai servir como um segundo balanceador"*, *e isso abre repensar as armas e acrescentar as que estão faltando.* **Falta ver o que o limite de grau e a sintonização fazem hoje, antes de decidir tirar.**
   >
   > **O que o limite de grau e a sintonização fazem hoje, lido das peças 16 e 20 em 19/09/2026:** *o `Teto de Estigma` é `3`: a arma tem teto pelas mãos e o objeto de apoio tem teto de dois; ele é estrutura do corpo, e a peça 20 diz que "conta pelas mãos e não pela mochila" — três armas guardadas com uma empunhada continuam sendo uma. Um `Estigma` de Classe `3` é do tamanho de uma aptidão, e `3` deles são `43%` das sete escolhas de marco da campanha (`1` são `14%`, `4` são `57%`). A sintonização é outra coisa: é o ATO de ativar, um descanso curto por ferramenta; sem ela a ferramenta é arma comum.* **Então o peso, que limita a mochila, não substitui o teto:** *a arma já é limitada pelas mãos, e o objeto de apoio (anel, cordão) pesa quase nada e não seria limitado por Volume nenhum.* **O peso limita a VARIEDADE que se carrega para trocar, e é aí que a sintonização hoje segura.** *Decisão dele pendente: tirar só a sintonização, ou mais.* **Também anotado por ele: o Volume de cada item vira um segundo balanceador, e isso abre revisar o catálogo de armas e acrescentar as que faltam** *(hoje são `52`).*
   >
   > ***DECIDIDO pelo Mizuki em 19/09/2026, terceira rodada (Estigma e sintonização).*** *Resposta literal: "Mantem limite pros de apoio, reduz pra 2. Mas remove o limite para arma e tira a sintonização".* **Leitura minha, para ele corrigir:** *o objeto de apoio continua limitado a `2` (que já é o valor hoje, peça 16 §5: "o apoio tem teto de duas"); a arma com `Estigma` deixa de ter limite de quantidade (as mãos continuam sendo físicas, e o peso limita o que se carrega); e a sintonização deixa de existir: a ferramenta funciona enquanto se empunha ou se veste.* **Isso reverte a decisão da v0.144 (sintonizar por descanso curto).** **O que precisa mudar quando for aplicado:** *peça 16 (§1.1 e o §5), capítulo 55 do livro, o `conferir-ferramenta.py` (a checagem `16`, de sintonia, e a `6`, do teto), e a peça 20 §4 com a checagem `11` do `conferir-marcial.py`, que fixa "o teto não se moveu".* **Aberto:** *o poder que a variedade de armas trocadas solta não foi medido; hoje a conta de Estigma é "quantos ao mesmo tempo".*


   > ***ESCRITO na v0.256, e a conta corrigiu DUAS leituras minhas pelo caminho.***
   >
   > **1 · O `Volume` de cada item não foi escolhido a mão.** *A régua lê as propriedades que a peça 14 §5.3 já publica: `de duas mãos` = `2`, `de uma mão com `Oculta` ou `Vestida`` = leve, todo o resto = `1`. Isso dá `17` leves, `14` de `Volume` `1` e `21` de `Volume` `2`, e o validador reconstrói os três baldes do catálogo em vez de guardar os números.* **A `Volumosa` NÃO entrou na régua:** *ela já é desvantagem vendida por orçamento — o `Nodachi` compra `Rompe` pagando com ela —, e o que ela descreve é ocultação e espaço apertado, não peso. Cobrar `Volume` em cima cobraria duas vezes.*
   >
   > **2 · O uniforme veio de validação externa, que o Mizuki pediu:** *"Faça uma validação baseado em outros sistemas, o quanto normalmente uma armadura pesada come do limite de uma ficha e afins, vamos na média".* **Os cinco sistemas medidos se partem em DOIS desenhos, e a fração depende do desenho:** *limite único (D&D 2024 `29%`, Pathfinder 2e `44%`) contra degraus de carga (D&D 5e variante `87%`, Pathfinder 1e `76%`, GURPS 4e `74%`).* **O nosso é o de limite único, e são os dois que ele mandou misturar: a média é `36%`, que de `Volume` `11` dá `4`.** *`Traje` `L · 1 · 2`, `Revestimento` `2 · 3 · 4`, escudo `L · 1 · 2`. A escada sobe sem tropeço: `2%` · `20%` · `25%` · `25%` · `33%` · `36%` do limite que a Força exigida por cada peça dá.*
   >
   > ***3 · CORREÇÃO: o peso NÃO substitui o `Teto de Estigma`, e a primeira leitura desta versão dizia que sim.*** *O teto da peça 16 §5 é de MÃO — uma arma empunhada mais dois apoios — e a peça 20 §4 escreve "conta pelas mãos e não pela mochila".* **Então a arma com `Estigma` já não tinha limite de quantidade guardada, e a decisão dele de "remover o limite para arma" não removeu nada que existisse.** *O que o peso substitui é a **sintonização**: era ela que segurava a variedade carregada, cobrando um descanso curto por ferramenta.*
   >
   > ***4 · CORREÇÃO: as checagens `6` do `conferir-ferramenta` e `11` do `conferir-marcial` NÃO precisaram mudar***, *contra o que este item previa: as duas guardam o teto de mão, e o teto não se moveu.* **A `16` foi reescrita inteira** *(empunhar ou vestir, com a regra antiga proibida — e a proibição é diferente nos dois documentos: a peça pode falar de sintonização, porque é registro de design, e o livro não, porque é texto de mesa).*
   >
   > **5 · A camada `3` do §6 da peça 14 ligou, e não foi o gatilho dela que disparou.** *Aquela seção dizia "se o playtest mostrar que o grupo leva tudo que quer sem precisar escolher, o espaço entra", e `04-playtest/` continua vazia. Quem ligou foi ele, e isso está escrito na peça para ninguém ler daqui a dez versões que o playtest aconteceu.*
   >
   > **Fica para depois, por decisão dele em 19/09/2026:** *revisar o catálogo de armas e acrescentar as que faltam.* **E o `conferir-equipamento.py` ganhou a checagem `15`**, *que deriva o limite, a régua, os três baldes, a escada do uniforme e o `4` do `Revestimento` `3` — sem número escrito no código.*

9. ~~**Concentração sem Restrição, e duração longa só na Forma `Efeito`.**~~ **FECHADO: a Concentração na v0.253 (Vigor contra a CD de quem te feriu), e a duração na v0.254 (a `Concentrada` e a `Duradoura`, na Família `Tempo`).** *Levantado pelo Mizuki em 19/09/2026: "a gente n abordou uma restrição pra por concentração e nem formas de aumentar duração de feitiços como minutos, horas e talz, q nem dnd, q são os feitiços mais 'especiais' e n de dano".* **Até a v0.252:** *a Concentração era regra do capítulo 2 (um efeito por vez, Vigor contra `10` ou metade do dano; desde a v0.253, Vigor contra a CD de quem te feriu), a Melhoria `Fica` dá `1` minuto e exige concentração, e minutos, horas, dia e semana existem só na tabela da Forma `Efeito`, por Classe.* **Falta:** *uma Restrição que ponha concentração num feitiço em troca de pontos, e um jeito de estender duração fora da Forma `Efeito`.*

   > ***DECIDIDO pelo Mizuki em 19/09/2026.*** **A metade da Concentração FECHOU na v0.253; a metade da duração segue aberta.**
   >
   > **1 · A Concentração rola Vigor contra a CD de quem te feriu, um teste por golpe** *(peça 3 §3, subseção `A CD de quem te feriu`).* **Por que um por golpe:** *o jogador raramente enfrenta mais de duas fichas, e o inimigo tem que bater em vários alvos.* **O motivo da troca:** *a CD antiga (`10` ou metade do dano, sem teto) quebra no dano de chefe — no nível `10` ela passa a `18` e quem treinou o Vigor resiste `45%`, e do nível `15` em diante nenhum `d20` resiste.* **A CD do inimigo é `8 + atributo + maestria` (peça 26 §3.1): `12` nos níveis 2 a 9, `14` nos 10 a 17, `16` nos 18 a 25, `18` nos 26 a 30.** *Contra ela, quem investiu e treinou o Vigor resiste `65%` em todo nível; quem não treinou cai de `60%` para `45%`, e Constituição `3` sem treino cai de `60%` para `30%`.* **Chefe com `2` golpes por rodada a `50%`, e `1` golpe em `4` em quem concentra: segura `10` rodadas em `41%` em qualquer nível, contra `53%` no nível `5`, `24%` no `10` e `7%` do `15` em diante na regra antiga.** *As duas tabelas e os números da prosa saem dos donos: é a checagem `7` do `conferir-acao.py`, sem número escrito no validador.*
   >
   > **2 · O `Carregar`** *(preço `Média`, Teste de Resistência de Espírito)* **usa a mesma CD de quem te feriu.** *A `Mão Firme` (dano de `10` ou menos) continua como está, e a `4m` do `conferir-manual.py` lê o `10` do `.docx` e compara com as três outras cópias.*
   >
   > **3 · A corrida de domínios virou a mesma rolagem, só com a contagem trocada.** *Isso reverteu a decisão de 12/09, que dava a CD do dono do outro domínio: o Mizuki alinhou em 19/09, na pergunta que eu fiz antes de mexer.* **Quando o jogador acertou o inimigo de mais de um jeito na rodada, com CDs diferentes, vale a maior** *(default meu, para ele vetar).*
   >
   > **Defaults meus, escolhidos com ele em 19/09:** *golpe de arma ou desarmado usa `8 + o atributo do ataque + maestria` (a peça 26 já lê assim a CD do inimigo); dano sem autor (queda, armadilha) tem a CD declarada pelo mestre na escada da peça 4 §2; a invocação usa a CD dos efeitos dela (peça 15 §3.6).*
   >
   > **O que a regra cobra, e ele ainda não viu:** *nos níveis baixos ela é mais dura que a antiga para quem concentra (`41%` contra `53%` no nível `5`), e um golpe pequeno de inimigo forte pede o mesmo teste que um golpe grande — só a `Mão Firme` livra dos golpes de `10` ou menos.* **E a escolha de um teste por golpe quase não pesa no número:** *contra `1` golpe em `4` são `41%` por golpe e `42%` por rodada, e se o chefe foca em quem concentra são `2%` contra `5%`.*
   >
   > **Onde a regra mora, medido na v0.253 e não de memória:** *peça 3 (dona), `partD.js` (o `Carregar`) e `partE.js` (a corrida) do manual, capítulo 2 (`11-o-turno.md`), capítulo 9 (`40-fundamento.md`: o `Carregar` e a corrida), glossário, e o texto compilado do livro.* ***As peças 14 e 24, o `dados.js` do gerador de inimigo e o capítulo 8 (`35-caminhos`) NÃO carregam a regra*** *— os `concentra` ali são "o chefe concentra o fogo", o foco de dano, e não a Concentração.* **A ficha (`Claude 3`), conferida nos arquivos dela:** *o catálogo em JSON dela tem o `Carregar` com a CD antiga (das duas ocorrências de `concentra` ali, a outra é a `Fica`, que não muda), e o texto do manual dela tem quatro cópias da regra antiga — capítulo 2, `Carregar`, corrida e glossário.* **Só mexe depois do livro.**
   >
   > **A DURAÇÃO — o que falta:** *a regra mais duas Melhorias, e não Restrição. O efeito de duração em combate exige concentração, com uma Melhoria de duração para o feitiço comum e outra para tirar a concentração, que custa mais; a Forma `Efeito` fica como está.* **Falta precificar as duas.** *Da pesquisa que ele já fez: D&D não tem preço de duração; com concentração a duração é quase de graça, sem concentração ela custa nível (`1` minuto `2,0`, `1` hora `3,1`, `24` horas `4,7`, até dissipar `5,4`); a escada da Forma `Efeito` (Classe `1` = 1 min, `2` = 10 min, `3` = 1 h, `4` = 1 dia, `5` = 1 semana) já bate com a do D&D, e a Melhoria `Fica` (`Média`) custa `1` ponto na Classe `1`.* **É a v0.254.**
   >
   > **O custo real da concentração, medido em 19/09/2026 para precificar a Melhoria que a tira:** *sob a regra nova, contra o cenário da peça 3 (`2` golpes por rodada a `50%`, `1` em `4` em quem concentra), num efeito lançado na rodada `1` de uma luta de `3` a `4` rodadas, quem treinou o Vigor mantém o efeito em `~90%` da luta (desconto de `10%`), e quem tem Constituição `3` sem treino no nível `30`, `~81%` (`19%`).* **Se o chefe foca em quem concentra, o desconto sobe a `34%` para quem treinou e a `52%` para Constituição `3` sem treino no nível `30`.** *Ou seja, tirar a concentração vale de `~10%` a `~35%` do efeito, e só passa disso contra quem não treinou o Vigor e é focado.* **Não é o valor de "concentrar só em um por vez", que é outro custo, e que esta conta não mede.** *A conta está feita em rascunho e ainda não virou checagem.*
   >
   > **A pesquisa de campo em outros sistemas voltou em 19/09/2026** *(1 agente, `185k` tokens; relatório no HD, na pasta de agentes de 19/09/2026 (fora dos repositórios), no arquivo RESULTADO da subpasta concentracao; 14 sistemas, 8 lidos em fonte primária e 5 só por resumo, marcados `NÃO VERIFICADO`).* **Achados que importam:** *só o d20 3.x e o 5e fazem a CD subir com o dano (Pathfinder 1e: `10 + dano + nível da magia`), então "um teste por golpe contra a CD de quem feriu" já está do lado dos que não escalam; o M&M 3e dá o desconto da concentração em número — o flaw Concentração vale `−1` por grau num efeito sustentado de `2` por grau, `−50%`, e tirar a concentração custa o DOBRO; o GURPS não derruba o efeito na falha, ele o congela como estava, e só a falha crítica encerra.* **Contra o nosso número:** *o desconto real da nossa concentração é de `10%` a `35%`, bem menor que os `50%` do M&M, então tirar a concentração deve custar de `1,1×` a `1,5×`, e não `2×`.* **Tabela de preço por Classe, lida do manual (Leve · Média · Pesada = `1·1·2`, `1·2·3`, `2·3·5`, `2·4·6`, `3·5·8`, `3·6·9`, `4·7·11`):** *A = Leve e B = Média dá razão `1,00×` na Classe 1 (empata, e a B domina a A) e `1,5×` a `2,0×` nas outras; A = Leve e B = Leve + `1` ponto dá `2,00×`, `2,00×`, `1,50×`, `1,50×`, `1,33×`, `1,33×`, `1,25×`, sem dominância em nenhuma Classe; A = Leve e B = Pesada dá `2,0×` a `3,0×`.*
   >
   > ***DECIDIDO pelo Mizuki em 19/09/2026 e APLICADO na v0.254.*** **1 · Preço: `B = Média`** *("fica mais fácil de organizar, evita de jogadores se perderem nas informações por ter uma exceção"), com `A = Leve`.* **Ele foi avisado de duas coisas e não mudou:** *na Classe `1` Leve e Média custam `1` ponto, então a `A` vira opção morta ali (não pede regra, é consequência da tabela), e o preço achatado paga `26%` a `71%` do valor de deixar uma condição durar a luta inteira, supondo o valor linear nas rodadas.* **Ele também foi avisado de uma alternativa de degrau (`A` Média, `B` Pesada) e não a escolheu.** **2 · Escopo: o feitiço inteiro.** **3 · Nomes: `Concentrada` (dura com concentração) e `Duradoura` (dura sem concentração)** *("fica intuitivo; se achar que não fica, podemos mudar").* **4 · A duração depende do TIPO do feitiço:** *buff ofensivo e debuff: `1` minuto; buff defensivo (proteção): `10` minutos; feitiço especial narrativo, sem efeito mecânico: `1` h, `8` h, `12` h, `24` h e assim por diante.* **Falta:** *classificar as Melhorias de estado do catálogo em ofensivas e defensivas, dizer como a escada narrativa (`1` h · `8` h · `12` h · `24` h) convive com a escada da Forma `Efeito` (`1` min · `10` min · `1` h · `1` dia · `1` semana), e precificar o efeito de `10` minutos, que passa da luta.*
   >
   > **A duração do buff defensivo, validada no 5e.tools em 19/09/2026** *(557 magias únicas de todas as fontes menos a `AU`, com a versão 2024 preferida quando existe nas duas; `33` proteções curadas por mim, `10` delas sem tag automática e classificadas por leitura).* **Com concentração (`19` proteções): `1` minuto `9` (seis delas de 5º círculo ou mais), `10` minutos `7`, `1` hora `3`. Sem concentração (`14`): `1` rodada `2`, `1` minuto `2`, `1` hora `5`, `8` horas ou mais `5`.** **A dúvida dele ("o Pele-Rocha não é nível baixo") se confirmou pela metade:** *sem concentração a duração sobe com o nível — correlação de postos de `0,36` em `134` magias e `0,64` nas `14` proteções, mediana de `1` h nos círculos `1` a `3`, `8` h no `4` e `24` h do `6` ao `8`; com concentração o nível NÃO explica a duração — correlação `0,02` em `235` magias, mediana entre `1` e `10` minutos em todo círculo.* **Pele-Rocha é de 4º círculo com concentração de `1` hora; as três proteções de `1` hora com concentração são todas resistência a dano, de círculo `3` e `4`.** *Entre as proteções com concentração a correlação é `−0,41` (`18` magias, amostra pequena): as mais fortes são as mais curtas.* **Leitura:** *a `Duradoura` deve escalar com a Classe, como a escada do `Efeito`; a `Concentrada` depende do efeito e não do nível.* **Guarda é o Escudo da Fé (concentração, `10` min) e Divide é o Vínculo de Proteção (`1` h, sem concentração).** **Categorias de efeito nas `33`: resistência `11`, imunidade a condição `8`, defesa `6`; o catálogo só tem defesa e dividir dano.** ~~*Resistência a tipo fica registrada como candidata a Melhoria nova, e é peça à parte.*~~ ***ADIADA na v0.258, por decisão do Mizuki: "abandona por enquanto, e espera o playtest" — o item 15 tem as contas.***
   >
   > ***DECIDIDO pelo Mizuki em 19/09/2026, fecho da duração.*** **1 · A `Duradoura` sobe pela escada `1` h · `8` h · `24` h por Classe** *(o mapa de Classe é meu: Classe `1` e `2` = `1` h, `3` = `8` h, `4` em diante = `24` h, a partir da mediana do D&D sem concentração com Classe `c` ≈ círculo `2c − 1`, e ele aceitou).* **2 · A escada de horas vale só para o buff MECÂNICO** *(resistência, imunidade, PV, condição, divisão de dano, fórmula de defesa).* **O buff NUMÉRICO (bônus fixo de defesa ou de salvaguarda) não sobe pela escada:** *o dado é que nenhum bônus de `+2` ou mais dura mais de `10` min no D&D, e as duas exceções longas são de número pequeno (`Vínculo de Proteção` `+1` por `1` h, `Auxílio` `+5` de PV por `8` h).* **3 · Ideia dele para o `Guarda` (que é o Escudo da Fé): `10` min com concentração e `1` min sem** *("daria pra por que 1min sem concentração, 10min com")* — **no buff numérico a `Duradoura` dura MENOS que a `Concentrada`, e o que ela compra é não concentrar.** **4 · PV sai do "numérico" e vai para o "mecânico"**, *porque `Auxílio` (`8` h) e `Falsa Vida` mexem em PV e duram horas.* **Defaults meus, APROVADOS por ele em 19/09/2026:** *a duração vale para os efeitos de ESTADO do feitiço (condição e buff), e não para a `Fica`, o dano nem o `Anteparo`; feitiço com efeitos de tipos diferentes dura a menor duração entre eles; buff ofensivo e debuff duram `1` minuto nas duas Melhorias; e a Família é `Tempo`.*

10. ~~**`Passiva Livre` e `Regra Própria` na criação.**~~ **FECHADO na v0.252, opção X.** *Levantado pelo Mizuki em 19/09/2026: falta dizer o nível máximo que a Regra pode ter na criação do Fundamento, e ele quer permitir que o Fundamento comece com os dois, porque viu ideias criativas e achou ruim ter de negar.* **Hoje o livro se contradiz um pouco:** *o capítulo 9 lista a `Passiva Livre` e, "se a técnica pedir", uma `Regra Própria` na criação; o capítulo 6 lista só a `Passiva Livre`; a tabela das Passivas abre a Classe Passiva `1` no nível `1`, `2` no `7` e `3` no `13`; e a frase da `Regra Própria` diz que só ela pode ser comprada em Classe Passiva `1` desde o nível `1`.* ***DECIDIDO em 19/09/2026, opção X:*** **a `Regra Própria` de Classe `1` vem de graça na criação, não gasta espaço, e o teto dela na criação é Classe `1`.** *Subir para a Classe `2` custa `1` espaço e para a `3` custa `2` (a diferença para a Classe `1`), então a Regra até a Classe `3` sai por `2` espaços em vez de `3`. Poder de graça: `1` espaço, que pesa `33%` da lista no nível `2` e `4%` no `30`. A opção Y, a Regra inteira grátis subindo com o nível, ficou recusada: chegava a `30%` da lista no nível `13`.* **Escrito na v0.252:** *o `partB.js` do manual (v7.33), o capítulo 9 e o capítulo 6 do livro e a peça 8, com a checagem `4l` do `conferir-manual.py`. Dois defaults meus para ele vetar: a Regra não conta nas cinco Passivas pagas, e a frase antiga "só ela pode ser comprada em Classe `1` desde o nível `1`" sai, porque a tabela já abre a Classe `1` para todas.*

11. ~~**Ritual.**~~ **FECHADO na v0.262, e é a peça 27 mais o capítulo 13 do livro, `46-ritual.md`.** *Levantado pelo Mizuki em 19/09/2026: "A gente n fez sistema de sinais de ritual para feitiços e talz".*

    > ***ESCRITO na v0.262.*** *A régua que eu usava estava errada duas vezes e ele pegou as duas — o gargalo é PE e não ação, e a comparação certa é contra gastar um feitiço para buffar (`0,59×`), não contra a rodada perdida.* **A escada virou `2 · 6 · 10` PONTOS por decisão dele, porque tier escala com a Classe e ponto de ritual não.** *As decisões e as contas estão na entrada da v0.262 do `CHANGELOG`; a regra mora na peça 27.*
    >
    > **1 · O que é.** *Correção dele sobre a minha primeira leitura: ritual **não** é conjuração lenta fora de combate.* **"Rituais são uma mecanica a parte no jujutsu que foi pouco trabalhada. O personagem principal que trabalhou rituais foi o proprio sukuna, ele usava no meio do combate para inflar, amplificar e melhorar seus feitiços."** *É ação de combate cara, e é **um capítulo inteiro só pra ele**.*
    >
    > **2 · O que ele compra: fura o limite de Melhorias por feitiço**, *que hoje é `2` nas Classes 1 e 2, `3` nas 3 e 4 e `4` da 5 em diante.* **E ele vende de uma LISTA PRÓPRIA, só acessível em ritual** — *decisão dele, e a conta obriga: uma rodada perdida vale `2,2` Melhorias `Pesada` em dano, e o limite de Melhorias segura **largura** e não dano (medido na v0.255).* **Vender Melhoria comum por uma rodada seria negócio que ninguém faz.**
    >
    > **3 · A escada de tempo tem três subidas, e DUAS JÁ TÊM PREÇO NO MANUAL:** *Ação Bônus (a Melhoria `Rápido`, que custa `Pesada`) → Ação Padrão (o normal) → Ação Completa (a Restrição `Atrasar`, que devolve `Média`) → dois turnos (**não existe**).* **Cada subida vale o que aquele degrau de tempo já custa:** *em Melhorias `Leve`, as duas primeiras compram `1` a `3`, que é exatamente a escala do F&M 2.5 — e os dois sistemas não se olharam.* **A terceira compraria de `3` a `12`, e é por isso que ela abre efeito exclusivo em vez de vaga.**
    >
    > **4 · O nome do degrau de cima é `Recitação Prolongada`**, *escolha dele.* **Passou na triagem, e as duas palavras separadas também.** *⚠ Duas coisas que a triagem NÃO pega e que precisam de cuidado ao escrever: ele é `<substantivo> <adjetivo>`, que é o formato que faz o `conferir-nomes` ler o adjetivo como nome de categoria; e `Prolongada` encosta em sentido na Melhoria `Duradoura` da v0.254 — uma é o tempo de **conjurar** e a outra o tempo que o **efeito dura**.*
    >
    > **5 · A lista tem dois eixos, os dois pedidos por ele:** *escala (*"o proprio sukuna tem diversos simbolos diferentes ao longo dos rituais que performa"*) e **Forma do feitiço** (*"vai ter melhoria de ritual q n vai encaixar por exemplo em CURA"*).* **As dez Formas já se agrupam por Família** — `Área` tem `Explosão`, `Aura`, `Cone` e `Linha`; `Amparo` tem `Cura`, `Apoio` e `Onda` —, *então o agrupamento não precisa ser inventado.* **Os três degraus abrem partes da lista, em tamanhos diferentes**, no molde do F&M 2.5.
    >
    > **6 · O acesso é uma aptidão, com gate `INT 5` e nível `10`.** ***Proposta dele*** *(*"ajudaria bastante a balancear as metrias"*), que começou em `INT 5` e nível `8`.* **O `8` foi recusado pela conta e o `10` é dele:** *no marco `6` a escolha `Corpo` dá o atributo e a escolha `Refino` dá a aptidão, e elas são exclusivas — então `INT 5` **e** uma aptidão só coexistem no marco `10`, e só para quem tem INT como principal (quem tem INT secundário chega no `14`).*
    >
    > **7 · O ritual pode ser auxiliado**, *decisão dele:* **"pessoas externas que saibam fazer rituais podem auxiliar, como no teste para suceder, amplificação e talz. Como na luta do sukuna e gojo, o gojo recebe auxilio na amplificação de seu primeiro feitiço."** *O F&M 2.5 tem o molde: o aliado gasta a Ação Completa e fornece espaços que não somam na dificuldade, e se o ritual falhar os dois pagam.*
    >
    > **A pesquisa da obra, feita em 20/09/2026:** *o Sukuna impôs uma amarra em si mesmo com **três condições** para cada Cortada — fazer o sinal de mão, recitar o encantamento do Desmantelar, e direcionar a trajetória com a palma.* **A escada de condições empilhadas é a forma que a obra já dá**, e ela encaixa no `Selo`, que é *"um gesto, um som, uma condição visível"*. *E a regra pendurada nele — **uma Restrição que cobra a mesma coisa que o Selo não devolve ponto** — é o que impede cobrar duas vezes pelo mesmo gesto.*
    >
    > **A base de referência é o `F&M 2.5 — Rituais Ritualísticos feitos por Ritualistas`**, *o sistema antigo que ele jogava, lido inteiro em 20/09/2026.* **Lá o tempo compra espaço de Melhoria** (*Ação Bônus `1`, Ação Comum `2`, Ritual Estendido `5`*), *com CD de Prestidigitação que sobe com os espaços ocupados, `Ritual Forçado` (espaço extra com `+2` de CD e colapso na falha), `Ritual Cooperativo` e a habilidade `Ritualista`.* **Ele avisou que não dá para copiar:** *"n da pra adaptar exatamente igual, principalmente pq nosso sistema é mais balanceado".* **Hoje o `Selo` é o único gesto de conjuração:** *um só por técnica, sempre o mesmo, sem custo e sem bônus, e a Condição `Calado` impede o que precisa de voz.* **Não existe conjuração de ritual, com sinais próprios e tempo de minutos, para o feitiço especial:** *o mais lento que há é a Restrição `Atrasar` (a rodada inteira) e o `Carregar`.*

12. ~~**`Alvo de Caça`, a Melhoria de buff de dano, o Hex do nosso sistema.**~~ **FECHADO na v0.255, na Família `Marca`.** *Proposta e nome do Mizuki em 19/09/2026, depois de aprovar os três defaults da duração:* **uma Melhoria auxiliar `Leve` que dá `1d4` de dano extra em cada golpe dele contra UM alvo marcado, até o fim da próxima rodada, com `1d8` quando pareada com o `Rápido`; para durar `1` minuto, a `Concentrada`.** *Ela segue a regra das Auxiliares: num feitiço de dano, o buff entra quando o feitiço acerta ou o alvo falha o Teste de Resistência; num feitiço só auxiliar, entra direto.* ***Lacuna confirmada:*** *o catálogo não tem nenhum buff de dano — `Marca` dá vantagem, `Ecoa` dá vantagem ao aliado, e `Remate`, `Acúmulo` e `Queima` são do próprio golpe.*
   >
   > ***DECIDIDO pelo Mizuki em 19/09/2026: o dado é FIXO, sem escala por Classe, e a conta confirma.*** *Dele: "no D&D a gente não tem esse aumento ao longo dos níveis, sinto que isso vai fortificar a possibilidade de só atacar ao invés de usar feitiços". **Eu tinha proposto `X`d4 (`X` = metade da Classe) e estava errado, e o erro foi da minha conta:** ela comparava o dano extra do buff COM taxa de acerto contra o dano de dado SEM ela, e subestimava o buff em `1/0,55`. Refeita com a mesma régua dos dois lados (`1` ponto = `1d8` = `4,5` de dano cheio; a Rotina é dano cheio):* **o `Xd4` paga `167%` do preço em toda Classe (`186%` com a `Concentrada`), sem nunca cair, e no nível `30` põe `20` de dano por rodada, `18,5%` da Rotina, por uma Melhoria `Leve` — mais que o `Acúmulo` (`Média`, `+3d8`, `13,5`) — e leva o golpe simples de `47,2%` para `55,5%` da Rotina.** **O dado fixo desbota como o do D&D:** *só o buff (`3` golpes na janela) paga `167%` nas Classes `1` e `2`, `83%` nas `3` e `4`, `56%` nas `5` e `6`, `42%` na `7`; com a `Concentrada` (`6,7` golpes) `186%`, `93%`, `62%`, `47%`; o `1d8` com o `Rápido` (`4` golpes, pagando o `Rápido` também) `133%`, `100%`, `57%`, `50%`, `36%`, `33%`, `27%`.* **E nenhuma das opções muda a vantagem ABSOLUTA de conjurar sobre atacar:** *o buff soma o mesmo por golpe nas duas rodadas, então a diferença entre a rodada de feitiço e a de golpe fica em `15` no nível `7` e em `57` no `30`, e o invariante da peça 11 (a rodada de golpe fica abaixo da Rotina) segue com folga — o golpe sobe de `51,6%` para `58,3%` (`62,5%` com `1d8`) no nível `7`, e de `47,2%` para `49,5%` (`51,3%`) no `30`.* **O acoplamento `1d8` com `Rápido`, que eu tinha chamado de exceção escondida, é o certo:** *ele faz a ficha que ataca só com a arma pensar em como combinar no kit, que é o que ele quer, e desbota nas Classes altas.*
   >
   > **O Nível 1 (Classe `1`, `3` pontos) NÃO cabe completo.** *O Hex inteiro (`Alvo de Caça` + `Concentrada` + `Rápido`) custa `4` pontos, que uma Restrição `Leve` (`Parado`, que devolve `1`) fecharia; mas o livro limita as Melhorias por feitiço a `2` nas Classes `1` e `2`, `3` nas `3` e `4` e `4` da `5` em diante, e o Hex tem `3`.* **Ele só cabe da Classe `3` (nível `9`), e a `9` de `9` pontos.** **Nas Classes `1` e `2` a ficha escolhe: `Alvo de Caça` + `Rápido` (`3` de `3` pontos, `1d8`, janela curta) ou `Alvo de Caça` + `Concentrada` (`2` pontos, `1d4`, `1` minuto)** — *uma decisão de kit de verdade.* **Do `Hex` completo, o custo é de `83%` a `100%` do orçamento da Classe `3` em diante.**
   >
   > ***FECHADO na v0.255, e as quatro escolhas são do Mizuki em 19/09/2026.*** **Família `Marca`** *("Coloca em marca"): ela é irmã da `Marca` — a mesma janela e o mesmo alvo, dano no lugar de vantagem —, a palavra `marcado` já mora ali, e é o MESMO estado, então a `Condicional` que dispara com "marcado por você" dispara com as duas. Em `Auxiliares` a `Régua`, que é o pronto de caçador, ficaria trancada pela Família Fechada; em `Marca` nenhum dos três prontos bloqueia, e a `Sentença` e a `Banca` têm desconto.* **O gatilho** *(dele: "Qualquer ataque que não seja 'continuo', ent rajada pega, ataque extra, afins (q nem dnd)"): toda rolagem de acerto sua que acerta o alvo marcado, com cada tiro da `Rajada` contando sozinho — é o `Hunter's Mark` do D&D 2024. Feitiço de Teste de Resistência não é ataque; dano que volta em rodadas seguintes e respingo não contam; a invocação não herda.* **Sem termo novo** *(dele: "A definitivamente") — a regra fala de "duas Melhorias escritas como uma", sem batismo e sem glossário.* **O preço aceito:** *só o buff paga `111%` do preço nas Classes `1` e `2` e `28%` na `7`; a `Rajada` seguinte soma `(Classe + 1) × 2,5`, que é `20,0` de dano na Classe `7` (`18,5%` da Rotina) — a mesma curva do `X`d4 que ele recusou, só que paga também com a `Rajada` e travada em `3` Melhorias. Ele viu o número antes de escolher e manteve.* **Escrito na v0.255:** *o `partD.js` (manual v7.36), o capítulo 9 e o glossário do livro, a peça 3 §3, com a checagem `9` do `conferir-acao.py` e a `4o` do `conferir-manual.py`.*

13. ~~**Combo do jogador, e a lacuna do `Efeito Próprio`.**~~ **FECHADO na v0.255.** *Dúvida do Mizuki em 19/09/2026 (se um jogador poderia fazer uma Melhoria "sem família" que junta duas Leves numa Média), pesquisada sem mexer em nada, e ele DECIDIU: fica o "combo do jogador que conta como as partes", "menos dor de cabeça".* **A regra decidida, ainda NÃO escrita:** *o combo cobra a soma dos preços das partes e conta no limite de Melhorias como as partes (é atalho de leitura na ficha, sem efeito de balanço); o texto deve deixar claro que o mestre PODE aprovar um combo custando menos ou economizando espaço, mas é decisão inteiramente dele, por conta e risco, e não recomendada.* **E isso fecha a lacuna que ele descobriu:** *o `Efeito Próprio` tem limite de um por feitiço (isso já estava escrito), mas o texto não diz se ele conta no limite de Melhorias de `2`, `3` ou `4` por Classe; a `Restrição Própria` diz que conta no limite de duas Restrições. A frase que falta é "o `Efeito Próprio` conta como uma Melhoria".* **O que a pesquisa achou (os números servem para o aviso do mestre):** *tirar o limite de Melhorias não move o pico de dano (busca exaustiva do `v7.py` numa cópia sem o limite: `17`, `34`, `51`, `68`, `84`, `101`, `118` de dano nas Classes `1` a `7`, idêntico); o que o limite corta é largura — por pontos caberiam `3`, `6`, `4`, `6`, `5`, `6`, `5` Leves e o limite deixa `2`, `2`, `3`, `3`, `4`, `4`, `4`; acrescentar a `Concentrada` sobre o buff de dano rende na margem uns `205%` do preço na Classe `2`, então o jogador monta o pacote de sinergia e os builds convergem; o D&D 2024 permite uma Metamagia por magia e só duas no nível `7` do Feiticeiro enquanto a Feitiçaria Inata está ativa; o Pathfinder 2e desperdiça o benefício de uma segunda ação metamágica.* ***ESCRITO na v0.255:*** *o `Efeito Próprio` passa a dizer que conta como uma Melhoria no limite da Classe, em três cópias de cada documento (a linha do catálogo, a frase depois da tabela de limite e a regra de ouro `3`); e o parágrafo do combo entra no `partA.js` e no capítulo 9, com a soma dos preços, o limite contado pelas partes, e o aviso de que o mestre pode aprovar por menos "por conta e risco" e que o manual "não recomenda". Sem termo novo, por escolha dele. A checagem `4o` do `conferir-manual.py` guarda as seis cópias e o parágrafo, e proíbe a redação antiga.*

14. ~~**O `Acúmulo` contra "num alvo só, feitiço comum para nos pontos da Classe".**~~ ***FECHADO na v0.259, e não por conta: por leitura de mesa.*** ***Decisão do Mizuki em 20/09/2026:*** **"o acúmulo n é um problema d verdade né, 4 rodadas é fim de combate".** *A conta abaixo fica como registro, e ela é justamente o que dá razão a ele: o caso só existe na **quarta** rodada seguida contra o mesmo alvo, e a luta média é de `3,7`.* **O que estourava era um número que a mesa não alcança.** *Achado enquanto eu media a soma do `Alvo de Caça` com o `Acúmulo` e o `Remate`, na v0.255.* **O pior feitiço num alvo só — `Acúmulo` (`Média`) mais `Remate` (`Média`) mais duas Restrições `Média` devolvendo o máximo — já passa do dano da `Liberação Máxima` nas Classes `3` e `4` na quarta rodada seguida contra o mesmo alvo:** `56` *contra* `54` *na Classe `3`, e* `73` *contra* `72` *na `4`. Isso é **antes** do `Alvo de Caça`, que soma `2,5` fixos ali (`5,6%` da Rotina na Classe `3`) e não é a causa.* **Três coisas que faltam, e é por isso que ele fica aberto:** *o manual não diz se o `+3` do `Acúmulo` é exceção do teto de um alvo só ou se o teto continua valendo por cima dele; nenhum dos `35` Fundamentos prontos usa `Acúmulo`, então o caso nunca apareceu montado; e o `v7.py` mede o dano de UM feitiço e não modela adição rodada a rodada, então a busca exaustiva dele passa por cima deste caso sem ver.* **Custa quatro rodadas seguidas no mesmo alvo para acontecer**, *que é mais que a luta média de `3,7` rodadas — é por isso que não é urgente.*

15. ~~**A Melhoria de resistência a tipo.**~~ ***TIRADA DA LISTA na v0.259, por decisão do Mizuki:*** *"o item 15 pode apagar da lista".* **A conta inteira mora na entrada da v0.258 do `CHANGELOG`**, *e ela é grande: a lacuna que motivou a candidata não existia (resistência a um tipo já é a Passiva `Escama`, desde a v0.26), o preço fecha em `72%` · `90%` · `99%` de `Pesada` para o grupo `Físicos`, e o escopo do meio não é calculável porque o Bestiário não diz quantos tipos de dano um inimigo usa.* **O nome `Amortece` passou na triagem e fica guardado lá.** *Ela sai da lista de pendências porque não é trabalho parado esperando alguém — é assunto de playtest, e o gatilho é o peso dos três grupos deixar de ser previsão.*
## Marcado para o playtest

> ***Decisão do Mizuki na v0.131: a `Torrente` inteira sai da lista de deveres e vai para o beta.*** *A pendência de regra dela fechou; o que sobrou são três perguntas que só a mesa responde, e nenhuma delas é trabalho de documento.* **Não reabra nenhuma das três sem retorno de jogador.**

- **A `Torrente` estourando `50%` incomoda na mesa?** *Ela fecha em `7,52` de um orçamento de `5,00`, com o estouro aceito no precedente da `Brasa`.* **Três coisas seguram ela e nenhuma é preço:** a matriz dá `100%` ação/alvo e zero nas outras três colunas; a rodada de pico custa `44` de PE de um poço de `180`, que é `1,1` luta no dia; e o relógio de `2×` por cena é escolha por rodada. *Se ela pesar, o conserto está medido — mas ele é o orçamento de Trilha, e mexer nele reabre a v0.73 inteira.*
- **Alguém sente falta da `Vazão` nos níveis 11 e 12?** *Nesses dois ela vale zero: o teto que ela dá é `13` de dano e o `Classe 0` que ela substitui já é `18`.* **A cláusula de piso tirou a armadilha de texto, não deu conteúdo aos dois níveis.** *Só começa a pagar no 13, quando a Classe 4 abre.*
- **A luta dura mesmo `3,7` rodadas?** *A taxa de `54%` do `Acelerar` sai daí, e ela decide o preço da Trilha inteira.* **Se a luta for mais curta, o `2×` por cena vira taxa maior e a `Torrente` cresce; se for mais longa, ela encolhe sozinha.**
- **Os `8` dados rerrolados por conjuração da `Cheia` cansam?** *Um `Classe 7` são `21d8`, e a janela de `1` a `3` mexe em `37%` deles.* **É preço de tempo de mesa, declarado, e é a primeira coisa a olhar nesta Trilha.**
- **A correção da v0.16 passou do ponto?** *Essência carrega a perícia mais rolada da mesa, o TR Espírito, os Pactos, é candidata a atributo da técnica — e, **desde a v0.145**, o tamanho da Integridade.* **São cinco trabalhos contra os dois da Constituição.** O peso estava empatado com Inteligência em 39% cada antes do quinto, e empate na planilha não é empate na mesa.
- **Apareceu alguém com Constituição 0 ou 1?** Ela é a maior alavanca de sobrevivência do sistema — **+79% contra os +56% da Destreza**, os dois medidos de 1 a 6. *Corrigido na v0.24:* o par que estava escrito aqui era +113% contra +56%, e ele mistura bases — o 113% é de 0 a 6. Na mesma base a Constituição está na frente por 1,4×, não por 2×. Continua sendo a pergunta de playtest, com o tamanho certo. Se ninguém a zera, virou obrigatória, e o conserto é uma linha: ela volta a entrar só do segundo nível em diante.
- **O espalhamento de vida de 3,2× incomoda?** O Evocador de Constituição 0 cai em 1,7 rodadas no nível 30; o Bastião de Constituição 6 aguenta 5,5.
- **O estágio 4 de dano de alma dispara alguma vez?** *A alma é a barra menor em `33,3%` das fichas da grade, e nas outras duas terças partes o corpo acaba antes.* **A Essência entrou na v0.145 e a fração NÃO se moveu** — o que mudou foi quem está nela: antes era quem investiu Constituição, por acidente; agora é quem não investiu Essência, de propósito. *Continua sendo pergunta de mesa.*
- **Intuição está em cima do muro.** "Ler a pessoa" tem cara de perceber e ela ficou em Inteligência como dedução. Se rolarem Percepção no lugar dela, muda de casa.
- **Provocar e Intimidação vão brigar?** Uma faz recuar, a outra faz avançar. Claro escrito, vago em jogo.
- **Força tem uma perícia só**, e a lista não conserta. O conserto barato, se doer, é Força somar em pontos de vida.
- **A taxa de acerto real é 50%** contra alvo que investiu em defesa, e o combate deve levar 3,4 a 4,0 rodadas. Os textos antigos citam 60% e 65% e estão marcados como previsão, não como número fechado.
- **Alguém rola Pontaria?** Ela e o ataque à distância são as duas Destreza e as duas acertam alvo.
- **Alguém usa ação bônus?** É a peça mais herdada do turno e a que mais custa tempo de mesa.
- **Dois mestres contam o mesmo número de lutas?** *Entrou na v0.26.* A exaustão dispara da quarta, e quem conta é o mestre. Medir a mesma missão com dois mestres e comparar o número de degraus no fim do dia.
- **Alguém escolhe a Escama?** *Entrou na v0.26.* Ela vale 50% quando o tipo bate e zero quando não bate, e o ponto de virada é uma luta em quatro. Medir se as pessoas pegam — e, se pegarem, com que frequência o tipo delas aparece.
- **`Alvo de Caça` vira o loop "marca uma vez e só ataca"?** *Entrou na v0.254 e foi escrito na v0.255.* ***E a `Rajada` também dispara o dado, um por tiro***, *decisão dele em 19/09/2026 — então o loop a testar não é só "marca e bate com a arma": é também "marca e solta `Rajada`", que na Classe `7` soma `20,0` de dano, `18,5%` da Rotina.* **O dado fixo desbota nas Classes altas de propósito, e a diferença entre a rodada de feitiço e a de golpe não se mexe; se a mesa mesmo assim só marcar e atacar, o conserto medido é tirar o `1d8` do `Rápido`.**

## O que existe e o que não existe, medido

Vale ter isso à mão, porque o material é grande e engana. *Medido na v0.33, e é retrato e não número fechado — reconte antes de citar.* **101.000 palavras** contando `sistema/` (fora o `99-arquivo/`), o CHANGELOG e o README, das quais **34.200** nas doze peças de mecânica e **32.000 no CHANGELOG** — quase um terço do projeto é o registro do porquê, e não o jogo. Mais **3.880 linhas** nos dez validadores de `03-mecanica/`, e 4.640 contando os treze.

**O que existe:** as regras, com conta, com validador e com o motivo de cada número.

**Uma ficha de nível 2 precisa de dezessete coisas. Treze existem, e as quatro que faltam não mordem nessa faixa** — *medido na v0.26, depois que os quatro buracos saíram, e recontado na v0.32, quando a tabela de XP saiu desta lista para a peça 12:*

| o que falta | por que não trava uma missão de nível 2 |
|---|---|
| ~~Tabela de proteção~~ | **fechada na v0.48**, na peça 14: Traje e Revestimento com três degraus cada, e escudo com três |
| ~~Regra de Pactos~~ | **fechada na v0.134**, na peça 22: quatro formas, e só o permanente tem teto. *Ela continua sendo opcional na criação — a ficha nasce sem pacto nenhum —, e as outras três formas de troca continuam com o dono que já tinham, no manual e na peça 13* |
| ~~Trilhas com número~~ | **fechada na v0.164**: as quinze têm as quatro entregas escritas, com preço e texto de mesa |
| ~~Aptidões e degraus de refino~~ | **fechada na v0.27**, na peça 11 — e as quatro anti-domínio na v0.29. *Continuam valendo só do nível 6 em diante* |

**O que não existe, e faz falta para alguém jogar:**

> **As duas primeiras linhas da segunda tabela são vocabulário que ainda não tem peça, e por isso a definição delas mora aqui — provisoriamente.** *Quando cada peça for escrita, a definição vai para ela e esta linha vira ponteiro.* **Enquanto isso, este é o dono:** a peça 13 e a peça 14 citam as duas e apontam para cá em vez de repetir, que é a lição nº 9 sendo obedecida em vez de explicada.

| falta | tamanho do buraco |
|---|---|
| ~~**Tabela de progressão consolidada**~~ | **fechada na v0.99**, na peça 18: uma tabela só, trinta linhas, nove colunas. *Ela não estava espalhada por cinco documentos — eram dez números em seis lugares, e um deles não tinha dono nenhum.* **A curva de refino das três rotas continua no `arquitetura.md` §4.3**, e é a última fonte da progressão fora de uma peça |
| ~~**Quick-start jogável**~~ | **Abandonado como arquivo separado na v0.102**, e **fechado como texto na v0.106**: `sistema/05-material/livro/` tem o Manual da Guilda completo, 230 páginas, com o quick-start (*"Antes da primeira sessão"*) escrito direto no PDF — o molde que a v0.103 previu, *"como o PDF carrega essa propriedade é trabalho dele"* |
| **Playtest** | **COMEÇOU na v0.215.** A Mesa 1 está em `04-playtest/mesa-01-grupo-01.md` — três personagens de nível 2. *A taxa de acerto deixou de ser previsão; o resto ainda é* |

*A **tabela de XP** saiu desta lista na v0.32.* Ela era a trava nº 1 de mundo compartilhado e ficou aberta trinta versões; hoje é a peça 12, com o `conferir-xp.py` em cima dela.

A skill `redacao-acessivel-rpg` existe exatamente para a travessia de "nota de design" para "texto de regra", e nunca foi rodada contra o material. **Com o quick-start fora, quem recebe essa travessia é o PDF.**

> **⚠ A pergunta que ficou aberta junto com aquela decisão FECHOU na v0.103.** *O dossiê de metodologia lista, como trava de arquitetura, que o material nasce com um quick-start na frente — e o argumento de lá não é sobre ter dois arquivos, é sobre **alguém conseguir jogar antes de ler tudo**.*
>
> ***Decisão do Mizuki: ela sai da lista do projeto.*** *"vamos finalizando as informações e mandando pro outro repositório o necessário para fazer o PDF, eu já tô no processo de estudo sobre".* **Como o PDF carrega essa propriedade é trabalho dele; o que o repositório faz é mandar o material para a entrega.**

**E as dez pendências que só a mesa responde são todas de nível 2** — Constituição virou obrigatória, alguém usa ação bônus, Intuição contra Percepção, se quatro perícias livres é escolha demais, se alguém rola Pontaria, se o extra da Origem é escolha de igual para igual, se a criação leva mesmo vinte a quarenta minutos, se um Legado por ficha é pouco, se três lutas de graça é o número certo, e se o descanso curto devia devolver alguma vida. **Nenhuma delas precisa das aptidões.**

### A fila de agora — v0.239

**Tudo aqui é DECISÃO TOMADA e CONSERTO NÃO FEITO.** *A v0.220 anotou e não consertou, por pedido dele.* **Quem pegar esta fila começa aplicando, e não decidindo.**

| # | o que foi decidido | onde mexe |
|---|---|---|
| 1 | ~~**O inimigo vai contar energia**, com poço semelhante ao do jogador~~ | ***REVERTIDA em 09/09, pelo próprio Mizuki.*** **O inimigo NÃO conta PE, e a peça 26 §6.1 fica.** *O limite dele é rótulo de frequência — `à vontade` · `1×/rodada` · `1×/luta` · `Recarga (5-6)` —, que é o que `8` de `9` sistemas medidos fazem.* **E a `Sobrecarga` que dependia disto foi reescrita na v0.221** — *"ele não usa Reação" no lugar de "o dobro de energia"*, com o `manual/matematica/sobrecarga.py` refeito contra ela |
| 2 | ~~**`Fura` = `2 × Classe`, `Enfraquece` = `Xd4`, `Abre Ferida` = UM Teste**~~ | ✅ **APLICADA na v0.223, e foram DEZ lugares em CINCO arquivos, não um.** *O `Fura` tinha oito cópias — a tabela do `partD.js` mais sete números de exemplo no `partA`, no `partC`, no `partE` e nos três feitiços prontos do `partF`, que a checagem `12` não alcança.* **As três linhas do `ESTADO-revisao.md` estão `fechada na v0.223`, e o manual foi para a `v7.27`** |
| 3 | ~~**O domínio sem barreira para de perder por regra**~~ | ✅ **APLICADA na v0.226, como um terceiro degrau: a `Expansão sem Barreiras`.** *Refino `10` e especialização em `Ocultismo`, `5` espaços, raio de `200 m`, e a Expansão inteira ganhou raio de `1,5 m × refino`.* **Ficaram adiados por ele: os anti-domínios contra ela, e o Rescaldo** — *ver os dois itens novos abaixo.* *O caminho está no `03-mecanica/RASCUNHO-expansao-sem-barreira.md`* |
| 4 | ~~**O DejaVu Mono é defeito**~~ | ✅ **APLICADA na v0.236.** *As dezesseis faces do release `2.5.0` da IBM foram para a pasta de fontes do usuário, e os dois PDFs de cada livro foram refeitos.* **A checagem `7.6` passa sem aviso** |
| 5 | ~~**`B18` vai ser corrigido**~~ | ✅ **FECHADO na v0.238, no clone `Claude 3`.** *O `Ficha.gs` sai da `ficha-v01`, a cópia da planilha viva, e os dezesseis validadores de lá passam. O clone `Ficha---RPG-JJK` da pasta `Ficha` aponta para o mesmo repositório e está parado no B10* |
| 6 | ~~**Revisar os anti-domínios**~~ — *decisão dele na v0.226: "vamos revisar a mecânica de como esses anti domínios funcionam"* | ✅ **FECHADO na v0.274, com a comparação das quatro:** *nenhuma ficou dominada, e a tabela está na peça 11 §6.5, em "As quatro lado a lado". O registro de antes fica abaixo.* as quatro da peça 11, e como elas se portam contra a `Expansão sem Barreiras`. *As saídas medidas estão no rascunho, seção 8.4.* ***A PESQUISA DE CAMPO SAIU na v0.264 e foi CONFERIDA na v0.265*** — em `01-pesquisa/anti-dominios/`, com o resumo das quatro e as **catorze** divergências no `H-resumo-das-quatro.md` e a verificação cega no `N-verificacao-do-H.md`. **⚠ A premissa da 8.4 está metade errada:** *a casca não é a variável, e sim a diferença de saída (`出力`) entre quem defende e quem abriu — quatro `Domínio Simples` aguentaram quase 99 s dentro de um domínio sem casca (cap. 258), e dentro de domínio FECHADO o Sukuna pagou metade do corpo (caps. 249 e 266).* **Nenhuma das quatro tem relógio próprio na obra; todas caem por fora.** **As catorze divergências, em duas metades:** *conserto de fato — o "pés no chão" é voto da Miwa (e a obra diz "do **ponto** onde foi ativado"), o raio `2,21 m` é dela, o Kusakabe expande o raio com a própria aptidão, a `Pétala` responde ao acerto garantido que **toca** e não a "ataque físico" (a frase do Acerto corporal cai), e seis frases que a peça atribui à obra e a obra desmente: a `Cesta Oca` "não faz mais nada" e "não quebra", a `Pétala` "cai se perder a concentração" e o Gojo "nunca tinha usado", a `Extensão` "acerta independentemente", e "nenhuma serve contra a incompleta" valendo para a `Extensão`.* **Decisão de preço, e é dele** — *como cada uma cede (a `Cesta Oca` e o `Domínio Simples` protegem **inteiro até cair**, e só a `Extensão` **atenua** contra saída maior); o que a `Extensão` faz contra o Acerto de domínio (o Fanbook diz que neutraliza, e a obra não tem cena); o que separa `Domínio Simples` e `Cesta Oca` (ela segura com o selo e racha sob golpe no dono; ele cai pela pressão ou pelo voto); e o custo da `Cesta Oca`, que é **selo imposto** e veta o golpe grande do dono.* **Livres de canon:** *custo de energia, duração, `Extensão` junto com a técnica reversa e aprendizado — a obra não amarra nenhum.* **Rodada 1 aplicada na v0.266:** *as frases de texto da peça 11, e duas cópias na peça 25 — nenhuma regra mexida.* **Rodada 2 aplicada na v0.267: a `Cesta Oca` foi reescrita** — *mãos presas no lugar do turno, cai pelos golpes em quem segura (metade da Essência em falhas), recarga de metade da Essência — e ela é a base da revisão das outras três.* **Rodada 3, o Domínio Simples, aplicada na v0.268 e v0.269:** *um relógio contra a Expansão em Essência (`4`, `3` ou `2` rodadas, maior, igual ou menor que a do dono — a v0.269 trocou a fórmula de refino da v0.268), o teste do `Carregar` a cada Acerto, a queda na hora, erguer de novo com a Ação Padrão e metade das rodadas, os pés como voto do iniciante, e `2` PE fixos; a Cesta perdeu a recarga (v0.268) e passou ao teste do `Carregar` (v0.269).* **Rodada 3, a Pétala, aplicada na v0.272:** *ela rebate o que toca, o dano do Acerto sai da Essência contra a do dono (maior anula, igual leva `1/4`, menor leva metade), o que a Expansão traz por contato e não é dano ela anula sempre, cai pelo teste do `Carregar` a cada golpe sem a queda na hora, contra-ataca com arma empunhada por `3` PE, e custa `1` PE por rodada; e erguer a Cesta, o Simples ou a Pétala passou a custar a maior Classe, toda vez.* **Rodada 3, a Extensão, aplicada na v0.273:** *imune a tudo o que a Expansão faz, em qualquer degrau; a técnica que encosta anulada até `1/3 do refino + 1`, e acima disso você leva `3/4`; não cai por golpe; erguer paga a maior Classe; nível 18 com requisito de história; o Corpo Amaldiçoado não compra; nenhum feitiço nem `Manejo` de pé; e a Técnica Marcial, a reversa e as aptidões continuam com ela.* **Falta a comparação das quatro.** *Na v0.272 esta linha registrava: as respostas dele para a Extensão já estavam dadas — erguer paga a maior Classe toda vez, ela anula o Acerto sempre, não cai por golpe, levanta como as outras, e o nível passa a 18 —, e ficaram duas perguntas: o que "reduz 1/4 do dano" quer dizer para a técnica acima do teto, e se ela ganha requisito de história. Os quatro consertos de texto dela também estão com ele. **Uma sobra para a rodada dela:** a peça 11 arredonda para cima o `1,5 × maior Classe` (`11` PE no nível 26) e o §6.5 da peça 26 usa `10,5`.* *Um ponto para a comparação: com a Essência maior que a do dono, a Pétala protege o mesmo que a Cesta.* ~~**Continua aberta, para a comparação, a sobra do arredondamento da Extensão:** *a peça 11 arredonda o `1,5 × maior Classe` para cima (`11` PE no nível 26) e o §6.5 da peça 26 usa `10,5`.*~~ **Fechada na v0.274:** *a peça 26 passou a arredondar para cima, pela peça 1 §5.4.* **E a comparação fechou:** *nenhuma dominada; com Essência maior, a Pétala protege um pouco mais que a Cesta, e paga de `2` a `5` PE a mais; e a queda na hora é um Acerto a mais.* |
| 7 | ~~**O Rescaldo e a porta de saída dele**~~ | ✅ **APLICADO na v0.239, como a aptidão `Regravação`, na peça 11 §6.** *Ação Bônus durante o Rescaldo: gasta o teto inteiro da `Energia Reversa`, a técnica volta, e fica uma marca.* **Com `metade da Inteligência + metade da maestria` marcas, a Expansão não abre até o descanso longo.** *A `Regravação` no inimigo fechou na v0.242, na peça 26 §6.4, com a corrente inteira e os marcos do jogador* |
| 11 | ~~**O teto de atributo e o incentivo da rota `Corpo`**~~ — *levantado por ele em 20/09/2026, enquanto mediamos a escada de CD: "o teto é alcançado por darmos de graça, oq tira o incentivo em parte de pegar rota de corpo"* | ✅ **FECHADO na v0.278, sem mudar nada — resposta dele: "A".** *As duas vertentes foram medidas no parecer da v0.264 (`sistema/01-pesquisa/PARECER-ideia-11-teto-de-atributo.md`), e esta linha ainda dizia "sem medida": o espelho não se move, o ganho de `+5` pontos percentuais só existe contra o teto fixo do inimigo e toca oito peças, e a rota `Corpo` já compra `+4` e `+3` no terceiro e no quarto atributo. Se o playtest mostrar a rota fraca, o conserto barato é `+1` em algo que só entra de um lado da rolagem — dano, alcance ou deslocamento. O registro de antes fica abaixo.* ***A premissa CAIU na medida, e fica registrado para quem voltar.*** *Só o atributo **principal** chega ao teto `6` de graça, com os sete pontos passivos dos marcos partindo de `3`. Os outros quatro só sobem se o jogador gastar a escolha — e é exatamente isso que a rota `Corpo` compra.* **A tabela da peça 2 §3 mostra: `sempre atributo` termina em `6·6·6·4·1` e `sempre refino` em `6·6·2·1·1`, dois atributos inteiros de diferença.** *E o principal chegar ao mesmo lugar nos três caminhos é declarado como proposital: "os três chegam ao mesmo lugar no atributo principal, e divergem em tudo o mais".* **As duas ideias dele ficaram na fila** *— a rota `Corpo` estourar o teto em `1` (um atributo por vez), ou o teto virar `5` com o `6` travado atrás dela —, e foram medidas no parecer da v0.264.* ⚠ **Qualquer uma mexe no teto de Defesa `20`, que a peça 14 §3 deriva do teto de atributo** — *não é mudança isolada* |
| 10 | ~~**Organizar os requisitos das aptidões**~~ ✅ **FECHADO na v0.260** — *pedido dele em 20/09/2026: "tem algumas que tem niveis que não se recebe aptidão e isso n faz sentido"* | **MEDIDO na v0.259, e ele está certo: `4` das `5` aptidões com gate de nível gateiam num nível que não é marco.** *Aptidão se ganha nos marcos `6 · 10 · 14 · 18 · 22 · 26 · 30`, e a `Energia Reversa` e a `Extensão de Domínio` pedem nível `13`, enquanto o `Domínio Simples` e a `Pétala` pedem `7`.* **O efeito prático é ZERO — escrever `13` ou `14` dá o mesmo resultado, porque o marco é quem manda** —, *e o número não é arbitrário: `7` e `13` são os níveis da Classe Passiva `2` e `3`, que o §5 declara como régua herdada.* **Então o gate é inerte, não errado.** *Decidir: trocar para o marco (`7`→`10`, `13`→`14`), ou deixar e escrever que o marco manda.* **Só o `Kokusen Melhorado`, no `14`, já caía em marco.** ***FECHADO na v0.260:*** *os gates subiram para `10` e `14` na peça 11, no `DESENHO-trilhas` e na peça 25, e o guarda de título do `conferir-aptidoes.py` foi junto.* **E a troca destampou uma coisa maior:** *a peça 16 dizia herdar esse gate, e o `conferir-ferramenta.py` acendeu — a conta mostrou que o `Estigma` SEMPRE foi mais fácil que a aptidão da mesma Classe (`3` níveis na Classe 2, `1` na Classe 3), porque a peça 16 tira a metade de refino e o refino é quem segura a aptidão.* **A herança era nominal e morreu; a ferramenta fica em `7` e `13` por decisão dele** — *"Ferramenta é decisão do mestre, são exemplos a tabela… por que mexeria?"* |
| 9 | **As duas fichas novas: a `ficha pessoal` e a `ficha maldita`** — *levantado por ele em 20/09/2026, varrendo a fila: "falta nessa fila ai a criação na ficha contendo 'ficha pessoal' (aqui vai ter os itens, bio, anotações, foto, xp etc), e 'ficha maldita' (aqui vai ter as tecnicas, aptidões e afins, é uma representação maior da '8' que tem na ficha principal)"* | o repositório da ficha (`Claude 3`), e **não** este. *É ela que destrava o `Volume` da v0.256 e da v0.257, que hoje não tem onde entrar — a palavra não aparece uma vez no `Ficha.gs` nem no catálogo.* **A dívida de regra da ficha é outra coisa e é menor:** *o `Carregar` com a CD velha (o único ERRADO hoje) e três Melhorias ausentes do catálogo de consulta, que não dependem de aba nenhuma.* ***FECHADAS: a rodada da v0.258 e a da v0.260 subiram em 22/09/2026 (`629473f`).*** ✅ **A ponta 3 da v0.262 FECHOU em 22/09/2026** (`7f83e35`): *o texto que a ficha carrega — o manual em txt do repositório dela — foi reextraído do PDF de coluna única do livro da v0.263, e foi de `13.940` para `14.352` linhas.* **Ela destampou três coisas que a edição à mão tinha deixado passar:** *o `Efeito Próprio` estava com o texto de antes da v0.255; a coluna `VOLUME` da v0.256 e da v0.257 fazia as **três** tabelas de equipamento lerem ZERO; e o parser de legados lia `79` de `90` e saía verde, porque o título `Legados da Latente` caiu numa página que imprime o número na mesma linha.* **O carimbo fica em `0.258` de propósito** — *ele é a versão do catálogo, e o catálogo não ganhou nada da v0.259 à v0.263.* **As dezesseis Melhorias de ritual não entram no catálogo de consulta:** *esperam a ficha maldita, porque o ritual é montagem de feitiço e a ficha não tem bloco de feitiço.* |
| 12 | ~~**Medir as fatias da coleção v0.4**~~ — ✅ ***FECHADO na v0.281, sem medir o resto — "n precisa tanto".*** *O piloto do Bastião ficou de registro, as três pendências da v0.4 fecharam (duas na v0.280, a do nível 15 do Emanador na v0.281), e a leitura dos outros três Caminhos (`sistema/01-pesquisa/medicao-v04/LEITURA-vanguarda-emanador-guia.md`) levou quatro perguntas, respondidas na v0.281. O índice de entregas da v0.4 foi para o item 17. O registro de antes fica abaixo.* ***Em andamento desde a v0.279: primeiro um piloto com o Bastião, sem agente ("2 - A"), e a leitura dele já declarou três exceções à cerca da peça 5. O piloto saiu na v0.280, em `sistema/01-pesquisa/medicao-v04/`, e o Mizuki achou a conta inflada — "você está calculando cogitando muitas coisas, n precisa tanto" —: o `Combatente Amaldiçoado` fica como está ("3 - A"), e o resto do item virou leitura sem conta ("2 - B"): os outros três Caminhos, atrás de regra ambígua e de texto que brigue com o resto do sistema.*** — *v0.270, nas palavras dele: "Não é necessário medir cada fatia ou certificar novamente o orçamento para implementar. […] Isso não autoriza declarar que o equilíbrio foi comprovado. Coloque na fila que futuramente terá de ser medido."* | **os quatro Caminhos e as doze Trilhas de `caminhos/`, com o degrau novo do nível 23.** *O ponto de partida é o registro com preço da coleção anterior — os `DESENHO-*.md` e a peça 17 —, e quando a medição fechar o índice e os preços passam a ser os da v0.4. Das três pendências que a própria v0.4 registrou, duas fecharam na v0.280, na tabela `Pendências da v0.4 decididas` da peça 6 §2: o prazo e a abrangência do `Oportunista`, e a ordem, o custo e o arredondamento do `Contra a Parede`. A terceira, as conversões do nível 15 do Emanador, fechou na v0.281 sem frase nova* |
| 13 | **O Evocador fora da edição jogável, até o subsistema dele fechar** — *decisão dele na v0.270* | *"Bloqueie temporariamente Evocador e Invocações na edição jogável."* `invocacoes/` — *a candidata r5, com decisões até o §45, e o §46 (a zero PV, a invocação sai de campo), o §47 (o invocador apagado não derruba a sustentação), o §48 (quando ele morre, as entidades saem de campo) o §49 (cada entidade tem a própria ficha, e o limite é um teto de corpos), o §50 (uma básica por corpo por ciclo), o §51 (uma Bônus redireciona todas as entidades) o §52 (o que conta no limite de ataques) o §53 (a entidade só entra no turno do invocador) o §54 (e só é recolhida no turno dele) o §55 (aparece colada no invocador, e na troca no lugar de quem sai) o §56 (a entrada e a troca custam a Ação Bônus) o §57 (o recolhimento também) o §58 (as manifestadas antes da luta começam em campo) o §59 (a energia das especiais, fechado na v0.301) e o §60 (a meta do conjunto) o §61 (a vida da entidade) o §62 (o teto de base) o §63 (o limite de base) o §64 (a parte das entidades) o §65 (a ficha da entidade) o §66 (a Defesa dela) o §67 (o PE da entrada) o §68 (o que segue o nível da entidade) o §69 (o custo da especial) o §70 (a duração da manifestação) o §71 (a aquisição e o preço) o §72 (a recuperação da reserva) o §73 (a consequência duradoura da queda) o §74 (os vínculos que não recolhem), o §75 (o corpo `Desligada`), o §76 (a cura numa entidade) os §§77 a 84 (os cinco tipos) o §85 (o preço da volta da caída) o §86 (o destino depois da morte do invocador) o §87 (o efeito que repete numa `Desligada`), o §88 (a manutenção com o invocador apagado) os §§89 a 105 (o construtor da entidade) e os §§106 a 109 (o reparo e o resto da fila) em `invocacoes/DECISOES-A-PARTIR-DO-46.md`, da v0.275 à v0.325. O primeiro lote de desenvolvimento depois do §46, com a candidata na revisão 44, fica no HD, fora do repositório.* **O texto antigo mora em `invocacoes/museu/`**, *e a peça 15 e o validador dela continuam contra ele. A volta ao livro é decisão dele, e o `conferir-invocacoes.py` e o `conferir-catalogo.py` acendem se o capítulo ou o Caminho reaparecerem antes* |
| 14 | **A ficha do `Claude 3` com os Caminhos velhos, e o catálogo do gerador daqui** | **a ficha do repositório `Claude 3`**, *que é extraída do livro e ficou com as Trilhas antigas, o Evocador e o texto velho da Cesta e do Simples até a próxima extração;* **e o `dados.js` do gerador em `05-material/`**, *que ainda lista as quinze Trilhas antigas e o Evocador como catálogo.* **As duas fichas `.docx` daqui não imprimem essa lista** *— a da Kaori só mostra a Trilha dela, o `Muro` —, e a v0.271 regerou a da Kaori para o `Provocar`.* *O `conferir-ficha.py` confere o `dados.js` contra a peça 6, que guardou a lista antiga como registro — por isso ele segue verde e não acusa a defasagem. ⚠ A v0.270 escreveu aqui que a ficha deste repositório imprimia as Trilhas antigas, e não imprime* |
| 15 | ~~**As decisões que a v0.270 deixou para ele**~~ | ✅ **FECHADO na v0.271**, *com as respostas dele: a perícia fixa do Bastião é `Provocar`; a frase dos Limites volta com o Socorrista como exceção; ninguém cura outra pessoa com Energia Reversa; e os renomes `Eco Amaldiçoado`, `Impulso Energético` (só o recurso do Catalisador) e `Sobre Carregar Energia`, com `Condutor Armado`, `Condução` e `Segunda Leitura` mantidos e toda colisão da triagem aprovada — "se a triagem colidir, pode falar que tá aprovado".* **As doze Trilhas e os três nomes novos entraram nas listas do `conferir-nomes.py`.** *Os nomes de habilidade da v0.4 entram quando a peça 17 for refeita, com a medição do item 12* |
| 16 | ~~**Medir o `Calado` na redação da v0.176**~~ — *achado na v0.276, quando as cinco cópias foram alinhadas* | ✅ **FECHADO na v0.277:** *o `Calado` é de nicho — só cala o que precisa de voz, e o inimigo não ganha campo —, e o nível continua `Média`, porque em `Leve` ele daria `4,06×` contra o filtro de `3,00×`. O registro de antes fica abaixo.* a peça 19 §3.2 e o `conferir-dano.py`. *A régua cobra do alvo uma ação inteira, o que supõe que ele conjura com voz, gesto ou Selo de voz; contra quem conjura com Selo de condição e sem `Gesto`, o `Calado` não tira ação.* **Medir quanto o preço `Média` sobra nesse caso, e se o nível continua** |
| 17 | **O índice de entregas da coleção v0.4, sem preço** — *sobra do item 12, que fechou sem medir* | *A peça 17 e o índice do `conferir-catalogo.py` continuam os da coleção anterior, e os nomes de habilidade da v0.4 não estão nas listas do `conferir-nomes.py`: a v0.271 deixou os dois para quando a medição refizesse a peça 17.* **Sem medição, falta decidir se o índice passa a ser o da v0.4 só com nomes e níveis.** *Até lá, a triagem de nome novo do `conferir-nomes.py` não conhece as entregas da v0.4, e a peça 6 evita escrever `Forma` na frente de um nome que não é Forma do Fundamento.* |
| 8 | ~~**Rever os inimigos, e o máximo de cada um**~~ — *levantado por ele na v0.242* | ✅ **FECHADO na v0.282, como a fase 2 do bestiário:** *a escada virou a grade — a categoria é a dificuldade da luta, feita para `×1` a `×6` pessoas, com a duração por degrau (`2 · 2,5 · 3 · 4 · 5`), as ações iguais ao N e o que o inimigo carrega pago na vida. As decisões e as contas estão em `bestiario/09-fase-2/`.* |
| 18 | **Sukuna na grade — integração concluída na v0.287** | Ficha, gerador e ensaio em `bestiario/05-sukuna/`. Débito de aptidões apenas da cota corrente disponível, aprovado por Mizuki. Sem dívida, restituição ou certificação de equilíbrio de mesa. |
| 19 | **Divergências da auditoria da fase 2** | O Evocador foi retirado da média na v0.285, por decisão expressa. A resistência a até dois tipos fixos no total foi aprovada na v0.286: não desconta PV; grupos completos seguem cobrados, e imunidades não mudam. A integração do Sukuna fechou no item 18, v0.287. A lacuna de três ou mais tipos mistos sem completar grupo foi registrada, sem preço inventado. |
| ~~20~~ | ~~**O Corpo Amaldiçoado não se cura por energia amaldiçoada**~~ | **Fechada na v0.326, pelo Mizuki: "A, mas n coloque nenhuma regra que diga sobre a questão dele n ser curado em combate, uma técnica poderia por exemplo, ser focada na narrativa de engenharia".** *A peça 9 §5 e o capítulo das Origens ganharam a linha da cura: a `Energia Reversa`, e o que monta nela, não cura o Corpo Amaldiçoado, e quem o conserta é o reparo — no descanso curto, `Entalhador` ou `Forja`, teste de ofício na escada que acompanha, metade da vida máxima —, o mesmo do corpo amaldiçoado das Invocações (§108). Nada proíbe outra cura: uma técnica cuja Regra alcance um corpo feito cura ele. A peça 10 e o capítulo do descanso apontam a exceção.* |
| ~~21~~ | ~~**O sistema não tem regra de peso**~~ | **Fechada na v0.327 — e a premissa estava errada:** *o sistema tem peso desde a v0.256, na peça 14 §6.6, com o limite de `5 + Força` em `Volume`; faltava só o talismã.* **Pelo Mizuki: "mas pode por o talismã como meio mesmo"**, *e o talismã guardado pesa `0,5` (Invocações §110).* **E a conta achou um buraco:** *dez leves faziam `1` arredondando para baixo, e nove pesavam zero — "fica como exploit pegar itens que valem menos que 1". Cada leve passou a valer `0,1`, sem arredondar.* |

**✅ As vinte divergências entre o manual e o livro fecharam na v0.227**, com o `Armado` redesenhado e a vida máxima tirada do dano de alma nos lugares que a v0.176 não alcançou. **As duas perguntas que ela deixou fecharam na v0.228:** *a Integridade do inimigo é metade da vida máxima, e o `Armado` não aceita gatilho no turno de quem armou.* **E a v0.229 deu ao inimigo a Expansão sem Barreiras**, *com os gates do jogador e o mesmo `1,92`, e remontou o Sukuna no nível 30.* **A v0.230 refez a `Recarga` de inimigo** — *ela ocupa as ações múltiplas e tira `2,5` golpes de cada alvo, medido contra três sistemas —, e fechou o bloco do Sukuna, que exige `21,0` pessoas.* **A v0.231 deu `18 m` ao `Artilheiro`, trocou a Amplificação de Domínio do Sukuna pela `Extensão de Domínio` da peça 11 e deu `180` de vida ao braço dele** — *e a v0.232 deu ao inimigo atributo no ritmo do `meio a meio` — `20` pontos no nível 30, em vez de `16` —, e a v0.233 fez o chefe começar com dez pontos na criação, com o Sukuna em Força `3` · Constituição `4` · Inteligência `2`.* **A v0.234 pôs nas prontas a Destreza que a Defesa pede, com o `±2` do papel entrando na Defesa por fora, e o capítulo 8 do livro do Bestiário voltou a bater com o gerador** — *ele tinha parado antes dos papéis, e a `9.5` agora roda os scripts do livro.* **A v0.235 fechou os três achados dela:** *o capítulo 6 ganhou a coluna do `Controlador` e do `Reforço`, a Hitotsume virou `Emboscador`, e cada pronta declara com que atributo ataca e onde entra cada ponto de marco.* **A v0.236 instalou as faces que faltavam do IBM Plex Mono**, *e os quatro PDFs dos dois livros saíram sem DejaVu.* **A v0.237 pôs a capa no Bestiário e deixou a caixa longa quebrar entre páginas**, *e a coluna única da Guilda foi de `259` para `254` páginas, com três curtas em vez de doze.* **A v0.238 fechou o `B18` no repositório da ficha.** *A lista é a oitava passada do `sistema/05-material/livro/ESTADO-revisao.md`, e a checagem `12` a lê — ela imprime a contagem dos três estados a cada rodada, então conte pela saída dela e não por esta linha.*

> ## ✅ O `papel` do inimigo ATRAVESSOU na v0.224
>
> **Os seis entraram no §3.4 da peça 26, com a checagem `10` em cima e vinte e uma perturbações.** *`Brutamontes` · `Baluarte` · `Artilheiro` · `Emboscador` · `Controlador` · `Reforço`.* **A regra é uma só: o que o papel paga é o inverso do que ele ganha, e o produto fecha em `1,000`.**
>
> **Dois nomes mudaram na triagem** — *`Apoio` era Forma no manual e virou `Reforço`; `Guardião` tinha a raiz de `Guarda`, que já morrera por ser Melhoria, e virou `Baluarte`.*
>
> **E as seis prontas ganharam papel com o número mudando junto**, *por martelo dele.* **Isso fechou a dívida do `Fogo-de-Raposa` que a v0.221 deixou aberta:** *a `Kitsune` passou a pagar vida pelo alcance que tinha de graça.*
>
> ⚠ **`Baluarte` e `Reforço` estreiam sem exemplo montado**, *porque nenhuma das seis lê como defensor ou como quem ajuda outro bloco.* **É preço declarado, e não pendência.**

> ~~**⚠ E uma dívida de antes continua aberta:** *a coincidência dos `256` entre o PDF de coluna única e o `-A-atual`* — **e agora ela tem uma variável a menos, porque os dois artefatos usam fontes diferentes.**~~ ***FECHADA na v0.236:*** *com as fontes certas nos dois, os marcadores do PDF mostram dois capítulos a mais, um a menos e dezesseis de vinte e três com outro tamanho. Os `256` eram soma que se compensava, e hoje a coluna única tem `259`.* *A outra — a `Sobrecarga` escrevendo "o dobro de energia" — fechou na v0.221: o texto virou "ele não usa Reação", o degrau ficou `Leve` nos dois donos, e a checagem `5` do `conferir-acao.py` passou a proibir a frase nela também.*

---

## Onde estamos, e o que falta


A ordem de construção é a da seção 6 do `arquitetura.md`, e ela **acabou** — os seis passos estão fechados.

| # | peça | estado |
|---|---|---|
| 1 | De onde vem o número, e defesa | **fechado** (peças 1 e 2) |
| 2 | Economia de ação e iniciativa | **fechado** (peça 3) |
| 3 | Teste fora de combate | **fechado** (peças 4 e 7) |
| 4 | Caminho e combate sem feitiço | **fechado** (peças 5 e 6) |
| 5 | Criação de personagem | **fechado** (peça 8) |
| 6 | Descanso e progressão fora de feitiço | **fechado** (peças 10 e 12) — descanso na v0.23, progressão na v0.31 e v0.32 |

O que falta agora, na ordem em que travam umas às outras:

**A ordem foi decidida simulando uma campanha que começa amanhã**, e não por tamanho de peça. Cada linha é o momento em que o jogo trava:

| # | peça | quando ela trava o jogo |
|---|---|---|
| ~~1~~ | ~~Descanso e recuperação~~ | **fechada na v0.23** (peça 10) |
| ~~2~~ | ~~Aptidões e degraus de refino~~ | **fechada na v0.27** (peça 11), e as quatro anti-domínio na v0.29 |
| ~~3~~ | ~~Tabela de XP~~ | **fechada na v0.31 e v0.32** (peça 12) — era a trava nº 1 de mundo compartilhado |
| ~~4~~ | ~~**Trilhas com número**~~ | **fechada na v0.164** — as três do Evocador foram as últimas. *A dúvida do Guia contra a Vanguarda já tinha fechado na v0.61* |
| ~~5~~ | ~~**Equipamento**~~ | **fechada na v0.48** (peça 14) — a proteção ganhou número, e o teto de Defesa ganhou dono derivado |

> **Mas a fila mudou de natureza na v0.32, e vale ler isto antes de pegar a próxima peça.**
>
> **Não existe mais peça de regra bloqueando alguém de jogar.** Uma missão de nível 2 roda inteira: cria, joga, recupera, sobe de nível. As duas acima travam a **segunda sessão** e a **primeira subida**, não a primeira mesa.
>
> O que falta para alguém sentar na mesa não é regra — é **material**: as peças são argumento de design e não texto de mesa. **`04-playtest/` está vazia desde a v0.1, e todo número do sistema continua sendo previsão.**
>
> A rota decidida com o Mizuki foi: v7.7 → anti-domínio → XP → **validação e polimento** → ficha e quick-start. *Os quatro primeiros saíram, o polimento foi a v0.33 e a **ficha saiu na v0.35** — `05-material/` não está mais vazia.* **O quick-start foi abandonado como arquivo na v0.102, e o último degrau desta rota virou o PDF — que saiu na v0.106, com o quick-start escrito direto nele.**

## A fila decidida com o Mizuki na v0.36

Quatro peças, e a ordem é de **dependência**, não de tamanho. A ordem que ele levantou era Legados → Caminhos → Itens → Invocações; a peça de Caminhos foi para o fim porque **duas das cinco árvores dependem das outras duas peças**.

| # | peça | destrava | depende de |
|---|---|---|---|
| ~~1~~ | ~~**Legados** — a régua de magnitude, e ~5 por Origem~~ | **fechada na v0.39** (peça 13): régua, catálogo de **81 entradas** e o `conferir-legados.py` | — |
| ~~2~~ | ~~**Equipamento** — armas, escudos, uniformes~~ | **fechada na v0.48** (peça 14): as 52 armas com orçamento fechado, proteção, escudo, treino e requisito de Força, mais o `conferir-equipamento.py` com quinze checagens | — |
| ~~3~~ | ~~**Invocações** — o sistema de criação~~ | **fechada na v0.58** (peça 15), com o `conferir-invocacoes.py`, que hoje tem trinta e quatro checagens | — |
| 4 | **Caminho, Trilhas e subtrilhas** — a árvore de cada um | o resto | **2 e 3** |

### A fila foi reordenada na v0.50, e as duas peças novas ganharam posição

*Decisão do Mizuki: "Invocações agora, ferramenta entre ela e a Trilha."* As duas que a v0.49 destampou entram assim:

| # | peça | por que aqui | move o contador? |
|---|---|---|---|
| ~~1~~ | ~~**Invocações**~~ | **fechada na v0.58** (peça 15), com o `conferir-invocacoes.py`, que hoje tem trinta e quatro checagens | rotas 6/9 → 6/9 · vagas 0 de 7 |
| ~~2~~ | ~~**Ferramenta amaldiçoada**~~ | **fechada na v0.59** (peça 16): a máquina e o catálogo saíram na v0.55 e na v0.56, e o `conferir-ferramenta.py` tem **dezenove** checagens | **rotas 6/9 → 8/9** · vagas 3 de 7 |
| ~~1~~ | ~~**Trilhas**~~ | **fechadas na v0.164**, com as três do Evocador | tocou **100% das fichas** |
| ~~2~~ | ~~**Objeto amaldiçoado**~~ | **fechada na v0.132** (peça 21), com o `conferir-objeto.py` e doze checagens | rotas 8/9 → 8/9 · **fechou a vaga de `Desliga` do Reencarnado** |

> **✔ A DUAS RESPOSTAS ACABOU NA v0.103.** *Esta fila dizia `Trilhas`; a peça 16 §9 dizia que a `Técnica Marcial` **é a peça seguinte**.* ***Decisão do Mizuki: são as três Trilhas do Evocador** — `Servo`, `Matilha` e `Coro`.* **A peça 16 foi corrigida junto**, e ela deixou de nomear a Técnica Marcial como a seguinte.
>
> ***As três entraram na v0.164***, depois de trinta e duas versões paradas. *Elas fecham as quinze Trilhas e tiram o Evocador de ser o único Caminho sem Trilha com número.* **O total da peça 17 foi de `90` para `102`, e a checagem 1 do `conferir-catalogo.py` acusou no mesmo commit — que é para o que ela existe.**
>
> **A fila da mecânica ficou SEM ITEM.** *O que sobrava eram duas peças que este arquivo já nomeava em outras seções: a criação própria de `Sem Técnica` e o `Bestiário`.* **A primeira fechou na v0.168 e é a peça 25, e o `Bestiário` fechou na v0.198 e é a peça 26.** *A decisão da v0.161 foi obedecida — máquina, e não recolhimento puro —, e o que sobra dela é o catálogo de maldições prontas.* **A fila da mecânica não tem mais item de regra.**

> **As posições 2 e 3 ganharam rascunho na v0.54**, e os dois têm o mesmo formato do de Invocações — perguntas em ordem de dependência, com o que a conta já fecha separado do que é sabor.
>
> **E a v0.55 fechou a máquina de ferramenta e duas perguntas de Trilhas.** A ferramenta é **uma das 52 armas mais UM `Estigma`**, e o grau decide o **formato** dele — grau 4 não dá Estigma nenhum e só fere maldição, grau 3 dá Classe 1, grau 2 dá Classe 2 com gate de nível 7, grau 1 dá Classe 3 com gate de nível 13, e a especial é Classe 3 e **única no mundo**. **O gate é o da peça 11 §6 sem a metade de refino**, porque cobrar refino trancaria a peça na cara da Restrição Celestial que não tem energia. O **`Desgaste`** compra o gate e nunca a Classe, e a ficha topa em **três `Estigmas`**, que é 43% do orçamento de escolha de marco da campanha. *Falta o catálogo e o validador.* **Em Trilhas:** sem multiclasse (uma Trilha por ficha, o que fecha a pendência nº 3 desta lista) e **as subtrilhas cruzam Trilhas do mesmo Caminho**.
>
> **`03-mecanica/16-ferramenta-amaldicoada.md`** *(era rascunho até a v0.59)*. A conta fechou três coisas antes de qualquer pergunta: **grau não pode ser mais ponto de arma** (no nv30, dobrar o orçamento de uma arma de duas mãos vale `1,5%` da Rotina contra os `6%` a `9%` de uma Trilha inteira); **a ferramenta não é o que faz o sem-energia competir em dano** (a arma comum é 96% da Rotina no nv2 e 12% no nv30 — fechar isso pediria 95 de dano por rodada, que é o Fundamento e não um item), então **ela entrega ferir maldição, que é binário**, e o dano é da Técnica Marcial; e **grau como gate de patente está refutado pela peça 12**, porque *"Grau é reconhecimento; nível é poder"* e a espiral fechada é a mesma. *E o cubo que prendeu o Gojo é **objeto** amaldiçoado, não ferramenta — a fonte é explícita, e ele é da peça que a v0.50 pôs em último.*
>
> **`03-mecanica/RASCUNHO-trilhas.md`.** O achado que decide o formato: **catorze dos vinte e nove níveis não entregam nada hoje, e são todos os ímpares** — os feitiços conhecidos cobrem todo nível par, e maestria e marcos caem em cima de níveis que já tinham feitiço. **A Trilha tem onde cair sem competir com nada.** E o risco real da peça é escala: **quinze Trilhas × quantas entregas** dá de 30 a 120 entradas, contra as 81 que a peça 13 fechou em uma versão e as 52 armas que custaram **seis** à peça 14. *A diferença entre as duas foi a régua vir antes do catálogo, e é a única recomendação de método que aquele documento faz.*

**Só a posição 3 contra 2 era escolha. As outras três a conta fechou sozinha:**

- **Invocações antes de Trilhas** não é preferência: `Servo`, `Matilha` e `Coro` **são** o sistema de invocação visto de dentro. As outras doze Trilhas já estão desbloqueadas desde que Equipamento fechou — era a Vanguarda que dependia dela.
- **Ferramenta antes de Técnica Marcial** está escrito na peça 5 §3: a Maki *"só compete porque a ferramenta amaldiçoada carrega a energia por ela"*. Técnica Marcial escrita antes produz rota que não fere maldição.
- **Objeto amaldiçoado por último**, e é o contrário do que a v0.49 fazia parecer. Ele foi o achado daquela versão, mas **Receptáculo e Reencarnado já rodam hoje** — os dois vão para o Fundamento. Ele fecha **1 vaga de Desliga e mais nada.** *Buraco de vocabulário real não é o mesmo que buraco que trava alguém.*

**Invocações fechou na v0.58 e é a peça 15**, em `03-mecanica/15-invocacoes.md`, com o `conferir-invocacoes.py` em cima dela. O §5 daquela peça é a especificação das trinta e quatro checagens, e ele foi escrito **antes** do validador — que é por que ele coube numa versão só, contra as seis que a peça 14 gastou.

> **A peça fechou na v0.58, e o argumento inteiro mora nela — não aqui.** A Q1 (iniciativa) no §3.1, a Q2 (cinco fichas ou uma) no §3.2, a Q3 (a ficha) no §3.3 e no §3.6, a Q4 (o custo) no §3.4, a Q5 (a morte e o retorno) no §3.5, o catálogo e a régua de criação no §3.7, e a especificação das trinta e duas checagens no §5. *Este ponteiro existe para quem retomar não recomeçar: as decisões têm um dono só, e é lá.*
>
> **A máquina, em seis linhas:** a invocação age **na casa do dono**; a Matilha é **uma ficha com cinco corpos**, pool com cascata, rodada resolvida **em pool**; a ficha é **dela** — os cinco atributos no orçamento da peça 2, e a maestria do dono em toda rolagem —, com `Traço` e `Comando` comprados num orçamento de **8 a 36** pontos; invocar custa **`1 × maior Classe` e a ação padrão**, e **comandar custa a ação padrão**; ela **some no zero**, é **vulnerável a área** e **morre em definitivo** se o excedente passar de metade da régua ou um golpe causar a régua inteira, sendo a régua `5 ×` a vida da fórmula para qualquer corpo — e quem só chegou a zero volta com **metade da vida**; e **a amarra são 18 metros**, lidos do alcance base de Projétil.
>
> **A Q6 fechou na v0.63**, e ela nunca foi desta peça: `Servo`, `Matilha` e `Coro` são Trilhas. **O `Servo` estava dominado por falta de eixo** — empatava em saída e perdia ou empatava em corpos e ação —, então não existia número que o consertasse dentro dos três. *O conserto era uma coluna nova na matriz.* **A concessão: o corpo do `Servo` leva `5 × h` de vida — o pool inteiro da `Matilha` num corpo só — e o orçamento da ficha mais metade.** A tabela está no fim do §3.7 daquela peça, e o `DOMINANCIA_PENDENTE_Q6` do validador foi a **conjunto vazio**.
>
> **A vida não entra por dominância, e por isso ela tem checagem própria.** Só o orçamento já zera a matriz; tirar o `5h` sairia **verde** e desfaria em silêncio a metade da pergunta que a matriz não mede — a de *"perder o corpo acaba o kit"*. *É a lição nº 8 por outra porta: uma checagem que se mede pelo eixo errado sai verde na perturbação que importa.*
>
> ~~**O que a peça ainda deixa pendurado são duas regras, e as duas apareceram na v0.67 por tropeço.**~~ ***AS DUAS FECHARAM na v0.163***, e nenhuma era a decisão que parecia ser: **a vida cheia volta no descanso longo, DERIVADO da peça 10 §3** — respiro não devolve vida —, e **a queda do dono estava respondida em três quartos**, com o `Insistir` caindo da regra e a invocação agir sozinha caindo da conta. *Com elas, as entregas de Trilha do Evocador voltam a ter contra o que ser medidas.*
>
> **E a v0.68 achou que a escala da v0.67 não tinha chegado inteira.** A venda de deslocamento ficou devolvendo `1` enquanto catálogo e orçamento iam para `×4`, **e a tabela do orçamento do `Servo` estava com o cabeçalho numa escala e as colunas na outra.** Ao todo foram seis linhas. **A devolução virou `4`**, a tabela do `Servo` passou a ser derivada, e as checagens 8, 9 e 10 ganharam a metade que faltava — o tamanho da devolução, o resumo do topo contra a tabela dona, a tabela do `Servo` contra os marcos, e a razão entre as duas moedas recalculada em vez de aceita.
>
> **E o arredondamento do `Servo` virou letra morta:** na escala nova todo orçamento é múltiplo de `4`, então *"mais metade"* sempre fecha redondo e ele ficou com `2` pontos a mais nos níveis 6, 14, 22 e 30. *A regra global da peça 1 continua valendo — ela só deixou de ter o que raspar aqui.*
>
> **E o buraco que ela achou na peça 6 continua aberto, porque é de playtest e não de conta:** a regra da seção 4 preça o **dano** da Matilha e não preça o **tempo de mesa** dela. Cinco corpos agindo por rodada custam o mesmo tempo quer cada um faça 25 de dano ou 5 — e foi por essa metade, não pela do dano, que o 5e 2024 trocou a família inteira de `conjure`. O conserto que a peça achou é de gesto e não de regra: **rolar em pool** corta de sete gestos e meio por rodada para três. **O número esperado está escrito no §3.2 antes da sessão** — a Matilha custa `2,5×` um personagem de nível 6 —, e a checagem 4 confere que ele continua batendo com a tabela dele mesmo.

> ~~**A dívida que a peça 13 marcou continua aberta, e agora ela é dupla.**~~ **Paga na v0.104.** *A peça 13 fechava dizendo "quando equipamento fechar, a primeira coisa a fazer é voltar aqui", e ninguém voltou nem quando a 14 fechou na v0.48 nem quando a 19 fechou na v0.103.* **As cinco vagas destravadas foram escritas**, e o que faltava não era trabalho: era a trava do `Desliga`, que proibia encostar em qualquer coisa com preço e por isso não deixava nenhuma delas nascer. *Decisão registrada não é decisão aplicada — e às vezes o que impede a aplicação é outra decisão.*

### Onde Equipamento parou, na v0.42

**Fechado:** duas classes de uniforme (`Traje` e `Revestimento`) com **escadas de Força separadas** — Traje `— / — / 3`, Revestimento `3 / 4 / 6`; a **escada de escudos** com proteção, requisito de Força e teto de Destreza; **treze categorias e 52 armas**; **as oito propriedades escritas**; o dado do tiro e a recarga; e a régua de **itens comuns** em três camadas, com a terceira desligada.

**O teto de Defesa ganhou dono, e não é o que o rascunho supunha.** O `20` é **derivado** de `10` (peça 1 §5) + teto de atributo `6` e teto de refino `10` (peça 2 §3) + a fórmula de cobrir-se (peça 11 §5) — zero parâmetros livres. **Ninguém escreve o número:** Equipamento é dona do **invariante** (*nenhuma montagem de equipamento passa da Defesa que a rota sem equipamento alcança*), e o validador deriva o teto dos três donos. **Equipamento topa em 19**, por decisão, e não em 20.

**Quatro coisas caíram nesta versão:** o §3 dizia que as duas rotas topam em 20 (dá 19, desde que o escudo ganhou teto de Destreza); o Traje era a classe do meio do 5e contra **cobrir-se**, que é a armadura leve deste sistema e ninguém tinha reconhecido; a peça 6 §3 **não tem exceção para arma de tiro**, o que fazia a arma acertar com Destreza e causar dano com Força — 5× o buraco que as propriedades deviam pagar; e o `0,60` do §5 não reproduz com a fórmula do §4, que dá `0,33`.

**A dívida da peça 11 e da peça 8 foi APLICADA:** o escudo **soma** com cobrir-se em vez de desligar, e o preço da Reação virou agnóstico de fonte. Três checagens novas no `conferir-criacao.py` guardam as duas.

### E o que a v0.44 fez com ela — a régua de preço mudou

**A pergunta *"o preço mora na classe ou na arma?"* foi respondida, e a resposta é a arma.** O motivo não foi de gosto: a escada de dados do §5.2 já punha **dois dados dentro da mesma classe** (Pistola `2d8` e Submetralhadora `3d6`, as duas em `Tiro leve`), então o catálogo praticava **9 pacotes de preço para 8 classes** desde a v0.42.

> **1 ponto = `0,33` por rodada = um passo de dado = uma propriedade.** Orçamento: **`2` numa mão, `4` em duas.**

Ele saiu por **regressão contra as seis classes publicadas**, e cinco fecham exatas. A sexta é a `Versátil`, que estourava em 1 — **a dominância que a v0.41 tinha achado e não sabia dimensionar.** A régua inteira cabe numa tabela de teto de dado por número de propriedades, no molde do PF2e, e o teto da `Fineza` (d6 numa mão) cai dela sozinho.

**Fecharam junto:** a escada do tiro (`3d10` → **`2d10`** no topo, porque o `3d10` gastava 9,0 num orçamento de 4 e estourava em 11 pontos na mão de um Força 0); o X da `Munição` em `2 · 3 · 4`, depois que o `X=1` foi flagrado **apagando o ataque extra**; e a `Versátil` a **custo zero**, que fecha a dominância de três versões com tamanho (0,1 ponto, só no nv2).

### A v0.45 inverteu a régua, e o efeito de crítico morreu

**O dado passou a ser ENTRADA e o número de vagas passou a ser SAÍDA** — a ficção diz o tamanho da arma e a conta diz quantas propriedades ela carrega. **Fundo `3` numa mão e `5` em duas**, e o teto de dado não se moveu. Como gastar menos que o orçamento é dominância estrita, **toda arma é obrigada a encher as vagas**: identidade deixou de ser opcional e virou construção.

**A restrição devolve `1` ponto** — `Volumosa`, `Embainhada`, `Comprida` —, que é a metade do *"a arma dá acesso e restrição"* que nunca tinha sido implementada. Usada por **3 das 41** (7%).

> **O efeito de crítico da categoria MORREU, e os treze nunca foram escritos.** *Achado do Mizuki:* **"ninguém lembra do efeito de crítico na hora de aplicar."** A conta confirmou — **0,44 disparo por combate na mesa inteira de quatro**, e um jogador vê o efeito da arma dele a cada 9 combates. E a causa embaixo era pior: na régua velha, a arma que a ficção põe no teto de dado tinha **zero vagas de propriedade**, então ter identidade *era* descer o dado. Com o fundo, as propriedades carregam a identidade sozinhas: **39 assinaturas para 41 armas**, contra as 14 que o preço sozinho dava.

**As 52 armas têm dado e propriedades** (§5.3), com zero estourando o orçamento e zero com vaga vazia. As duas gêmeas que sobraram são `Machete = Machado` e `Soqueira = Tekko`, que são a mesma coisa na ficção.

### A v0.47 fechou as duas decisões de acesso

**A divisão simples/marcial** (§5.4.1) e **o requisito de Força** (§5.5). As duas resolvem acesso por eixos diferentes — uma separa por **Caminho**, a outra por **atributo** —, e nenhuma pode ser preço: toda arma já fecha no mesmo fundo.

> **Simples — 24 armas:** `Lâmina Curta` · `Porrete` · `Ceifa` · `Arremesso` · `Manopla` · `Massa`, mais a `Balestra`.
> **Marciais — 17:** `Lâmina Longa` · `Machado` · `Armas Longas` · `Flexível`, mais o `Yumi`.
> **De fogo:** `Arma de Fogo`, sozinha. Ferramenta amaldiçoada fica fora desta peça.
>
> **Requisito `Força 3` nos dois degraus de cima de cada escada:** `d10` e `d12` no corpo a corpo (11 armas), `2d8` e `2d10` no tiro (6). Ele lê o **dado impresso** — o passo do `Versátil` não conta, senão ele pega a Katana, que tem `Fineza`.

**Busca exaustiva dos 1024 cortes possíveis: 543 passam nas quatro travas de conta**, e o que fecha é cruzar com a âncora do 5e 2024. **A trava que a v0.45 achou que era estrutural não é:** o `d8` de uma mão e o `d12` de duas moram nas mesmas três categorias — `Lâmina Longa`, `Massa` e `Machado` —, e qualquer corte que ponha as três no marcial deixa o balde simples **1,0 dado atrás nas duas mãos**, que é o modo de falha do 5e que aquela versão diz ser impossível.

**E os dois gates se multiplicam em vez de somar.** Sob o requisito de Força sobram **duas** armas de duas mãos sem requisito — Kusarigama e Corrente —, então uma das duas categorias delas tem de ser simples, ou o Caminho não-marcial de Força baixa fica **sem a economia de duas mãos inteira**. Nenhum dos dois gates faz isso sozinho.

**O gate no tiro fecha um buraco que o do corpo a corpo não alcança:** sem ele, um conjurador de Força 0 e Destreza 0 pega o Rifle de Precisão e faz **11,0 sem investir um ponto de atributo**, contra 6,5 do melhor corpo a corpo dele.

~~**O que falta:** a **penalidade** por empunhar sem treino ou sem requisito, que é da peça 19.~~ ***FECHADA na v0.104 e na v0.117, na peça 19 §6:*** **sem treino, desvantagem na rolagem de ataque e a maestria fora dela; sem o requisito de Força, `−3 m` de deslocamento.** *As duas somadas custam `33,8` vezes o que a arma inteira entrega — é porta fechada, e não preço —, com a checagem 11 do `conferir-dano.py` em cima.* **Os nomes dos degraus de escudo fecharam na v0.59:** `Broquel` (punho, 15–45 cm), `Médio` e `Torre` (cobre o corpo, se planta no chão). *O `Médio` carrega duas colisões aceitas e declaradas na peça 14 — uma letra de `Medo` (Tema) e o gênero do tier de Restrição `Média`.*

> **Esta lista tinha mais dois itens até a v0.59, e os dois já estavam prontos.** O **`conferir-equipamento.py`** entrou na **v0.48**, com a dominância rodando uma vez por rota de proteção — cobrir-se, uniforme e sem energia nenhuma, as três. E **os dois dados do `Yumi`** foram corrigidos na **v0.47**, na mesma versão que flagrou: `Daikyū` para `1d10`, `Hankyū` para `1d8`, fechando exatos em `4 de 4`. *Vencido em dois documentos ao mesmo tempo, porque a lista foi copiada em vez de apontada.*


### ~~Bloquear — a regra opcional que a v0.43 escreveu~~ **FECHOU na v0.143, e é a peça 23**

***Decisão do Mizuki:*** *"Bloqueio pode ligar, é uma mecânica que o jogador pode TOMAR, na hora que for receber um ataque, é uma mecânica real, não uma opcional."* **O rascunho foi para `99-arquivo/` e virou `03-mecanica/23-bloquear.md`, com o `conferir-bloquear.py` — **oito checagens** hoje.** *O desenho não mudou uma linha — o que mudou foi o estatuto.*

> **⚠⚠ E o parágrafo que fechava esta seção dizia o CONTRÁRIO, com todas as letras:** *"o validador dela não pode ser arquivo novo… um `conferir-*.py` novo quebraria a contagem de treze por treze, e Bloquear não é peça."* **Ele foi escrito quando existiam treze peças, e a decisão do Mizuki o revoga.** *Fica registrado porque quem retomasse a tarefa sem ler até aqui seria contradito pelo próprio documento de retomada.*

**O que a v0.143 mediu, e nada disso estava previsto:**

> **A dívida da `Talha` foi paga, e ela ficou aberta noventa e oito versões.** *A propriedade de arma custa `1` ponto e dá `−1` no Bloquear de quem se defende; a peça 14 registrava desde a v0.45 que numa mesa sem Bloquear ela valia zero.* **As nove armas que a carregam passam a receber o que compraram** — e o bilhete velho contava `sete`, com nove no catálogo desde alguma versão que ninguém acompanhou. *O capítulo 13 do livro já publicava `nove`.*
>
> **O preço do `Incapacitado` NÃO se move, e o motivo novo é melhor que o antigo.** *A peça 19 justificava o zero da metade do Bloquear dizendo que a regra era opcional.* **O motivo verdadeiro é que o Bloquear é neutro por construção:** *tirar de alguém uma rolagem cuja média é exatamente o número que ela substitui não tira nada.* **Medido em `+0,02` de dano por rodada, contra um teto de `Leve` com folga de sobra.** *A peça 19 aponta para a 23 em vez de repetir a conta, e a checagem 1 da 23 é a única do projeto que existe para sustentar um número de outra peça.*
>
> **E o item que ficava "em aberto" há cem versões não precisava ser escrito.** *"Quais condições impedem Bloquear" — o rascunho chamava isso de "a única peça do desenho que ainda não tem forma".* **Só o `Incapacitado`, porque ele é a condição cujo eixo *é* a defesa — e a peça 19 §3.4 já tinha decidido isso por outro caminho, quando separou `Atordoado` de `Incapacitado`.** *Acrescentar uma segunda repreçaria uma condição com número publicado.*
>
> **⚠⚠ E o validador achou dois erros de aritmética que estavam no rascunho desde a v0.43.** *A "folga do nível 22" era `9,00 − 6,88 = 2,12` e estava publicada como `3,86` — dois números com o mesmo nome, sendo o segundo o teto do bônus em dano cru. E o líquido do pacote supunha `1%` para os dois extremos, quando a própria trava do `20` natural faz o `Aparar` valer `0,95%` e a `Brecha` `1,00%`.* **A conclusão nunca esteve errada — `+3` continua sendo o maior bônus que cabe.** *O que estava errado era a conta escrita ao lado dela, e ela sobreviveu cem versões porque ninguém tinha um validador que subtraísse.*
>
> **⚠ E o levantamento do GURPS estava errado em três pontos**, porque tinha sido escrito de memória de busca. *Lido no manual da 4ª edição:* **só o bloqueio tem teto por turno; aparar tem penalidade cumulativa de `−4`; a defesa ativa é paga por manobra e não é de graça; e a frase que o rascunho publicava entre aspas não existe no capítulo de combate.** *Em compensação, o mesmo manual entregou o precedente da linha de ficha:* **"os valores das defesas ativas devem ser calculados previamente e registrados na planilha de personagem."**

*A Defesa continua sendo `10 + Destreza + proteção`, e a peça 1 continua dona dela.* **A regra é publicada no capítulo 1 do livro, colada na Defesa** — decisão do Mizuki, e o apêndice que era o capítulo 18 deixou de existir.

**O que continua em aberto são duas coisas, e as duas são de mesa:** *o gatilho de playtest que libera subir o `+3` se a decisão do nível 22 nunca aparecer na mesa, e quanto tempo de mesa a rolagem a mais custa de verdade.* **A Reação na ficha de inimigo FECHOU na v0.159**, na seção `Inimigos` do manual — *e a `Brecha` passou a valer contra inimigo.* **A linha `Defesa 17 · Bloquear 2d10+6` saiu de "em aberto": ela é obrigação da ficha, e o `conferir-ficha.py` é quem confere.**

### Decidido — o Caminho continua sem dar dados de dano

*A regra da peça 5 §4 foi desafiada e confirmada.* Três das cinco árvores propostas pediam dado de dano — a tabela de desarmado do Bastião, a mecânica de arma da Vanguarda e o atributo somado no dano do Emanador. **A regra fica, e as árvores se desenham dentro dela.**

O motivo é o pilar 1, e está escrito na peça 5: *"se o Caminho desse dano, dois personagens do mesmo Caminho começariam a se parecer, e a técnica que cada um escreveu perderia espaço."* O que sobra para o Caminho conceder é a lista permitida — posicionamento, alvo, duração, recuperação, troca do fixo do acerto por atributo, e exceção estreita e paga na economia de ação.

### O que sobrevive de cada proposta, e o que não

| Caminho | o que passa | o que não passa, e por quê |
|---|---|---|
| **Guia** | **tudo.** Auxílio, estender, reposicionar e recuperar são literalmente a lista do permitido. E fecha a pergunta aberta desde a v0.24: *o que Elo, Sutura e Perímetro valem contra um golpe por rodada* | — |
| **Bastião** | socar como ação bônus (*"exceção estreita e paga na economia de ação"*); agarrar, prender e forçar reposicionamento | **a tabela de desarmado tipo monge** é dado de dano. O dado do soco é **equipamento**, e o Caminho mexe no que se faz com ele |
| **Vanguarda** | o que se **faz** com a arma: alcance, reposicionamento forçado, troca de alvo, exceção na economia de ação. Proezas passivas, se não forem dado | **o dado de cada arma é equipamento**, não Caminho. Por isso ela vem depois da peça 2 |
| **Emanador** | **metade já existe:** a peça 6 §5 concede *trocar o fixo de 2 do acerto de conjuração por Inteligência ou Essência*. Isso é acerto, e é neutro porque os dois lados crescem +3 | **somar atributo no dano do feitiço.** Ele quebra a paridade conjurador‑guerreiro, que está calibrada em `d20 + 3` nos dois desde o nível 2 |
| **Evocador** | benefício que não seja ação nem dano | depende da peça 3. E a trava é dura: *você e todas as suas invocações somados entregam **uma** Rotina* — mais corpos agindo por rodada é o que quebra todo sistema d20 |

**Duas coisas para medir antes de escrever, e as quinze Trilhas já foram escritas:**

- **A reação de RD do Bastião encosta em cobrir-se de energia**, que já dá RD de `1,5 × refino` por 2 PE. *Ou uma delas domina a outra, ou são a mesma peça com dois nomes.* **A medida NÃO foi rodada, e as três Trilhas do Bastião foram escritas e preçadas sem ela** — *a matriz delas já estava fechada na v0.76.* *O `Absorver` do Caminho custa `1,60` fatia e o `Alicerce` do `Muro` custa `1,33`, os dois preçados contra a régua de Trilha e nenhum contra a Reação da aptidão.* **Ela deixou de ser "antes de escrever" e virou dívida de conta**, e o que ela pode mover é preço de Caminho, não texto de mesa.
- ~~**Os *pontos de feitiço* do Emanador são moeda nova ao lado do PE.**~~ ***FECHADO na v0.131, e sem objeto:*** **a `Torrente` cobra em PE, no preço que o manual já dá para a Melhoria `Rápido`** — `Classe e meia`, arredondando para cima. *A pendência dizia que "uma lista de pontos à parte é o modelo mais provável", e não existe lista de pontos à parte nem moeda nova.* **A peça 6 §9 é a dona do fecho, e ela nomeia esta linha e a do `RASCUNHO-trilhas.md` §4 pelo nome.**

### A peça de Legados fechou — o que ela deixou pendurado

*A régua veio primeiro e o catálogo depois, e a ordem se pagou: os quatro Legados que a régua reprovou eram do catálogo antigo.* São **81 entradas** nas sete Origens, mais o `Sem Técnica` — escrito uma vez e referenciado pelas cinco Origens que o aceitam, porque cinco cópias do mesmo texto seria a lição nº 9 dentro de um catálogo.

**A ficha leva dois Legados, e um deles é obrigatoriamente Destranca.** A regra óbvia — *dois de listas diferentes* — não conserta: ela deixa pegar `Ajusta + Desliga`, e aí quem otimiza continua sem ficção **e a economia mecânica dobra**. Com o Destranca obrigatório ela não dobra.

**O que ficou pendurado, e é o que Equipamento vai encontrar:**

| pendência | espera |
|---|---|
| ~~**Sete vagas de Desliga**~~ **UMA** | **as cinco destravadas fecharam na v0.104** — `Cabo`, `Assinado`, `Revezamento`, `Talhe` e `Usado`, cada uma apagando uma condição nomeada uma vez, com o relógio saindo do nível dela. *Só couberam porque a trava do `Desliga` foi relaxada na mesma versão.* **A sexta fechou na v0.132**, com o `Conhecido`, quando objeto amaldiçoado virou a peça 21 e nomeou a atração. **A que sobra é a do Corpo Amaldiçoado, e ela está destravada de Origem e travada de ALVO** — *a peça 20 fechou na v0.122, e a enumeração da peça 13 §8 ficou com zero livre quando o `Ferro Velho` gastou os degraus de exaustão* |
| ~~A **Armaria** do Descendente e o **Enterrado** do Reencarnado~~ | relidos na v0.49, e **os dois não pediam a mesma coisa**: a Armaria é `ferramenta amaldiçoada` e o Enterrado é `objeto amaldiçoado`. ***As duas peças existem*** — a 16 na v0.59 e a 21 na v0.132 |
| ~~O **Não Sou Gente** virar Passiva paga com espaço de feitiço~~ | ***REPROVADO na v0.188, e o destino cai junto.*** *A lista `Limites` do manual e do capítulo 9 do livro põe **"imunidade completa a um tipo de dano ou condição"** entre o que nenhuma Passiva paga pode fazer.* **A caixa que a v0.39 citou fala de FURAR imunidade — `Melhoria` é peça de feitiço —, e não de tê-la.** *Cento e quarenta e nove versões de decisão tomada e nunca aplicável; a peça 13 §9.9 tem a medida e a sub-checagem `6.2` guarda a relação* |
| ~~A **máquina de criação do Sem Técnica**~~ | ***FECHADA na v0.168, e é a peça 25.*** *Ela não esperava Aptidão nem `Estilo da Sombra`: a Aptidão virou a semente `Energia Reversa` e o `Estilo da Sombra` virou a semente `Domínio Simples`, que a peça 11 §6.5 publicava desde a v0.29* |

> **O alvo livre acabou, e é por isso que as vagas existem.** A enumeração de alvos legais do sistema inteiro tem sete, e o `Ferro Velho` gastou o último. Inventar oito alvos para fechar a cota seria escrever entrada para fechar contagem — que é exatamente o defeito que essa régua nasceu para achar. **Peça nova é o que cria alvo novo.**
>
> **E a v0.49 mediu isso pela primeira vez com uma peça pronta na mão: Equipamento fechou e produziu UM alvo legal.** A trava do Desliga proíbe encostar no que tem preço, e a peça 14 **precificou quase tudo que nomeou** — propriedade, restrição, teto de Destreza, treino. Sobrou o **requisito de Força**, que ninguém compra — e ele vale `1,0` de dado, e vale zero para quem já tem Força 3. *A régua funcionando como desenhada, numa direção que ninguém previu: peça nova cria alvo novo, mas peça bem precificada cria pouquíssimo.*

### E um padrão que vale saber antes de começar

**As quatro peças caem quase todas em 5, 6 e 9 — que são as que não têm validador.** A peça 8 ganhou o dela na v0.34, depois de sete versões com a Defesa errada. As outras três continuam descobertas, e é de lá que saíram os dois erros daquela versão.

**Depois dessas quatro**, e não antes:

| peça | por que só depois |
|---|---|
| ~~**Técnica Marcial**~~ | **FECHADA na v0.122, e é a peça 20.** *Destravada na v0.48 por Equipamento, e liberada de vez na v0.59, quando a ferramenta amaldiçoada virou a peça 16.* **Ela destravou a ORIGEM da vaga de `Desliga` do Corpo Amaldiçoado, e não o alvo dela** — *a enumeração da peça 13 §8 está com zero livre desde que o `Ferro Velho` gastou os degraus de exaustão, e todo `Desliga` novo depende de peça nova nomear coisa* |
| ~~**Estilo da Sombra**~~ | **NÃO virou peça, e isso é o desfecho.** *Ele estava bloqueado pelas aptidões — a rota da Shoko é literalmente "o poder vem de aptidão" —, e quando a trava caiu ele já tinha dono: **a semente `Domínio Simples`**, que a peça 11 §6.5 publica desde a v0.29.* **A peça 25 §4.2 chama ela pelo nome da escola, a Nova Sombra**, e a peça 9 §8 registra o fecho na v0.168 |

As duas eram economias de poder novas, e construir a quarta e a quinta antes de a segunda ter teto escrito é o erro que o esqueleto já avisou. **Nenhuma das duas virou peça pelo caminho que esta linha previa:** *a Técnica Marcial virou o Fundamento com o corpo no lugar da energia, e o `Estilo da Sombra` dissolveu numa aptidão que já existia.*

**E depois de todas essas**, na ordem em que fazem falta:

| peça | o que ela resolve |
|---|---|
| **Objeto amaldiçoado** | **a maldição presa em forma de objeto** — não é item imbuído de energia: *é* a coisa. Resto de feiticeiro antigo, que encarna quando um receptáculo compatível o consome. *Entrou na lista na v0.49, escondido dentro da palavra "ferramenta".* **Duas Origens inteiras são construídas em cima dele** — Receptáculo é comer um dedo, Reencarnado é ter virado um |
| **Ferramenta amaldiçoada** | **arma forjada para canalizar energia**, com graus, que até quem não é feiticeiro consegue usar. Prometida desde a peça 5 §5 e declinada pela peça 14 §8 item 2, que a mandou para tópico próprio *"com graus e forja"*. **É o único jeito de ferir maldição sem energia própria** — a Maki e o Toji |
| ~~**Dano de alma, com Essência na Integridade**~~ | **FECHADA na v0.145, e é a peça 24.** *Ela não foi escrita, foi recolhida: a máquina estava partida em cinco donos e nenhum era dono da régua.* **A Integridade virou `20 + (Essência + 5) × (nível − 1)`**, o Teste de Resistência de Espírito que a v0.7 decidiu foi aplicado cento e trinta e sete versões depois, e o `Cisão` virou a exceção declarada que atravessa o corpo |
| ~~**Pactos**~~ | **FECHADA na v0.134, e é a peça 22.** *O recorte encolheu na v0.116 e voltou a crescer na v0.133, quando o Mizuki abriu a forma que sobrava em quatro.* **As quatro travas do Passo 8 da peça 8 continuam sendo a fundação, e a peça 22 aponta para elas em vez de as repetir** |
| ~~**Itens iniciais por Caminho**~~ | **FECHADA na v0.211.** *Levantado pelo Mizuki na v0.135.* ***Decisão: não existe kit por Caminho, nem fixo nem recomendado*** — o orçamento livre da v0.175 já produz a variação de build que um kit substituiria, e cada Caminho só aponta pro capítulo 14. *Esta linha ficou dizendo "em aberto" por trinta e seis versões depois de fechar — é a lição nº 9 dentro da própria fila* |
| ~~**Itens menores**~~ | **TIRADA DA FILA na v0.248, por decisão do Mizuki.** *Levantada na v0.131: talismã pronto, remédio, corda, lanterna, o kit que o `Herbalismo` usa.* **A v0.171 já tinha matado a ideia de item consumível** — *"melhor não ter item consumível"* —, e ninguém tinha voltado para fechar a pendência que ficou sem substância. *A camada 1 (permissão) da peça 14 §6 segue de pé, com preço no §6.5* |
| **O que cada ofício FAZ** | *levantado pelo Mizuki na v0.139.* **Hoje os onze ofícios são só uma rolagem de análise** — o capítulo 3 diz o que cada um cobre e que o mestre escolhe o atributo na hora, e para por aí. *Falta a mecânica própria, no molde do D&D:* **o que cada um FABRICA, e o que ele faz num descanso.** *`Herbalismo` produz remédio, `Caligrafia` produz talismã, `Forja` conserta e afia — nada disso tem regra.* **Decisão dele: aqui é a versão superficial; o aprofundamento vai para o livro do mestre.** *Com **itens menores** fora da fila, esta peça é quem decide sozinha o que um ofício produz* |
| ~~**As entradas fora das quatro camadas**~~ | **FECHADA na v0.153, e o número ganhou dono e validador.** *Medida na v0.141 e nunca re-medida, ela sobreviveu porque o par publicado não tinha definição escrita — e as duas versões que tentaram remedir acharam `209` e `4`.* **Reconstruída, endireitada e paga: `14` rótulos em `11` entradas, e hoje o livro carrega `0` em `52`.** *A régua declara os dois números e a fronteira; o `ROTULO-LONGO` do `conferir-voz.py` reconta e falha nos dois sentidos.* **Nenhum número de sistema se moveu** |
| ~~**Bestiário**~~ | **FECHADO na v0.198, e é a peça 26.** *Ele não saiu só da matemática do manual: três dos números que a mesa rola toda rodada não tinham dono nenhum, e a peça é quem os derivou* |

~~E uma coisa solta que não é peça: o nome do sistema.~~ **Batizado na v0.94: `Projeto - M`.** *Era a pendência mais velha do projeto — aberta na v0.1 e fechada 93 versões depois.*

**As nove rotas de Origem rodam, e a dona da tabela é a peça 9 §6.**

| rota | jogável hoje |
|---|---|
| Latente · Receptáculo · Descendente · Reencarnado · Feto | **sim** — vão para o Fundamento |
| Restrição Celestial, ramo do Kokichi Muta | **sim** — Fundamento, com o corpo limitado na ficha |
| qualquer uma **+ Sem Técnica** | **sim** — a semente, e o Fundamento em cima: a peça 25, na v0.168 |
| Corpo Amaldiçoado | **sim** — Técnica Marcial, a peça 20, na v0.122 |
| Restrição Celestial, ramo da Maki | **sim** — Técnica Marcial mais Bênçãos e Lapidação, na v0.122 |

> **⚠ Esta linha dizia `não — falta Aptidão ou Estilo da Sombra` até a v0.188**, vinte versões depois de a peça 25 fechar a rota. *A peça 9 §6 marcava `sim` desde a v0.168, o `README` publicava as nove, e esta cópia envelheceu sozinha.* **É a lição nº 9 na forma que não tem número: uma tabela de estado, com dono declarado, copiada para o documento que se lê no começo de toda conversa.**

**E três coisas que a criação ainda contorna**, cada uma com a saída escrita no ponto do texto onde ela pesa:

| falta | como se contorna |
|---|---|
| Regra de Pactos | **na criação as três formas de jogo não entram**, e isso não mudou com a peça 22 — quem quiser começar com uma troca já feita usa a `Regra Própria` do manual ou um `Legado` da peça 13. *A única das quatro que a criação alcança é o **pacto de restrição**, e ele não entrega benefício* |
| ~~Tabela de proteção~~ | **fechada na v0.48**, na peça 14. A ficha continua nascendo com a proteção 1 de cobrir-se; o que mudou é que agora existe o que vestir por cima, e o escudo **soma** em vez de desligar |
| Trilhas com número | a Trilha é escolhida na criação, junto do Caminho. O que ela entrega é a peça de Trilhas |

## Como o Mizuki gosta de trabalhar

**Perguntar antes de decidir.** Escolha de sabor — quantos itens numa lista, quais são, como se chamam, em que ordem aparecem — é dele, e ele quer decidir junto em vez de aprovar depois de pronto. Trazer as opções com o número e o trade-off de cada uma já calculados.

**Mas não perguntar o que a conta responde.** Se dominância, deriva ou o filtro multi-mestre já decidem, rodar a conta e apresentar o resultado. A pergunta é para onde a conta empata ou não se aplica.

Fase por fase, com o plano à vista antes de executar. Número vem de conta rodada, não de intuição. Documento não pode ter cara de saída de IA. Antes de fechar versão, revisão cética — inclusive contra o que eu mesmo escrevi. Material superado vai para o `99-arquivo/`, não fica com aviso em cima.

**As lições que custaram erro moram no `README.md`, e só lá.** São nove, e a seção se chama *"Nove lições que custaram erro"*.

*Até a v0.32 este arquivo guardava a própria cópia da lista.* Ela tinha parado em cinco enquanto o README chegava a nove, e a lição nº 2 daqui ainda listava *"v0.16, v0.17, v0.19, v0.24 e v0.26"* quando o README já contava sete versões. Duas cópias, duas respostas — que é a lição nº 9 acontecendo dentro do documento que existe para avisar sobre ela. Uma lista, um dono.

As três que a semana da v0.28 à v0.32 acrescentou, e que valem ler antes de escrever conta nova: **um preço se mede somado, nunca sozinho** (nº 7); **uma checagem não pode se medir contra a própria constante** (nº 8, que apareceu três vezes em três versões); e **um número que mora em dois documentos vai divergir** (nº 9).
