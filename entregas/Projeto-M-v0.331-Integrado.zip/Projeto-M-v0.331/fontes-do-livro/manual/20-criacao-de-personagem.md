# Criação de Personagem

## Peças da ficha

- **Uma técnica** que só você tem, escrita por você
- **Cinco atributos**, de 0 a 6
- **Um Caminho e uma Trilha**, que dizem o seu lugar numa equipe e quem você é dentro dele
- **Uma Origem**, que diz de onde veio o seu poder
- **Nove perícias e dois ofícios** treinados, ou dez e nenhum, você escolhe
- **Dois Testes de Resistência** treinados, de quatro
- **Dois Legados**, das listas da sua Origem. Um `Destranca` e um `Desliga` ou `Ajusta`
- **Cinco feitiços**: dois pequenos e grátis, três de verdade
- **Os números que caem sozinhos**: vida, energia, Defesa, iniciativa

## Nível inicial

> **Personagem novo começa no nível 2.** Não existe ficha de nível 1 padrão.

O nível 1 é o personagem antes de virar feiticeiro: a pessoa que ainda não é feiticeira de verdade, o Itadori antes do dedo. Ele fica como opção de campanha para quem quiser jogar essa parte.

No nível 2 você já tem técnica, já tem feitiço e já dá para encarar uma missão. As contas do passo 7 presumem o nível 2.

## Ordem dos passos

> **Origem → a Regra em uma frase → Caminho → Atributos → a técnica inteira → perícias e ofícios → os números → Pactos.**

A técnica sai partida em duas: a Regra, uma frase só, vem no passo 2, antes do Caminho decidir nada por você; o resto espera até o passo 5, depois que o Caminho e os atributos já estão na ficha.

## Passo 1 · Origem

De onde vem o seu poder. Nasceu com você, veio no sangue de um clã, você virou recipiente de alguma coisa, alguém te fez, ou trocaram uma coisa por outra antes de você nascer.

São sete Origens, mais a sub-origem Sem Técnica. Escolha e anote na ficha:

**Anotações da Origem**
{: .tab-titulo }

| O que anotar | De onde sai |
|---|---|
| Uma perícia | da lista de quatro da sua Origem |
| Uma perícia livre | que a sua história justifique, com o mestre aprovando na leitura |
| Um Teste de Resistência treinado | qualquer um dos quatro; o outro vem do Caminho |
| Um traço | do catálogo da sua Origem, ou escrito por você |
| Dois Legados | um `Destranca` obrigatório, mais um de qualquer formato |
| A rota de criação | por onde você monta o seu poder |

As listas de perícia, os traços e as rotas estão no capítulo 7, *Origens e Legados*, e é lá que estão também as listas de Legado de cada Origem.

A Origem não dá ponto de atributo nenhum, e não decide a sua patente: todo personagem começa **Grau 4**, venha de onde vier.

> **O `Efeito na ficha` de cada Origem, no capítulo 7, *Origens e Legados*, diz por qual rota ela monta o poder.** Se a sua for a sub-origem Sem Técnica, a máquina inteira está no capítulo 11, *Sem Técnica* — e o Passo 2 e o Passo 3 valem igual.

> **Duas rotas montam poder pela Técnica Marcial, no capítulo 10:** o Corpo Amaldiçoado e a Restrição Celestial pelo ramo sem energia. Se for o seu caso, o Passo 2 e o Passo 3 valem igual — o que muda é o capítulo que você abre para montar.

## Passo 2 · Regra da técnica

Uma frase que diz o que a sua técnica faz com o mundo, sem falar em efeito nem em dano.

> *"Tudo que eu prendo entre as minhas mãos fica mais pesado."*
>
> *"Eu troco de lugar com qualquer coisa do meu tamanho que eu esteja enxergando."*
>
> *"Quem mente na minha frente sangra."*

Uma frase, verificável pela mesa, sem número. Você carrega ela a campanha inteira, porque a técnica nunca muda. O que evolui é o que você consegue fazer com ela.

Pare aqui e vá para o Caminho. O resto da técnica volta no passo 5.

## Passo 3 · Caminho e Trilha

Que lugar você ocupa numa equipe. Um Caminho por personagem, escolhido agora e para sempre. Não existe multiclasse.

**Caminhos**
{: .tab-titulo }

| Caminho | O que ele é | Atributos naturais |
|---|---|---|
| **Bastião** | o corpo como resposta: aguentar, encarar, prender | Força, Constituição |
| **Vanguarda** | a arma como resposta: alcançar, cortar, acabar | Destreza, Força |
| **Guia** | o outro como resposta: estender, recuperar, reposicionar | Essência |
| **Emanador** | a técnica como resposta: mais feitiço, e mais barato | Inteligência, Essência |
| **Evocador** | o vínculo com suas invocações | Inteligência, Essência |
| **Incursor** | movimento e abertura no confronto | Destreza, Força |

O Caminho mexe em posicionamento, alvo, duração e recuperação. Cada habilidade declara suas exceções de dano, Classe e recuperação; cumpra os custos e requisitos do capítulo 8.

### Características do Caminho

**Características do Caminho**
{: .tab-titulo }

| Caminho | Vida inicial | Vida por nível | PE por nível | Perícias fixas |
|---|---|---|---|---|
| **Bastião** | 12 (d12) | 7 | 4 | Atletismo · Provocar |
| **Vanguarda** | 8 (d8) | 5 | 5 | Acrobacia · Percepção |
| **Guia** | 8 (d8) | 5 | 5 | Persuasão · Medicina |
| **Emanador** | 6 (d6) | 4 | 6 | Ocultismo · Investigação |
| **Evocador** | 6 (d6) | 4 | 6 | Religião · Lidar com Animais |
| **Incursor** | 6 (d6) | 4 | 6 | Acrobacia · Intuição |

Mais **cinco perícias à sua escolha**, de qualquer uma da lista de perícias do sistema, **dois ofícios à sua escolha** e **um Teste de Resistência treinado**. *Os dois ofícios se trocam por mais uma perícia, e no `Guia`, no `Emanador` e no `Evocador` duas das cinco se trocam por treino em uma arma.*

### Equipamento

> **Você sai de casa com o `Traje` degrau 1 da instituição e ¥150.000 para montar o resto.**

O Caminho te treina numa lista de armas; ele não te dá a arma. Isso você compra, e as tabelas de `Preços` estão no capítulo 15, *Equipamento*. Os ¥150.000 são uma mensalidade de um Grau 4, que é o que você é no começo.

O dinheiro dá para mais que a arma, e é aí que duas fichas do mesmo Caminho começam diferentes: dá para sair de espada e escudo, de uniforme reforçado, ou de `Revestimento` e punho fechado. As contas de cada uma estão no capítulo 14.

O uniforme não muda a sua Defesa no nível 2 — ele dá proteção 1 e desliga o `cobrir-se`, que no refino 1 também dá 1. Ele é roupa, e serve para você não andar de blusa de moletom numa missão.

### Trilha

A Trilha é escolhida agora, junto do Caminho, e nasce com o personagem. São três por Caminho: Muro · Punho · Combatente Amaldiçoado no Bastião, Estocada · Batedor · Executor na Vanguarda, e assim por diante. A lista está no capítulo 8, *Caminhos e Trilhas*.

> **A Trilha já entrega no nível 2**, junto do primeiro degrau do Caminho, e volta a entregar nos níveis 11, 19 e 27. O texto de cada uma está no capítulo 8, *Caminhos e Trilhas*.
>
> **Para jogar com invocações**, leia também o capítulo 17, *Invocações*. O Evocador aprimora esse subsistema; outros Caminhos podem utilizá-lo seguindo suas regras comuns.

## Passo 4 · Atributos

> **Nove pontos entre os cinco atributos. Nenhum acima de 3.**

O número **é** o modificador. Não existe valor separado nem tabela de conversão. A escala vai de 0 a 6, e 6 é o topo humano. Uma distribuição legal, por exemplo, é 3 · 2 · 2 · 1 · 1.

O que cada atributo governa está na tabela `Atributos` do capítulo 1, *Como Jogar*.

Inteligência sabe; Essência percebe. Sentir energia amaldiçoada é a sua energia reagindo à de outro.

> **Trave agora o seu Teste de Resistência Físico.** Ele usa Força ou Destreza, você escolhe na criação e não muda depois.

## Passo 5 · Técnica inteira

Aqui você abre o capítulo 9, *Fundamento*. É a parte longa. Você já tem a Regra e já sabe o Caminho; falta o resto.

1. **Descrição.** De onde a técnica veio, como ela aparece, o que as pessoas veem quando ela age. Sem efeito mecânico.
2. **Famílias.** Duas **Livres**, cujas Melhorias custam metade da Classe a menos, e três **Fechadas**, das quais você nunca compra nada.
3. **Selo.** O gesto, a condição ou o objeto que a sua técnica exige. Não custa nem devolve ponto. Restrição que o Selo já obriga não devolve ponto.
4. **Passiva Livre.** Uma, de graça, para todo mundo. Ela não rola dado, não muda número e não faz ninguém rolar. Se a técnica impõe uma regra ao mundo, a `Regra Própria` de Classe Passiva 1 vem junto, também de graça.
5. **Os feitiços.** No nível 2 você tem **Classe 1**, dois feitiços de **Classe 0** (grátis, não ocupam espaço) e **três feitiços conhecidos**, montados pelo orçamento da Classe 1. Três é o que a fórmula `2 + (nível ÷ 2)` dá no nível 2.

> **A Regra da técnica é lida por outra pessoa antes de entrar em jogo.** Quem escreveu sabe o que quis dizer; quem vai arbitrar, não.

## Passo 6 · Perícias, ofícios e Testes de Resistência

**Treino na criação**
{: .tab-titulo }

| De onde vem | Perícias | Ofícios | Teste de Resistência |
|---|---|---|---|
| **Caminho** | 2 fixas + 5 à sua escolha | 2 à sua escolha | 1 |
| **Origem** | 1 da lista dela + 1 livre | — | 1 |

Os dois ofícios da Origem se trocam por mais uma perícia livre, e as duas rotas fecham a ficha:

**Rotas do ofício**
{: .tab-titulo }

| Rota | Perícias | Ofícios |
|---|---|---|
| ficando com os ofícios | 9 de 23 | 2 de 11 |
| trocando os dois | 10 de 23 | 0 de 11 |

**E nos três Caminhos com treino inicial em Arma de Fogo e Balestra — `Guia`, `Emanador` e `Evocador` — duas das cinco perícias à sua escolha viram treino em uma arma da lista.** *Não a categoria e não o tipo: uma arma.*

Os dois Testes de Resistência treinados saem de quatro: Físico, Vigor, Espírito e Intelecto. Um vem da Origem, o outro do Caminho.

Perícia pertence a um atributo fixo: Atletismo é sempre Força. Ofício não pertence a atributo nenhum. O atributo muda conforme o que você faz com ele, e quem decide é o mestre na hora. Forjar uma lâmina é Força, falsificar uma assinatura é Destreza, saber qual selo o papel pede é Inteligência, e as três coisas são o mesmo ofício.

> **Perícia sem treino você tenta; ofício sem treino, não.** Qualquer um escala e falha. Ninguém forja uma lâmina por tentativa.

O quadro completo das perícias e dos ofícios está no capítulo 3, *Perícias e Ofícios*.

## Passo 7 · Números derivados

Nada aqui é escolha. Você copia da tabela e faz a conta.

**Números do nível 2**
{: .tab-titulo }

| Número | Como sai |
|---|---|
| Maestria | 1 |
| Refino | 1 |
| Pontos de vida | (vida inicial do Caminho + Constituição) + (vida por nível do Caminho + Constituição) |
| Integridade | 25 + Essência |
| Pontos de Energia | PE por nível do Caminho × 2 |
| Defesa | 10 + Destreza + 1 |
| Iniciativa | d20 + Destreza |
| Deslocamento | 9 metros |
| Ataque corpo a corpo | d20 + Força + 1 |
| Ataque à distância | d20 + Destreza + 1 |
| Ataque de conjuração | d20 + atributo da técnica + 1 |
| CD de feitiço | 8 + atributo da técnica + maestria |
| Perícia treinada | d20 + atributo + 1 |
| Teste de Resistência | d20 + atributo do TR + maestria, e a maestria só se treinado |

No refino 1 você já tem duas aptidões, de graça: `Cobrir-se de energia`, que dá proteção sem equipamento, e `Canalizar energia`, que permite ferir uma maldição com o corpo ou com a arma. São básicas de qualquer feiticeiro.

> **Toda ficha de nível 2 nasce com proteção 1.** É o `+1` que entra na Defesa acima. Sem Traje e sem Revestimento, a sua proteção é `1/3 do refino + 1`, que no refino 1 dá 1. Escudo soma com ela; Traje e Revestimento não.

## Passo 8 · Pactos

Opcional, e a ficha nasce sem nenhum.

Pacto é o que você trocou por poder, e as quatro formas dele têm onde morar:

**Onde cada forma de pacto se escreve**
{: .tab-titulo }

| O que você quer dizer | Onde isso se escreve |
|---|---|
| *"a minha técnica fica maior sob uma condição que eu aceitei"* | **Restrição**, por feitiço, no capítulo 9 |
| *"a minha técnica impõe uma regra ao mundo"* | **`Regra Própria`**, por técnica, no capítulo 9 |
| *"eu troquei uma coisa antes de a campanha começar"* | **Legado**, na criação, no capítulo 7 |
| *"eu e mais alguém fechamos um trato, aqui, na mesa"* | **Pactos**, no capítulo 18 |

> **Das quatro formas do capítulo 18, só o pacto de restrição entra na criação**, e ele se escreve junto da Origem ou da técnica. As outras três nascem em jogo.

## Exemplo

**A Kaori**, feiticeira de nível 2.

### Origem

**Descendente.** Um clã menor que perdeu o nome faz três gerações. Como todo mundo, ela começa Grau 4: quem abre porta pra ela é o sobrenome, mesmo com a patente baixa.

- *Perícia da lista* (Hierarquia · História · Ocultismo · Persuasão): **Hierarquia**
- *Perícia livre:* **História**, porque ela cresceu ouvindo de quem o clã perdeu o nome
- *Ofícios:* **Forja** e **Herbalismo**, o segundo da avó
- *Teste de Resistência:* **Vigor**
- *Traço:* o ramo do clã que perdeu, e ela é dele
- *Legado · `Destranca`:* **O Sobrenome**, que dá audiência em qualquer lugar do meio jujutsu. Ser bem recebida é outra história
- *Legado · o segundo:* **Biblioteca**, que uma vez por cena refaz um teste de História ou Ocultismo. A casa tinha os livros, e ela foi obrigada a ler

### Regra

*"Tudo que eu prendo entre as minhas mãos fica mais pesado."*

### Caminho e Trilha

**Bastião**, Trilha **Muro**: o corpo é o escudo, e é o que a Regra dela já pedia. *Teste de Resistência do Caminho:* **Físico**.

### Atributos

Força 3 · Constituição 2 · Destreza 2 · Inteligência 1 · Essência 1. Nove pontos, nenhum acima de 3, e o **TR Físico travado em Força**.

### Técnica

*Famílias Livres:* Controle e Castigo. *Fechadas:* Amparo, Área e Auxiliares, porque ela não cura, não pega área e não dá suporte. *Selo:* as duas mãos precisam se tocar antes. *Passiva Livre:* ela sabe o peso exato de qualquer coisa que encoste nela.

### Perícias e ofícios

**Nove perícias.** Do Caminho, fixas: Atletismo e Provocar. Do Caminho, livres: Sentir Energia, Percepção, Sobrevivência, Intuição e Persuasão. Da Origem: Hierarquia e História.

**Dois ofícios.** Forja e Herbalismo, os dois da Origem.

### Números

**Números da Kaori**
{: .tab-titulo }

| | Conta | Resultado |
|---|---|---|
| Vida | (12 + 2) + (7 + 2) | **23** |
| Integridade | 25 + 1 | **26** |
| PE | 4 × 2 | **8** |
| Defesa | 10 + 2 + 1 | **13** |
| Iniciativa | d20 + 2 | |
| Ataque corpo a corpo | d20 + 3 + 1 | **d20 + 4** |
| Ataque de conjuração | d20 + 3 + 1 | **d20 + 4** |
| CD dos feitiços dela | 8 + 3 + 1 | **12** |
| Atletismo (treinado) | d20 + 3 + 1 | **d20 + 4** |

## Conferência da ficha

Sete perguntas, e todas têm resposta objetiva. Você mesmo passa por elas antes de entregar.

1. **Os atributos somam nove, e nenhum passa de 3?**
2. **O Teste de Resistência Físico está travado** em Força ou Destreza?
3. **São nove perícias e dois ofícios, ou dez e nenhum?** As duas rotas são legais; o que não pode é somar as duas. E as duas perícias fixas do Caminho precisam estar entre elas.
4. **São dois Testes de Resistência treinados**, um da Origem e um do Caminho?
5. **A Regra da técnica cabe em uma frase**, é verificável pela mesa e não tem número?
6. **Alguém que não seja o dono leu a técnica?**
7. **Os três feitiços conhecidos fecham no orçamento da Classe 1?** Três pontos cada.

O mestre pode recusar mesmo quando a ficha passa nas sete.
