# Aptidões e Refino

Aptidão é o que qualquer feiticeiro pode aprender, venha a energia de onde vier: cobrir-se de energia, levantar uma barreira, ficar de pé dentro de uma Expansão de Domínio. Ela não depende da sua técnica.

Aptidão se ensina ou se aprende. Ela passa de mestre para aluno, de escola de espada para escola de espada, e dois feiticeiros de técnicas opostas sabem exatamente as mesmas quatro coisas contra um domínio. É o repertório comum da profissão.

Quem compra aptidão é o **refino**, o eixo de controle da sua ficha. Poder é quanto você tem. Refino é quanto você não desperdiça.

> **Sem energia amaldiçoada não existe refino nem aptidão.** Uma ficha nessa situação usa **Lapidação** e **Bênçãos** no lugar dos dois, no capítulo 14, *Bênçãos e Lapidação*. A máquina é a mesma casa por casa; o que muda é o conteúdo do catálogo.

## Refino

Energia amaldiçoada vaza. Ela escapa do corpo de quem produz, o tempo todo, e é por isso que um feiticeiro fareja outro a um quarteirão de distância. O refino mede quanto da sua você segura.

A camada em volta do corpo de um feiticeiro de refino 1 sai fina, o domo que ele levanta desmancha no primeiro empurrão, e o que sobra dele no ar avisa qualquer maldição de que ele está chegando. Um feiticeiro de refino 10 entrega a energia inteira onde deseja: a mesma quantidade rende o dobro, a camada aguenta a luta toda, o domo aguenta o cerco, e o que ele solta no ar é só o que ele decidiu soltar.

É por isso que o refino é a moeda que compra aptidão. Aptidão se aprende manejando energia, com a técnica fora da conta, e quem maneja melhor aprende mais coisas.

Na ficha, o refino é um número de 1 a 10. Toda ficha começa em 1, e ele sobe nos marcos: os níveis **6, 10, 14, 18, 22, 26 e 30**, sete ao longo da campanha inteira.

> **Cada marco te dá +1 de refino de graça. Se você escolher Refino no marco, você ganha mais +1.**

**Refino por marco**
{: .tab-titulo }

| marco | quem nunca escolhe Refino | quem sempre escolhe |
|---|---|---|
| começo da ficha | 1 | 1 |
| 6 | 2 | 3 |
| 10 | 3 | 5 |
| 14 | 4 | 7 |
| 18 | 5 | 9 |
| 22 | 6 | **10** |
| 26 | 7 | 10 |
| 30 | **8** | 10 |

### Efeito do refino

> Ele fica fora de acerto, CD, defesa e Teste de Resistência.

**Efeito do refino**
{: .tab-titulo }

| onde o refino não entra | onde ele entra |
|---|---|
| acerto | custo: quanto PE a aptidão cobra |
| CD | frequência: quantas vezes por cena, por descanso, por dia |
| defesa | escopo: alcance, duração, quantos alvos |
| Teste de Resistência | magnitude fora de disputa: Redução de Dano e proteção |
| dano de feitiço | dano fora da rodada de feitiço, e disputa contra outro refino |

**Duas entradas põem refino em dano, e as duas só valem na rodada em que você não conjura:** `Projetar energia` e o dano na arma do `Canalizar energia`. **Feitiço nunca cresce com refino** — ele tem orçamento próprio, no capítulo 9, *Fundamento*.

A proteção de `Cobrir-se de energia` entra na sua Defesa, e usa `1/3 do refino`.

> **Arredondamento.** Toda divisão de refino arredonda para baixo: refino 5 dividido por 2 dá 2.

## Marco

A cada marco a ficha ganha três coisas de graça e escolhe uma quarta.

> **Passivo:** +1 ponto de atributo, +1 de refino e +1 espaço de feitiço.
>
> **Escolha, uma das três:**
>
> **Corpo** — mais um ponto de atributo, **e mais uma perícia ou um ofício treinado**.
> *Do nível 10 em diante, no lugar da perícia ou do ofício novo, você pode **especializar** um que já treina: some **metade da maestria** de novo naquela rolagem, arredondando para baixo.*
>
> **Refino** — mais um de refino, e uma aptidão. **Se o seu refino já estiver no teto, você leva duas aptidões no lugar.**
>
> **Leque** — mais um feitiço, que só pode ser feitiço, e uma Passiva.

Quem escolhe Refino em todo marco bate no teto no nível 22. Dali em diante escolher a rota entrega uma segunda aptidão no lugar do refino extra.

> **Quem nunca escolhe Refino termina a campanha com zero aptidões.** A rota existe e é jogável.
{: .aviso }

Mesmo essa ficha não fica sem nada. `Cobrir-se de energia` e `Canalizar energia` vêm de graça no refino 1, e a primeira continua crescendo com o refino passivo até 8. O que ela nunca vai ter é `Energia Reversa` nem `Barreira Simples`.

*O marco é do capítulo 19, __Experiência e Progressão__: é lá que estão os sete níveis em que ele cai, quanto refino cada rota junta marco a marco, e o que Corpo e Leque compram.*

## Aptidões

Um marco de Refino compra **uma aptidão**, de qualquer altura que o seu refino alcance. Duas do catálogo não custam marco nenhum: `Cobrir-se de energia` e `Canalizar energia` já estão na sua ficha desde o refino 1.

> **Aptidão não custa espaço de feitiço.** Espaço de feitiço é a moeda das Passivas e da Expansão de Domínio. As duas economias são separadas: aptidão custa marco, e só marco.

`Sua maior Classe` aparece no texto de várias aptidões. Ela é a variável do capítulo 9, *Fundamento*, e é lá que ela é definida.

### Classe Passiva

**A Classe Passiva é o tamanho da aptidão**, e diz o quanto aquela entrada pode entregar. As aptidões usam a mesma escala das Passivas: a escala, e o que cabe em cada nível de Classe, estão no capítulo 9, *Fundamento*, na seção `Passivas`.

O marco compra uma aptidão de qualquer escala, e o preço é o mesmo. Quem separa e limita as escalas são só os requisitos.

**E se você for escrever uma `Aptidão Própria`, a escada do capítulo 9 é a base:** escolha a escala que a sua ideia alcança, e escreva dentro do que aquela linha permite.

### Requisito

Cada aptidão declara o próprio requisito, e ele está na linha dela no catálogo: nenhum, nível, refino, os dois juntos, outra aptidão, ou Origem.

Três exigem outra aptidão, e nas três a exigida é a mesma coisa em tamanho menor: `Cortina` pede `Barreira Simples`, `Circulação` pede `Energia Reversa`, e `Regravação` pede `Circulação`. As duas de kokusen são alternativas entre si, e nenhuma exige a outra.

## Catálogo

### Como uma aptidão funciona

Cada entrada aparece duas vezes. Primeiro nesta tabela, com quatro campos: **nome**, **requisito**, **Classe Passiva** e **o que o refino escala**. Depois na seção dela, na caixa de regra.

Traço na coluna de Classe Passiva quer dizer que a entrada não tem uma. Traço na última coluna quer dizer que o refino não mexe naquela aptidão.

**Como ler uma aptidão**
{: .tab-titulo }

| Aptidão | Requisito | Classe Passiva | O que o refino escala |
|---|---|---|---|
| Cobrir-se de energia | grátis no refino 1 | — | a proteção, e a Redução de Dano da Reação |
| Canalizar energia | grátis no refino 1 | — | — |
| Projetar energia | sem requisito | — | o dano |
| Energia Reversa | refino 7 e nível 14 | 3 | — |
| Circulação | `Energia Reversa`, refino 8 | 3 | — |
| Regravação | `Circulação` | 3 | — |
| Kokusen Melhorado | refino 5 e nível 14 | — | vantagem no d100 |
| Kokusen Constante | refino 5 | — | a chance no d100 |
| Cesta Oca de Vime | ser Reencarnado, ou treinado em `História` | 1 | — |
| Domínio Simples | ter visto um sendo usado, ou ter aprendido com alguém; refino 5, ou 4 com o voto | 2 | o raio |
| Pétala | ser Descendente, ou ter aprendido com alguém de um clã; refino 4 e nível 10 | 2 | — |
| Extensão de Domínio | ter visto uma sendo usada, ou ter estudado, ou aprendido com alguém; refino 7 e nível 18; o Corpo Amaldiçoado não compra | 3 | a duração |
| Barreira Simples | sem requisito | — | a vida do domo |
| Cortina | exige a `Barreira Simples` | — | a vida dela |
| Aptidão Própria | uma vez na ficha inteira | 1 ou 2 | conforme o que for escrito |

## Aptidões de graça

Estas duas chegam com a ficha, no refino 1, sem custar marco nenhum. Elas são o que separa alguém que tem energia amaldiçoada de alguém que sabe usar energia amaldiçoada.

### Cobrir-se de energia

> **Cobrir-se de energia** — sem Traje e sem Revestimento, a sua proteção é `1/3 do refino + 1`. Escudo soma com ela.
>
> Como Reação, você concentra a energia no impacto: Redução de Dano de `1,5 × refino` num golpe, por **2 PE**. Você fica sem proteção até o fim do seu próximo turno.
>
> Requisito: grátis no refino 1. O refino escala a proteção e a Redução de Dano da Reação.

> **Exemplo.** Com refino 6 a sua proteção passiva é 3, e a Reação desconta 9 de um golpe por 2 PE.

### Canalizar energia

> **Canalizar energia** — você ataca com uma arma ou com o soco, e o ataque vem imbuído de energia amaldiçoada, o que permite a um item mundano matar maldição.
>
> **Dano na arma.** Os seus ataques **com arma** causam `1d4` de dano a mais a cada `3` pontos de refino — `1d4` no refino `1`, `2d4` no `3`, `3d4` no `6`, `4d4` no `9`. **No refino `10` os dados viram `d6`: `4d6`.**
>
> **Só arma.** Ele não entra em feitiço nem em Kata. E se o mesmo ataque já estiver carregando um feitiço de dano de `Classe 0` ou mais — como no `Ferrão`, o nível 27 da Estocada, em que o golpe leva um Classe 0 junto —, este dano **não** se soma por cima.
>
> Requisito: grátis no refino 1. O refino escala o dano na arma.

Ela é a porta de toda arma de contato, e é ela que põe energia no que a sua mão carrega.

> **Exemplo.** Com refino 6, o soco e a lâmina levam `3d4` de dano a mais.

## Energia crua

### Projetar energia

> **Projetar energia** — você dispara energia crua. O dano é `Xd6`, e ela gasta PE num valor menor ou igual ao seu refino: cada `1` PE aumenta o `X` em `1`. O alcance segue o da sua maior Classe disponível.
>
> Requisito: nenhum. O refino escala o dano.

`Projetar energia` é o que sobra quando o combustível acaba: o turno em que o seu PE zerou, a luta ainda não terminou e você continua precisando fazer alguma coisa.

### Energia Reversa

> **Energia Reversa** — ação padrão. Gaste até `a sua maior Classe` de PE e recupere `1d8` de vida por PE gasto, em você.
>
> Requisito: refino 7 e nível 14. Classe Passiva 3.

> **A `Energia Reversa` cura só você.** Curar outra pessoa é o degrau raro.

Ela muda a forma das lutas longas e muda o que acontece entre elas: um personagem com Energia Reversa não precisa voltar para casa depois de cada cena.

### Circulação

> **Circulação** — o teto por uso da sua `Energia Reversa` sobe para `1,5 × a sua maior Classe` de PE, arredondando para baixo.
>
> Você também pode usá-la como **Ação Bônus**. Usada assim, os dados de cura são `d4` em vez de `d8`.
>
> E você **recompõe o que foi arrancado** — braço, olho, o que a mesa tiver tirado de você. Isso gasta o teto inteiro do uso, e naquele uso você não cura vida nenhuma.
>
> Requisito: ter a `Energia Reversa` e refino 8.

Energia positiva reconstrói sangue, osso, carne e órgão, e quem chega aqui tem ela andando pelo corpo o tempo todo em vez de ligar e desligar. É o degrau mais alto da cura, e ele é caro: você gasta um marco na `Energia Reversa`, outro nesta, e o refino 8 pede mais quatro de sete.

Na Ação Bônus você cura e ainda ataca na mesma rodada. O dado menor é o preço disso — é a diferença entre segurar um golpe e ficar inteiro.

Recompor membro é a mesma aptidão fazendo a coisa mais difícil que a energia positiva faz. Em combate ela custa a sua rodada e o combustível, e você continua machucado. Fora de combate é barata, e é lá que ela deve ser usada.

> **Membro perdido.** Não tem regra neste livro, e isso é decisão: quem tira é o mestre ou um pacto, e as penalidades são as que a mesa combinar, do mesmo jeito que o d20 faz. Esta aptidão desfaz.

**Curar outra pessoa continua fora daqui.**

### Regravação

> **Regravação** — Ação Bônus, durante o seu Rescaldo. Gaste o teto inteiro da sua `Energia Reversa`, e o Rescaldo acaba: a sua técnica volta a responder. Nesse uso você não cura vida nenhuma.
>
> Cada uso deixa uma **marca**, e as marcas somem no descanso longo. Com `metade da sua Inteligência + metade da sua maestria` marcas, cada metade arredondando para baixo, você não abre Expansão de Domínio.
>
> Requisito: ter a `Circulação`. Classe Passiva 3.

Quando o domínio acaba, a técnica queima pelo resto da cena: é o Rescaldo, do capítulo 9, *Fundamento*. Quem chega aqui destrói a gravação queimada com energia e refaz com energia reversa, e o estrago acumula até a Expansão não abrir mais.

Ela só serve a quem abre Expansão de Domínio, e regravar é escolha. Sem regravar, o Rescaldo acaba com a cena, e na luta seguinte você abre de novo.

> **Exemplo.** No nível 26, com Inteligência 5, você tem `2 + 2 = 4` marcas. Você abre a Expansão, regrava, e repete até a quarta regravação. Ela devolve a técnica, e a Expansão fica fechada até o descanso longo.

## Aptidões de kokusen

### Kokusen

> **Kokusen** — em crítico no corpo a corpo, role d100. `2 × refino` ou menos é kokusen: o dano leva +50% depois de todos os valores resolvidos.
>
> Cada d100 falhado empurra o próximo em **+2**, e o acumulado zera no descanso longo.
>
> Requisito: nenhum, e ele não gasta marco. O refino escala a chance no d100.

O +50% entra em cima do crítico que já dobrou os dados. Um crítico entrega dois punhados de dado; um kokusen entrega três. Por exemplo, com refino 6 o kokusen sai em 12 ou menos no d100 — 12% dos seus críticos corpo a corpo.

O Kokusen em si não é uma aptidão: é uma mecânica, e todo feiticeiro que tem energia consegue usar. Ele não ocupa vaga de catálogo e não custa marco. Abaixo estão as duas aptidões que melhoram essa fonte.

### Kokusen Melhorado

> **Kokusen Melhorado** — mesma regra do `Kokusen`, exceto que você rola dois d100 e fica com o melhor.
>
> Requisito: refino 5 e nível 14. O refino escala a vantagem no d100.

### Kokusen Constante

> **Kokusen Constante** — mesma regra do `Kokusen`, exceto que a base sobe para `3 × refino`.
>
> Requisito: refino 5. O refino escala a chance no d100.

## Aptidões anti-domínio, e a `Extensão de Domínio`

Uma Expansão de Domínio completa não erra. O Acerto dela simplesmente acontece com quem está lá dentro, sem rolagem e sem Teste de Resistência, e nenhuma defesa da ficha encosta nele.

> **As quatro protegem do Acerto de uma Expansão de Domínio. Algumas delas servem contra a Expansão incompleta.**
>
> Erguer qualquer uma das quatro custa a sua maior Classe em PE, toda vez que ela sobe.
>
> A incompleta não tem acerto garantido: o Acerto dela rola. Contra ela você se defende com Defesa e com Teste de Resistência, como se defende de tudo o mais no jogo.

**Aptidões anti-domínio**
{: .tab-titulo }

| | protege | e cobra | PE por rodada |
|---|---|---|---|
| **Cesta Oca de Vime** | só você, dentro de uma esfera | as duas mãos presas no símbolo, e ela cai com os golpes em você | nenhum |
| **Domínio Simples** | um raio em volta de você, e quem estiver nele | aguenta poucas rodadas de Expansão, menos contra quem tem mais Essência | `2` |
| **Pétala** | o seu corpo, e rebate o que toca | cede contra quem tem mais Essência, e cai com os golpes em você | `1` |
| **Extensão de Domínio** *(não é anti-domínio: ela serve como uma)* | você inteiro, contra tudo o que a Expansão faz | nenhum feitiço nem `Manejo` enquanto ela estiver de pé, e é a mais cara | `1,5 × maior Classe` |

### Cesta Oca de Vime

> **Cesta Oca de Vime** — você faz o símbolo e uma esfera se fecha em volta de você. Enquanto você o segurar, o Acerto de uma Expansão não te alcança, e as suas duas mãos ficam presas nele: nada de arma, escudo, feitiço com `Gesto` ou `Agarrar`. Andar e chutar, pode. Ela levanta com uma Reação quando uma Expansão abre, ou com uma Ação Bônus no seu turno. Erguer custa a sua maior Classe em PE, toda vez que ela sobe; de pé, ela não custa nada.
>
> Ela cai pelos golpes em você, e não pela Expansão. Cada golpe que te acerta pede o teste do `Carregar`: um Teste de Resistência de Espírito contra a CD de quem te feriu. As falhas se acumulam, e com metade da sua Essência em falhas (no mínimo 1) a esfera se desfaz. Esse teste não ocupa a sua Concentração, e a Mão Firme não protege dele.
>
> Se você soltar o símbolo, ela fica de pé e você recupera as mãos, mas cada Acerto letal da Expansão conta uma falha, no máximo uma por rodada. Quando ela cai, a Expansão te alcança na hora, com um Acerto a mais: o do começo do turno do dono continua vindo. Você pode levantar de novo sem espera, com as falhas zeradas, gastando a Ação Bônus do seu turno.
>
> Requisito: ser Reencarnado, ou ser treinado em `História`. Classe Passiva 1.

A `Cesta Oca de Vime` anula o Acerto e mais nada: o Efeito da Expansão continua acontecendo em cima de você. Contra uma Expansão pequena ela segura quase tudo; contra uma grande ela cede, porque a luta dura mais e quem bate tem CD mais alta.

### Domínio Simples

> **Domínio Simples** — um domínio pequeno em volta de você, de raio `1,5 m + refino ÷ 2`, que cobre quem estiver nele. Lá dentro a Expansão não alcança ninguém: nem o Acerto dela, nem o que ela faz com as pessoas ou com o lugar. Ele levanta com uma Reação quando uma Expansão abre, ou com uma Ação Bônus no seu turno, e custa `2` PE por rodada. Erguer custa a sua maior Classe em PE, toda vez que ele sobe.
>
> Ele aguenta a Expansão por 3 rodadas, 4 se a sua Essência for maior que a do dono dela e 2 se for menor. Cada Acerto que ele segura gasta uma rodada, a começar pelo de quando ela abre. Quando as rodadas acabam, o Acerto seguinte o derruba e alcança quem ele protegia. Golpe em você não o derruba.
>
> Cada Acerto que ele segura pede o teste do `Carregar`: um Teste de Resistência de Espírito contra a CD do dono da Expansão. Uma falha tira uma rodada, mas as falhas nunca levam a duração abaixo de metade da sua Essência (no mínimo 1). Esse teste não ocupa a sua Concentração, e a Mão Firme não protege dele.
>
> Se ele cair pelo voto, no meio da rodada, a Expansão alcança na hora, com um Acerto a mais: o do começo do turno do dono continua vindo. Você pode erguer de novo sem espera, mas da segunda vez em diante, na mesma Expansão, isso custa a Ação Padrão, e ele aguenta metade das rodadas (no mínimo 1).
>
> Requisito: ter visto um sendo usado, ou ter aprendido com alguém (anote na ficha de quem, ou onde); refino 5, ou refino 4 com o voto do iniciante. Classe Passiva 2. O refino escala o raio.

**Rodadas que o Domínio Simples aguenta**
{: .tab-titulo }

| a sua Essência, contra a do dono da Expansão | maior | igual | menor |
|---|---|---|---|
| rodadas que ele aguenta | `4` | `3` | `2` |
| erguendo de novo, na mesma Expansão | `2` | `1` | `1` |

O refino não entra nas rodadas: ele dá o raio. A mesa só fica sabendo das rodadas, então a Essência do dono da Expansão continua escondida, a não ser no empate.

Uma Expansão de refino 10 solta seis Acertos, então contra ela nenhum Domínio Simples aguenta até o fim, nem erguido de novo.

**O voto do iniciante.** Com refino 4 você só firma o Domínio Simples com um voto: ele fica no ponto em que você o ergueu, e se os seus dois pés saírem desse ponto ele se desfaz, e a Expansão alcança na hora quem ele protegia. Andar, ou ser empurrado, tira os pés do ponto. Quando o seu refino chega a 5 você larga o voto, e ele passa a andar com você.

O que a Expansão dá ao dono dela continua com o dono: o desconto nos feitiços e o que o Efeito dele permite fazer. A técnica dele entra no raio como técnica comum, rolando ataque e Teste de Resistência, e quem está preso no domínio continua preso.

### Pétala

> **Pétala** — a energia cobre o seu corpo e rebate o que encosta nela, energia contra energia. Quando o Acerto de uma Expansão toca você, o dano dele depende da sua Essência contra a do dono da Expansão: maior, ele não te fere; igual, você leva um quarto; menor, você leva metade. O que a Expansão traz por contato e não é dano, como agarrar, condição ou marca, ela anula de qualquer jeito.
>
> Ela levanta com uma Reação quando uma Expansão abre, ou com uma Ação Bônus no seu turno. Erguer custa a sua maior Classe em PE, toda vez que ela sobe, e de pé ela custa `1` PE por rodada.
>
> Ela cai pelos golpes em você. Cada golpe que te acerta, de qualquer um, pede o teste do `Carregar`: um Teste de Resistência de Espírito contra a CD de quem te feriu. Com metade da sua Essência em falhas (no mínimo 1), ela se desfaz. Esse teste não ocupa a sua Concentração, e a Mão Firme não protege dele.
>
> Quando ela cai, a Expansão não te alcança na hora: o próximo Acerto te pega inteiro se ela ainda estiver caída. Erguer de novo custa a Ação Bônus, com as falhas zeradas.
>
> Com uma arma corpo a corpo empunhada, ela contra-ataca. Quando um golpe corpo a corpo te acerta, você pode gastar a Reação num ataque de oportunidade com vantagem contra quem te acertou, se ele estiver ao seu alcance. Cada contra-ataque custa `3` PE. O soco não conta.
>
> Requisito: ser Descendente, ou ter aprendido com alguém de um clã; refino 4 e nível 10. Classe Passiva 2.

**Quanto a Pétala segura**
{: .tab-titulo }

| a sua Essência, contra a do dono da Expansão | maior | igual | menor |
|---|---|---|---|
| o dano do Acerto que toca, que você leva | nada | `1/4` | metade |

A Pétala só responde ao que toca: corte, chama, enxame, criatura, a mão de alguém. O Acerto que não encosta, como informação ou uma regra, passa por ela, e o que não é Acerto de Expansão também, como um soco. Contra a Expansão incompleta ela não faz nada, e fora de uma Expansão ela só serve para o contra-ataque.

### Extensão de Domínio

> **Extensão de Domínio** — você se envolve numa camada fina de domínio sem técnica dentro. Enquanto ela estiver de pé, nada do que uma Expansão faz te alcança: nem o Acerto dela, nem o que ela faz com as pessoas ou com o lugar, seja ela completa, incompleta ou sem barreiras. A barreira continua te prendendo, e o que a Expansão dá ao dono dela continua com ele.
>
> Ela levanta com uma Reação quando uma Expansão abre, ou com uma Ação Bônus no seu turno. Erguer custa a sua maior Classe em PE, toda vez que ela sobe; de pé, ela custa `1,5 × a sua maior Classe` de PE por rodada, e dura `refino` rodadas. Ela não cai por golpe.
>
> A técnica que encostar nela é anulada até `1/3 do refino + 1`: uma Classe Passiva, uma Regra Própria ou um feitiço de Classe até esse número. Acima dele, ela reduz o dano em um quarto, e você leva `3/4`.
>
> Enquanto ela estiver de pé, você não usa feitiço nem `Manejo`. Se a sua Expansão já estava aberta, ela continua; abrir uma nova derruba a Extensão.
>
> Requisito: ter visto uma sendo usada, ou ter estudado, ou aprendido com alguém; refino 7 e nível 18. O Corpo Amaldiçoado não compra. Classe Passiva 3. O refino escala a duração e o teto.

## Aptidões de barreira

> **As duas levam um minuto para levantar**, e um minuto são dez rodadas. As duas são ferramenta de preparação, e se levantam antes da briga começar.

### Barreira Simples

> **Barreira Simples** — um domo de raio `6 m`, ancorado no lugar onde você o ergueu, que bloqueia passagem e linha de efeito nos dois sentidos. Ele tem `5 × refino` de pontos de vida, e cai quando você fica `Inconsciente`.
>
> Requisito: nenhum. O refino escala a vida do domo.

O domo fica onde foi erguido. Você não leva ele junto, e é por isso que ele serve para fechar um cômodo, uma porta, uma escada.

### Cortina

> **Cortina** — mesma preparação de um minuto da `Barreira Simples`, exceto que ela cobre um lugar inteiro: um prédio, uma escola, um quarteirão. Ela esconde o que está dentro de quem não é feiticeiro, e você pendura uma condição sobre quem atravessa. Ela tem `40 × refino` de pontos de vida, e cai quando você fica `Inconsciente`.
>
> Requisito: exige a `Barreira Simples`. O refino escala a vida dela.

**Cortina**
{: .tab-titulo }

| a condição pode | a condição não pode |
|---|---|
| barrar uma pessoa específica | causar dano a quem entra |
| deixar entrar quem tem energia amaldiçoada, e mais ninguém | mover a cortina, ou fazer ela seguir você |
| impedir que quem está dentro saia | dar bônus a quem está dentro |
| deixar passar quem você nomeou na hora de levantar | esconder de quem é feiticeiro, porque o efeito base já é o contrário |

> **Tamanho.** A `Cortina` não se mede em metros: ela cobre um lugar — um prédio, uma escola, um quarteirão —, e nada do que ela faz depende de distância. Quem precisa fechar uma distância com energia usa a `Barreira Simples`, que tem raio.

## Escrever uma aptidão

### Aptidão Própria

A vaga em branco do catálogo. É o truque que o seu feiticeiro desenvolveu manejando a própria energia, pequeno o bastante para nunca ter virado regra escrita, e específico o bastante para ninguém mais na mesa fazer igual.

> **Aptidão Própria** — você escreve, com o mestre, uma aptidão que não está no catálogo. Antes da sessão, e nunca no meio dela. Ela é Classe Passiva 1 ou 2, nunca 3, e você só pode pegá-la uma vez na ficha inteira.
>
> A ficha registra duas coisas: a frase, e a resposta de *"em quantas cenas por arco isso vai importar?"*.
>
> Requisito: uma vez na ficha inteira. Classe Passiva 1 ou 2.

A resposta dessa pergunta é o que decide o degrau:

**Peso e degrau**
{: .tab-titulo }

| em quantas cenas por arco | o peso | o degrau |
|---|---|---|
| uma | Leve | Classe Passiva 1 |
| metade | Média | Classe Passiva 2 |
| quase toda | Pesada | Classe Passiva 3 |

> **Na dúvida, Pesada.** Pesada é Classe Passiva 3, e a Classe Passiva 3 está fora do que a `Aptidão Própria` alcança. Então dúvida reprova a proposta.

As cinco travas:

1. **Uma frase.**
2. **Verificável**: a mesa aponta o momento em que ela disparou.
3. **Não é atalho**: ela não repete uma das treze outras entradas do catálogo com outro nome, e não entrega uma que o seu requisito ainda não alcança.
4. **Sem dado de dano.**
5. **Com limite por cena**, se ela for Classe Passiva 2.

Três propostas, e uma delas é recusada:

**Exemplos de Aptidão Própria**
{: .tab-titulo }

| proposta | em quantas cenas | degrau | veredito |
|---|---|---|---|
| *"você sabe se um objeto foi tocado por energia amaldiçoada nas últimas 24 horas"* | uma por arco | Classe Passiva 1 | **passa** |
| *"uma vez por cena, quando um aliado a até 9 m falha um Teste de Resistência, ele rerrola"* | metade | Classe Passiva 2 | **passa** |
| *"o seu deslocamento é `+3 m`"* | quase toda | Classe Passiva 3 | **recusada** |

A trava é de forma e não de tamanho: `+3 m` é pouca coisa, e mesmo assim está fora. Uma coisa que fica sempre ligada é Classe Passiva 3, no tamanho que for.

> Quem quiser a mesma ficção com Classe Passiva 3 tem a `Passiva Própria`, do lado do Fundamento, pagando em espaço de feitiço.

## Expansão de Domínio

A regra da Expansão está no capítulo 9, *Fundamento*, e é lá que ela é montada. Ela gasta espaço de feitiço, como Passiva, e o Acerto dela é o que as três aptidões anti-domínio anulam — mais a `Extensão de Domínio`, que não é da categoria e anula o mesmo.
