# PERÍCIAS E TESTES FORA DE COMBATE

**Fase 4, quarta peça.** O que se rola quando não é feitiço.
Versão v0.12, encurtada na v0.21 — 06/08/2026

> **O quadro de perícias saiu daqui.** Ele mora na peça 7, com vinte e três perícias e onze ofícios — a lista de catorze que ficava aqui foi para `99-arquivo/`. **Atenção a uma mudança de casa:** desde a v0.16, **Sentir Energia e Percepção moram em Essência**, não em Inteligência. **O resto desta peça vale inteiro:** a rolagem, a escada de dificuldade, falhar move a cena, ajudar e rolar em grupo, e o ataque de oportunidade.

---

## 1. A rolagem

> **Perícia = d20 + atributo + maestria, se você for treinado.**
> **Sem treino, é d20 + atributo.**

Uma frase. Maestria é o que marca o treino — é o número que diz *isto aqui eu faço melhor que os outros*.

**E o treino tem um segundo grau, que se compra: a especialização.** *Do nível 10 em diante, a escolha `Corpo` do marco pode especializar uma perícia ou um ofício que você já treina, e aí você soma **metade da maestria** de novo naquela rolagem.* **A regra mora na peça 11 §3.** *Esta seção dizia "uma frase, sem exceção" desde a v0.12, e deixou de ser verdade na v0.212.*

### Por que o treino é a MESMA coisa nos dois — e por que já não foi

> **Perícia, ofício e Teste de Resistência: treinado soma maestria. Sem treino, só o atributo.**

*Isso mudou na v0.117, e a decisão anterior está registrada abaixo porque ela era boa e o que a derrubou foi um número, não uma opinião.*

**Até a v0.116 o treino valia `+2` fixo no Teste de Resistência e maestria na perícia**, e o motivo escrito era este: a CD de uma perícia é fixa pela dificuldade da tarefa — uma fechadura comum é a mesma fechadura no nível 2 e no 30 —, enquanto a CD de um Teste de Resistência cresce com quem conjura. *Se o treino também crescesse, quem não treinou ficaria para trás um ponto por vez.*

**A frase estava certa e a conclusão inverteu quando a CD passou a crescer `+6`.** *A peça 1 §5.0 tem a conta:* com `CD = 8 + atributo + maestria`, um TR de `atributo + 2` cai de `70%` para `55%` na campanha. **O `+2` fixo deixou de segurar o treinado; ele passou a afundar junto com o não-treinado.**

| | contra o quê | o que o treino soma | quem fica para trás |
|---|---|---|---|
| **Perícia · Ofício** | dificuldade fixa da tarefa | maestria | ninguém — o mundo não cresce |
| **Teste de Resistência** | CD que cresce `+6` | maestria | **o TR que você não treinou, `−15pp`** |

***Decisão do Mizuki: o não-treinado ficar para trás deixou de ser defeito e virou o preço.*** *Toda ficha treina dois Testes de Resistência de quatro, e os outros dois são o lugar por onde um chefe entra — cada vez mais, conforme a campanha anda.*

**A regra por trás continua sendo a mesma da peça 1: os dois lados de uma rolagem disputada precisam crescer no mesmo ritmo.** *Na perícia, um lado não cresce — então o outro pode crescer sozinho.* **No Teste de Resistência os dois crescem `+6`, e quem não paga o treino sai da igualdade de propósito.**

## 2. As duas escadas de dificuldade

**São duas, e a diferença entre elas é uma só: a coisa tem nível próprio ou não tem?**

*Escrita na v0.261, depois de o Mizuki apontar que o `fácil` da escada antiga não era fácil:* **"um cara com atributo bom, treinado, passa com seus 50% no começo do jogo. Isso n é facil".** *A medida deu razão a ele — o `fácil` dava `65%` e o `média` dava `45%` para o melhor personagem comum do nível 2.*

### 2.1 A escada fixa — para o que não tem nível

**Seis degraus, de quatro em quatro.** *A fechadura não fica mais difícil porque você ficou bom: é você que passa a abrir mais.*

| CD | dificuldade | um personagem bom e treinado, no nível 2 | no nível 30 |
|---|---|---|---|
| **6** | fácil | 95% | 100% |
| **10** | média | 75% | 100% |
| **14** | difícil | 55% | 85% |
| **18** | muito difícil | 35% | 65% |
| **22** | extrema | 15% | 45% |
| **26** | quase impossível | 0% | 25% |

**Esta é a escada que o mestre usa na maior parte das vezes**, *e é por isso que ela vem primeiro.*

> **O salto é de `4` e ele não varia.** *A escada antiga ia `10 · 12 · 16 · 20 · 26`, com pulos de `2`, `4`, `4` e `6` — irregular sem motivo.* **O D&D é a referência e ele usa salto constante de `5`;** *aqui o salto é `4` porque o nosso bônus é menor que o de lá, e a escada tem de caber numa banda mais estreita.*

> **O `quase impossível` continua em `26`, e o motivo é o mesmo de sempre:** *no nível 30 ele ainda é um quarto de chance.* **É o degrau reservado para o que deveria ser impossível e o jogador quer tentar mesmo assim.**

> **O `fácil` em `6` é quase automático, e isso é escolha.** *Um personagem competente raramente falha no que é fácil — era exatamente a queixa que abriu esta revisão.* **Quem não investiu no atributo nem treinou ainda falha `20%` das vezes ali**, *que é o que separa "quase automático" de "automático".*

### 2.2 A escada que acompanha — para o que tem nível

**Quando a coisa tem nível próprio, a CD sai da ficha de quem a fez.**

> **CD = `8` + o atributo dela + a maestria dela + o degrau.**

*É o mesmo molde da CD de feitiço da peça 1 §5 e da CD do inimigo da peça 26 §3.1 — o sistema já usa `8 + atributo + maestria` dos dois lados de toda rolagem disputada.*

| degrau | dificuldade | quem está no nível da coisa passa |
|---|---|---|
| **−4** | fácil | 85% |
| **−2** | média | 75% |
| **0** | difícil | 65% |
| **+2** | muito difícil | 55% |
| **+6** | quase impossível | 35% |

**Aqui a porcentagem não muda com o nível**, *porque o atributo e a maestria aparecem nos dois lados e se cancelam.* **Quem cresce não fica melhor nisso — ele passa a enfrentar coisa maior**, e é isso que a escada mede.

### 2.3 A fronteira, e ela é escrita para não virar discussão

**Tem nível próprio, e vai para a escada que acompanha:**

- **o que um feiticeiro fez** — uma barreira, um selo, um ritual, um objeto preparado
- **o que uma maldição é** — resistir ao que ela faz, entender o que ela é
- **o que a sua própria técnica exige de você** — o ritual da peça de Ritual é o exemplo

**Não tem nível, e vai para a escada fixa:**

- **o mundo** — uma porta, um muro, um rio, uma queda
- **o que se sabe** — de que família é aquele brasão, o que aquele símbolo quer dizer
- **gente comum** — convencer, enganar, intimidar quem não é feiticeiro

> **O teste é uma pergunta só: se um feiticeiro mais forte tivesse feito isso, estaria mais difícil?** *Se sim, tem nível. Se a coisa é a mesma não importa quem a fez, é fixa.*

> **⚠ E o custo disto está declarado:** *o mestre passa a escolher a tabela antes de escolher o degrau.* **O Pathfinder 2e paga o mesmo preço e pela mesma razão** — *ele tem a CD por nível e as `Simple DCs` lado a lado, porque usar só a que acompanha produz a esteira que a comunidade dele critica: arrombar a mesma fechadura continua precisando do mesmo número no nível 30.*

## 3. O quadro de perícias mora na peça 7

**Vinte e três perícias e onze ofícios**, em `07-pericias-e-oficios.md`. O Caminho dá duas perícias fixas e mais cinco à escolha livre; a Origem dá mais duas perícias e dois ofícios livres. Nove de vinte e três.

*Esta linha publicava `quatro à escolha` e `Oito de vinte e três` — os números de antes da v0.212 — e nenhum validador acendia, porque ela é prosa e a contagem que o `conferir-pericias.py` confere sai da peça 7.*

*A lista de catorze que ficava aqui foi para `99-arquivo/secoes-substituidas/`.*

Duas coisas que valem repetir, porque o resto desta peça depende delas:

**Inteligência não concede perícias extras**, ao contrário do costume d20. Ela já carrega conhecimento e um Teste de Resistência; dar perícias por Inteligência a empurraria de carregada para obrigatória, e um atributo obrigatório é o oposto de espalhar a ficha.

**O treino em Teste de Resistência não mudou desde a v0.12:** a **Origem treina um, o Caminho treina outro**. Dois de quatro. É aqui que a Origem deixa de ser só sabor.

## 4. Falhar move a cena

Esta seção é curta e é a mais importante do documento para uma Guilda com cinco a sete mestres.

**Uma falha nunca resulta em "não acontece nada".** Se o resultado de errar for a cena parar no mesmo lugar, o teste não deveria ter sido pedido.

Uma falha entrega uma destas três coisas:

- **Custo.** Você consegue, mas paga — tempo, barulho, um ferimento, um recurso.
- **Complicação.** Você consegue, e alguma coisa piora junto.
- **Informação indesejada.** Você não consegue, mas descobre por quê, e isso abre outro caminho.

A regra existe por dois motivos. O primeiro é ritmo: mesa que trava em teste falhado morre. O segundo é o que importa para a Guilda — **é a norma que faz cinco mestres diferentes falharem do mesmo jeito.** Sem ela, um mestre trava a cena e outro dá de graça, e o mesmo personagem tem experiências incompatíveis em duas mesas.

E o corolário: **se você não consegue nomear o custo antes de pedir a rolagem, não peça.** Deixe acontecer.

## 5. Ajudar e rolar em grupo

> **Vantagem não empilha: duas fontes valem uma.** *Desvantagem também não, e uma vantagem com uma desvantagem se cancelam — você rola um d20 e pronto.*

**⚠ Esta linha estava publicada no livro e em peça nenhuma, e duas peças apontavam para cá como se ela estivesse escrita.** *A peça 14 §2 preça o Traje dizendo que vantagem "**não empilha** pela peça 4 §5", e o que o §5 escrevia era só o caso do `Ajudar` — dois ajudantes.* **De um caso particular ninguém deriva a regra geral**, e a v0.171 precisou dela para o teto da `Cicatriz`, na peça 1 §5.5. *Achada pelo próprio validador, indo procurar o dono e não achando nenhum.*

**Ajudar:** um personagem que possa contribuir de verdade dá vantagem ao teste de outro. Um por teste — dois ajudantes não dão vantagem duas vezes, que é a regra acima aplicada ao caso mais comum da mesa. **Custa a Ação Padrão** — o slot está na peça 3 §3.1, e esta seção passou sete versões escrevendo a regra sem nunca dizer em que ação ela acontece. *O `Mão na Roda` do Guia, no nível 7, é a exceção: para aquele Caminho o `Ajudar` vira Ação Bônus.*

**Teste de grupo:** quando o grupo inteiro precisa passar por algo — atravessar sem ser notado, aguentar o frio —, metade do grupo passando resolve. Isso impede que o personagem de Destreza 1 arruine sozinho a furtividade de quatro pessoas, sem precisar que ele finja ser bom nisso.

## 6. O ataque de oportunidade, e por que ele não pode ser feitiço

Ficou pendente da peça anterior, e a conta responde.

**Ataque de oportunidade é ataque físico.** Rola como um ataque comum — d20 + Força para corpo a corpo — e custa a Reação.

Conjurar na Reação continua exigindo a Melhoria **Reação**, que custa Pesada. E o motivo é aritmético:

| Classe do feitiço | custo da Melhoria Reação | quanto isso é do orçamento |
|---|---|---|
| 1 | 2 de 3 pontos | 67% |
| 3 | 5 de 9 pontos | 56% |
| 5 | 8 de 15 pontos | 53% |
| 7 | 11 de 21 pontos | 52% |

A Melhoria custa **metade do feitiço**. Se qualquer feitiço pudesse virar ataque de oportunidade de graça, a Melhoria Reação viraria peça morta na hora — dominância direta, do tipo que o catálogo inteiro foi calibrado para evitar.

Um conjurador **pode** fazer ataque de oportunidade, com soco ou arma, como qualquer um. E uma **trilha de Caminho** pode abrir a exceção limitada — conjurar na reação sob condição estreita, uma vez por cena, ou só com feitiço de Classe baixa. Aí é um recurso pago por um caminho específico, não um bônus universal, e a Melhoria continua valendo o que vale.

## 7. Em aberto

- **Se Força precisa de um segundo trabalho.** Uma perícia é pouco, e a lista de vinte e três não consertou.
- ~~**Se treino em perícia tem graus** (treinado, especialista, mestre) ou é binário. Binário por ora — graus adicionam uma escada nova para pouco ganho, e a maestria já cresce.~~ ***FECHADO na v0.212, e este aviso só saiu na v0.263.*** **São dois graus: treinado soma a maestria, especializado soma metade dela de novo** — *comprado pela escolha `Corpo` do marco, do nível 10 em diante, na peça 11 §3.* **O motivo do "por ora" foi respeitado:** *a especialização não abriu escada nova, ela é a mesma maestria pela metade.* *Foram cinquenta e uma versões com as duas peças discordando, e nenhuma checagem comparava.*
- **Quantas trilhas de Caminho abrem exceção de conjuração na reação**, e sob que condição.

*Resolvido e tirado daqui:* a lista de catorze virou o quadro de **vinte e três perícias e onze ofícios** da peça 7.
