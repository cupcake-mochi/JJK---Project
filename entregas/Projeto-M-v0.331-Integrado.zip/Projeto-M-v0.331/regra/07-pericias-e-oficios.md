# PERÍCIAS E OFÍCIOS

**Fase 4, sétima peça.** O quadro completo do que o personagem sabe fazer fora da técnica.
Versão v0.16, ampliada na v0.17 e na v0.22, corrigida na v0.24 — 08/08/2026

Esta peça substitui a seção 3 e a seção 4 da peça 4. O resto daquela peça — a escada de dificuldade, falhar move a cena, ajudar e rolar em grupo, o ataque de oportunidade — continua valendo inteiro.

---

## 1. Duas listas, não uma

O personagem tem **perícias** e **ofícios**. São coisas diferentes e a diferença é fácil de errar, então ela vem primeiro.

**Perícia** é uma capacidade do corpo ou da cabeça. Ela pertence a um atributo e só a esse atributo. Correr é Atletismo, e Atletismo é sempre Força.

**Ofício** é uma prática que alguém te ensinou. Ele não pertence a atributo nenhum — o atributo muda conforme o que você está fazendo com ele.

| É perícia | É ofício |
|---|---|
| Escalar um muro | Dirigir a van até o muro |
| Saber que aquilo é uma maldição de segundo grau | Desenhar o talismã que segura ela |
| Convencer o clã a te receber | Preencher a requisição que abre a porta |
| Notar o cheiro de sangue na sala | Fazer o chá que faz o ferido dormir |

A regra prática: **se é uma ferramenta ou um procedimento que alguém te ensinou passo a passo, é ofício.** Ferramenta pode ser a chave de fenda, o papel de talismã ou o formulário certo — Burocracia é ofício pelo mesmo motivo que Forja é.

## 2. Como se rola

> **Perícia = d20 + o atributo dela + maestria, se você for treinado.**
> **Sem treino, é só d20 + o atributo.**

> **Ofício = d20 + o atributo que a situação pede + maestria, se você for treinado.**
> **Sem treino, você normalmente não consegue tentar.**

Duas diferenças, e as duas têm motivo.

**A perícia tem atributo fixo; o ofício não.** Forjar uma lâmina é Força. Falsificar uma assinatura é Destreza. Saber qual selo o papel pede é Inteligência — e as três coisas são o mesmo ofício. O mestre escolhe o atributo na hora, do mesmo jeito que escolhe a dificuldade.

**Perícia sem treino você tenta; ofício sem treino, não.** Qualquer um pode tentar escalar e falhar. Ninguém forja uma lâmina por tentativa. Quando o mestre achar que dá para improvisar — dirigir um carro automático em linha reta, fazer um curativo torto —, ele libera a rolagem sem a maestria.

**Exemplo.** A Rina é uma Vanguarda de nível 6. Destreza 4, Inteligência 2, maestria 1. Ela é treinada em Furtividade e no ofício Arrombamento.

Ela quer entrar num depósito sem ser vista. Furtividade é Destreza: `d20 + 4 + 1 = d20 + 5`. Contra a CD 18 de uma média, ela passa em 40% das vezes.

Chegando na porta, ela usa Arrombamento. O mestre decide que forçar aquela tranca é trabalho de mão, então cobra Destreza: `d20 + 4 + 1` de novo. Se fosse uma tranca eletrônica, ele teria cobrado Inteligência, e o mesmo ofício renderia `d20 + 2 + 1` — três a menos, porque ela é boa com as mãos e não com o sistema.

## 3. Inteligência sabe, Essência percebe

Esta frase decide onde cada perícia mora, e ela existe porque a divisão anterior não sobrevivia à mesa.

**Inteligência é o que você estudou.** O catálogo de maldições, o que aconteceu, como o corpo funciona, quem manda em quem.

**Essência é o que você capta.** A energia no ar, o barulho no corredor, a mentira na voz de alguém.

Antes da v0.16, Sentir Energia e Percepção moravam em Inteligência, e isso vinha de uma decisão boa que envelheceu mal: quando Sabedoria e Carisma fundiram em Essência, a percepção foi para Inteligência para tirar dela o papel de atributo-depósito.

Mas Essência não *sabe* nada — ela **sente**. Sentir energia amaldiçoada é a sua energia reagindo à de outro, e isso não é análise, é ressonância. Na obra, quem sente bem não é quem estuda mais: é o Gojo com os Seis Olhos, é a Nobara, é o instinto do Todo. E existe o contrário — gente que sabe tudo de teoria e não sente nada chegando.

O ganho prático é maior do que parece. Comparando o **peso de mesa** de cada atributo — quanto do que se rola numa campanha depende dele —, e não a contagem crua:

| | perícias em Int | perícias em Ess | peso de mesa (Int / Ess) |
|---|---|---|---|
| antes | 10 de 20 | 5 de 20 | **56% / 21%** |
| agora | 11 de 23 | 7 de 23 | **39% / 39%** |

Inteligência ficou com *mais* perícias do que antes e **vale menos**, porque as duas que saíram são as duas mais roladas da mesa. Contagem não é valor.

## 4. As vinte e três perícias

Nenhuma delas mora em Constituição. Constituição governa os **pontos de vida** e o Teste de Resistência Vigor, e isso é trabalho suficiente para um atributo.

*Vale registrar que essa frase só passou a ser verdade na v0.17.* Até lá, três documentos diziam que Constituição governava vida e nenhum dizia quanto — a única fórmula existente, a do manual, não tinha atributo nenhum. O argumento que tirava as perícias dela era um trabalho que ela não tinha. A fórmula está na peça 1, seção 5.1.

| Atributo | Perícias | |
|---|---|---|
| **Força** | Atletismo | 1 |
| **Destreza** | Acrobacia · Furtividade · Pontaria · Prestidigitação | 4 |
| **Inteligência** | Investigação · Intuição · Ocultismo · Religião · História · Hierarquia · Medicina · Sobrevivência · Natureza · Lidar com Animais · Tecnologia | 11 |
| **Essência** | **Sentir Energia** · Percepção · Persuasão · Enganação · Intimidação · Atuação · Provocar | 7 |
| **Constituição** | — | 0 |

### O que cada uma cobre

**Atletismo** — correr, escalar, nadar, saltar, carregar alguém que não consegue andar.

**Acrobacia** — equilíbrio, cair sem se machucar, escapar de um agarrão, passar por espaço apertado.
**Furtividade** — mover-se sem ser visto nem ouvido.
**Pontaria** — acertar o que é pequeno, o que está longe ou o que se mexe, fora de uma rolagem de ataque.
**Prestidigitação** — mão rápida: esconder um objeto, tirar do bolso alheio, trocar uma coisa por outra na frente de quem está olhando.

**Investigação** — vasculhar, deduzir, ligar duas pistas que ninguém tinha ligado.
**Intuição** — ler a pessoa pelo que ela faz: a inconsistência na história, o detalhe que não fecha, a motivação atrás do pedido. É dedução sobre gente, e por isso é Inteligência — perceber que alguém está nervoso é Percepção.
**Ocultismo** — maldições, técnicas conhecidas, barreiras, o funcionamento da energia amaldiçoada. O lado técnico.
**Religião** — xintoísmo, budismo, exorcismo, templo, ritual, o que os selos querem dizer. O lado sagrado, que é de onde o jujutsu veio antes de virar instituição.
**História** — o que aconteceu e quem estava lá, no mundo comum e no registro das famílias.
**Hierarquia** — os clãs, a política, quem manda em quem e quem deve o quê a quem. Diz o que você pode pedir, a quem, e o que vai custar.
**Medicina** — ferimento, veneno, doença, corpo. O saber; a prática de campo é o ofício Herbalismo.
**Sobrevivência** — aguentar o ambiente, achar água e abrigo, se orientar, e **seguir um rastro**, seja pegada ou resíduo de energia.
**Natureza** — planta, bicho, clima, terreno. O que é o quê, o que é venenoso, quando a chuva vem.
**Lidar com Animais** — acalmar, montar, conduzir, mandar num bicho. Vale para o que não é bicho mas se comporta como um.
**Tecnologia** — computador, câmera, rede, equipamento moderno.

**Sentir Energia** — perceber energia amaldiçoada. Notar o feiticeiro escondido, medir o tamanho de uma maldição antes de encostar nela, sacar que alguém está prestes a conjurar. É a perícia mais rolada da mesa, e em Jujutsu Kaisen quem não sente energia morre por não ter sentido.
**Percepção** — notar o mundano: som, cheiro, movimento, a coisa que está fora do lugar, a pessoa suando frio.
**Persuasão** — convencer, negociar, conseguir que façam o que você quer porque querem.
**Enganação** — mentir, blefar, se passar por outro.
**Intimidação** — ameaçar, dominar pela presença, fazer alguém **recuar**.
**Atuação** — representar, cantar, tocar para uma plateia, sustentar um personagem que não é você.
**Provocar** — tirar alguém do sério, fazer perder a linha, forçar a vir para cima de você. É o oposto de Intimidação: uma faz recuar, a outra faz **avançar**.

### Onde foi parar "analisar a técnica do inimigo"

Não existe perícia para isso, e é de propósito — são duas coisas diferentes e cada uma já tem casa.

**Ocultismo** reconhece o que você está vendo porque você conhece o catálogo. *"Isso é uma técnica de troca, e troca sempre tem um custo."*

**Sentir Energia** lê como a energia se move, mesmo sem saber o nome do que está acontecendo. *"Ela gasta muito no começo de cada golpe. Se eu forçar três seguidos, ela seca."*

O Nanami faz a primeira. O Todo faz a segunda.

### Sobre o nome "Provocar"

O manual usa *"sem provocar ataque de oportunidade"* em três lugares. **Colisão registrada e aceita:** a expressão é comum demais em qualquer mesa de d20 para gerar confusão real, e "provocar ataque de oportunidade" e "rolar Provocar" nunca aparecem no mesmo tipo de frase. Fica anotado no validador com o motivo, para não virar surpresa quando alguém reler o material daqui a seis meses.

## 5. Os onze ofícios

**Condução** — carro, moto, van, o que estiver na garagem.
**Arrombamento** — tranca, alarme, cofre, janela que não devia abrir.
**Herbalismo** — planta que cura, planta que mata, chá, unguento, e o que dá para fazer no mato quando não tem hospital.
**Forja** — fazer, afiar e manter arma, e cuidar de ferramenta amaldiçoada sem estragar o que tem dentro.
**Caligrafia** — talismã, papel de barreira, documento oficial. E documento oficial que não é oficial.
**Burocracia** — a máquina jujutsu por dentro: relatório, requisição, quem assina o quê, como se pede uma janela e como se encobre o que não devia ter sido visto.
**Entalhador** — madeira, pedra, osso. Fazer o corpo que vai receber alguma coisa.
**Alfaiate** — tecido, corte, remendo. O uniforme que aguenta energia amaldiçoada sai daqui, e o traje sob medida também — o de prateleira veste todo mundo e ninguém.
**Culinária** — cozinhar de verdade, para gente ou para o que aceitar comida.
**Instrumento** — um instrumento, escolhido no treino.
**Jogatina** — carta, dado, aposta, e ler a mesa enquanto joga.

### O atributo padrão de cada ofício

*Escrito na v0.104.* **Ofício continua não pertencendo a atributo nenhum — o que ele ganhou foi um padrão, para a mesa não parar em toda rolagem.**

> **Cada ofício tem um atributo padrão. O mestre troca quando a ficção pedir, e diz qual antes da rolagem.**

**O padrão não foi escolhido a gosto: cada ofício herda o atributo da perícia que mora mais perto dele.**

| ofício | atributo padrão | a vizinha que decide |
|---|---|---|
| **Condução** | Destreza | `Acrobacia` — é o corpo reagindo rápido |
| **Arrombamento** | Destreza | `Prestidigitação` — é mão fina em coisa pequena |
| **Caligrafia** | Destreza | `Prestidigitação` — o traço é da mão; *o que* o selo diz é `Religião` ou `Ocultismo`, que são perícia |
| **Entalhador** | Destreza | `Prestidigitação` — trabalho fino em material duro |
| **Alfaiate** | Destreza | `Prestidigitação` — corte e costura |
| **Forja** | Força | `Atletismo` — martelo, bigorna e peso |
| **Herbalismo** | Inteligência | `Medicina` e `Natureza`, as duas |
| **Burocracia** | Inteligência | `Hierarquia` — é a mesma máquina, vista por dentro |
| **Culinária** | Inteligência | `Natureza` — proporção, tempo e o que é o quê |
| **Instrumento** | Essência | `Atuação` — *"tocar para uma plateia"* está escrito lá |
| **Jogatina** | Essência | `Percepção` e `Enganação` — ler a mesa é ler gente |

**Cinco em Destreza, três em Inteligência, duas em Essência, uma em Força — e nenhuma em Constituição.** *Constituição não tem perícia nem ofício: ela paga pontos de vida, e a peça 1 §4 já decidiu isso com o motivo escrito.*

> **A cláusula que importa é a última: o mestre diz qual atributo ANTES da rolagem.** *Sem ela o padrão não resolve nada — trocar depois de ver o dado é a mesma discricionariedade com um passo a mais.* **É o mesmo molde do *"o mestre declara o que foi uma luta"* da peça 10 §4:** a decisão continua sendo dele, e o que a regra exige é que ela seja anunciada.

Forjar uma lâmina é **Força**, falsificar uma assinatura é **Destreza**, e saber qual selo o papel pede é **Inteligência**. As três continuam sendo o mesmo ofício. *O padrão diz de onde a mesa parte, não onde ela tem que ficar.*

**Primeiros Socorros saiu, e Herbalismo não cobre o mesmo.** Estancar sangue no meio da missão deixa de ser rolagem e vira cena: ou alguém tem cura de verdade, ou a consequência acontece. É a leitura da obra — quem conserta gente é a Shoko e a Energia Reversa, não um curativo bem feito.

## 6. De onde vem o treino

> **O Caminho dá duas perícias fixas e mais cinco à sua escolha, de qualquer uma da lista de perícias do sistema.**
> **Nos três Caminhos que não treinam arma de verdade, duas das cinco à sua escolha se trocam por treino em UMA arma** — não a categoria, não o tipo: uma arma da lista. **A troca pode se repetir uma segunda vez, com outras duas das cinco — até duas armas, nunca mais.**
> **A Origem dá mais duas perícias: uma da lista de quatro dela, e uma livre — de fora das sete que o Caminho te deu.**
> **Mais dois ofícios à sua escolha, e os dois se trocam por mais uma perícia livre.**

**Nove perícias de vinte e três e dois ofícios de onze** — ou dez e nenhum, se você trocar os dois ofícios da Origem por mais uma perícia. *E sete e dois, mais uma arma, para quem faz uma troca de arma — ou cinco e dois, mais duas armas, para quem faz as duas.*

As duas fixas são a assinatura do Caminho — o que qualquer um daquele Caminho sabe fazer. As cinco livres são suas.

| Caminho | Perícias fixas |
|---|---|
| **Bastião** | Atletismo · Provocar |
| **Vanguarda** | Acrobacia · Percepção |
| **Guia** | Persuasão · Medicina |
| **Emanador** | Ocultismo · Investigação |
| **Evocador** | Religião · Lidar com Animais |
| **Incursor** | Acrobacia · Intuição |

**O Caminho não dá ofício, e quem dá é a Origem.** *Os dois ofícios moraram no Caminho da v0.105 até aqui, e antes disso cada Caminho fixava um — Forja no Bastião, Arrombamento na Vanguarda, Herbalismo no Guia, Caligrafia no Emanador, Entalhador no Evocador.*

**Os dois passos foram na mesma direção, e o segundo termina o serviço do primeiro.** *A v0.105 já tinha escrito o motivo:* **o que um personagem faz com as mãos fora da luta não é assinatura de Caminho.** *Ela desamarrou qual ofício, e deixou a entrega onde estava.* **Ofício é uma prática que alguém te ensinou — e quem te ensinou é o seu passado, não a sua rota de combate.** *A Origem é o lugar do sistema onde o passado tem endereço: é ela que já entrega a perícia que a sua história justifica, o traço e os Legados.*

**A escolha continua livre, e a conta não se move.** *Dois de onze antes, dois de onze agora — o que muda é de onde eles vêm.* **O que se ganha é a pergunta que a mesa passa a fazer:** *não "que ofício eu quero", e sim* **"o que na minha história me deu isso"**. *Cada Origem carrega um gancho para essa resposta, na peça 9.*

**Sentir Energia não é fixa de ninguém, e isso é escolha.** Ela é a mais rolada da mesa; fixá-la num Caminho daria àquele Caminho uma escolha livre a mais disfarçada. Livre para todos, ela vira decisão de ficha — e **o feiticeiro ruim de sentir energia passa a caber**, que é o Itadori do começo e é uma coisa boa de existir.

**O Evocador entalha o corpo que vai receber a invocação.** É o ofício que dá razão de existir para os shikigami de madeira e para a boneca que anda.

### O que a Origem dá

**Uma perícia da lista de quatro da sua Origem, e uma perícia livre** que a sua história justifique. Foi filho de médico, tem Medicina. Batia carteira antes de saber o que era energia amaldiçoada, tem Prestidigitação.

**E os dois ofícios**, livres, que se trocam por mais uma perícia livre. *O quadro do topo desta seção é o dono da conta.*

> *Este parágrafo dizia o contrário — que a Origem não dá ofício e que "o ofício ficou com um dono só, que é o Caminho". **É o texto da v0.212, que a v0.216 virou de lado e esqueceu aqui**, na mesma seção da frase que diz o certo.* **A checagem `6.1` do `conferir-criacao.py` lia as duas declarações e ficava com a primeira que achasse**, então a peça declarava dois donos e saía verde. *Achado na v0.263, e desde ela a `6.1` reprova quando as duas estão escritas. O "v0.211" daqui também estava errado: a mudança é da v0.212.*

*O catálogo das Origens está na peça 9, com a lista de cada uma.*

### Testes de Resistência

Sem mudança desde a peça 4: **a Origem treina um, o Caminho treina outro.** Dois de quatro, e treinado vale **maestria** — a mesma marca de treino da perícia e do ofício. *Isso mudou na v0.117, e o motivo está na peça 4, seção 1: a CD de um Teste de Resistência passou a crescer `+6`, então o treino tem de crescer junto. **O que fica para trás é o TR que você não treinou, e isso é o preço.***

## 7. Por que vinte e três, e por que cinco livres

A lista antiga tinha catorze, e ela não aguentava um Caminho generoso.

| lista | treinadas | fração |
|---|---|---|
| 14 (peça 4) | 9 | **64%** |
| 23 | 9 | **39%** |

Com 64%, o personagem sai treinado em quase tudo que existe e **"ser treinado" para de significar alguma coisa.** Pior: não sobra em que o resto do grupo brilhar. Se todo mundo tem Investigação, ninguém é o investigador.

Com 39%, o personagem é bom em pouco mais de um terço do quadro. Ele tem buracos, o grupo cobre os buracos um do outro, e a mesa passa a ter conversa sobre quem faz o quê.

**A faixa é de `30%` a `42%` de perícias treinadas, e ela vale para a rota de base** — *o que a regra dá antes de qualquer troca, as nove do §6.* **Abaixo dela a ficha esvazia; acima, "ser treinado" para de significar alguma coisa.** ***Decisão do Mizuki na v0.263: as duas trocas do §6 ficam fora dela.*** *Trocar os dois ofícios por uma perícia empurra a fração para cima dela, e trocar perícia por arma empurra para baixo.* **A troca é do jogador e tem preço escrito**, *então o `conferir-pericias.py` imprime a fração de cada rota e só julga a de base.*

> *Até a v0.263 a faixa morava só no validador, escrita na v0.27 — antes das duas trocas existirem —, e ele nunca mediu nenhuma delas: com o extra da Origem zerado, as duas rotas que ele imprimia eram a mesma. Esta tabela e a frase de cima diziam `8` e `35%`, a conta de antes da v0.212.*

**Cinco das sete do Caminho são livres**, e é o que impede duas fichas do mesmo Caminho de serem a mesma pessoa. O Caminho ainda diz alguma coisa — as duas fixas —, mas ele não escolhe o personagem por você. Dois Bastiões dividem Atletismo e Intimidação e podem não ter mais nada em comum.

Os ofícios ficam entre **0% e 18% de propósito — nenhum ou dois de onze**, conforme o jogador trocar os dois da Origem por mais uma perícia. Ofício é para ser raro. O grupo que precisa arrombar uma porta e não tem ninguém com Arrombamento tem um problema real, e problema real é cena.

*Eram dois de dez, 20%, até o **Alfaiate** entrar com a peça de equipamento.* A fração caiu e isso **não é deriva**: a frase diz que ofício é para ser raro, e onze opções com duas treinadas é mais raro que dez com duas. A conta de criação não mudou — o que mudou foi o tamanho do quadro.

> **⚠ E o `de dez` sobreviveu em dois lugares até a v0.104.** *Esta seção foi corrigida quando o `Alfaiate` entrou, e o §6 desta peça e a tabela das duas rotas da peça 8 §Passo 6 não foram — as duas continuaram publicando `de dez` por sete versões.* **O `conferir-criacao.py` lia aquelas linhas e conferia só o numerador**, então o denominador podia envelhecer à vontade. *Hoje ele lê os dois, contra a contagem desta peça.* **É a checagem medindo pelo eixo errado, de novo.**

## 8. O que mudou em relação à peça 4

| | peça 4 | agora |
|---|---|---|
| Perícias | 14 | 23 |
| Ofícios | não existiam | 11 |
| Caminho dá | 3 perícias | 2 fixas + 5 livres |
| Origem dá | 2 perícias | 2 perícias, mais 2 ofícios livres |
| Treinadas | 5 de 14 (36%) | 9 de 23 (39%) |
| Perceber mora em | Inteligência | **Essência** |
| Força tem | 1 perícia | 1 perícia |

**Força continua com uma só, e a lista não conserta isso.** Nenhuma perícia nova cabia nela sem enchimento: correr, escalar e carregar já são Atletismo, e aguentar dor e fome é leitura de Constituição em qualquer mesa. O segundo trabalho de Força tem que vir de fora do quadro de perícias — o requisito de arma e de proteção da peça 6 já é um, e somar em pontos de vida continua sendo o conserto barato se doer no playtest.

Três perícias antigas foram partidas em duas: **Ocultismo** perdeu o lado sagrado para **Religião**, **Sobrevivência** perdeu o lado de conhecimento para **Natureza**, e **Táticas** deixou de existir porque o trabalho dela já estava coberto por Ocultismo e Sentir Energia.

## 9. Em aberto

- ~~**Se a perícia livre da Origem devia ser da lista também.**~~ **Fechado na v0.104, na peça 9 §2:** ela continua livre e perdeu a aprovação do mestre; a trava passou a ser *não pode ser uma das seis que o seu Caminho te deu*. ***O `8 de 23` do §6 já supunha isso*** — com repetição a ficha teria `7 de 23`, que são `30%` e não os `35%` em que o §7 apoia o argumento inteiro de por que são vinte e três perícias.
- **Intuição é a única que fica em cima do muro.** "Ler a pessoa" tem cara de perceber, e ela está em Inteligência como dedução. Se em mesa as pessoas rolarem Percepção quando deviam rolar Intuição, ela muda de casa.
- **Se cinco livres é escolha demais.** *Eram quatro até a v0.212, e a quinta entrou junto com a troca por treino de arma.* Ela deixa o Caminho quase invisível na ficha de perícia. Medir se as pessoas do mesmo Caminho ainda parecem coisas diferentes — e se parecem *demais*.
- **Se Pontaria se sobrepõe à rolagem de ataque à distância.** As duas são Destreza e as duas acertam alvo. Se ninguém rolar Pontaria, ela sai.
- **Provocar e Intimidação vão brigar?** Uma faz recuar, a outra faz avançar. A distinção é clara escrita e vaga na mesa.
- ~~**Se o extra da Origem é escolha de igual para igual.**~~ ***FECHADO na v0.212, e não pela resposta:*** *o extra deixou de existir.* **A Origem parou de dar o extra, o Caminho passou a dar cinco perícias à escolha em vez de quatro, e o ofício ficou com um dono só** — *o Caminho, até a v0.216 trocar esse dono pela Origem.* *A pergunta media a equivalência entre duas coisas que não são equivalentes — perícia sem treino se rola, ofício sem treino não —, e a saída foi tirar a escolha em vez de preçá-la.*
