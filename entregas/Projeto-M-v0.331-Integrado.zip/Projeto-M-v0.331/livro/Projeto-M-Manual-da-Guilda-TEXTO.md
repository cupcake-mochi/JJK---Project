# Projeto M — Manual da Guilda

*RPG de mesa de Jujutsu Kaisen. Texto corrido para revisão: sem diagramação, na mesma ordem do PDF.*

*As seções “Notas de revisão” dos arquivos-fonte não entram aqui, igual não entram no PDF.*


---


# Bem-vindo à Guilda

*fonte: `manual/05-introducao.md`*

Você vai criar um feiticeiro. Alguém que nasceu com energia amaldiçoada, ou que aprendeu a lidar com quem tem, e que agora anda entre o mundo comum e o mundo jujutsu: o das maldições, dos clãs, da instituição que treina quem sobrevive aos dois.

Este é um sistema de mesa feito para um servidor de guilda. Várias pessoas mestrando, e personagem que atravessa mesas diferentes. A ficha que você monta aqui pode sentar em mais de uma mesa, com mestres diferentes, e continuar sendo a mesma ficha.

## Material da mesa

- **Um mestre.** Quem prepara a cena, interpreta todo mundo que não é personagem de jogador, e decide o que as regras não cobrem.
- **Um grupo.** De cinco a sete jogadores, com dois a três mestres é o tamanho que este sistema pressupõe, mas qualquer grupo funciona.
- **Dados.** Um d20 e um punhado de d8 resolvem quase tudo. Aparecem também d4, d6, d10 e d12, quase sempre como dado de dano de arma.
- **Uma ficha.** Papel, planilha ou o que a sua mesa usar.

## Organização do manual

Nem todo capítulo é para ler do começo ao fim. Metade dos capítulos é catálogo, e catálogo se abre quando você está montando alguma coisa. A coluna *Para quê* diz qual é qual.

**Capítulos**
| | Capítulo | Para quê |
|---|---|---|
| | **O vocabulário do sistema** | *consulta* · toda palavra que este manual usa com significado próprio, em uma linha |
| | **Antes da primeira sessão** | *cena pronta* · uma ficha e um combate guiados, para jogar hoje sem ter lido o resto |
| | **O JOGO** | |
| **1** | Como Jogar | *ler* · o dado, o teste, o acerto, a defesa, e o que acontece quando a vida acaba |
| **2** | O Turno | *ler* · a iniciativa e as doze ações |
| **3** | Perícias e Ofícios | *ler, depois consultar* · as vinte e três perícias e os onze ofícios |
| **4** | Dano, Condições e Cobertura | *consulta* · os catorze tipos de dano, as treze condições, e a mureta no meio do caminho |
| **5** | Descanso e Recuperação | *ler* · o que volta entre uma luta e a seguinte |
| | **O PERSONAGEM** | |
| **6** | Criação de Personagem | *ler, com a ficha na mão* · oito passos, de vinte a quarenta minutos |
| **7** | Origens e Legados | *consulta* · de onde vem o seu poder, e o que você já trazia |
| **8** | Caminhos e Trilhas | *consulta* · o seu lugar numa equipe |
| **9** | Fundamento | *ler uma vez, depois consultar* · a sua técnica, e como se monta feitiço com ela |
| **10** | Técnica Marcial | *consulta* · a mesma máquina do Fundamento, com o corpo e o equipamento no lugar da energia |
| **11** | Sem Técnica | *consulta* · a mesma máquina, para quem nasceu sem técnica inata |
| **12** | Aptidões e Refino | *consulta* · o que qualquer feiticeiro pode aprender, técnica à parte |
| **13** | Ritual | *consulta* · o que um feitiço ganha quando você para de omitir |
| **14** | Bênçãos e Lapidação | *consulta* · o que entra no lugar dos dois para quem não tem energia amaldiçoada |
| **15** a **16** | Equipamento · Ferramenta Amaldiçoada | *consulta* · o que você carrega |
| **17** | Invocações | *consulta* · montar entidades, manifestar e comandar |
| **18** | Pactos | *consulta* · o que você troca com a sua própria energia, e o que ela cobra |
| | **A CAMPANHA** | |
| **19** | Experiência e Progressão | *consulta* · o que cada nível entrega, do 1 ao 30 |
| | **Índice remissivo** | no fim: termo, e em que página ele aparece |

**Grupo novo, sem ninguém ter lido nada?** Vá direto para *Antes da primeira sessão*. É uma cena pronta, com ficha e tudo, para jogar antes de estudar o resto.

**Leia Como Jogar antes de qualquer outra coisa.** É o capítulo dono do vocabulário que todos os outros usam. Depois dele, pular direto para o que te interessa.

**E se esbarrar num nome que ninguém te apresentou**, ele está no vocabulário do sistema, com o número do capítulo que trata dele por extenso.

---


# O vocabulário do sistema

*fonte: `manual/07-glossario.md`*

Cada termo vem com uma linha de explicação e o número do capítulo que trata dele por extenso. Nada aqui é regra completa.

## Rolagens

**Rolagens**
| Termo | O que é | Cap. |
|---|---|---|
| **Teste** | `d20` + atributo, comparado com uma CD. Igualou ou passou, você conseguiu | 1 |
| **CD** | O número que a tarefa pede. Quem diz qual é o mestre, numa escada de 10 a 26 | 1 |
| **Vantagem** | Role dois `d20` e fique com o melhor | 1 |
| **Desvantagem** | Role dois `d20` e fique com o pior | 1 |
| **Maestria** | Bônus que mede tempo de estrada. Começa em 1 e sobe a cada oito níveis. Entra em toda rolagem de ataque, na CD dos seus feitiços, e no que você treinou — perícia, ofício e Teste de Resistência | 1 |
| **Teste de Resistência** | O que **você** rola quando algo acontece com você. São quatro: Físico, Vigor, Intelecto e Espírito | 1 |
| **Defesa** | `10` + Destreza + proteção. O número que o inimigo precisa alcançar para te acertar | 1 |
| **Crítico** | `20` natural numa rolagem de acerto. Dobra os dados da arma ou da Classe, e nada mais | 1 |
| **`Bloquear`** | Ao ser atacado, role `2d10 + (Defesa − 11)` e use no lugar da Defesa parada. Na média dá a mesma Defesa | 1 |
| **`Aparar`** | O duplo 10 no `Bloquear`. O ataque não acerta, e você pode gastar a Reação para revidar com `+3` de dano | 1 |
| **`Brecha`** | O duplo 1 no `Bloquear`. O ataque acerta, e o agressor pode gastar a Reação dele para atacar de novo | 1 |
| **Arredondamento** | Sempre para o lado que não te favorece. O que você paga sobe, o que você ganha desce | 1 |

## Números da ficha

**Números da ficha**
| Termo | O que é | Cap. |
|---|---|---|
| **Atributo** | Cinco, de 0 a 6: Força, Destreza, Constituição, Inteligência, Essência. O número **é** o modificador | 1 |
| **Pontos de vida** | O corpo. Vêm do Caminho mais a sua Constituição, a cada nível | 1 |
| **Pontos de energia** (`PE`) | O combustível dos feitiços. PE por nível do Caminho × o seu nível. Numa ficha sem energia amaldiçoada a mesma sigla se lê **Pontos de Esforço**, e nenhuma regra pergunta qual das duas você tem | 1 |
| **Integridade** | A vida da alma. `20 + (Essência + 5) × (nível − 1)`. Só volta com descanso longo | 1 |
| **`Vida temporária`** | Anteparo, não vida. Gasta antes da vida real, não acumula, teto de metade da vida máxima, some no fim da cena | 1 |
| **`Energia temporária`** | A mesma regra, com o PE: gasta antes do PE, não acumula, teto de metade do PE máximo, some no fim da cena | 1 |
| **Proteção** | O que soma na Defesa: o uniforme que você veste, ou a energia com que você se cobre | 15 |
| **`Volume`** | O espaço que uma coisa ocupa na sua carga. O seu limite é `5 + Força`, e `12` kg valem `1` | 15 |
| **Redução de Dano** | Desconto no dano que já passou pela Defesa. Não é a mesma coisa que proteção | 9 |
| **Perícia** | Uma das vinte e três. Cada uma tem um atributo fixo. Sem treino você ainda tenta | 3 |
| **Ofício** | Um dos onze. Não tem atributo fixo, e sem treino você **não** tenta | 3 |
| **Condição** | Estado nomeado que muda o que você consegue fazer. São treze, em três níveis: `Leve`, `Média` e `Pesada` | 4 |
| **`Leve`** [Nível] | O menor dos três níveis. Como preço de Melhoria, custa metade da Classe; como condição, sai por `1` ponto de energia | 4 |
| **`Média`** [Nível] | O nível do meio. Como preço, custa a Classe; como condição, sai por `2` pontos de energia | 4 |
| **`Pesada`** [Nível] | O maior. Como preço, custa Classe e meia; como condição, sai por `3` pontos de energia. Dá Teste de Resistência no fim de cada turno do alvo | 4 |
| **Exaustão** | Relógio de descanso, em três degraus. **Não é condição neste sistema** | 5 |
| **Sequela** | O que você ganha ao levantar de uma queda. Encurta em uma rodada a janela da queda seguinte | 1 |
| **Cicatriz** | Permanente, ganha na segunda queda. Vantagem em `Intimidação`, desvantagem em `Persuasão`. Não sai no descanso, sendo permanente a não ser que você se cure com `Energia Reversa`; ser curado por outros não tira a cicatriz, e nem quando ela já está formada no seu corpo | 1 |

## Personagem

**Personagem**
| Termo | O que é | Cap. |
|---|---|---|
| **Caminho** | O seu lugar numa equipe. Seis nesta edição: Bastião, Vanguarda, Guia, Emanador, Evocador e Incursor. Escolhido na criação, para sempre | 8 |
| **Trilha** | Quem você é dentro do Caminho. Três por Caminho, dezoito nesta edição | 8 |
| **Fluidez** | Estado do Incursor: guarda um por vez e gasta nos usos do Caminho ou da Trilha | 8 |
| **Canalizar em Golpe** | Nos Caminhos, o dano na arma da aptidão Canalizar energia; cada habilidade declara suas exceções | 12 |
| **Pontos de Vínculo** | Reserva do Evocador para intervenções; começa em zero e cresce no começo de seus turnos | 8 |
| **Entidade** | Criatura com ficha própria obtida por técnica, criação ou domínio de uma maldição | 17 |
| **Básica** | Atuação comum da entidade; conhecer opções não concede atuações adicionais | 17 |
| **Especial de invocação** | Habilidade que exige seu comando, com custos e requisitos próprios | 17 |
| **Reação coletiva** | Reserva de Reação compartilhada pelas entidades, separada da sua Reação pessoal | 17 |
| **`Rápido`** | Melhoria que troca a Ação Padrão do feitiço pela Ação Bônus; requisitos e limites no catálogo | 9 |
| **`Aquecer`** | Restrição que impede usar o feitiço na primeira rodada do combate; requisitos e limites no catálogo | 9 |
| **`Levanta`** | Melhoria de Amparo que devolve vida a um aliado caído; requisitos e limites no catálogo | 9 |
| **`Fica`** | Melhoria que mantém uma área e exige concentração; requisitos e limites no catálogo | 9 |
| **`Rajada`** | Melhoria que divide o feitiço em tiros com rolagens próprias; requisitos e limites no catálogo | 9 |
| **`Inescapável`** | Melhoria de dano automático, incompatível com outras peças; requisitos e limites no catálogo | 9 |
| **`Anteparo`** | Melhoria que cria uma parede ou escudo com vida própria; requisitos e limites no catálogo | 9 |
| **`Toca a Alma`** | Melhoria que converte dados de dano em dano na alma; requisitos e limites no catálogo | 9 |
| **`Remenda`** | Melhoria que recupera Integridade de um aliado; requisitos e limites no catálogo | 9 |
| **`Dívida`** | Restrição que aumenta o PE do próximo feitiço na cena; requisitos e limites no catálogo | 9 |
| **`Escolher`** | Melhoria que permite escolher quem é atingido na área; requisitos e limites no catálogo | 9 |
| **`Guarda`** | Melhoria que concede um bônus de Defesa por prazo definido; requisitos e limites no catálogo | 9 |
| **`Queima`** | Melhoria que repete parte dos dados no começo do turno seguinte do alvo; requisitos e limites no catálogo | 9 |
| **`Armado`** | Melhoria que reserva um feitiço para um gatilho futuro da cena; requisitos e limites no catálogo | 9 |
| **`Efeito Próprio`** | Melhoria para uma mecânica definida com o mestre antes da sessão; requisitos e limites no catálogo | 9 |
| **`Mão Firme`** | Passiva que protege concentração e carga contra dano baixo; requisitos e limites no catálogo | 9 |
| **`Fluxo`** | Passiva que concede vida temporária ao conjurar uma Classe elegível; requisitos e limites no catálogo | 9 |
| **`Passiva Própria`** | Passiva definida com o mestre na escala do catálogo; requisitos e limites no catálogo | 9 |
| **Origem** | De onde vem o seu poder. Sete, mais a sub-origem Sem Técnica | 7 |
| **Legado** | O que você já trazia, das listas da sua Origem. Dois por ficha | 7 |
| **Traço** | Marca de história vinda da Origem, sem número | 7 |
| **Pacto** | O que você trocou por poder. Opcional. Quatro formas: permanente, temporário, `Promessa` e de restrição. Só o permanente tem teto, e ele é metade da Essência | 18 |
| **`Promessa`** | O pacto entre duas partes, com as duas aceitando. Tem três termos: o que eu dou, o que eu recebo, e a cláusula que eu acrescento | 18 |
| **Patente** | O seu reconhecimento na instituição, de Grau 4 a Grau 1. Todo personagem começa **Grau 4** | 7 |

> **Cuidado com a palavra `Grau`.** Ela nomeia duas escadas de cinco casas que não se encostam: a **patente** de um feiticeiro e o **grau** de uma ferramenta amaldiçoada. Patente é reconhecimento; grau de ferramenta é a energia que a ferramenta carrega. O capítulo 15 abre a diferença.
## Técnica

**Técnica**
| Termo | O que é | Cap. |
|---|---|---|
| **Fundamento** | A sua técnica inata, escrita por você na criação. Nunca muda. Descrição, Regra, Famílias, Selo e Passivas | 9 |
| **Regra** | A frase única que resume a técnica. Todo feitiço seu precisa caber nela | 9 |
| **Feitiço** | Uma aplicação concreta da técnica, com nome próprio, montada por você com pontos | 9 |
| **Classe** | O tamanho do feitiço, de 0 a 7. Define pontos, PE, teto e limites | 9 |
| **Pontos** | O orçamento do feitiço: `3 × Classe`. Cada ponto que sobra vira `1d8` de dano | 9 |
| **Teto** | O máximo de dados de dano, somando alvos e repetições: `4 × Classe` | 9 |
| **Forma** | Como o feitiço sai: `Projétil`, `Toque`, `Explosão`, `Aura`, `Cone`, `Linha`, `Cura`, `Apoio`, `Onda`, `Efeito` | 9 |
| **Melhoria** | O que você compra com ponto. Custa `Leve`, `Média` ou `Pesada` | 9 |
| **Restrição** | O que você vende para recuperar ponto. Paga Melhoria, **nunca vira dano** | 9 |
| **`Concentrada`** | Melhoria que faz um efeito de estado durar mais que uma rodada, e exige concentração | 9 |
| **`Duradoura`** | A mesma Melhoria, sem exigir concentração | 9 |
| **`Alvo de Caça`** | Melhoria que marca um alvo: cada ataque seu que acerta ele causa `1d4` a mais | 9 |
| **Família** | Um dos nove grupos de Melhoria. Na criação você fecha duas como Livres e três como Fechadas | 9 |
| **Selo** | O que você sempre faz para conjurar. Não custa nem devolve ponto | 9 |
| **Classe 0** | O feitiço grátis: não gasta PE e não ocupa espaço na lista | 9 |
| **Passiva** | Efeito que fica ligado sozinho. Custa espaço de feitiço | 9 |
| **Classe Passiva** | A altura de uma Passiva, de Livre a 3. Diz quantos espaços ela cobra e em que nível abre | 9 |
| **Espaço de feitiço** | `2 + (nível ÷ 2)`, arredondando para baixo, mais um por marco. É a moeda que Passiva e Expansão de Domínio também gastam | 19 |
| **Ampliar** | Lançar um feitiço que você conhece numa Classe maior, pagando o PE da Classe nova | 9 |
| **Liberação Máxima** | Feitiço à parte, escrito antes da sessão, de Classe 3 ou mais. Rompe o limite de dano num alvo só. Nos níveis 10, 20 e 30 | 9 |
| **Técnica Máxima** | O golpe de dano fixo que carrega o nome da técnica. Do nível 17 em diante | 9 |
| **Uso Livre** | O que a sua técnica faz de graça fora de combate, sem rolagem e sem montagem | 9 |
| **Expansão de Domínio** | O espaço onde a sua técnica manda, com barreira ou sem. Custa espaço de feitiço | 9 |
| **Expansão sem Barreiras** | O degrau de cima da Expansão de Domínio: pode abrir sem barreira, com raio de `200 m`, e aí não prende ninguém | 9 |
| **Dano na alma** | Tira vida e Integridade no mesmo tanto. Entra cheio, e tem quatro estágios | 4 |

## Técnica Marcial

Quem não escreve Fundamento monta o poder aqui. A máquina é a mesma; três nomes mudam.

**Técnica Marcial**
| Termo | O que é | Cap. |
|---|---|---|
| **Técnica Marcial** | O Fundamento com o corpo no lugar da energia. Mesmo orçamento, mesma montagem, e o equipamento no lugar do Selo | 10 |
| **`Kata`** | O feitiço desta rota: mesma Classe, mesmos pontos, mesmo custo | 10 |
| **`Ruptura`** | A Liberação Máxima desta rota. Nos níveis 10, 20 e 30 | 10 |
| **`Ōgi`** | A Técnica Máxima desta rota. Do nível 17 em diante | 10 |

## Bênçãos e Lapidação

O eixo de controle de quem não tem energia amaldiçoada nenhuma, no lugar do refino e das aptidões.

**Bênçãos e Lapidação**
| Termo | O que é | Cap. |
|---|---|---|
| **Lapidação** | Quanto do que o corpo tem chega até o fim do movimento. Começa em 1, teto 10. Sobe `+1` de graça em cada marco | 14 |
| **Bênção** | O que um corpo sem energia aprende a fazer. Catorze, e custa marco | 14 |
| **`Defesa sem Armadura`** | Bênção de graça: proteção `1/3 da Lapidação + 1`, e barreira de energia não segura você | 14 |
| **`Estímulo Muscular`** | Bênção de graça: vantagem numa perícia e num Teste de Resistência escolhidos, `1×` por cena | 14 |

## Progressão

**Progressão**
| Termo | O que é | Cap. |
|---|---|---|
| **Marco** | Um dos sete níveis em que a ficha muda de forma: **6, 10, 14, 18, 22, 26 e 30** | 19 |
| **Refino** | Quanto da sua energia você não desperdiça. Começa em 1, teto 10. Sobe `+1` de graça em cada marco | 12 |
| **Aptidão** | O que qualquer feiticeiro pode aprender, independente da técnica. Custa marco, e só marco | 12 |
| **Corpo**, **Refino**, **Leque** | As três escolhas que um marco oferece: mais atributo e mais uma perícia ou ofício; mais refino e uma aptidão; ou mais feitiço e uma Passiva. Numa ficha sem energia, o eixo do meio é **Lapidação** e entrega Bênção | 19 |

## Turno

**Turno**
| Termo | O que é | Cap. |
|---|---|---|
| **Rodada** | Todo mundo teve o seu turno. 6 segundos | 2 |
| **Ação de Movimento** | Uma por turno. Compra até 9 metros de deslocamento, e o segundo saque do turno | 2 |
| **Ação Padrão** | Uma por turno. Atacar, conjurar, a maior parte das coisas | 2 |
| **Ação Bônus** | Uma por turno, e só o que a regra disser com todas as letras que é Ação Bônus | 2 |
| **Reação** | Uma por turno, responde a um gatilho e vale fora do seu turno | 2 |
| **Rodada inteira** | Custa a Ação de Movimento, a Ação Padrão e a Ação Bônus de uma vez. A Reação continua sua | 2 |
| **Concentração** | Manter um efeito de pé. Um por vez, e tomar dano pede Teste de Resistência de Vigor contra a CD de quem te feriu | 2 |
| **`Estudar`** | Ação Padrão: um teste sobre uma criatura ou objeto que você enxerga, para saber o que ele é e o que ele vai fazer | 2 |
| **Cobertura** | O que está entre você e quem atira. Três degraus: Parcial, Boa e Total | 4 |
| **`Agarrar`** | Opção do `Atacar`. Aplica a condição `Agarrado` | 2 |

## Condições

Treze estados nomeados, em três níveis. `Leve`, `Média` e `Pesada` também nomeiam custo de
Melhoria — são escadas diferentes que usam as mesmas três palavras. O capítulo 4 separa as duas.

**Condições**
| Termo | O que é | Cap. |
|---|---|---|
| **`Agarrado`** | Seu deslocamento é `0`. Acaba se quem agarrou ficar `Incapacitado`, ou se algo tirar você do alcance dele. Ataque à distância tem 50% de chance de acertar quem está agarrando: role `1d10`, e em 6 ou mais você acerta o alvo desejado; em 5 ou menos, acerta quem está agarrando | 4 |
| **`Amedrontado`** | Desvantagem em ataque e em teste enquanto você enxergar a fonte do medo, e você não se aproxima dela de vontade própria | 4 |
| **`Atordoado`** | Você perde a Ação Padrão e não usa reação | 4 |
| **`Calado`** | Você não conjura. Nada que precise de voz, gesto ou Selo que envolva voz sai | 4 |
| **`Cego`** | Você não enxerga. Falha automática em teste que precise de vista, desvantagem nos seus ataques, e quem ataca você tem vantagem | 4 |
| **`Derrubado`** | Está no chão, de pé no medidor. Vantagem a quem ataca de perto | 1 |
| **`Desarmado`** | A sua arma está no chão ou na mão de outro. Você bate desarmado até pegar de volta | 4 |
| **`Enfeitiçado`** | Você não ataca quem enfeitiçou nem mira efeito nocivo nele, e ele tem vantagem em teste social contra você | 4 |
| **`Envenenado`** | Desvantagem nos seus ataques e em todo teste de perícia | 4 |
| **`Impedido`** | Deslocamento `0`, desvantagem nos seus ataques e no Teste de Resistência Físico, e vantagem para quem te ataca | 4 |
| **`Incapacitado`** | Você não pode `Bloquear`, e todo ataque corpo a corpo que acertar você é crítico — só ele, e não conjuração nem tiro | 4 |
| **`Lento`** | Seu deslocamento cai pela metade e você não usa Ação Bônus | 4 |
| **`Surdo`** | Não ouve. Falha automática em teste que precise de audição, e `−2` na iniciativa | 4 |

## Equipamento

**Equipamento**
| Termo | O que é | Cap. |
|---|---|---|
| **Ferramenta amaldiçoada** | Arma forjada para ferir maldição. Tem grau, de 4 a especial | 16 |
| **`Estigma`** | O efeito que uma ferramenta carrega. O grau dela decide o formato | 16 |
| **`Desgaste`** | A ferramenta dispensa o nível mínimo do `Estigma`, e em troca dura um número fixo de missões | 16 |
| **`Emaranha`** | Propriedade de arma: você pode `Agarrar` sem largar a arma | 15 |
| **`Fineza`** | Propriedade de arma: no corpo a corpo, troca Força por Destreza no acerto e no dano | 15 |
| **`Longo Alcance`** | Propriedade de arma: ela alcança à distância, em metros | 15 |
| **`Oculta`** | Propriedade de arma: dá para esconder no corpo, com um teste de `Prestidigitação` | 15 |
| **`Par`** | Propriedade de arma: role dois dados de dano e fique com o melhor | 15 |
| **`Rompe`** | Propriedade de arma: vantagem contra objeto e estrutura | 15 |
| **`Talha`** | Propriedade de arma: `−1` no `Bloquear` de quem se defende | 15 |
| **`Versátil`** | Propriedade de arma: nas duas mãos, o dado sobe um passo | 15 |
| **`Vestida`** | Propriedade de arma: não ocupa a mão | 15 |
| **`Volumosa`** | Propriedade de arma: não dá para esconder, e atrapalha em espaço apertado | 15 |

## Formas, Melhorias e Restrições do Fundamento

**Fundamento**
| Termo | O que é | Cap. |
|---|---|---|
| **`Projétil`** | Forma: 18 m, um alvo, rolagem de acerto | 9 |
| **`Toque`** | Forma: 1,5 m, um alvo. `Projétil` com `Corpo a Corpo` embutida | 9 |
| **`Explosão`** | Forma: esfera de raio 3 m, num ponto a até 18 m, Teste de Resistência | 9 |
| **`Aura`** | Forma: esfera de raio 3 m centrada em você. `Explosão` com `Corpo a Corpo` embutida | 9 |
| **`Cone`** | Forma: 4,5 m saindo de você, Teste de Resistência | 9 |
| **`Linha`** | Forma: 18 m por 1,5 m, Teste de Resistência | 9 |
| **`Cura`** | Forma: um aliado a até 9 m, e os dados viram cura | 9 |
| **`Apoio`** | Forma: um aliado a até 9 m, sem dano; o que sobra vira vida temporária | 9 |
| **`Onda`** | Forma: esfera de raio 3 m centrada em você, pega todos os aliados dentro | 9 |
| **`Efeito`** | Forma: fora de combate, sem dano | 9 |
| **`Corpo a Corpo`** | Restrição: `Projétil` vira `Toque`, `Explosão` vira `Aura`. `Cone` e `Linha` não pegam | 9 |
| **`Atrasar`** | Restrição: o feitiço custa a rodada inteira — sem movimento, sem Ação Bônus, sem mais nada naquele turno | 9 |
| **`Condicional`** | Restrição: só funciona quando uma condição de cena ou de alvo é verdadeira | 9 |
| **`Gesto`** | Restrição: precisa das duas mãos livres e de falar em voz audível | 9 |
| **`Parado`** | Restrição: você não se move no turno em que conjura | 9 |
| **`Uma Vez`** | Restrição: uma vez por cena | 9 |
| **`Fura`** | Melhoria: ignora até `2 × Classe` de Redução de Dano | 9 |
| **`Longe`** | Melhoria: sobe um degrau na escada de alcance. Pode comprar duas vezes | 9 |
| **`Maior`** | Melhoria: sobe um degrau de tamanho de área. Pode comprar duas vezes | 9 |
| **`Precisão`** | Melhoria: `+2` na rolagem de acerto, ou `+2` na CD do Teste de Resistência | 9 |

## Caminhos e Trilhas

**Caminhos e Trilhas**
| Termo | O que é | Cap. |
|---|---|---|
| **`Versado`** | Escolha da `Escola de Arma` da Vanguarda: depois de acertar um Golpe Inicial, guarde uma arma e saque outra sem ação, uma troca por Sequência. Leva-se no lugar de uma categoria e sua Manha | 8 |

## Palavras com sentido próprio

**Palavras com sentido próprio**
| Palavra | Aqui ela quer dizer | E não quer dizer |
|---|---|---|
| **Classe** | o tamanho de um feitiço | a profissão do personagem |
| **Grau** | patente na instituição, **ou** a força de uma ferramenta | nada além disso |
| **Restrição** | o que você vende para recuperar pontos num feitiço | limite de movimento no turno |
| **`Incapacitado`** | você age, mas não se protege | você perde o turno — isso é `Atordoado` |
| **`Inconsciente`** | você chegou a 0 de vida | uma condição comprável — não é |
| **Exaustão** | relógio de descanso | condição — não é, e não se compra com a Melhoria `Condição` |
| **Essência** | perceber energia, trato social, hierarquia | força de vontade sozinha |
| **Refino** | quanto da sua energia não se perde | melhorar um item |

---


# Antes da primeira sessão

*fonte: `manual/08-inicio-rapido.md`*

Uma cena pronta para jogar hoje, sem ninguém ter lido o livro. Alguém lê em voz alta, ou
com as próprias palavras, e a mesa roda a cena com a Kaori — a ficha pronta que vem logo
abaixo.

## Regras da cena

> **Role um `d20`, some o seu bônus, compare com a CD.** Igualou ou passou, você conseguiu.
>
> **Vantagem:** role dois `d20` e fique com o melhor. **Desvantagem:** fique com o pior.
>
> **O seu turno tem ações que podem ser feitas:** uma Ação de Movimento, uma Ação Padrão, uma Ação Bônus
> (só se alguma coisa na ficha disser isso com todas as letras) e uma Reação.
>
> **Atacar** = `d20` + maestria + Força (corpo a corpo), Destreza (à distância) ou o
> atributo da sua técnica (conjuração), contra a **Defesa** do alvo.
>
> **Teste de Resistência** = `d20` + o atributo daquele Teste, mais a maestria se você for
> treinado nele. É o que **você** rola quando alguma coisa acontece com você.

Todo termo aqui tem explicação completa no capítulo 1 e no vocabulário do sistema, logo
atrás.

## Kaori

Feiticeira de nível 2, a mesma ficha de exemplo do capítulo 6.

**Quem ela é.** O clã da Kaori perdeu o nome faz três gerações, e ela cresceu ouvindo a
história de quem perdeu. A avó era a única que ainda sabia alguma coisa de valor — ervas,
principalmente — e fez questão de ensinar. Kaori entrou na instituição querendo provar que
o sobrenome ainda vale alguma coisa, mas ninguém perguntou se ela queria.

**O que ela quer nesta cena:** sair sem que ninguém se machuque, inclusive ela. Kaori não
procura briga; ela entra na frente de quem procura.

**A técnica.** *"Tudo que eu prendo entre as minhas mãos fica mais pesado."* O Selo dela é
físico: as duas mãos precisam se tocar antes de qualquer feitiço sair.

**Kaori, nível 2**
| | |
|---|---|
| **Vida** | 23 |
| **Integridade** | 26 |
| **PE** | 8 |
| **Defesa** | 13 |
| **Iniciativa** | `d20 + 2` |
| **Ataque corpo a corpo (soco)** | `d20 + 4`, dano `d4 + 3` |
| **Ataque de conjuração** | `d20 + 4` — a técnica dela usa **Força** |
| **CD dos feitiços dela** | 12 |

> **`Peso nas Mãos`** · Classe 1 · Toque
> Ela toca o alvo com as duas mãos. **`d20 + 4` contra a Defesa dele.** Acertando: **3d8 de
> dano de concussão**, e o alvo fica `Derrubado` (condição).

> **`Olhos Em Mim`** · Ação Bônus, do Caminho Bastião
> Uma área de `6 m` em volta dela, que anda com ela até o fim da cena. Ao abrir a área, ela
> tenta Provocar até **dois** inimigos dentro dela — metade da Força, `3 ÷ 2` para baixo, mais
> um. Enquanto a área estiver aberta, antes da rolagem de um ataque contra um aliado nela, pode
> gastar a **Reação** para assumir esse ataque. O atacante rola contra a Defesa dela ou seu Bloquear.

> **`Alicerce`** · da Trilha Muro
> Ela escolheu `Cortante` e `Concussão` no último descanso longo. Enquanto `Olhos Em Mim`
> estiver ativo, o dano desses dois tipos cai pela metade contra ela.

## Corredor da ala oeste

Leia (ou narre) isto para o grupo:

> *A escola mandou vocês verificarem uma sala trancada na ala oeste, desativada desde o ano
> passado. O corredor está escuro cedo demais para o horário. No fim dele, encostada na
> porta que vocês precisam abrir, tem uma coisa do tamanho de um cachorro grande, sem
> cabeça que dê para notar.*

Isso é uma **Maldição Menor**: Vida 14, Defesa 12, ataque `d20 + 3` por `1d6 + 2` de dano
`Cortante`.

**1 — Iniciativa.** Todo mundo rola `d20 + Destreza`. Kaori tem Destreza 2: ela tira 11 no
dado, soma 2, fica com 13. A maldição, mais rápida, tira 16 com Destreza 3: age primeiro.

**2 — O turno da maldição.** Ela avança e ataca: `d20 + 3` contra a Defesa 13 de Kaori. Sai
17: acertou. `1d6 + 2` de dano: sai 5, e a vida da Kaori cai de 23 para 18. *O `Alicerce`
ainda não vale: ela não abriu a área de `Olhos Em Mim`.*

**3 — O turno de Kaori.** Três escolhas boas para ela:

- **Gastar a Ação Bônus em `Olhos Em Mim`.** Se ela sabe que a luta vai continuar, abrir a
  área agora liga o `Alicerce` e corta o próximo golpe `Cortante` pela metade — e a maldição
  ataca com garra. Ao abrir, ela ainda tenta Provocar a maldição.
- **Gastar a Ação Padrão em `Peso nas Mãos`.** Precisa estar a `1,5 m`: ela anda até lá com
  o movimento e toca. Rola `d20 + 4` contra a Defesa 12 da maldição: tira 12, soma 4, fica
  16. Acertou. `3d8` de dano: sai 14. **A maldição, com 14 de vida, cai.**
- **Recuar e negociar.** Nem toda cena precisa terminar em dano. Se o grupo tiver outra
  ideia, ela vale tanto quanto as duas de cima.

**Se a maldição tivesse sobrevivido**, o turno dela viria de novo, e a cena continuaria
até alguém desistir, fugir ou cair. **Se Kaori chegasse a `0` de vida**, ela escolheria
entre `Aguentar` e `Insistir`. A regra está no capítulo 1, na seção *Vida a 0*.

## Depois da cena

- **Quer entender por que cada número é aquele?** Capítulo 1, *Como Jogar*.
- **Quer montar o seu próprio personagem?** Capítulo 6, *Criação de Personagem*, os oito
  passos — a Kaori acima é o exemplo completo de lá.
- **Esbarrou numa palavra que não foi explicada?** O vocabulário do sistema tem uma
  linha para cada termo e o capítulo que o explica por extenso.

---


# Capítulo 1 · Como Jogar

*fonte: `manual/10-como-jogar.md`*

## Teste

Na maior parte do tempo o jogo é conversa. Alguém descreve o que o personagem faz, o mestre descreve o que acontece, e a cena anda. O dado entra num momento específico: quando a coisa é difícil **e** o fracasso muda alguma coisa. Empurrar uma porta emperrada com uma maldição arranhando o outro lado pede rolagem. Empurrar a mesma porta com a tarde inteira pela frente, não; o mestre deixa acontecer e segue.

> **Role um d20, some o seu bônus e compare com a CD. Igualou ou passou, você conseguiu.**

A **CD** é o número que a tarefa pede. Quem diz qual é o mestre, e ele tira de uma escada de cinco degraus.

**Escada de CD**
| CD | dificuldade | como isso aparece na cena |
|---|---|---|
| 6 | fácil | pular o muro do colégio, lembrar de que família é aquele brasão |
| 10 | média | passar por dois vigias distraídos, convencer um funcionário cansado |
| 14 | difícil | escalar a fachada de um prédio na chuva, mentir para quem já desconfia |
| 18 | muito difícil | reconhecer uma técnica que só aparece em três registros |
| 22 | extrema | acompanhar alguém que não quer ser seguido, por uma cidade inteira |
| 26 | quase impossível | sair inteiro de uma coisa que não devia deixar ninguém sair |

Por exemplo, numa CD 12 você precisa tirar 12 ou mais no d20 depois de somar o bônus: com bônus 3, um 9 no dado já basta.

O bônus muda conforme o tipo de rolagem.

### Teste de perícia

> **Perícia = d20 + atributo + maestria, se você for treinado.**
> **Sem treino, é d20 + atributo.**

Cada perícia tem um atributo fixo, e o quadro completo (vinte e três perícias e onze ofícios) está no capítulo 3, *Perícias e Ofícios*. Você é **treinado** naquilo que a sua Origem e o seu Caminho te deram na criação: o Caminho dá duas perícias fixas e mais cinco à sua escolha, e a Origem dá mais duas perícias e dois ofícios livres. Nove perícias de vinte e três. O resto você ainda pode tentar; só tenta sem a maestria.

> **Exemplo.** Rin precisa passar por um corredor com dois vigias. Dá para contornar por fora (Furtividade, CD 12) ou subir pela lateral do prédio (Atletismo, CD 16). Ela é treinada em Furtividade e não em Atletismo, e escolhe contornar. Destreza 3, maestria 1: rola 9 no d20, soma 4, dá 13. Passou.

### Vantagem e desvantagem

> **Vantagem: role dois d20 e fique com o melhor.**
> **Desvantagem: role dois d20 e fique com o pior.**
> O bônus é somado normalmente ao dado que ficou.

Qualquer coisa pode ligar um dos dois: um Legado, uma condição, um aliado te ajudando, a posição em que você está. Nenhum dos dois mexe em número da ficha — os dois mexem em quantos dados você joga.

> **Exemplo.** Sousuke ataca alguém que está `Derrubado`, a 1,5 m de distância. A condição dá vantagem a quem ataca de perto: ele rola dois d20, tira 6 e 17, e usa o 17.

### Ajudar

> Um personagem que possa contribuir de verdade dá **vantagem** ao teste de outro. Um ajudante por teste: dois ajudando não dão vantagem duas vezes.

Contribuir de verdade quer dizer estar em condição de fazer diferença naquela tarefa específica: segurar a escada, apontar a lanterna, distrair o segurança enquanto o outro passa. Alguém torcendo do outro lado da sala não conta.

`Ajudar` custa a sua Ação Padrão. A economia de ações está no capítulo 2, *O Turno*.

### Teste de grupo

> Quando o grupo inteiro precisa passar por alguma coisa (atravessar sem ser notado, aguentar o frio), **metade do grupo passando resolve**.

### Falha

Toda falha empurra a cena para algum lugar. O mestre pediu a rolagem porque o resultado importava, então o dado ruim tem que mudar a situação tanto quanto o dado bom mudaria. Uma falha entrega uma destas três coisas:

- **Custo.** Você consegue, e paga: tempo, barulho, um ferimento, um recurso.
- **Complicação.** Você consegue, e alguma coisa piora junto.
- **Informação indesejada.** Você não consegue, descobre por quê, e isso abre outro caminho.

> **Exemplo.** Rin falha na Furtividade por dois pontos. O mestre escolhe **custo**: ela passa pelos vigias, mas derruba um cone de sinalização, e agora os dois estão andando na direção do corredor. Ela conseguiu o que queria e o relógio da missão encurtou.

## Atributos

**Força · Destreza · Constituição · Inteligência · Essência**

O número **é** o modificador, numa escala de 0 a 6. Um personagem com Força 4 soma 4 no ataque corpo a corpo, e ponto. Não existe valor separado, tabela de conversão nem coluna extra na ficha.

**Atributos**
| Atributo | O que governa |
|---|---|
| **Força** | ataque corpo a corpo, agarrar, quebrar, carregar |
| **Destreza** | ataque à distância, Defesa, iniciativa, furtividade |
| **Constituição** | pontos de vida |
| **Inteligência** | conhecimento, investigação, reconhecer uma técnica pelo catálogo |
| **Essência** | perceber energia amaldiçoada, trato social, hierarquia, negociar Pactos |

Essência é a sua energia amaldiçoada como sentido: o que ela capta do ar de uma sala é da mesma natureza do que ela capta da voz de alguém. A divisória entre ela e Inteligência: **Inteligência sabe, Essência percebe**. Sentir Energia e Percepção rolam com Essência.

Inteligência não concede perícias extras. O que você é treinado vem da Origem e do Caminho, e de mais nada.

## Maestria

> **Maestria começa em 1 e sobe um ponto a cada oito níveis.**

**Maestria por nível**
| nível | 2–9 | 10–17 | 18–25 | 26–30 |
|---|---|---|---|---|
| maestria | 1 | 2 | 3 | 4 |

Maestria é o bônus que mede o tempo de estrada do personagem. Ela entra em toda rolagem de ataque, na CD dos seus feitiços, e no que você treinou: perícia, ofício e Teste de Resistência. Por exemplo, no nível 6 a sua maestria é 1, e no nível 10 ela vira 2. Ela fica fora da Defesa.

A ficha começa no **nível 2**, já com um feitiço. O nível 1 fica como opção de campanha, para quando a mesa quiser jogar o personagem de antes de ele ser feiticeiro.

## Acertar

Três rolagens, uma para cada jeito de machucar alguém. Todas comparam com a **Defesa** do alvo, e todas seguem a mesma regra do teste: igualou ou passou, acertou.

> **Ataque corpo a corpo = d20 + Força + maestria**
> **Ataque à distância = d20 + Destreza + maestria**
> **Ataque de conjuração = d20 + o atributo da sua técnica + maestria**

O atributo da conjuração é aquele que você escolheu quando escreveu a técnica, e ele pode ser qualquer um dos cinco.

Nem todo feitiço rola acerto. Um feitiço resolve de três jeitos, e o capítulo 9, *Fundamento*, diz qual é o de cada um:

**Resolução de feitiço**
| como resolve | o que acontece |
|---|---|
| **Acerto** | você rola o ataque de conjuração contra a Defesa do alvo |
| **Teste de Resistência** | o alvo rola contra a CD do seu feitiço |
| **Automático** | acontece, sem rolagem de nenhum dos dois lados |

> **CD de feitiço = 8 + o atributo da sua técnica + maestria.**

> **Exemplo.** Mei está no nível 10, então a maestria dela é 2, e a técnica dela usa Essência, que ela tem em 4. O ataque de conjuração dela é `d20 + 6` e a CD de qualquer feitiço dela é 14. Ela tem duas versões da mesma técnica na ficha: uma que pede acerto e uma que pede Teste de Resistência. O alvo é um mestre-maldição com Defesa 17 e Teste de Resistência de Espírito alto. Ela escolhe a de acerto, porque 17 contra `d20 + 6` é uma aposta melhor do que a CD 14 contra a resistência daquele bicho.

### Crítico

> **20 natural numa rolagem de acerto é crítico. Você dobra os dados.**
> **Dobra só os dados do que rolou o acerto:** os dados da arma, se foi ataque com arma; os dados da Classe, se foi feitiço ou feitiço de Toque.
> **Nada mais dobra**: nem Força, nem dados que vieram de Melhoria, nem dano fixo, nem dados que vieram de aptidão ou Bênção, nem feitiço que viajou junto do ataque, que tem crítico próprio.

Crítico só existe onde existe rolagem de acerto. Feitiço que resolve por Teste de Resistência ou por Automático nunca crita, e isso vale também para as Melhorias que compram precisão tirando a rolagem de ataque.

> **Exemplo.** Sousuke acerta com uma Espada Longa, de d8, e Força 4. No 20 natural ele rola 2d8 e soma 4. A Força continua entrando uma vez só.

## Defesa

> **Defesa = 10 + Destreza + proteção**

Defesa é o número que o inimigo precisa igualar ou passar para te acertar. Por exemplo, com Destreza 3 e um Traje de degrau 2, a sua Defesa é 15. Ela é um número parado, e por padrão você não rola nada — mas pode trocar ela por uma rolagem quando for atacado, e é a seção `Bloquear`.

**Proteção** é o que você veste ou o que você cobre. Cobrir-se de energia amaldiçoada dá proteção sem equipamento nenhum, e é aptidão básica de todo feiticeiro.

Defesa evita ser acertado. Reduzir o dano que já passou é outra coisa, chamada **Redução de Dano**, e ela aparece no capítulo 9, *Fundamento*.

### Cobertura

Estar atrás de alguma coisa sobe a sua Defesa, e a cobertura Total tira você da lista de alvos possíveis. Os três degraus, com os números de cada um, estão no capítulo 4, *Dano, Condições e Cobertura*.

## Bloquear

> **Ao ser atacado, você pode `Bloquear`:** role `2d10 + (a sua Defesa − 11)` e use esse resultado no lugar da sua Defesa contra aquele ataque.
>
> `Bloquear` não custa nada, não gasta a sua Reação, e é de todo mundo — você, os seus aliados e os inimigos.

**Na média dá exatamente a sua Defesa.** A média de `2d10` é 11, que é o número que a sua Defesa parada já supõe. Você troca um número certo por dois dados, e não ganha nem perde nada com a troca.

### Linha da ficha

O `−11` some no número que a ficha imprime. Ela traz a linha pronta, do lado da Defesa:

> **Defesa 17 · Bloquear 2d10+6**

Na mesa você lê *"role 2d10+6"*.

### Aparar e Brecha

> **Duplo 10, `Aparar`.** O ataque não acerta. Você pode gastar a sua Reação para atacar o agressor na hora, e esse ataque sai com `+3` de dano.
>
> **Duplo 1, `Brecha`.** O ataque acerta. O agressor pode gastar a Reação dele para atacar você de novo na hora, sem bônus nenhum.

**O `Aparar` não anula um 20 natural.** Quem ataca continua rolando d20, e crítico fura o `Aparar`.

> **Exemplo.** A Rina está com Defesa 17, então a linha dela é `Bloquear 2d10+6`. Uma maldição ataca e tira **18**: com a Defesa parada, isso acerta. Ela tenta bloquear, tira `7` e `4`, e com o `+6` dá **17** — o ataque acerta do mesmo jeito.
>
> Na rodada seguinte a mesma maldição tira **19**. A Rina bloqueia e sai `10` e `10`: `Aparar`. O ataque não acerta, e ela ainda tem a Reação na mão. Aí vem a decisão — gastar a Reação para bater de volta com `+3` de dano, ou guardar ela para o capanga que ainda não agiu neste turno.

### Limites

> **`Bloquear` não vale em Teste de Resistência.** Só contra ataque com rolagem de acerto.
>
> **`Bloquear` usa exatamente o mesmo modificador da sua Defesa parada.** Nada pode aumentar um sem aumentar o outro — se um escudo, uma aptidão, um Legado ou uma ferramenta subir um lado só, a regra quebra.

Quem está `Incapacitado` não pode `Bloquear`. É a única condição que impede a rolagem, e ela está no capítulo 4, *Dano, Condições e Cobertura*.

## Testes de Resistência

**Você rola um Teste de Resistência** quando alguma coisa acontece com você e você tenta segurar a barra. O ataque parte do outro lado; a rolagem é sua. São quatro.

> **Teste de Resistência = d20 + atributo do TR + maestria, e a maestria só entra se você for treinado nele.**

**Testes de Resistência**
| Teste de Resistência | Usa | Serve para |
|---|---|---|
| **Físico** | Força **ou** Destreza, declarado na criação e travado | reagir, esquivar, aguentar impacto |
| **Vigor** | Constituição | veneno, doença, exaustão |
| **Intelecto** | Inteligência | controle mental, ilusão, dissociação |
| **Espírito** | Essência | vontade, determinação, não se dobrar |

**Só o TR Físico escolhe entre dois atributos**, e essa escolha é feita uma vez na criação. Ela diz como o seu personagem sai da frente de uma explosão: quem travou em Força planta o pé e absorve, quem travou em Destreza salta.

Você é treinado em **dois dos quatro**: a sua Origem treina um, o seu Caminho treina outro. **No Teste de Resistência que você treinou, você soma a maestria; nos outros dois, só o atributo.** É a mesma marca de treino da perícia e do ofício.

> Nos dois Testes de Resistência que você não treinou, você não soma a maestria — e a distância entre eles e os treinados só cresce conforme a campanha anda. É por ali que um chefe vai entrar.
> **Exemplo.** Kaito travou o TR Físico em Destreza, que é 4, e a Origem dele treinou justamente esse. Um feitiço de área de CD 15 explode do lado dele: ele rola 9 no d20, soma 4 de Destreza e 2 de treino, dá 15. Igualou, então resistiu.

## Vida, energia e alma

Vida é o **corpo**, energia é o **combustível**, Integridade é a **alma**. O **Caminho** define os números abaixo, e você escolhe ele na criação; o capítulo 6, *Criação de Personagem*, explica o que cada Caminho é.

### Pontos de vida

> **No nível 1 você recebe a vida inicial do seu Caminho, mais a sua Constituição.**
> **Em cada nível depois, você recebe a vida por nível do seu Caminho, mais a sua Constituição de novo.**

**Vida e PE por Caminho**
| Caminho | dado | vida no nível 1 | por nível | PE por nível |
|---|---|---|---|---|
| **Bastião** | d12 | 12 | 7 | 4 |
| **Vanguarda** | d8 | 8 | 5 | 5 |
| **Guia** | d8 | 8 | 5 | 5 |
| **Emanador** | d6 | 6 | 4 | 6 |
| **Evocador** | d6 | 6 | 4 | 6 |
| **Incursor** | d6 | 6 | 4 | 6 |

> **Exemplo.** Mei é Vanguarda, Constituição 3, nível 4. Nível 1: 8 + 3 = 11. Cada um dos três níveis seguintes: 5 + 3 = 8. Total: 11 + 24 = **35 de vida**.

> **Variante: rolar a vida.** Se a sua mesa preferir, role o dado do Caminho a cada nível em vez de pegar o valor fixo da tabela. Na média isso rende um pouco menos.
### Vida temporária

Algumas coisas dão **vida temporária**: a Forma `Apoio` e a Passiva `Fluxo`.

> **Vida temporária é anteparo, e não vida.** Ela é **gasta antes** da vida real, **não acumula** — duas fontes, você fica com a maior, nunca com a soma —, tem **teto de metade da sua vida máxima**, e **some no fim da cena**.

Por exemplo, com 40 de vida máxima o seu teto é 20: um efeito que daria 27 te deixa em 20, e um segundo efeito que daria 12 não soma nada, porque 20 é maior.

**O mestre pode deixar ela atravessar para a cena seguinte** quando a preparação foi deliberada — quem se cobre antes de entrar no prédio não perde o que gastou porque a cena mudou.

Ela não sobe a sua vida máxima, não conta para `Insistir`, e não é cura: quem está a `0` de vida e recebe vida temporária continua a `0`.

### Pontos de energia

**Pontos de energia** são o combustível dos seus feitiços, e o manual chama de **PE** nas tabelas. É o que acaba primeiro numa missão longa.

> **Pontos de energia = PE por nível do seu Caminho × o seu nível.**

Sem atributo e sem valor inicial: no nível 1 você tem o PE de um nível.

> **Exemplo.** Mei, Vanguarda de nível 4: 5 × 4 = **20 de PE**. Nenhum atributo entra nessa conta.

### Energia temporária

O `Embalo` do Combatente Amaldiçoado e a Conclusão Refluxo da Estocada dão **energia temporária**.

> **Energia temporária segue a regra da vida temporária, com o PE no lugar da vida.** Ela é **gasta antes** do seu PE, **não acumula** — duas fontes, você fica com a maior —, tem **teto de metade do seu PE máximo**, e **some no fim da cena**.

O mestre pode deixar ela atravessar para a cena seguinte, do mesmo jeito que a vida temporária.

### Integridade

> **Integridade = 20 + (Essência + 5) × (nível − 1).**

Integridade é a sua alma. Nem o Caminho nem a Constituição mexem nela — dano de alma passa por cima do corpo físico. Quem manda no tamanho dela é a **Essência**, e é por isso que ela é a única reserva em que um corpo resistente pode ser frágil.

Toda ficha começa com os mesmos 20: você nasce com essa alma, e o que a Essência muda é o quanto ela cresce daí em diante.

> **Exemplo.** Kaori tem Essência 1. No nível 2 a Integridade dela é `20 + 6 = 26`; no nível 10, `20 + 6 × 9 = 74`. Um Emanador de Essência 5 no nível 10 teria `110`.

Dano de alma tem quatro estágios, e eles estão no capítulo 4, *Dano, Condições e Cobertura*, na seção *Dano na alma*. O quarto é o fim da linha: *"você não é mais você, e o que sobra é decisão do mestre"*.

## Arredondamento

Boa parte das contas do sistema cai em fração.

> **Arredonde sempre para o lado que não te favorece.**
> O que você **paga** sobe. O que você **ganha** desce. E o que você ganha nunca fica abaixo de 1.

> **Exemplo.** Você recupera 2,5 de PE num descanso curto: recupera 2. Um efeito te cobra 2,5 de PE: você paga 3.

Número que já está impresso numa tabela você copia e segue: a vida por nível do Caminho, por exemplo, já vem arredondada na tabela `Vida e PE por Caminho`.

## Vida a 0

O personagem levou o golpe que zerou a barra, a mesa para, e quem escolhe o que acontece é o jogador.

> **Você chega a 0 de vida. Escolha uma das duas, na hora:**
>
> **Aguentar** — você apaga. Tem uma janela de **3 rodadas**. Uma cura de **20% ou mais da sua vida máxima**, de uma vez, te põe de pé, e a Melhoria `Levanta` te põe de pé com qualquer valor. **Cada dano que você recebe apagado tira uma rodada da janela**, no mínimo uma. Se a janela acabar sem socorro, você chega ao **estágio 4 de dano de alma**.
>
> **Insistir** — você fica de pé a 0 de vida e age normalmente. Cada rodada custa um pedaço da sua **vida máxima**, e ele dobra: **1/8, depois 1/4, depois 1/2**. Na quarta rodada você desaba.
>
> **O dano que entra enquanto você está a 0 se acumula.** Passou de **metade da sua vida máxima original**, acaba na hora: no Aguentar você chega ao estágio 4, e no Insistir você desaba. O custo do Insistir não entra nessa conta.

Quem desaba pelo Insistir não levanta com um ponto de cura. Só acorda com **metade da sua vida máxima original**, e aqui a cura **soma**: pode vir de várias fontes, em várias rodadas. A Melhoria `Levanta` põe de pé com qualquer valor, aqui também.

O custo do Insistir usa o arredondamento de sempre.

> **Exemplo.** Kaito tem 80 de vida máxima e chega a 0 com o chefe quase morto. Ele escolhe Insistir. Na primeira rodada paga 10 (1/8 de 80), na segunda 20, na terceira 40. Se o chefe não cair até lá, Kaito desaba na quarta.

### Sequela e Cicatriz

> Toda vez que você levanta de uma queda, ganha uma **Sequela**. Cada Sequela tira uma rodada da janela da sua próxima queda.
>
> **Na segunda queda você também ganha uma Cicatriz**, que é permanente e não sai no descanso.
>
> Sequela some no descanso longo. Vida máxima e Integridade voltam junto, como sempre.
>
> **A Cicatriz é uma marca visível.** Você passa a rolar `Intimidação` com vantagem e `Persuasão` com desvantagem.
>
> Cura de qualquer outra fonte deixa a marca, inclusive a `Energia Reversa` de outra pessoa. E nenhuma cura apaga uma Cicatriz depois de ela existir.
>
> **Duas Cicatrizes não acumulam**, porque vantagem não empilha. Da segunda em diante elas são só mais histórias.

Sequela deixa as suas rolagens exatamente como estavam. O que encurta é a próxima queda: onde antes havia três rodadas de janela, agora há duas.

A Cicatriz é o contrário: ela não mexe em nada dentro da luta. O que ela muda é depois.

**Fechar o próprio ferimento é a única forma de não levar a marca.** Quem escolheu Aguentar está apagado e não age: só outra pessoa alcança ele. Quem ficou de pé pelo Insistir ainda tem a Ação Padrão, e a `Energia Reversa` é uma Ação Padrão.

### Inconsciente

Chegar a 0 de vida tem nome próprio: `Inconsciente`, o estado descrito nesta seção. Duas condições parecidas costumam ser confundidas com ele, e as duas moram no capítulo 4, *Dano, Condições e Cobertura*:

**Inconsciente, Incapacitado e Derrubado**
| | o que é |
|---|---|
| `Inconsciente` | você chegou a 0 de vida, e está nesta seção |
| `Incapacitado` | condição, e quem está `Incapacitado` continua com vida |
| `Derrubado` | condição, e quem está `Derrubado` está no chão, de pé no medidor |

## Condições

**Condição** é um estado nomeado que muda o que você consegue fazer enquanto durar. Ficar `Cego` no meio de uma briga, levar um golpe que te deixa `Atordoado`, ser agarrado e não sair mais do lugar: tudo isso é condição. Cada uma tem um nível, e o nível é o que ela custa quando alguém monta um feitiço para aplicá-la.

São treze, e elas têm capítulo próprio: o capítulo 4, *Dano, Condições e Cobertura*. Lá está o efeito de cada uma por extenso, o nível de cada uma, o que não conta como condição neste sistema, e como se tira uma condição de alguém.

## Notação e nomes

Ao longo do manual, o que aparece `assim` é nome de mecânica: uma condição, uma perícia, uma ação, uma Melhoria. Quando você vir uma palavra nesse formato, ela tem regra escrita em algum lugar, e o nome dela é exatamente aquele.

---


# Capítulo 2 · O Turno

*fonte: `manual/11-o-turno.md`*

O combate é contado em rodadas. Todo mundo rola Iniciativa, e essa rolagem decide a ordem em que as pessoas agem. Cada um tem o seu **turno**; quando todo mundo já teve o seu, a rodada fecha e começa outra, na mesma ordem.

Uma rodada são 6 segundos. Tudo que acontece nela está acontecendo mais ou menos ao mesmo tempo; a ordem existe para a mesa conseguir narrar.

## Iniciativa

> **Iniciativa = `d20` + Destreza. Quem tirar mais age primeiro.**
>
> Empate se resolve pela maior Destreza. Se as Destrezas também forem iguais, o jogador age antes do inimigo.

A ordem sai uma vez e vale enquanto a cena durar. Ninguém rola de novo a cada rodada.

> **Exemplo.** A Rina tem Destreza 4. Ela rola o d20, tira 11, e a iniciativa dela é 15. A maldição do outro lado do galpão tem Destreza 3 e tira 16: iniciativa 19. A maldição age antes dela, nesta rodada e em todas as próximas.

## Recursos do turno

**Recursos do turno**
| Recurso | Quanto | O que faz |
|---|---|---|
| Ação de Movimento | uma | até 9 metros de deslocamento, e o segundo saque do turno |
| Ação Padrão | uma | atacar, conjurar, a maior parte das coisas |
| Ação Bônus | uma | só o que a regra disser, com todas as letras, que é Ação Bônus |
| Reação | uma | responde a um gatilho, vale fora do seu turno, e volta no começo do seu turno |

Os quatro são independentes. Você tem os quatro em todo turno seu, e gastar um não mexe nos outros.

**Dá para converter**, quando você quer tomar mais de uma ação menor no mesmo turno. Uma **Ação Padrão** vira uma **Ação Bônus**, e uma **Ação Bônus** vira uma **Ação de Movimento**. **Sempre da maior para a menor, nunca o contrário:** abrir mão do movimento não compra Ação Bônus, e abrir mão da Ação Bônus não compra Ação Padrão.

É normal ter o slot de Ação Bônus sem nada no que usar na maioria dos turnos. Ele só acende quando alguma coisa escrita na sua ficha diz **Ação Bônus** — então não se preocupe com isso caso ocorra com a sua ficha: existem ações que o próprio sistema traz para você nesses casos.

### Deslocamento

**Ação de Movimento** é o slot do turno; **deslocamento** é a distância que ele oferece. Onde a sua ficha disser `+3 m`, `metade do deslocamento` ou `perde o deslocamento do próximo turno`, está falando de metros.

O seu deslocamento base é 9 metros, e você corta esse total em quantos pedaços quiser dentro do turno. Dá para andar 3 metros, atacar, e andar os 6 que sobraram. É assim que alguém sai de trás de uma coluna, dá o golpe e volta para trás dela no mesmo turno.

### Sacar e guardar

> **Sacar ou guardar um item — inclusive arma — não custa nada. Uma vez por turno.**
>
> **Do segundo em diante, sacar ou guardar custa a sua Ação de Movimento inteira.** Não meia, não 3 metros: a Ação de Movimento do turno.

**Trocar de arma é sacar e guardar, então é dois.** Guardar a que está na mão é o primeiro e sai de graça; sacar a outra é o segundo, e custa a Ação de Movimento.

**Largar no chão não é guardar.** Largar é de graça e é sempre. É por isso que *soltar e sacar* sai mais rápido que *trocar*, ao preço de deixar a arma no chão.

### Rodada inteira

Algumas coisas custam a rodada inteira: Ação de Movimento, Ação Padrão e Ação Bônus de uma vez só. A Reação continua sua.

> **Exemplo.** A Rina abre o turno andando 6 metros até a porta do depósito. Gasta a Ação Padrão em `Atacar` a maldição que estava esperando atrás dela, e ainda tem 3 metros sobrando, que usa para sair do vão da porta. A Ação Bônus dela fica parada: nada na ficha da Rina diz que é Ação Bônus, e sem isso o slot não faz nada.

## Ações de Ação Padrão

Doze ações têm regra escrita, e você continua podendo tentar o que não está aqui.

**Ações de Ação Padrão**
| Ação | O que ela faz |
|---|---|
| **Atacar** | um ataque com arma ou desarmado, e os ataques a mais que a sua regra de ataque extra der. `Agarrar` e `Derrubar` são opções desta ação |
| **Conjurar** | um feitiço, pelo Fundamento |
| **Correr** | ganhe deslocamento igual ao seu, pelo resto do turno |
| **Desengajar** | o seu movimento não provoca ataque de oportunidade pelo resto do turno |
| **Esquivar** | ataques contra você têm desvantagem, e os seus Testes de Resistência Físicos têm vantagem, até o começo do seu próximo turno |
| **Esconder** | um teste de `Furtividade` |
| **Ajudar** | dá vantagem ao próximo teste ou ataque de um aliado |
| **Influenciar** | um teste de Essência para mudar a atitude de alguém |
| **Preparar** | escolha uma ação e um gatilho visível. Quando o gatilho acontecer, você gasta a Reação para fazer a ação |
| **Vasculhar** | um teste de `Percepção` ou `Investigação` sobre uma coisa ou uma criatura ao seu alcance |
| **Estudar** | um teste de `Sentir Energia`, `Ocultismo`, `Medicina` ou `História` sobre uma criatura ou objeto que você enxerga |
| **Usar objeto** | usar um objeto não mágico |


### Agarrar e Derrubar

Quem tem ataque extra pode agarrar com um golpe e bater com o outro, no mesmo turno. Cada uma aplica a condição de mesmo nome, e o efeito delas está no capítulo 4, *Dano, Condições e Cobertura*.

### Ajudar

Um ajudante por teste. Dois aliados ajudando não dão vantagem duas vezes, e o segundo perde a Ação Padrão dele à toa. A regra completa de `Ajudar`, com o que conta como ajuda de verdade, está no capítulo 1, *Como Jogar*.

### Influenciar

O teste é de Essência, e a perícia depende do jeito que você escolher: `Persuasão`, `Enganação`, `Intimidação` ou `Atuação`. Serve tanto para o negociador do outro lado da barreira quanto para a maldição que ainda tem alguma coisa de gente dentro. O que muda é a CD que o mestre põe.

Nem sempre é possível influenciar alguém: depende completamente da decisão do seu mestre.

### Preparar

Você gasta a Ação Padrão para preparar, e a Reação depois, quando o gatilho acontecer. Se o gatilho não acontecer até o começo do seu próximo turno, a ação se perde.

> **A Reação não fica reservada.** Até o gatilho acontecer, ela continua sua para qualquer outro uso — e gastar ela em outra coisa faz a ação preparada se perder. Usar a ação preparada gasta a Reação.

O gatilho precisa ser visível e verificável pela mesa: *"quando ela sair da fumaça"*, *"quando ele encostar na porta"*. Um gatilho que só o jogador consegue julgar, ou que é aberto, trava a cena.

> **Exemplo.** O Kaito prepara: *"se aquela coisa passar da linha das prateleiras, eu ataco."* Gastou a Ação Padrão dele agora. A maldição passa da linha ainda na rodada, e ele gasta a Reação para dar o golpe. Se ela tivesse ficado parada até a vez dele de novo, ele teria perdido o turno inteiro esperando.

### Vasculhar e Estudar

As duas gastam a Ação Padrão para trocar informação por tempo, e a diferença é a distância. `Vasculhar` é mão no objeto: revistar o corpo, abrir a gaveta, apalpar a parede atrás de um vão (`Investigação`). `Estudar` é olhar com atenção de longe: ler a energia de uma maldição, reconhecer o formato de um selo, avaliar quanto sangue aquele ferido ainda aguenta perder (`Percepção`). Os dois contra uma dificuldade que o mestre estipular.

## Ações de Ação Bônus

> **`Provocar`** — Ação Bônus. Teste de `Provocar` contra o Teste de Resistência de Espírito do alvo. Se ele falhar, até o começo do seu próximo turno ele ataca com desvantagem qualquer alvo que não seja você, e com vantagem contra você.

> **`Ler o Ambiente`** — Ação Bônus, uma vez por cena. Teste de `Percepção` ou `Intuição` contra a dificuldade que o mestre puser. Num sucesso, o mestre te diz uma coisa daquele lugar que dê para usar: um objeto, um caminho, uma posição, um risco. Se não houver nada, ele diz isso e a ação não é gasta.

`Provocar` puxa o golpe para você: enquanto durar, você é o alvo mais fácil da sala, e quem foi provocado erra mais em qualquer outro.

`Ler o Ambiente` fala do lugar e só do lugar. Ela nunca diz nada sobre uma criatura. Quem quer saber do inimigo usa `Estudar`; quem quer revistar alguém usa `Vasculhar`; e as duas custam a Ação Padrão.

> **Exemplo.** O Kaito está encurralado num estacionamento. Ele gasta a Ação Bônus em `Ler o Ambiente` e tira 17 num teste de `Percepção`. O mestre diz que o carro ao lado dele está com o tanque aberto e cheirando a gasolina. Se ele tivesse perguntado *"o que essa maldição está prestes a fazer?"*, a resposta seria outra: isso é `Estudar`, e custa a Ação Padrão.

## Ataque de oportunidade

> **Quando alguém sai do seu alcance de corpo a corpo sem tomar cuidado, você pode gastar a sua Reação para atacar essa pessoa.**

É o que impede um inimigo de passar correndo pelo meio do grupo como se ninguém estivesse ali. É um ataque físico, rolado como qualquer outro ataque, com soco ou com arma. Feitiços não entram como opção.

Duas coisas passam livre: quem usou `Desengajar` naquele turno, e qualquer movimento cujo texto diga **sem provocar**.

> **Exemplo.** A maldição está encostada na Rina e resolve correr atrás do Kaito. Ela não usou `Desengajar`, então a Rina gasta a Reação dela e ataca a maldição saindo. A Reação da Rina só volta no começo do próximo turno dela.

## Concentração

Alguns efeitos exigem que você mantenha a atenção neles enquanto duram: a barreira que continua de pé, a coisa que você está segurando no lugar do outro lado da sala. Você concentra em um por vez; começar um segundo derruba o primeiro.

> **Quando você toma dano concentrando, faça um Teste de Resistência de Vigor contra a CD de quem te feriu. Se falhar, o efeito cai.**

**A CD é a de quem te feriu**, a que ele usa para o que faz. Num feitiço, é a CD do feitiço dele: `8 + o atributo + a maestria`. Num golpe de arma ou desarmado, é a mesma conta com o atributo do ataque. Num inimigo, é a CD que a ficha dele diz. **Cada golpe que te acerta é um teste**, mesmo que sejam vários na mesma rodada. Se o dano não tem autor (uma queda, uma armadilha), o mestre escolhe a CD na escada de dificuldade do capítulo 1, *Como Jogar*.

**Dano de 10 ou menos não pede o teste** para quem tem a Passiva `Mão Firme`.

Quem monta um feitiço com a Melhoria `Concentrada` põe o efeito de estado dele no ar por mais tempo, e passa a concentrar nele. A `Duradoura` faz o mesmo sem pedir concentração. As duas estão no capítulo 9, na Família `Tempo`.

> **Exemplo.** A CD da maldição é 14. O Kaito está concentrando num efeito e ela o acerta duas vezes na rodada. Ele faz dois Testes de Resistência de Vigor contra 14, um por golpe. Se falhar em qualquer um dos dois, o efeito cai.

**Na corrida entre dois domínios a rolagem é a mesma, com a contagem trocada.** A regra está no capítulo 40, na seção *Domínios sobrepostos*.

### Concentração e Carregar

As duas seguram alguma coisa contra o dano, em momentos diferentes da vida de um feitiço. **As duas rolam contra a CD de quem te feriu**; o que troca é o teste e o que você perde.

**Concentração e Carregar**
| | O que você segura | Teste | Falhar custa |
|---|---|---|---|
| **Concentração** | o efeito que já está no ar | Vigor | o efeito cai |
| **Carregar** | o feitiço que ainda não saiu | Espírito | o feitiço, e o que você pagou por ele |

Quem usa a Restrição `Carregar` mantém o movimento e a Ação Bônus no turno de carga. Só a Ação Padrão daquele turno vai embora.

## Limites

> **Feitiço de Classe só permite mais um de Classe 0 no seu turno.**

Por exemplo, se você conjurou um feitiço de Classe 3 na Ação Bônus (ou Padrão), então ainda cabe na Ação Padrão (ou Bônus) um Classe 0.

---


# Capítulo 3 · Perícias e Ofícios

*fonte: `manual/12-pericias-e-oficios.md`*

O seu personagem tem duas listas de coisas que sabe fazer fora da técnica: **perícias** e **ofícios**. Elas se parecem na ficha e funcionam diferente.

**Perícia** é uma capacidade do corpo ou da cabeça. Ela pertence a um atributo e só a esse atributo. Correr é `Atletismo`, e `Atletismo` é sempre Força.

**Ofício** é uma prática que alguém te ensinou. Ele vive solto no quadro de atributos: o atributo muda conforme o que você está fazendo com ele.

**Perícia e ofício**
| É perícia | É ofício |
|---|---|
| Escalar um muro | Dirigir a van até o muro |
| Saber que aquilo é uma maldição de segundo grau | Desenhar o talismã que segura ela |
| Convencer o clã a te receber | Preencher a requisição que abre a porta |
| Notar o cheiro de sangue na sala | Fazer o chá que faz o ferido dormir |

A regra prática: se é uma ferramenta ou um procedimento que alguém te ensinou passo a passo, é ofício. A ferramenta pode ser a chave de fenda, o papel de talismã ou o formulário certo. `Burocracia` é ofício pelo mesmo motivo que `Forja` é.

## Rolagem de perícia e ofício

> **Perícia = `d20` + o atributo dela + maestria, se você for treinado.**
> Sem treino, é só `d20` + o atributo.

> **Ofício = `d20` + o atributo que a situação pede + maestria, se você for treinado.**
> Sem treino, você normalmente não consegue tentar.

Ser **treinado** quer dizer ter aquela perícia ou aquele ofício marcado na ficha; a seção *Treino* diz de onde vêm as marcas. **Maestria** é o bônus que cresce com o nível, e a escada dela está no capítulo 1, *Como Jogar*. O mestre põe uma **CD**, o número que a sua rolagem precisa alcançar para você conseguir o que queria. Por exemplo, com Destreza 3 e maestria 1, uma `Furtividade` treinada rola `d20 + 4`; sem treino, `d20 + 3`.

### Atributo do ofício

Forjar uma lâmina é Força. Falsificar uma assinatura é Destreza. Saber qual selo o papel pede é Inteligência. As três coisas são o mesmo ofício, `Caligrafia` ou `Forja`, e o mestre escolhe o atributo na hora, do mesmo jeito que escolhe a dificuldade. Perícia não faz isso: o atributo dela é o da tabela e não muda.

Um ofício rende diferente na mão de cada personagem. O mesmo `Arrombamento` é uma coisa para quem tem Destreza 4 e outra para quem tem Inteligência 4, e as duas fichas passam por portas diferentes.

### Sem treino

Qualquer um pode tentar escalar e falhar. Ninguém forja uma lâmina por tentativa. Quando o mestre achar que dá para improvisar, tipo dirigir um carro automático em linha reta ou fazer um curativo torto, ele libera a rolagem sem a maestria.

> **Exemplo.** A Rina joga de Vanguarda, no nível 6. Destreza 4, Inteligência 2, maestria 1. Ela é treinada em `Furtividade` e no ofício `Arrombamento`.
>
> Para entrar no depósito sem ser vista ela rola `Furtividade`, que é Destreza: `d20 + 4 + 1`, ou seja `d20 + 5`.
>
> Chegando na porta, ela usa `Arrombamento`. O mestre decide que forçar aquela tranca é trabalho de mão e cobra Destreza: `d20 + 4 + 1` de novo. Se a tranca fosse eletrônica ele teria cobrado Inteligência, e o mesmo ofício sairia `d20 + 2 + 1`. Três a menos, porque a Rina é boa com as mãos e não com o sistema.

## Catálogo

**Perícias e ofícios**
| Nome | Tipo | Atributo | Sem treino |
|---|---|---|---|
| Atletismo | perícia | Força | `d20` + atributo |
| Acrobacia | perícia | Destreza | `d20` + atributo |
| Furtividade | perícia | Destreza | `d20` + atributo |
| Pontaria | perícia | Destreza | `d20` + atributo |
| Prestidigitação | perícia | Destreza | `d20` + atributo |
| Investigação | perícia | Inteligência | `d20` + atributo |
| Intuição | perícia | Inteligência | `d20` + atributo |
| Ocultismo | perícia | Inteligência | `d20` + atributo |
| Religião | perícia | Inteligência | `d20` + atributo |
| História | perícia | Inteligência | `d20` + atributo |
| Hierarquia | perícia | Inteligência | `d20` + atributo |
| Medicina | perícia | Inteligência | `d20` + atributo |
| Sobrevivência | perícia | Inteligência | `d20` + atributo |
| Natureza | perícia | Inteligência | `d20` + atributo |
| Lidar com Animais | perícia | Inteligência | `d20` + atributo |
| Tecnologia | perícia | Inteligência | `d20` + atributo |
| Sentir Energia | perícia | Essência | `d20` + atributo |
| Percepção | perícia | Essência | `d20` + atributo |
| Persuasão | perícia | Essência | `d20` + atributo |
| Enganação | perícia | Essência | `d20` + atributo |
| Intimidação | perícia | Essência | `d20` + atributo |
| Atuação | perícia | Essência | `d20` + atributo |
| Provocar | perícia | Essência | `d20` + atributo |
| Condução | ofício | o que a situação pedir | não rola |
| Arrombamento | ofício | o que a situação pedir | não rola |
| Herbalismo | ofício | o que a situação pedir | não rola |
| Forja | ofício | o que a situação pedir | não rola |
| Caligrafia | ofício | o que a situação pedir | não rola |
| Burocracia | ofício | o que a situação pedir | não rola |
| Entalhador | ofício | o que a situação pedir | não rola |
| Alfaiate | ofício | o que a situação pedir | não rola |
| Culinária | ofício | o que a situação pedir | não rola |
| Instrumento | ofício | o que a situação pedir | não rola |
| Jogatina | ofício | o que a situação pedir | não rola |

> **`Sentir Energia` não existe para a Restrição Celestial pelo ramo sem energia.** Aquele ramo não tem energia amaldiçoada nenhuma, e não é caso de rolar sem treino: a perícia não entra na ficha. Está no capítulo 7, *Origens e Legados*.
**Inteligência sabe, Essência percebe.** Inteligência é o que você estudou: o catálogo de maldições, o que aconteceu, como o corpo funciona, quem manda em quem. Essência é o que você capta: a energia no ar, o barulho no corredor, a mentira na voz de alguém.

## Perícias

### Força

**Atletismo** — correr, escalar, nadar, saltar, carregar quem não anda. A cena em que o obstáculo é o terreno.

### Destreza

**Acrobacia** — equilíbrio, cair sem se machucar, passar por espaço apertado. Também é o que tira você de um `Agarrado`, no capítulo 4, *Dano, Condições e Cobertura*.

**Furtividade** — mover-se sem ser visto nem ouvido. Decide se a cena começa com o grupo escolhendo o momento, ou com o inimigo.

**Pontaria** — acertar o que é pequeno, o que está longe ou o que se mexe, fora de uma rolagem de ataque. O arremesso que resolve a cena antes de virar combate.

**Prestidigitação** — mão rápida: esconder um objeto, tirar do bolso alheio, trocar uma coisa por outra. A cena com plateia.

### Inteligência

**Investigação** — vasculhar, deduzir, ligar duas pistas que ninguém tinha ligado. A cena de local, e o padrão que se repete.

**Intuição** — ler a pessoa pelo que ela faz: a inconsistência, o detalhe que não fecha, a motivação atrás do pedido. Perceber que alguém está nervoso é `Percepção`.

**Ocultismo** — maldições, técnicas conhecidas, barreiras, o funcionamento da energia amaldiçoada. O nome da coisa, o grau dela, e o que costuma matá-la.

**Religião** — xintoísmo, budismo, exorcismo, templo, ritual, o que os selos querem dizer. O lugar antigo, e o rito que precisa ser feito na ordem certa.

**História** — o que aconteceu e quem estava lá, no mundo comum e no registro das famílias. A cena de arquivo: por que este clã odeia aquele.

**Hierarquia** — os clãs, a política, quem manda em quem. Diz o que você pode pedir, a quem, e o que vai custar.

**Medicina** — ferimento, veneno, doença, corpo. É o saber; a prática de campo é o ofício `Herbalismo`.

**Sobrevivência** — aguentar o ambiente, achar água e abrigo, se orientar, e seguir um rastro, seja pegada ou resíduo de energia.

**Natureza** — planta, bicho, clima, terreno. O que é venenoso, qual vale enche, quando a chuva vem.

**Lidar com Animais** — acalmar, montar, conduzir, mandar num bicho. Vale para invocação que ainda não te obedece direito.

**Tecnologia** — computador, câmera, rede, equipamento moderno. A câmera antes de a equipe entrar, o celular da vítima, o registro de acesso.

### Essência

**Sentir Energia** — perceber energia amaldiçoada: o feiticeiro escondido, o tamanho de uma maldição, quem está prestes a conjurar.

**Percepção** — notar o mundano: som, cheiro, movimento, a coisa fora do lugar, a pessoa suando frio.

**Persuasão** — convencer, negociar, conseguir que façam o que você quer porque querem. Termina com as duas partes de pé.

**Enganação** — mentir, blefar, se passar por outro. Termina com alguém acreditando em coisa que não é verdade, e o relógio correndo.

**Intimidação** — ameaçar, dominar pela presença, fazer alguém **recuar**. O capanga que abre a porta, a testemunha que decide falar.

**Atuação** — representar, cantar, tocar para uma plateia. A infiltração longa: você não mente uma frase, vive um disfarce.

**Provocar** — tirar alguém do sério, forçar a vir para cima de você. É o oposto de `Intimidação`: uma faz recuar, a outra faz **avançar**. Em combate ela tem ação própria, `Provocar`, no capítulo 2, *O Turno*.

### Técnica do inimigo

Não existe perícia para isso. São duas perguntas diferentes, e cada uma já tem casa.

**Ocultismo e Sentir Energia**
| `Ocultismo` reconhece o que você está vendo | `Sentir Energia` lê como a energia se move |
|---|---|
| *"Isso é uma técnica de troca, e troca sempre tem um custo."* | *"Ela gasta muito no começo de cada golpe. Se eu forçar três seguidos, ela seca."* |
| Você conhece o catálogo | Você não precisa saber o nome do que está acontecendo |

## Ofícios

Ofício é o que o personagem sabe fazer porque alguém sentou com ele e ensinou.

**Condução** — carro, moto, van, o que estiver na garagem. Chegar a tempo, e sair inteiro com dois feridos atrás.

**Arrombamento** — tranca, alarme, cofre, janela que não devia abrir. Decide por qual porta o grupo entra.

**Herbalismo** — planta que cura, planta que mata, chá, unguento. O acampamento, e a volta da missão com alguém mal.

**Forja** — fazer, afiar e manter arma, e cuidar de ferramenta amaldiçoada sem estragar o que tem dentro.

**Caligrafia** — talismã, papel de barreira, documento oficial. E documento oficial que não é oficial.

**Burocracia** — relatório, requisição, quem assina o quê, como se encobre o que não devia ter sido visto. A cena depois da luta.

**Entalhador** — madeira, pedra, osso. O corpo que vai receber alguma coisa: recipiente, selo físico, boneco.

**Alfaiate** — tecido, corte, remendo. O uniforme que aguenta energia amaldiçoada sai daqui, e o traje sob medida também.

**Culinária** — cozinhar de verdade, para gente ou para o que aceitar comida. As cenas de descanso, e o que quer ser agradado.

**Instrumento** — um instrumento, escolhido no treino. A festa, o velório, o templo, ou segurar a atenção de uma sala inteira.

**Jogatina** — carta, dado, aposta, e ler a mesa enquanto joga. A porta social: a sala de mahjong nos fundos.

## Treino

> **O Caminho dá duas perícias fixas e mais cinco à sua escolha, de qualquer uma da lista de perícias do sistema.**
> **A Origem dá mais duas perícias, e dois ofícios à sua escolha.**

As duas fixas são a assinatura do Caminho, o que qualquer um daquele Caminho sabe fazer. As cinco livres são a sua escolha.

**Perícias fixas por Caminho**
| Caminho | Perícias fixas |
|---|---|
| **Bastião** | Atletismo · Provocar |
| **Vanguarda** | Acrobacia · Percepção |
| **Guia** | Persuasão · Medicina |
| **Emanador** | Ocultismo · Investigação |
| **Evocador** | Religião · Lidar com Animais |
| **Incursor** | Acrobacia · Intuição |

### Perícias da Origem

Uma perícia da lista de quatro da sua Origem, e uma perícia livre que a sua história justifique, com aprovação do mestre. Foi filho de médico, tem `Medicina`. Batia carteira antes de saber o que era energia amaldiçoada, tem `Prestidigitação`.

**O Caminho não dá ofício.** Quem dá é a Origem — dois, à sua escolha —, e os dois dela se trocam por mais uma perícia livre. *Ofício é uma prática que alguém te ensinou, e quem te ensinou é o seu passado.*

**Rotas do ofício**
| Se você | Perícias treinadas | Ofícios treinados |
|---|---|---|
| ficar com os dois ofícios | 9 | 2 |
| trocar os dois por perícia | 10 | 0 |

> **Exemplo.** O Kaito é Guia. Ele já entra com as fixas `Persuasão` e `Medicina`. Das cinco livres do Caminho ele gasta duas em treino de arma — o `Guia` não treina arma de verdade, e ele quis a Naginata —, e nas três que sobram pega `Sentir Energia`, `Ocultismo` e `Percepção`. A Origem dele dá mais duas perícias e os dois ofícios, e nesses ele pega `Herbalismo` e `Caligrafia`. Ele fecha com 7 perícias, 2 ofícios e uma arma: ele lê talismã, alcança com a haste, e não arromba uma porta.

### Testes de Resistência

A Origem treina um Teste de Resistência, o Caminho treina outro. Ser treinado num Teste de Resistência vale **a maestria**, igual à perícia e ao ofício, e a lista dos quatro está no capítulo 1, *Como Jogar*.

---


# Capítulo 4 · Dano, Condições e Cobertura

*fonte: `manual/15-dano-e-condicoes.md`*

## Tipos de dano

Todo dano deste sistema tem um tipo, e os catorze tipos se dividem em três grupos. O grupo importa porque várias habilidades resistem a um grupo inteiro em vez de a um tipo só.

> | grupo | tipos |
> |---|---|
> | **Físicos** | `Cortante` · `Perfurante` · `Concussão` |
> | **Elementais** | `Fogo` · `Frio` · `Elétrico` · `Ácido` · `Trovejante` · `Veneno` |
> | **Especiais** | `Radiante` · `Necrótico` · `Psíquico` · `Energia Reversa` · `Alma` |

A lista é fechada. Quando uma arma, um feitiço ou uma habilidade disser de que tipo é o dano, ou a que tipo ela resiste, o nome sai daqui.

### Catálogo

O número do dano vem da arma ou do feitiço. O tipo diz quem resiste a ele e como a mesa descreve o golpe.

#### Físicos

**`Cortante`** — causado por lâminas, fios e superfícies afiadas. Rasga tecidos e carne, deixando ferimentos abertos e sangramento visível.

**`Perfurante`** — causado por pontas, agulhas e projéteis. Concentra toda a força em um único ponto, perfurando defesas para atingir órgãos e estruturas internas.

**`Concussão`** — causado por socos, impactos com objetos pesados e quedas. Transmite força bruta para fraturar ossos, desorientar e mover o alvo do lugar.

#### Elementais

**`Fogo`** — causado por chamas e calor extremo. Incendeia alvos, consome o ambiente e continua queimando após o impacto.

**`Frio`** — causado por temperaturas congelantes. Drena o calor do corpo, travando articulações e enrijecendo os músculos.

**`Elétrico`** — causado por descargas e correntes elétricas. Percorre o organismo provocando espasmos violentos e eletrificando condutores.

**`Ácido`** — causado por compostos químicos corrosivos. Corrói a matéria continuamente, degradando equipamentos e pele ao mesmo tempo.

**`Trovejante`** — causado por ondas de choque sonoras e deslocamento de ar. Empurra estruturas, estoura tímpanos e estilhaça o ambiente.

**`Veneno`** — causado por toxinas e substâncias nocivas. Age de forma insidiosa dentro do organismo, enfraquecendo a vítima antes da queda.

#### Especiais

**`Radiante`** — causado por luz abrasadora ou julgamento espiritual. Queima o alvo de dentro para fora, e pode cegar antes de causar o dano físico.

**`Necrótico`** — causado por forças de decomposição e podridão. Atrofia a carne viva, escurece a pele e dificulta a regeneração dos ferimentos.

**`Psíquico`** — causado por trauma mental puro e colapso da consciência. Bate diretamente na mente, causando dor agonizante sem deixar marcas externas no corpo.

**`Energia Reversa`** — causado pela inversão da energia em maldições. Desmonta a biologia da maldição, desestruturando tecidos.

**`Alma`** — causado por ataques diretos à essência espiritual. Ele gasta Integridade em vez de vida, e tem quatro estágios próprios. Os quatro estágios estão na tabela `Estágios de dano na alma`.

### Nomes repetidos

Seis desses nomes você já viu em outro lugar, e ali eles querem dizer outra coisa.

**Nomes repetidos**
| onde o nome aparece | o que ele é ali |
|---|---|
| `Fogo`, `Ácido`, `Veneno` como **Tema** do Fundamento | rótulo de sabor pendurado numa técnica, sem efeito próprio |
| `Cortante`, `Trovejante`, `Alma` dentro de `Passo Cortante`, `Palma Trovejante`, `Toca a Alma` | pedaço do nome de um feitiço pronto |
| os catorze desta seção | o tipo do dano na hora que ele cai |

Um não puxa o outro. Um feitiço com o Tema `Fogo` só causa dano do tipo `Fogo` se o texto dele disser isso.

> **Exemplo.** A Mei tem uma habilidade que dá resistência a `Fogo`. O inimigo acerta ela com `Palma Trovejante`, que causa dano `Trovejante`. Os dois são Elementais, e isso não basta: a resistência dela nomeia um tipo, e `Trovejante` não é `Fogo`. Ela toma o dano inteiro.

### Dano na alma

**Integridade é a vida da alma**, e a fórmula dela é `20 + (Essência + 5) × (nível − 1)`, do capítulo 1, *Como Jogar*. Por exemplo, 6 de dano na alma tiram 6 de vida e 6 de Integridade.

> **Cada ponto de dano na alma tira 1 de vida e 1 de Integridade.**
>
> Caso você chegue a `0` de vida antes da sua Integridade, você fica `Inconsciente`.
>
> **Dano na alma entra cheio**, sem redução pela metade.
>
> Ao receber, faça um **Teste de Resistência de Espírito** contra a CD do atacante. Numa falha, você também avança um estágio na hora, mesmo que a fração ainda não tenha fechado.
>
> Esse teste só pode ser feito uma vez por rodada.

**Estágios de dano na alma**
| Integridade perdida | Estágio | O que pega |
|---|---|---|
| 1/4 | **1** | Desvantagem em testes de perícia. |
| 1/2 | **2** | Deslocamento pela metade, e todo feitiço custa +1 PE por Classe. |
| 3/4 | **3** | Desvantagem em ataques e Testes de Resistência. Você não conjura acima de metade da sua Classe máxima. |
| Toda | **4** | Você não é mais você. O que sobra é decisão do mestre. |

**Cura comum não devolve o que a alma perdeu.** Só descanso longo, ou a Melhoria `Remenda`, no capítulo 9, *Fundamento*. O descanso longo devolve toda a Integridade e limpa os estágios.

**Nenhum feitiço passa de 2 × Classe em dados na alma.**

#### Dano direto na alma

Existe um dano na alma que não leva o corpo junto: ele tira Integridade e **só** Integridade.

> **Dano na alma que atravessa não tira vida.** Ele desconta da Integridade, e os estágios valem igual.

Isso não é o padrão — é exceção, e ela precisa estar escrita no efeito. **Hoje existe uma:** o `Cisão`, no capítulo 16, *Ferramenta Amaldiçoada*.

## Condições

**Condição** é um estado nomeado que muda o que você consegue fazer enquanto durar. São treze, e cada uma tem um **nível**: `Leve`, `Média` ou `Pesada`.

> **O nível faz duas coisas, e são as duas contas que a condição pede.**
> É o que ela **custa para comprar** dentro de um feitiço.
> É o que ela **custa para tirar** de alguém, em pontos de energia.

### Como ler

Cada condição abre dizendo **quando** ela vale. Depois vem um parágrafo por efeito, e cada
efeito tem nome próprio: `Deslocamento`, `Seus ataques`, `Contra você`, `Ação`, `Testes` e
`Sai quando`. Os mesmos seis nomes aparecem em todas as treze, então quem aprende um
reconhece nas outras.

No fim do capítulo, a tabela `Condições em uma linha` traz as treze resumidas, para
consulta na mesa.

### Nível `Leve`

#### `Lento`

Enquanto está `Lento`, você sofre os seguintes efeitos.

**Deslocamento.** Cai pela metade.

**Ação.** Você não pode usar Ação Bônus.

#### `Incapacitado`

Enquanto está `Incapacitado`, você sofre os seguintes efeitos.

**Ação.** Você não pode `Bloquear`.

**Contra você.** Todo ataque corpo a corpo **que acertar** é crítico.

**Só o corpo a corpo.** *Ataque de conjuração e ataque à distância não críticam por causa desta condição — e o feitiço de Toque é conjuração, mesmo saindo encostado em você.* O crítico dobra o dado da arma e mais nada; o capítulo 1, `Crítico`, é quem diz o que entra.

#### `Derrubado`

Você está no chão. Enquanto está `Derrubado`, você sofre os seguintes efeitos.

**Deslocamento.** Só se move rastejando, com metade do deslocamento. Levantar custa a sua Ação de Movimento, quando não for efeito de duração.

**Seus ataques.** Desvantagem.

**Contra você.** Vantagem a até **1,5 m**, desvantagem de mais longe.

#### `Agarrado`

Enquanto está `Agarrado`, você sofre os seguintes efeitos.

**Deslocamento.** É `0`.

**Ataque à distância.** Quem atira contra alguém que está agarrando outra pessoa tem 50% de chance de errar o alvo pretendido: role `1d10`, e em 6 ou mais você acerta o alvo desejado; em 5 ou menos, acerta quem está agarrando.

**Sai quando.** Quem agarrou ficar `Incapacitado`, ou alguma coisa tirar você do alcance dele.

#### `Desarmado`

A sua arma está no chão ou na mão de outro. Enquanto está `Desarmado`, você sofre o seguinte
efeito.

**Seus ataques.** Você bate desarmado até pegar a arma de volta.

#### `Surdo`

Você não ouve. Enquanto está `Surdo`, você sofre os seguintes efeitos.

**Testes.** Falha automática no que precise de audição.

**Iniciativa.** `−2`.

### Nível `Média`

#### `Calado`

Enquanto está `Calado`, você sofre o seguinte efeito.

**Conjuração.** Você não conjura. Nada que precise de voz, gesto ou Selo que envolva voz sai. Na `Kata`, o mesmo padrão: ela não sai se precisar de voz, como a Restrição `Gesto`, que pede falar, ou de uma ferramenta que precise de som. A que não precisa sai normalmente.

É uma condição de nicho: ela só cala o que precisa de voz. O feitiço de quem tem Selo de condição, sem a Restrição `Gesto`, sai normalmente, e num inimigo ela só cala o Selo ou a habilidade que precise de voz. O inimigo que não usa voz não é imune a ela: ela só não tem o que calar.

#### `Enfeitiçado`

Enquanto está `Enfeitiçado`, você sofre os seguintes efeitos.

**Seus ataques.** Você não ataca quem enfeitiçou, nem mira efeito nocivo nele.

**Contra você.** Ele tem vantagem em teste social contra você.

**Sai quando.** O alvo enfeitiçado recebe um ataque ou um efeito ofensivo.

### Nível `Pesada`

> **Só as de nível `Pesada` dão Teste de Resistência no fim de cada turno do alvo.**
> **E só cabe uma delas por feitiço.**

#### `Impedido`

Enquanto está `Impedido`, você sofre os seguintes efeitos.

**Deslocamento.** É `0`.

**Seus ataques.** Desvantagem.

**Testes.** Desvantagem no Teste de Resistência Físico.

**Contra você.** Vantagem.

#### `Cego`

Você não enxerga. Enquanto está `Cego`, você sofre os seguintes efeitos.

**Testes.** Falha automática no que precise de vista.

**Seus ataques.** Desvantagem.

**Contra você.** Vantagem.

#### `Amedrontado`

Enquanto está `Amedrontado`, você sofre os seguintes efeitos.

**Seus ataques.** Desvantagem, enquanto você enxergar a fonte do medo.

**Testes.** Desvantagem, enquanto você enxergar a fonte do medo.

**Deslocamento.** Você não se aproxima da fonte do medo por vontade própria.

#### `Envenenado`

Enquanto está `Envenenado`, você sofre os seguintes efeitos.

**Seus ataques.** Desvantagem.

**Testes.** Desvantagem em todo teste de perícia.

#### `Atordoado`

Enquanto está `Atordoado`, você sofre os seguintes efeitos.

**Ação.** Você perde a Ação Padrão e não usa reação. Quem tem mais de uma Ação Padrão no
turno — um chefe, um capanga grande — perde **uma** das suas ações, e não todas.

> **Exemplo.** A Rina fica `Atordoada`. Ela perde a Ação Padrão daquele turno e não usa reação, então ninguém leva ataque de oportunidade dela. A Defesa continua a mesma: `Atordoado` não abre a guarda de ninguém. No fim do turno dela, como é uma condição `Pesada`, ela faz o Teste de Resistência e pode sair sozinha.

### Condições em uma linha

Para consulta na mesa. O efeito inteiro de cada uma está na entrada dela.

**Condições em uma linha**
| condição | nível | o que faz |
|---|---|---|
| `Lento` | `Leve` | deslocamento pela metade, sem Ação Bônus |
| `Incapacitado` | `Leve` | não `Bloqueia`, e todo ataque corpo a corpo que acertar é crítico — só ele |
| `Derrubado` | `Leve` | rasteja; desvantagem nos seus ataques; vantagem a quem ataca de perto |
| `Agarrado` | `Leve` | deslocamento `0` |
| `Desarmado` | `Leve` | bate desarmado até pegar a arma de volta |
| `Surdo` | `Leve` | falha no que precise de audição, `−2` na iniciativa |
| `Calado` | `Média` | não conjura |
| `Enfeitiçado` | `Média` | não ataca quem enfeitiçou; ele tem vantagem social contra você |
| `Impedido` | `Pesada` | deslocamento `0`, desvantagem nos ataques e no Físico |
| `Cego` | `Pesada` | falha no que precise de vista, desvantagem nos ataques |
| `Amedrontado` | `Pesada` | desvantagem enquanto vir a fonte, e não se aproxima dela |
| `Envenenado` | `Pesada` | desvantagem nos ataques e em todo teste de perícia |
| `Atordoado` | `Pesada` | perde a Ação Padrão e a reação |

### `Inconsciente`, `Exaustão` e `Invisível`

Estas três não são condição.

**`Inconsciente`, `Exaustão` e `Invisível`**
| não é condição | onde ela está |
|---|---|
| `Inconsciente` | é cair a 0 de vida, com regra própria no capítulo 1, *Como Jogar* |
| `Exaustão` | é relógio de descanso, e mora no capítulo 5, *Descanso e Recuperação* |
| `Invisível` | é benefício, e as condições são compradas para aplicar num alvo |

### Comprar uma condição

> **Existe uma Melhoria `Condição`, e o preço dela é o nível da condição que você escolheu.**
> Escolher `Derrubado` custa `Leve`. Escolher `Atordoado` custa `Pesada`.

Você aponta a condição na tabela `Condições em uma linha`, lê o nível dela, e esse é o preço. Não existe pacote nem grupo de compra.

> **Exemplo.** O Kaito está montando um feitiço de Classe 2 que derruba quem for acertado. Ele compra a Melhoria `Condição` e escolhe `Derrubado`, que é `Leve`. Numa Classe 2 isso custa `1` ponto, e ele fica com o resto do orçamento em dados de dano. Se ele quisesse `Impedido`, que é `Pesada`, o mesmo feitiço pagaria `3` e sairia bem menor.

### Tirar uma condição

> **Tirar uma condição de alguém custa `1` ponto de energia por nível: `1` para `Leve`, `2` para `Média`, `3` para `Pesada`.**

Você só faz isso se tiver uma habilidade que tire condição, e cada habilidade dessas tem um teto de quanta energia ela gasta por uso. O teto é que decide o que você alcança: com teto `2` você limpa `Leve` e `Média`, e a `Pesada` fica fora até o teto subir.

> **Exemplo.** A Mei tem uma habilidade de tirar **uma** condição com teto de `2` pontos de energia por uso. O aliado dela está `Calado`, que é `Média`: ela gasta `2` e limpa. No turno seguinte o mesmo aliado fica `Cego`, que é `Pesada`: ela precisaria de `3`, e não consegue até a habilidade dela crescer.

## Cobertura

Cobertura é o que está entre você e quem está atirando. São três degraus, e você lê o que enxerga do alvo para saber em qual deles ele está. A pergunta que o mestre faz é sempre a mesma: daqui, quanto do corpo dele dá para acertar?

**Degraus de cobertura**
| cobertura | o que ela dá | exemplo |
|---|---|---|
| **Parcial** (`1/4`) | **`+2` de Defesa e `+2` no Teste de Resistência Físico** | mureta, tronco, uma criatura no caminho |
| **Boa** (`1/2`) | **`+5` de Defesa e `+5` no Teste de Resistência Físico** | seteira, olhando por cima de uma parede, metade do corpo atrás de um canto |
| **Total** | **você não pode ser escolhido como alvo** | parede inteira, do outro lado da porta |

> **Vale contra o que vem do outro lado da cobertura, e só.** Quem está atrás de uma mureta não ganha nada contra quem já está do outro lado dela.
>
> **Só a maior conta.** Duas coberturas parciais não viram uma boa.

A **Total** tira você da lista de alvos possíveis, e não dá número nenhum. Um efeito que pega área continua alcançando quem está atrás dela, se o efeito não precisar de linha até o alvo.

> **Exemplo.** O Sousuke está agachado atrás do capô de um carro, com meio corpo de fora. Isso é cobertura **Boa**: a Defesa dele sobe `5` contra quem atira do outro lado do estacionamento. Ele decide se jogar inteiro para trás do carro e passa a ter cobertura **Total**, então ninguém do outro lado consegue escolher ele como alvo. Mas um feitiço de área que estoura embaixo do carro não precisa de linha até ele, e alcança do mesmo jeito. Como a **Total** não dá número, o Teste de Resistência Físico dele sai limpo, sem os `5` que ele tinha um segundo antes.

---


# Capítulo 5 · Descanso e Recuperação

*fonte: `manual/70-descanso-e-recuperacao.md`*

O combustível volta em dois momentos.

> **Descanso curto: você parou entre uma luta e outra.** Ninguém está te caçando agora.
>
> **Descanso longo: a missão acabou.** Você parou de trabalhar.

Não existe contagem de horas: o gatilho é o que aconteceu na história.

## Cena

> **Quem conta é o mestre.** Uma cena pode ser uma sala, um segmento de salas, ou um combate. **Ela acaba quando a pressão daquele pedaço acaba**: o inimigo caiu, a porta fechou, o grupo saiu dali.

## Ambiente propício

Quase tudo neste capítulo depende de uma pergunta só: o lugar onde você parou tem recursos?

> **Ambiente propício é um lugar com gente, suprimento e teto.** Talismã, kit, comida, alguém que sabe costurar um corte. É a diferença entre voltar para a escola e dormir no mato.

Contam como propício:

- a escola, e qualquer campus da instituição
- um posto oficial ou barreira montada da instituição
- a casa de um clã que te recebe
- um hospital, jujutsu ou comum
- um veículo de apoio, com o kit dentro

> **O mestre tem a palavra final, sempre.** Um santuário abandonado com um velho que já foi feiticeiro pode ser propício; a escola sob ataque pode não ser.

## Recuperação

O PE é o que você tem para a missão inteira. Só o descanso longo devolve tudo.

### PE

Os pontos de energia amaldiçoada que você gasta para conjurar.

### Descanso curto

**Descanso curto**
| | devolve |
|---|---|
| **PE** | **25% do seu máximo** |
| **Vida** | nada |
| **Usos `por descanso curto`** | recarregam |

**O Corpo Amaldiçoado é a exceção da vida:** no descanso curto, um `Entalhador` ou uma `Forja` o reparam em metade da vida máxima (capítulo das Origens).

Os 25% valem em qualquer lugar. O que o ambiente propício faz é **proteger esse número da exaustão**: fora dele, cada degrau de exaustão corta um pedaço, até sobrar nada.

Vida não volta sozinha no respiro entre lutas, porque quem cura pessoas neste mundo é a Energia Reversa.

### Descanso longo

**Descanso longo**
| | em ambiente propício | fora dele |
|---|---|---|
| **PE** | **cheio** | **metade do seu máximo** |
| **Vida** | **cheia** | **metade do seu máximo** |
| **Exaustão** | **zera** | **não zera** |
| **Integridade** | **cheia**, e os estágios limpam | **cheia**, e os estágios limpam |

A metade é sempre metade do **máximo**, nunca metade do que sobrou. Um Emanador de nível 10 com pool 60 que dorme no campo acorda com 30. No quarto dia de campo ele continua acordando com 30.

A Integridade volta inteira em qualquer lugar. É a única coisa que o ambiente não toca: não precisa de enfermaria quem precisa é do corpo.

> **Frações.** Arredonde para baixo, e o que você recupera nunca fica abaixo de 1.

Quando a tabela `Degraus de Exaustão` diz que no degrau 3 você recupera **nada**, ela diz nada.

## Exaustão

> **Da quarta luta do dia em diante, cada luta dá um degrau de exaustão. Máximo de três.**

### Contagem de luta

> **Quem conta é o mestre, e ele conta como em qualquer mesa: foi uma luta se pareceu uma luta.**

Não depende de ter rolado iniciativa. Uma perseguição que virou briga no meio conta; uma emboscada de uma rodada em que ninguém revidou pode não contar. E não é só maldição: feiticeiro contra feiticeiro cansa igual, e às vezes mais.

Costumam contar:

- um combate com inimigo que reage, maldição ou feiticeiro
- uma fuga em que o grupo gastou recurso para escapar
- um ritual ou uma contenção sob pressão, com alguém tentando impedir

Costumam não contar: a maldição de nível baixo que morre no primeiro golpe, o treino, a discussão que não virou porrada.

### Degraus

**Degraus de Exaustão**
| degrau | o que pega | quanto o descanso curto devolve, fora de ambiente propício |
|---|---|---|
| **0** | — | 25% |
| **1** | desvantagem em perícia e ofício | 15% |
| **2** | deslocamento cai para 4,5 m | 5% |
| **3** | desvantagem em ataque e em Teste de Resistência | nada |

Desvantagem é rolar dois d20 e ficar com o menor.

**Em ambiente propício o descanso curto devolve 25% em qualquer degrau.** A exaustão só corta o combustível de quem está longe de casa.

### Exaustão e Integridade ao mesmo tempo

As duas escadas se parecem muito, e é comum estar nas duas.

**Exaustão e Integridade**
| | exaustão | Integridade |
|---|---|---|
| **degrau 1** | desvantagem em perícia e ofício | desvantagem em testes de perícia |
| **degrau 2** | deslocamento cai para 4,5 m | deslocamento pela metade, e +1 PE por Classe |
| **degrau 3** | desvantagem em ataque e em Teste de Resistência | desvantagem em ataque e em Teste de Resistência, e teto de Classe |

> **Quem está nas duas pega o pior, não soma.**

Desvantagem não empilha com desvantagem, e dois cortes de deslocamento não se multiplicam. O que só uma das duas tem continua valendo normalmente: o +1 PE por Classe e o teto de Classe são da Integridade e não competem com nada do lado da exaustão.

### Teto

A exaustão para no terceiro degrau. Uma missão de campo de três dias com quatro lutas por dia acumula três degraus e trava ali.

> **O mestre pode tirar um degrau quando a ficção pedir.** Uma noite de sono de verdade, um chá que alguém sabia fazer, um dia parado.

O mestre nunca adiciona degrau fora da regra.

## Relógios

**Relógios**
| relógio | recarrega quando | frequência |
|---|---|---|
| **por cena** | a cena acaba | a mais frequente |
| **por descanso curto** | você para entre lutas | ↓ |
| **por dia** | você dorme | ↓ |
| **por descanso longo** | a missão acaba | a menos frequente |

`Por dia` e `por descanso longo` não são a mesma coisa, e a diferença aparece em missão comprida. Uma missão pode durar cinco dias: quem tem alguma coisa `por dia` recarrega cinco vezes; quem tem `por descanso longo` recarrega uma.

## Exemplo

> **A Kaori** — Bastião de nível 2, Constituição 2. Vida 23, PE 8.
>
> **Manhã.** Sai da escola com tudo cheio.
>
> **Primeira luta.** Gasta 6 PE e leva 9 de dano. Fica com 2 PE e 14 de vida.
>
> **Descanso curto, no carro de apoio.** O carro está na lista: ambiente propício. Volta 25% de 8 = **2 PE**, e ela fica com 4. A vida não volta, porque ninguém ali sabe curar.
>
> **Segunda luta.** Gasta 3 PE e leva 7 de dano. Fica com 1 PE e 7 de vida.
>
> **Descanso curto, num prédio abandonado.** Não é propício, mas ela está no degrau 0 de exaustão, e no degrau 0 não há corte. Recupera os mesmos **2 PE**, ficando com 3.
>
> **Terceira luta.** Gasta 3 PE e sobrevive com 3 de vida e 0 PE, socando.
>
> **Quarta luta?** Se acontecer, ela ganha o primeiro degrau de exaustão: desvantagem em perícia e ofício.
>
> **Fim da missão, de volta na escola.** Ambiente propício: PE cheio, vida cheia, exaustão zerada, Integridade cheia.
>
> **Se a missão não tivesse acabado** e ela dormisse no mato: 4 PE, 11 de vida, e a exaustão que tivesse continuaria com ela.

O prédio abandonado sozinho não é problema. O prédio abandonado **com você cansado** é.

---


# Capítulo 6 · Criação de Personagem

*fonte: `manual/20-criacao-de-personagem.md`*

## Peças da ficha

- **Uma técnica** que só você tem, escrita por você
- **Cinco atributos**, de 0 a 6
- **Um Caminho e uma Trilha**, que dizem o seu lugar numa equipe e quem você é dentro dele
- **Uma Origem**, que diz de onde veio o seu poder
- **Nove perícias e dois ofícios** treinados, ou dez e nenhum, você escolhe
- **Dois Testes de Resistência** treinados, de quatro
- **Dois Legados**, das listas da sua Origem. Um `Destranca` e um `Desliga` ou `Ajusta`
- **Cinco feitiços**: dois pequenos e grátis, três de verdade
- **Os números que caem sozinhos**: vida, energia, Defesa, iniciativa

## Nível inicial

> **Personagem novo começa no nível 2.** Não existe ficha de nível 1 padrão.

O nível 1 é o personagem antes de virar feiticeiro: a pessoa que ainda não é feiticeira de verdade, o Itadori antes do dedo. Ele fica como opção de campanha para quem quiser jogar essa parte.

No nível 2 você já tem técnica, já tem feitiço e já dá para encarar uma missão. As contas do passo 7 presumem o nível 2.

## Ordem dos passos

> **Origem → a Regra em uma frase → Caminho → Atributos → a técnica inteira → perícias e ofícios → os números → Pactos.**

A técnica sai partida em duas: a Regra, uma frase só, vem no passo 2, antes do Caminho decidir nada por você; o resto espera até o passo 5, depois que o Caminho e os atributos já estão na ficha.

## Passo 1 · Origem

De onde vem o seu poder. Nasceu com você, veio no sangue de um clã, você virou recipiente de alguma coisa, alguém te fez, ou trocaram uma coisa por outra antes de você nascer.

São sete Origens, mais a sub-origem Sem Técnica. Escolha e anote na ficha:

**Anotações da Origem**
| O que anotar | De onde sai |
|---|---|
| Uma perícia | da lista de quatro da sua Origem |
| Uma perícia livre | que a sua história justifique, com o mestre aprovando na leitura |
| Um Teste de Resistência treinado | qualquer um dos quatro; o outro vem do Caminho |
| Um traço | do catálogo da sua Origem, ou escrito por você |
| Dois Legados | um `Destranca` obrigatório, mais um de qualquer formato |
| A rota de criação | por onde você monta o seu poder |

As listas de perícia, os traços e as rotas estão no capítulo 7, *Origens e Legados*, e é lá que estão também as listas de Legado de cada Origem.

A Origem não dá ponto de atributo nenhum, e não decide a sua patente: todo personagem começa **Grau 4**, venha de onde vier.

> **O `Efeito na ficha` de cada Origem, no capítulo 7, *Origens e Legados*, diz por qual rota ela monta o poder.** Se a sua for a sub-origem Sem Técnica, a máquina inteira está no capítulo 11, *Sem Técnica* — e o Passo 2 e o Passo 3 valem igual.

> **Duas rotas montam poder pela Técnica Marcial, no capítulo 10:** o Corpo Amaldiçoado e a Restrição Celestial pelo ramo sem energia. Se for o seu caso, o Passo 2 e o Passo 3 valem igual — o que muda é o capítulo que você abre para montar.

## Passo 2 · Regra da técnica

Uma frase que diz o que a sua técnica faz com o mundo, sem falar em efeito nem em dano.

> *"Tudo que eu prendo entre as minhas mãos fica mais pesado."*
>
> *"Eu troco de lugar com qualquer coisa do meu tamanho que eu esteja enxergando."*
>
> *"Quem mente na minha frente sangra."*

Uma frase, verificável pela mesa, sem número. Você carrega ela a campanha inteira, porque a técnica nunca muda. O que evolui é o que você consegue fazer com ela.

Pare aqui e vá para o Caminho. O resto da técnica volta no passo 5.

## Passo 3 · Caminho e Trilha

Que lugar você ocupa numa equipe. Um Caminho por personagem, escolhido agora e para sempre. Não existe multiclasse.

**Caminhos**
| Caminho | O que ele é | Atributos naturais |
|---|---|---|
| **Bastião** | o corpo como resposta: aguentar, encarar, prender | Força, Constituição |
| **Vanguarda** | a arma como resposta: alcançar, cortar, acabar | Destreza, Força |
| **Guia** | o outro como resposta: estender, recuperar, reposicionar | Essência |
| **Emanador** | a técnica como resposta: mais feitiço, e mais barato | Inteligência, Essência |
| **Evocador** | o vínculo com suas invocações | Inteligência, Essência |
| **Incursor** | movimento e abertura no confronto | Destreza, Força |

O Caminho mexe em posicionamento, alvo, duração e recuperação. Cada habilidade declara suas exceções de dano, Classe e recuperação; cumpra os custos e requisitos do capítulo 8.

### Características do Caminho

**Características do Caminho**
| Caminho | Vida inicial | Vida por nível | PE por nível | Perícias fixas |
|---|---|---|---|---|
| **Bastião** | 12 (d12) | 7 | 4 | Atletismo · Provocar |
| **Vanguarda** | 8 (d8) | 5 | 5 | Acrobacia · Percepção |
| **Guia** | 8 (d8) | 5 | 5 | Persuasão · Medicina |
| **Emanador** | 6 (d6) | 4 | 6 | Ocultismo · Investigação |
| **Evocador** | 6 (d6) | 4 | 6 | Religião · Lidar com Animais |
| **Incursor** | 6 (d6) | 4 | 6 | Acrobacia · Intuição |

Mais **cinco perícias à sua escolha**, de qualquer uma da lista de perícias do sistema, **dois ofícios à sua escolha** e **um Teste de Resistência treinado**. *Os dois ofícios se trocam por mais uma perícia, e no `Guia`, no `Emanador` e no `Evocador` duas das cinco se trocam por treino em uma arma.*

### Equipamento

> **Você sai de casa com o `Traje` degrau 1 da instituição e ¥150.000 para montar o resto.**

O Caminho te treina numa lista de armas; ele não te dá a arma. Isso você compra, e as tabelas de `Preços` estão no capítulo 15, *Equipamento*. Os ¥150.000 são uma mensalidade de um Grau 4, que é o que você é no começo.

O dinheiro dá para mais que a arma, e é aí que duas fichas do mesmo Caminho começam diferentes: dá para sair de espada e escudo, de uniforme reforçado, ou de `Revestimento` e punho fechado. As contas de cada uma estão no capítulo 14.

O uniforme não muda a sua Defesa no nível 2 — ele dá proteção 1 e desliga o `cobrir-se`, que no refino 1 também dá 1. Ele é roupa, e serve para você não andar de blusa de moletom numa missão.

### Trilha

A Trilha é escolhida agora, junto do Caminho, e nasce com o personagem. São três por Caminho: Muro · Punho · Combatente Amaldiçoado no Bastião, Estocada · Batedor · Executor na Vanguarda, e assim por diante. A lista está no capítulo 8, *Caminhos e Trilhas*.

> **A Trilha já entrega no nível 2**, junto do primeiro degrau do Caminho, e volta a entregar nos níveis 11, 19 e 27. O texto de cada uma está no capítulo 8, *Caminhos e Trilhas*.
>
> **Para jogar com invocações**, leia também o capítulo 17, *Invocações*. O Evocador aprimora esse subsistema; outros Caminhos podem utilizá-lo seguindo suas regras comuns.

## Passo 4 · Atributos

> **Nove pontos entre os cinco atributos. Nenhum acima de 3.**

O número **é** o modificador. Não existe valor separado nem tabela de conversão. A escala vai de 0 a 6, e 6 é o topo humano. Uma distribuição legal, por exemplo, é 3 · 2 · 2 · 1 · 1.

O que cada atributo governa está na tabela `Atributos` do capítulo 1, *Como Jogar*.

Inteligência sabe; Essência percebe. Sentir energia amaldiçoada é a sua energia reagindo à de outro.

> **Trave agora o seu Teste de Resistência Físico.** Ele usa Força ou Destreza, você escolhe na criação e não muda depois.

## Passo 5 · Técnica inteira

Aqui você abre o capítulo 9, *Fundamento*. É a parte longa. Você já tem a Regra e já sabe o Caminho; falta o resto.

1. **Descrição.** De onde a técnica veio, como ela aparece, o que as pessoas veem quando ela age. Sem efeito mecânico.
2. **Famílias.** Duas **Livres**, cujas Melhorias custam metade da Classe a menos, e três **Fechadas**, das quais você nunca compra nada.
3. **Selo.** O gesto, a condição ou o objeto que a sua técnica exige. Não custa nem devolve ponto. Restrição que o Selo já obriga não devolve ponto.
4. **Passiva Livre.** Uma, de graça, para todo mundo. Ela não rola dado, não muda número e não faz ninguém rolar. Se a técnica impõe uma regra ao mundo, a `Regra Própria` de Classe Passiva 1 vem junto, também de graça.
5. **Os feitiços.** No nível 2 você tem **Classe 1**, dois feitiços de **Classe 0** (grátis, não ocupam espaço) e **três feitiços conhecidos**, montados pelo orçamento da Classe 1. Três é o que a fórmula `2 + (nível ÷ 2)` dá no nível 2.

> **A Regra da técnica é lida por outra pessoa antes de entrar em jogo.** Quem escreveu sabe o que quis dizer; quem vai arbitrar, não.

## Passo 6 · Perícias, ofícios e Testes de Resistência

**Treino na criação**
| De onde vem | Perícias | Ofícios | Teste de Resistência |
|---|---|---|---|
| **Caminho** | 2 fixas + 5 à sua escolha | 2 à sua escolha | 1 |
| **Origem** | 1 da lista dela + 1 livre | — | 1 |

Os dois ofícios da Origem se trocam por mais uma perícia livre, e as duas rotas fecham a ficha:

**Rotas do ofício**
| Rota | Perícias | Ofícios |
|---|---|---|
| ficando com os ofícios | 9 de 23 | 2 de 11 |
| trocando os dois | 10 de 23 | 0 de 11 |

**E nos três Caminhos com treino inicial em Arma de Fogo e Balestra — `Guia`, `Emanador` e `Evocador` — duas das cinco perícias à sua escolha viram treino em uma arma da lista.** *Não a categoria e não o tipo: uma arma.*

Os dois Testes de Resistência treinados saem de quatro: Físico, Vigor, Espírito e Intelecto. Um vem da Origem, o outro do Caminho.

Perícia pertence a um atributo fixo: Atletismo é sempre Força. Ofício não pertence a atributo nenhum. O atributo muda conforme o que você faz com ele, e quem decide é o mestre na hora. Forjar uma lâmina é Força, falsificar uma assinatura é Destreza, saber qual selo o papel pede é Inteligência, e as três coisas são o mesmo ofício.

> **Perícia sem treino você tenta; ofício sem treino, não.** Qualquer um escala e falha. Ninguém forja uma lâmina por tentativa.

O quadro completo das perícias e dos ofícios está no capítulo 3, *Perícias e Ofícios*.

## Passo 7 · Números derivados

Nada aqui é escolha. Você copia da tabela e faz a conta.

**Números do nível 2**
| Número | Como sai |
|---|---|
| Maestria | 1 |
| Refino | 1 |
| Pontos de vida | (vida inicial do Caminho + Constituição) + (vida por nível do Caminho + Constituição) |
| Integridade | 25 + Essência |
| Pontos de Energia | PE por nível do Caminho × 2 |
| Defesa | 10 + Destreza + 1 |
| Iniciativa | d20 + Destreza |
| Deslocamento | 9 metros |
| Ataque corpo a corpo | d20 + Força + 1 |
| Ataque à distância | d20 + Destreza + 1 |
| Ataque de conjuração | d20 + atributo da técnica + 1 |
| CD de feitiço | 8 + atributo da técnica + maestria |
| Perícia treinada | d20 + atributo + 1 |
| Teste de Resistência | d20 + atributo do TR + maestria, e a maestria só se treinado |

No refino 1 você já tem duas aptidões, de graça: `Cobrir-se de energia`, que dá proteção sem equipamento, e `Canalizar energia`, que permite ferir uma maldição com o corpo ou com a arma. São básicas de qualquer feiticeiro.

> **Toda ficha de nível 2 nasce com proteção 1.** É o `+1` que entra na Defesa acima. Sem Traje e sem Revestimento, a sua proteção é `1/3 do refino + 1`, que no refino 1 dá 1. Escudo soma com ela; Traje e Revestimento não.

## Passo 8 · Pactos

Opcional, e a ficha nasce sem nenhum.

Pacto é o que você trocou por poder, e as quatro formas dele têm onde morar:

**Onde cada forma de pacto se escreve**
| O que você quer dizer | Onde isso se escreve |
|---|---|
| *"a minha técnica fica maior sob uma condição que eu aceitei"* | **Restrição**, por feitiço, no capítulo 9 |
| *"a minha técnica impõe uma regra ao mundo"* | **`Regra Própria`**, por técnica, no capítulo 9 |
| *"eu troquei uma coisa antes de a campanha começar"* | **Legado**, na criação, no capítulo 7 |
| *"eu e mais alguém fechamos um trato, aqui, na mesa"* | **Pactos**, no capítulo 18 |

> **Das quatro formas do capítulo 18, só o pacto de restrição entra na criação**, e ele se escreve junto da Origem ou da técnica. As outras três nascem em jogo.

## Exemplo

**A Kaori**, feiticeira de nível 2.

### Origem

**Descendente.** Um clã menor que perdeu o nome faz três gerações. Como todo mundo, ela começa Grau 4: quem abre porta pra ela é o sobrenome, mesmo com a patente baixa.

- *Perícia da lista* (Hierarquia · História · Ocultismo · Persuasão): **Hierarquia**
- *Perícia livre:* **História**, porque ela cresceu ouvindo de quem o clã perdeu o nome
- *Ofícios:* **Forja** e **Herbalismo**, o segundo da avó
- *Teste de Resistência:* **Vigor**
- *Traço:* o ramo do clã que perdeu, e ela é dele
- *Legado · `Destranca`:* **O Sobrenome**, que dá audiência em qualquer lugar do meio jujutsu. Ser bem recebida é outra história
- *Legado · o segundo:* **Biblioteca**, que uma vez por cena refaz um teste de História ou Ocultismo. A casa tinha os livros, e ela foi obrigada a ler

### Regra

*"Tudo que eu prendo entre as minhas mãos fica mais pesado."*

### Caminho e Trilha

**Bastião**, Trilha **Muro**: o corpo é o escudo, e é o que a Regra dela já pedia. *Teste de Resistência do Caminho:* **Físico**.

### Atributos

Força 3 · Constituição 2 · Destreza 2 · Inteligência 1 · Essência 1. Nove pontos, nenhum acima de 3, e o **TR Físico travado em Força**.

### Técnica

*Famílias Livres:* Controle e Castigo. *Fechadas:* Amparo, Área e Auxiliares, porque ela não cura, não pega área e não dá suporte. *Selo:* as duas mãos precisam se tocar antes. *Passiva Livre:* ela sabe o peso exato de qualquer coisa que encoste nela.

### Perícias e ofícios

**Nove perícias.** Do Caminho, fixas: Atletismo e Provocar. Do Caminho, livres: Sentir Energia, Percepção, Sobrevivência, Intuição e Persuasão. Da Origem: Hierarquia e História.

**Dois ofícios.** Forja e Herbalismo, os dois da Origem.

### Números

**Números da Kaori**
| | Conta | Resultado |
|---|---|---|
| Vida | (12 + 2) + (7 + 2) | **23** |
| Integridade | 25 + 1 | **26** |
| PE | 4 × 2 | **8** |
| Defesa | 10 + 2 + 1 | **13** |
| Iniciativa | d20 + 2 | |
| Ataque corpo a corpo | d20 + 3 + 1 | **d20 + 4** |
| Ataque de conjuração | d20 + 3 + 1 | **d20 + 4** |
| CD dos feitiços dela | 8 + 3 + 1 | **12** |
| Atletismo (treinado) | d20 + 3 + 1 | **d20 + 4** |

## Conferência da ficha

Sete perguntas, e todas têm resposta objetiva. Você mesmo passa por elas antes de entregar.

1. **Os atributos somam nove, e nenhum passa de 3?**
2. **O Teste de Resistência Físico está travado** em Força ou Destreza?
3. **São nove perícias e dois ofícios, ou dez e nenhum?** As duas rotas são legais; o que não pode é somar as duas. E as duas perícias fixas do Caminho precisam estar entre elas.
4. **São dois Testes de Resistência treinados**, um da Origem e um do Caminho?
5. **A Regra da técnica cabe em uma frase**, é verificável pela mesa e não tem número?
6. **Alguém que não seja o dono leu a técnica?**
7. **Os três feitiços conhecidos fecham no orçamento da Classe 1?** Três pontos cada.

O mestre pode recusar mesmo quando a ficha passa nas sete.

---


# Capítulo 7 · Origens e Legados

*fonte: `manual/25-origens.md`*

A Origem responde uma pergunta só: de onde veio o seu poder. O que você faz com ele é a técnica; o seu lugar numa equipe é o Caminho.

São sete Origens. Cinco principais (Latente, Receptáculo, Descendente, Reencarnado e Feto) e duas especiais, Corpo Amaldiçoado e Restrição Celestial. Existe ainda uma sub-origem, Sem Técnica, que se soma a qualquer uma das cinco principais.

## Características da Origem

**Características da Origem**
| O que você anota | Detalhe |
|---|---|
| **Uma perícia** | da lista de quatro da sua Origem |
| **Uma perícia livre** | que a sua história justifique; o mestre aprova na leitura |
| **Dois ofícios** | à sua escolha, do quadro do capítulo 3; ou mais uma perícia livre no lugar dos dois |
| **Um Teste de Resistência treinado** | qualquer um dos quatro; o outro vem do Caminho |
| **Um traço** | do catálogo dela, ou escrito por você |
| **Dois Legados** | um `Destranca` obrigatório, mais um de qualquer formato |
| **A rota de criação** | por onde você monta o seu poder |

### Limites

#### Atributo

Nenhuma Origem dá ponto de atributo. Ser recipiente de alguma coisa te dá um passageiro, e o corpo continua exatamente o que era.

#### Feitiço

Nenhuma Origem abre Família, fecha Família, dá Melhoria nem muda Classe.

#### Patente

Todo personagem começa **Grau 4**, venha de onde vier. A patente é eixo social e narrativo, e ela sobe por feito. A instituição pode classificar quem ela quiser onde ela quiser; nenhuma Origem começa na frente.

### Como ler uma Origem

Toda Origem abre pela frase que a resume, seguida do que é ser aquilo no mundo e de quem a carrega na obra.

Depois vem **Efeito na ficha**, sempre na mesma ordem: as **Perícias**, a lista de quatro de onde você escolhe uma, mais a livre; o **Teste de Resistência**, que é escolha sua e sai igual em toda Origem; os **Destrancas**, que dizem quantos Legados a ficha leva; e a **Criação**, a rota por onde você monta o seu poder. As duas Origens especiais mexem nessa rota, e o texto delas diz como.

Por último vêm os **Legados** da Origem, nos três formatos.

## Legados

Legado é um benefício pequeno e específico que você trouxe de antes de a história começar. Legado nenhum produz dano ou escala com nível.

> **Um deles é obrigatoriamente um `Destranca`, e `Destranca` é zero no dado.**
> O outro sai de qualquer lista da sua Origem, dentre `Ajusta` e `Desliga`.

Cada um dos três formatos se lê de um jeito.

A regra de um Legado é a linha em negrito. Quando a entrada termina numa linha *Na mesa*, essa linha diz **em que cena aquilo aparece**, com um exemplo.

### Como ler um Destranca

Um Destranca abre uma porta: um lugar onde você é recebido, uma coisa que você sabe, uma pessoa que existe no mundo por sua causa. Ele nunca mexe em acerto, CD ou dano, e nunca decide o que outra pessoa faz.

A maioria vale sempre, sem contagem. Só quando o Destranca obriga o mestre a te entregar uma informação nova é que ele ganha relógio, pela escada de sempre: por cena, por descanso curto, por dia, por descanso longo, do mais frequente ao mais raro.

### Como ler um Ajusta

Um Ajusta mexe num número de uma rolagem. Quase sempre de um dos dois jeitos: você refaz um teste que já falhou, ou rola com **vantagem** (joga dois dados e fica com o melhor resultado).

Ele carrega relógio sempre, e quanto mais largo o que ele alcança, mais raro o relógio: um que pega qualquer perícia vale por dia, e um que pega uma condição só vale por cena.

### Como ler um Desliga

Um Desliga apaga uma coisa que aconteceria com você, sempre que a situação aparecer, sem rolagem nenhuma. Não existe "tentar" um Desliga; ou a situação bateu e ele age, ou não bateu. **Ele nunca desliga a ficha de outra pessoa** — o que ele apaga é o que o mundo cobra de você, e isso vem de dois jeitos: uma coisa que **chega** em você, como ficar `Agarrado`, ou uma coisa que você **teria de fazer**, como precisar dormir ou rolar para reconhecer uma técnica.

A maioria vale sempre, sem contagem. E cada entrada diz o que você paga em troca: nenhum Desliga é só ganho.

## Latente

*Você nasceu com. Ninguém te deu nada e ninguém te ensinou.*

**Na obra:** Nanami e Hakari, que não vêm de clã e construíram sozinhos o que fazem. O Junpei também: a técnica dele, Escória da Lua, era inata, e o que o Mahito fez foi mexer no cérebro dele para que ela despertasse antes da hora.

### Efeito na ficha

#### Perícias

Escolha uma: Sentir Energia · Sobrevivência · Furtividade · Intuição

Mais uma perícia livre, que a sua história justifique.

Os dois ofícios você aprendeu sozinho, porque não teve de quem aprender. Os dois se trocam por mais uma perícia livre.

#### Teste de Resistência

**Um Teste de Resistência treinado, à sua escolha entre os quatro** — o outro vem do seu Caminho.

*Ele vale igual em toda Origem, e os dois ofícios também: são livres, do quadro do capítulo 3, e os dois se trocam por mais uma perícia livre. **O Caminho não dá ofício** — quem dá é a sua Origem. O que muda de uma Origem para a outra é a lista de perícias e a razão pela qual você aprendeu o que aprendeu.*

#### Destrancas

Você começa toda a ficha com um `Destranca` e um `Ajusta` ou `Desliga`.

#### Criação

Fundamento, do jeito padrão.

### Legados da Latente

#### Destranca

*Escolha um destes, obrigatoriamente.*

> **O Jeito Errado** — **escreva na ficha o que você aprendeu errado antes de aprender certo. Uma vez por dia, aponte alguém fazendo a mesma coisa errada: o mestre diz o que aquilo está custando a essa pessoa.**
> *Na mesa:* serve quando o grupo observa outro feiticeiro trabalhar. *Exemplo: o inimigo gasta energia demais em cada golpe, e você aponta isso antes de a luta começar.*

> **O Professor Que Você Não Teve** — **escreva na ficha um feiticeiro que podia ter te ensinado e não ensinou, e por quê. Essa pessoa está viva e sabe que você existe.** A escolha dela continua de pé.
> *Na mesa:* serve quando o grupo precisa de alguém daquele nível. *Exemplo: ninguém ali sabe desfazer a barreira, e essa pessoa sabe — o que ela vai cobrar é com ela.*

> **A Testemunha** — **escreva na ficha alguém sem energia amaldiçoada que sabe o que você é e nunca contou.** Essa pessoa continua na vida dela, e continua sabendo.
> *Na mesa:* serve quando o grupo precisa de um endereço fora do meio jujutsu. *Exemplo: vocês precisam sumir por uma noite, e existe uma casa que não está em registro nenhum.*

> **Sem Técnica** — você tem energia amaldiçoada e a técnica não veio junto. O texto está adiante, em *Legado de Sem Técnica*.

#### Ajusta

> **Aprendi Apanhando** — **uma vez por dia, refaça um teste de perícia que você falhou.**
> *Na mesa:* serve quando uma rolagem só trava a cena. *Exemplo: você falha em arrombar a porta com o inimigo chegando, e tenta de novo.*

> **Instinto Bruto** — **uma vez por cena, role `Sentir Energia` no lugar de `Intuição`**, dizendo como o seu jeito de sentir resolve aquilo.
> *Na mesa:* serve quando o grupo precisa saber se alguém está mentindo. *Exemplo: o informante fala calmo, e a energia dele não.*

> **Gambiarra** — **uma vez por dia, use um ofício em que você não é treinado como se fosse.**
> *Na mesa:* serve quando falta o especialista. *Exemplo: ninguém do grupo tem `Condução`, e é você que tira a van do estacionamento.*

> **Desconfiado** — **uma vez por cena, role com vantagem o Teste de Resistência contra ficar `Enfeitiçado`.**
> *Na mesa:* serve contra quem convence antes de atacar. *Exemplo: a maldição fala com voz de gente e oferece uma saída fácil.*

#### Desliga

> **Inédito** — **a sua técnica não está em registro nenhum: ninguém a reconhece pelo catálogo, e quem quiser se preparar contra ela precisa ter te visto usar.** Em troca, ninguém sabe te ajudar com ela. *Vale também para quem escolheu Sem Técnica — uma técnica montada em cima de uma aptidão comum é, por construção, uma que catálogo nenhum registrou.*
> *Na mesa:* serve no reencontro com o mesmo inimigo. *Exemplo: ele volta sabendo o que te viu fazer na primeira luta, e nada além disso.*

> **Chão Duro** — **para você, qualquer lugar conta como ambiente propício**, no capítulo 5, *Descanso e Recuperação*. Em troca, você não percebe quando os outros não estão aguentando.
> *Na mesa:* serve em missão longe da escola. *Exemplo: o grupo dorme no mato e acorda com metade do PE; você acorda cheio.*

## Receptáculo

*Você carrega alguma coisa, e ela ainda está aí.*

**Na obra:** o Itadori, que come o dedo e passa a dividir o corpo com o Sukuna, e que tem técnica inata própria por baixo disso. E a Hana Kurusu, em quem o Anjo vive simbioticamente, sem sobrescrever a consciência dela.

### Efeito na ficha

#### Perícias

Escolha uma: Sentir Energia · Ocultismo · Intuição · Religião

Mais uma perícia livre, que a sua história justifique.

Os dois ofícios vieram com o que você carrega, e você não sabe direito quando aprendeu. Os dois se trocam por mais uma perícia livre.

#### Teste de Resistência

**Um Teste de Resistência treinado, à sua escolha entre os quatro** — o outro vem do seu Caminho.

*Ele vale igual em toda Origem, e os dois ofícios também: são livres, do quadro do capítulo 3, e os dois se trocam por mais uma perícia livre. **O Caminho não dá ofício** — quem dá é a sua Origem. O que muda de uma Origem para a outra é a lista de perícias e a razão pela qual você aprendeu o que aprendeu.*

#### Destrancas

Você começa toda a ficha com um `Destranca` e um `Ajusta` ou `Desliga`.

#### Criação

Fundamento, do jeito padrão. O passageiro mora na ficção da mesa, e a montagem da ficha é a mesma de qualquer feiticeiro.

### Legados do Receptáculo

#### Destranca

*Escolha um destes, obrigatoriamente.*

> **A Voz de Dentro** — **uma vez por dia, pergunte ao mestre uma coisa sobre uma maldição ou técnica presente na cena. Ele responde com a verdade.**
> *Na mesa:* serve na criatura que ninguém identificou. *Exemplo: você pergunta do que aquilo se alimenta, e o grupo para de tentar resolver na marra.*

> **De Antes de Você** — **escreva na ficha uma pessoa, um lugar ou um clã que conheceu o que te habita, de quando ele andava sozinho. Eles existem e sabem o que você carrega.** O que fazem com isso é com eles.
> *Na mesa:* serve quando a missão encosta em história antiga. *Exemplo: o clã que o grupo foi investigar já lidou com o que está dentro de você.*

> **Alcunha** — **escreva na ficha como ele era chamado quando andava sozinho. Você pode dizer esse nome em voz alta quando quiser, e quem é do meio jujutsu sabe o que ele significa.** Dito, não dá para despronunciar.
> *Na mesa:* serve numa sala em que ninguém sabe o que você carrega. *Exemplo: você diz o nome numa negociação, e a conversa passa a ser sobre isso — para melhor ou para pior.*

> **O Que Ele Quer** — **escreva na ficha o que ele quer, e que não é o que você quer. Uma vez por descanso longo, entregue a ele uma coisa que ele queria e ele te dá passagem para o que você precisava.** O mestre narra os dois lados, e o que você cedeu fica escrito na ficha para sempre.
> *Na mesa:* serve quando a cena está perdida e o preço deixou de importar. *Exemplo: você cede o controle da mão direita por um minuto, e o golpe sai.*

> **Sem Técnica** — você tem energia amaldiçoada e a técnica não veio junto. O texto está adiante, em *Legado de Sem Técnica*.

#### Ajusta

> **Não Sou Só Eu** — **uma vez por cena, refaça um Teste de Resistência de Espírito que você falhou contra ser controlado, dominado ou lido.**
> *Na mesa:* serve contra quem ganha a luta virando aliado contra aliado. *Exemplo: a maldição tenta te pôr contra o grupo, e não pega.*

> **Costume Antigo** — **escolha uma perícia na criação. Uma vez por cena, role essa perícia como se fosse treinada.**
> *Na mesa:* serve quando o grupo precisa de uma perícia que ninguém tem. *Exemplo: você lê a inscrição do templo sem nunca ter estudado aquilo.*

> **Tranco** — **uma vez por cena, refaça um Teste de Resistência Físico que você falhou.**
> *Na mesa:* serve contra veneno, queda e agarrão. *Exemplo: você falha em não cair do andaime, e tenta de novo.*

> **Passagem** — **uma vez por dia, você deixa ele assumir e refaz qualquer rolagem. Quando você volta, o mestre diz uma coisa que ele fez enquanto estava no comando.** O tempo é decidido pelo mestre, ou por uma negociação usando a **Promessa**.

#### Desliga

> **Máscara** — **quem sente a sua energia amaldiçoada sente a dele: você não aparece como o que é.** Em troca, o que essas pessoas concluem sobre você costuma ser pior do que a verdade.
> *Na mesa:* serve em infiltração e contra barreira de detecção. *Exemplo: você atravessa a `Cortina` sem acender nada, e quem está do outro lado lê outra coisa.*

> **Revezamento** — **uma vez por descanso longo, você não fica `Incapacitado`.** Em troca, quem estava olhando viu que naquele momento não era você que se mexia.
> *Na mesa:* serve quando você não pode abrir uma brecha. *Exemplo: uma técnica acaba de te deixar com a guarda aberta, mas os seus olhos se mantêm fixos no alvo, reagindo no último momento.*

## Descendente

*Você é de uma das famílias, e elas cobram.*

**Na obra:** Gojo, Inumaki, Kamo, Zen'in. As técnicas de clã têm nome próprio, e todo mundo do meio conhece.

### Efeito na ficha

#### Perícias

Escolha uma: Hierarquia · História · Ocultismo · Persuasão

Mais uma perícia livre, que a sua história justifique.

Os dois ofícios o clã te fez aprender: um nome não se carrega sem ofício. Os dois se trocam por mais uma perícia livre.

#### Teste de Resistência

**Um Teste de Resistência treinado, à sua escolha entre os quatro** — o outro vem do seu Caminho.

*Ele vale igual em toda Origem, e os dois ofícios também: são livres, do quadro do capítulo 3, e os dois se trocam por mais uma perícia livre. **O Caminho não dá ofício** — quem dá é a sua Origem. O que muda de uma Origem para a outra é a lista de perícias e a razão pela qual você aprendeu o que aprendeu.*

#### Destrancas

Você começa toda a ficha com um `Destranca` e um `Ajusta` ou `Desliga`.

#### Criação

Fundamento, do jeito padrão.

### Legados do Descendente

#### Destranca

*Escolha um destes, obrigatoriamente.*

> **O Sobrenome** — **em qualquer lugar da sociedade jujutsu você consegue audiência com quem manda.** Você entra na sala; o que sai da conversa continua valendo o teste de sempre. *O clã do nome, como os Gojo.*
> *Na mesa:* pula a etapa de achar a pessoa. *Exemplo: o grupo precisa falar com o chefe da vigilância da região, e você marca a reunião em vez de investigar como chegar nele.*

> **Armaria** — **escreva na ficha qual ferramenta amaldiçoada da sua família é sua por direito, e quem está com ela agora. Ela existe, é sua, e ninguém devolveu.** *O clã da ferramenta, como os Zen'in.*
> *Na mesa:* serve quando o grupo precisa de uma ferramenta que ninguém tem. *Exemplo: a peça que resolveria a missão é sua por direito, e está na mão de outra pessoa.*

> **Arquivo** — **escreva na ficha um experimento com corpo que a sua família fez e nunca publicou. Quando esse método aparecer numa cena, você reconhece na hora, sem teste.** Ninguém de fora sabe que a sua família fez aquilo. *O clã do corpo, como os Kamo.*
> *Na mesa:* serve quando o grupo encontra o método em uso. *Exemplo: os corpos da missão têm a mesma sutura, e você sabe qual é o processo e o que ele exige de quem faz.*

> **Palavra Dada** — **o meio jujutsu sabe que a sua família não desperdiça palavra.** Quando você empenha a sua, ela conta como garantia; o que o outro lado faz com isso continua sendo dele. *O clã da voz, como os Inumaki.*
> *Na mesa:* serve quando o grupo precisa que alguém garanta um acordo. *Exemplo: você promete devolver a ferramenta depois da missão, e o dono passa a ter com o que contar se decidir emprestar.*

> **Treino de Berço** — **escreva na ficha uma coisa que só o seu clã ensina.** Quem quiser aprender aquilo passa pela sua família, ou por você.
> *Na mesa:* põe você na rota de quem precisa daquilo. *Exemplo: um feiticeiro de outro clã procura o grupo porque precisa do selo que só a sua casa ensina.*

> **Sem Técnica** — você tem energia amaldiçoada e a técnica não veio junto. O texto está adiante, em *Legado de Sem Técnica*.

#### Ajusta

> **Conversa de Jantar** — **uma vez por cena, role com vantagem o Teste de Resistência contra uma técnica conhecida no mundo jujutsu.**
> *Na mesa:* serve quando o antagonista é do meio. *Exemplo: o feiticeiro do outro lado usa a técnica da casa dele, e você já ouviu falar dos defeitos dela.*

> **Etiqueta** — **uma vez por cena, refaça um teste social que você falhou diante de alguém de patente ou clã superior ao seu.**
> *Na mesa:* serve em audiência, tribunal interno e reunião de clã. *Exemplo: você erra o tom com o chefe da casa e conserta antes de a porta fechar.*

> **Repetição** — **escolha um Teste de Resistência na criação. Uma vez por descanso curto, role-o com vantagem.**

> **Biblioteca** — **uma vez por cena, refaça um teste de `História` ou `Ocultismo` que você falhou.**
> *Na mesa:* serve na cena de pesquisa. *Exemplo: o grupo trava no arquivo por causa de um dado ruim, e você tenta de novo.*

#### Desliga

> **Coleira** — **o seu clã te selou na infância: técnica nenhuma te localiza, te rastreia ou te encontra à distância.** Em troca, a sua família sempre sabe onde você está.
> *Na mesa:* serve quando o grupo precisa sumir. *Exemplo: o inimigo perde vocês na cidade, e a sua casa não.*

> **Cabo** — **uma vez por cena, você não fica `Desarmado`: a arma escorrega e volta para a sua mão.** Em troca, você não larga ela quando devia, e não atravessa lugar nenhum como civil.
> *Na mesa:* serve quando desarmar você era o plano. *Exemplo: a técnica arranca a sua lâmina, e ela volta antes de encostar no chão.*

## Reencarnado

*Você já foi outra pessoa, e o corpo em que você está não nasceu seu.*

> **A diferença para Receptáculo.** Receptáculo é simbiose: os dois estão lá. Reencarnado é sobrescrita: sobrou um.

**Na obra:** o Kashimo, feiticeiro de quatrocentos anos atrás que aceitou virar objeto amaldiçoado e encarnar num corpo que o Kenjaku preparou, com a condição de poder enfrentar o Sukuna.

### Efeito na ficha

#### Perícias

Escolha uma: História · Ocultismo · Investigação · Intimidação

Mais uma perícia livre, que a sua história justifique.

Os dois ofícios a outra pessoa sabia, e as mãos deste corpo lembram. Os dois se trocam por mais uma perícia livre.

#### Teste de Resistência

**Um Teste de Resistência treinado, à sua escolha entre os quatro** — o outro vem do seu Caminho.

*Ele vale igual em toda Origem, e os dois ofícios também: são livres, do quadro do capítulo 3, e os dois se trocam por mais uma perícia livre. **O Caminho não dá ofício** — quem dá é a sua Origem. O que muda de uma Origem para a outra é a lista de perícias e a razão pela qual você aprendeu o que aprendeu.*

#### Destrancas

Você começa toda a ficha com um `Destranca` e um `Ajusta` ou `Desliga`.

#### Criação

Fundamento, do jeito padrão.

### Legados do Reencarnado

#### Destranca

*Escolha um destes, obrigatoriamente.*

> **O Que Ninguém Lembra** — **uma vez por descanso longo, você sabe um lugar, um nome ou uma técnica de antes do seu tempo, e isso responde uma dúvida que ninguém vivo responderia.**
> *Na mesa:* serve quando a investigação trava. *Exemplo: o selo do porão tem duzentos anos, e você sabe quem o pôs ali e por quê.*

> **Encomenda** — **escreva na ficha quem pagou para você voltar e qual era a condição do acordo. Essa pessoa está viva e considera o acordo aberto.** O que ela acha que comprou pode não ser o que você acha que vendeu.
> *Na mesa:* serve quando a campanha precisa de um credor. *Exemplo: a pessoa aparece no meio da missão cobrando o que combinaram.*

> **Quem Morava Aqui** — **escreva na ficha de quem era este corpo, e uma pessoa que ainda espera essa pessoa voltar. Ela não sabe que é você quem está aqui.**
> *Na mesa:* serve quando o grupo passa pela vida antiga do corpo. *Exemplo: alguém te chama pelo nome do antigo dono no meio da rua.*

> **Enterrado** — **escreva na ficha uma coisa que você guardou antes de morrer e onde ela está. Continua lá, se o lugar ainda existir.**
> *Na mesa:* põe no mapa um ponto que só você conhece. *Exemplo: o grupo precisa de dinheiro ou de uma arma, e você sabe de um esconderijo de cem anos atrás.*

> **Sem Técnica** — você tem energia amaldiçoada e a técnica não veio junto. O texto está adiante, em *Legado de Sem Técnica*.

#### Ajusta

> **Corpo Emprestado** — **uma vez por cena, role com vantagem o Teste de Resistência contra ficar `Incapacitado`.** O corpo avisa os outros e não avisa você.
> *Na mesa:* serve na cena em que você devia cair. *Exemplo: o golpe abre a sua guarda e você continua de pé, e só vê o estrago depois.*

> **Espasmo** — **uma vez por descanso curto, refaça um Teste de Resistência Físico ou de Vigor que você falhou.**
> *Na mesa:* serve quando o corpo tinha que ter respondido. *Exemplo: você não sai da frente do desabamento, e sai.*

> **Já Morri** — **uma vez por cena, role com vantagem o Teste de Resistência contra ficar `Amedrontado`.**
> *Na mesa:* serve contra maldição de terror e contra intimidação. *Exemplo: você é quem entra na sala que o resto do grupo evita.*

> **Método Velho** — **uma vez por cena, um teste que envolva método antigo — ritual, selo, barreira velha, escrita morta — sai como se você fosse treinado nele.**
> *Na mesa:* serve em ruína, templo lacrado e documento em língua morta. *Exemplo: a barreira do santuário não abre há gerações, e você sabe por onde começar.*

#### Desliga

> **Conhecimento Antigo** — **você reconhece de imediato técnicas da sua Era, sem precisar de teste.** Em troca, você não conhece nenhuma das modernas, e falha ao tentar entendê-las.
> *Na mesa:* serve quando enfrentar outro Reencarnado da sua Era, ou uma técnica antiga conhecida. *Exemplo: vocês encontram uma maldição de lendas muito antigas, e você sabe do que ela é capaz.*

> **Usado** — **uma vez por cena, você não fica `Derrubado`.** Em troca, o mestre diz uma coisa pequena que o seu corpo passa a fazer errado até o fim da cena.
> *Na mesa:* serve quando cair custava a rodada. *Exemplo: a onda te joga no chão e você não vai — e a sua mão esquerda para de fechar direito até a cena acabar. É a idade.*

## Feto

*Alguém te fez, peça por peça.*

**Na obra:** o Choso e os irmãos, ventres de Pintura da Morte, metade humano e metade maldição.

### Efeito na ficha

#### Perícias

Escolha uma: Ocultismo · Medicina · Sentir Energia · Natureza

Mais uma perícia livre, que a sua história justifique.

Os dois ofícios estavam no projeto de quem te fez, e não na sua escolha. Os dois se trocam por mais uma perícia livre.

#### Teste de Resistência

**Um Teste de Resistência treinado, à sua escolha entre os quatro** — o outro vem do seu Caminho.

*Ele vale igual em toda Origem, e os dois ofícios também: são livres, do quadro do capítulo 3, e os dois se trocam por mais uma perícia livre. **O Caminho não dá ofício** — quem dá é a sua Origem. O que muda de uma Origem para a outra é a lista de perícias e a razão pela qual você aprendeu o que aprendeu.*

#### Destrancas

Você começa toda a ficha com um `Destranca` e um `Ajusta` ou `Desliga`.

#### Criação

Fundamento, do jeito padrão.

### Legados do Feto

#### Destranca

*Escolha um destes, obrigatoriamente.*

> **Irmãos** — **escreva na ficha quantos vocês eram e o que aconteceu com eles. Você reconhece um irmão quando encontra, e sabe quando um morre, esteja onde estiver.** Nem todos se parecem com você.
> *Na mesa:* serve a qualquer momento, e o mestre escolhe quando. *Exemplo: no meio de outra cena você sente que um irmão acabou de morrer, e não sabe onde.*

> **Numeração** — **escreva na ficha o seu número e quantos eram no total. Quem sabe do assunto reconhece a série.**
> *Na mesa:* serve quando aparece documento antigo. *Exemplo: o registro que o grupo achou lista a sua série, e a investigação passa a ser sobre você.*

> **Guardado** — **escreva na ficha quem te guardou antes de você acordar, onde, e por quanto tempo. Essa pessoa, ou o que sobrou dela, ainda tem a ver com você.**
> *Na mesa:* põe um lugar concreto no mapa, com dono. *Exemplo: a missão passa perto de onde você ficou guardado, e alguém lá ainda te reconhece.*

> **Devagar** — **escreva na ficha há quanto tempo você existe e com que idade você parece. O seu corpo não envelhece no calendário dos outros.**
> *Na mesa:* abre a campanha para o passado. *Exemplo: alguém que te conheceu há trinta anos está velho, e você não.*

> **Sem Técnica** — você tem energia amaldiçoada e a técnica não veio junto. O texto está adiante, em *Legado de Sem Técnica*.

#### Ajusta

> **Meio e Meio** — **uma vez por cena, role com vantagem um Teste de Resistência contra veneno ou doença.**
> *Na mesa:* serve no lugar contaminado. *Exemplo: o porão está cheio de gás e é você que desce.*

> **Como Se Monta** — **uma vez por cena, refaça um teste de `Medicina` que você falhou.**
> *Na mesa:* serve para ler cadáver e tentar fechar ferimento simples. *Exemplo: você falha em estancar o sangramento de um aliado, e tenta de novo.*

> **Faro** — **uma vez por cena, quando o que você procura é maldição, role `Sentir Energia` no lugar de `Investigação`.**
> *Na mesa:* corta a busca por prédio ou por escombro. *Exemplo: o grupo ia vasculhar três andares, e você aponta o certo.*

> **Paciência** — **uma vez por dia, refaça um teste de perícia feito enquanto você esperava, vigiava ou estava escondido sem se mexer.**
> *Na mesa:* recompensa o plano de tocaia. *Exemplo: você falha na `Furtividade` na terceira hora de espera, e tenta de novo.*

#### Desliga

> **Sangue que Não é Sangue** — **você não precisa comer, dormir nem respirar como um humano.** Em troca, o seu corpo tem necessidades que ninguém sabe nomear.
> *Na mesa:* serve em água funda, gás, soterramento e vigília longa. *Exemplo: o corredor está inundado e é você que atravessa.*

> **Talhe** — **uma vez por cena, você não fica `Agarrado`.** Em troca, você sai por onde couber: quem te agarrou escolhe se você larga o que estava na sua mão ou termina fora da posição que queria.
> *Na mesa:* serve quando te agarrar era o plano. *Exemplo: a coisa fecha a mão em você, você sai, e a sua arma fica lá.*

## Sem Técnica

*Você tem energia amaldiçoada e não tem técnica inata.*

**Sem Técnica se soma a uma das cinco Origens principais.** Você continua sendo Latente, Receptáculo, Descendente, Reencarnado ou Feto, com a marca de que a técnica não veio junto.

Você monta o seu estilo em cima de uma coisa que qualquer feiticeiro pode aprender, e foi mais fundo nela do que ninguém tinha ido.

O poder vem de dois lugares.

**Aptidão.** Você foi fundo no que todo feiticeiro pode fazer.

**Estilo da Sombra.** Você mata maldição com técnica de corpo e de arma, sem técnica amaldiçoada.

**Na obra:** a Miwa e o Kusakabe, pelo Estilo da Sombra; a Shoko Ieiri, pela Aptidão.

### Efeito na ficha

Você escreve Fundamento como qualquer conjurador: tem Regra, tem Famílias, tem Selo e tem Passivas. Duas peças mudam de nome — o feitiço é o `Manejo`, e a Técnica Máxima é o `Auge`. E uma não existe nesta rota: a Expansão de Domínio.

A Origem principal continua dando tudo o que dá.

#### Criação

Na criação você escolhe uma **semente**: uma aptidão que vem aberta, sem os gates de nível e de refino que ela pede de todo mundo. Ela é o assunto do seu Fundamento.

**A máquina inteira está no capítulo 11, *Sem Técnica*** — as três sementes, a Regra que sai delas, a cura da `Energia Reversa` e dois Fundamentos prontos.

### Legado de Sem Técnica

Sem Técnica não amplia a conta de Legados: ela é uma entrada de `Destranca` e ocupa uma das duas vagas, como qualquer outra. Cinco Origens alcançam ela — Latente, Receptáculo, Descendente, Reencarnado e Feto.

> **Sem Técnica** — **você tem energia amaldiçoada e a técnica não veio junto. Escolha a sua semente: é dela que o seu Fundamento nasce.**

Corpo Amaldiçoado e Restrição Celestial não aceitam Sem Técnica. As duas já vêm com uma troca própria no lugar da técnica.

## Corpo Amaldiçoado

*Alguém te fez, e você acordou.*

**Na obra:** o Panda, feito pelo Yaga, com três núcleos que ele troca à vontade: o de gorila, o de panda e o de tricerátops.

### Efeito na ficha

Sem Fundamento, porque não existe técnica inata para escrever. Você tem energia amaldiçoada: cadáver de mutação abrupta produz a própria, uns três meses depois de acordar. Então PE, aptidões e refino são normais, com Técnica Marcial no lugar do Fundamento.

#### Perícias

Escolha uma: Atletismo · Percepção · Ocultismo · Intimidação

Mais uma perícia livre, que a sua história justifique.

Os dois ofícios quem te fez pôs em você, junto com o resto. Os dois se trocam por mais uma perícia livre.

#### Teste de Resistência

**Um Teste de Resistência treinado, à sua escolha entre os quatro** — o outro vem do seu Caminho.

*Ele vale igual em toda Origem, e os dois ofícios também: são livres, do quadro do capítulo 3, e os dois se trocam por mais uma perícia livre. **O Caminho não dá ofício** — quem dá é a sua Origem. O que muda de uma Origem para a outra é a lista de perícias e a razão pela qual você aprendeu o que aprendeu.*

#### Destrancas

Você começa toda a ficha com um `Destranca` e um `Ajusta` ou `Desliga`.

#### Criação

Técnica Marcial, no capítulo 10.

Você tem energia amaldiçoada, então tem PE, aptidões e refino como qualquer feiticeiro tem — inclusive `Canalizar energia`, que faz o seu golpe simples ferir maldição. O que você não tem é técnica inata para escrever, e é a Técnica Marcial que ocupa esse lugar. Por isso a `Extensão de Domínio` você não compra: ela é um domínio vazio, e sem técnica inata você não tem domínio para esvaziar.

#### Cura

A `Energia Reversa`, e o que monta nela, não te cura: você é um corpo feito de peças. **Quem te conserta é o reparo.** No descanso curto, alguém com `Entalhador` ou `Forja` — você mesmo, ou outro — faz o teste de ofício, na escada que acompanha: difícil com você no nível de quem repara. Passou, você recupera metade da vida máxima. Um reparo por descanso curto.

Uma técnica cuja Regra alcance um corpo feito — uma de engenharia, por exemplo — cura você como cura qualquer um.

#### Imunidade

Você é imune a `Envenenado`.

### Legados do Corpo Amaldiçoado

#### Destranca

*Escolha um destes, obrigatoriamente. A configuração que você escolhe aqui decide qual das quatro listas de Ajusta você alcança.*

> **Ninhada** — **três seres num corpo só, e é o arranjo que estabiliza. Escreva na ficha o que são os três.**
> *Na mesa:* serve quando o grupo pede conselho. *Exemplo: os três discordam sobre entrar ou não, e você interpreta a discussão em voz alta.*

> **Gêmeos** — **foram dois, e dois não estabilizam. Vocês se revezam, e quem escolhe a hora da troca é o mestre.** Vale combinar antes o que muda de uma para a outra.
> *Na mesa:* serve quando a troca cai na hora errada. *Exemplo: a outra assume no meio da negociação, e ela não sabe o que já foi combinado.*

> **Inteiro** — **um núcleo só, e mesmo assim você acordou. Pelo método conhecido isso não acontece.**
> *Na mesa:* serve quando alguém do meio descobre o que você é. *Exemplo: um pesquisador da escola quer te estudar, e não desiste.*

> **Manutenção** — **a consciência é sua; a energia é de quem te fez, e ela acaba. Escreva na ficha quem te abastece e o que essa pessoa cobra.** Você decide quando ir.
> *Na mesa:* põe um relógio na campanha. *Exemplo: a energia começa a faltar no meio do arco, e voltar lá vira parte do plano.*

#### Ajusta

*Três por configuração; você só alcança os da sua.*

##### Ninhada

> **Rodízio** — **escolha três perícias na criação, uma por ser. Uma vez por cena, role uma delas como se fosse treinada.**
> *Na mesa:* cobre três buracos da equipe, um de cada vez. *Exemplo: ninguém tem `Tecnologia`, e o segundo ser sabe.*

> **Vigília** — **uma vez por cena, role Iniciativa com vantagem.**
> *Na mesa:* serve contra emboscada. *Exemplo: a coisa cai do teto e você age antes dela.*

> **Desempate** — **uma vez por dia, refaça um Teste de Resistência que você falhou.**
> *Na mesa:* guarde para o efeito que tiraria o personagem da cena. *Exemplo: você falha contra `Atordoado`, e tenta de novo.*

##### Gêmeos

> **Cabeça Trocada** — **escolha uma perícia e um atributo na criação. Uma vez por cena, role essa perícia com esse atributo em vez do que ela pede.**
> *Na mesa:* serve quando o jeito de sempre não serve. *Exemplo: você rola `Persuasão` com Inteligência, porque a outra convence por argumento e não por presença.*

> **Nunca os Dois** — **uma vez por descanso curto, refaça um Teste de Resistência de Intelecto que você falhou.**
> *Na mesa:* serve contra ilusão e leitura de mente. *Exemplo: a maldição te convence de que a saída é para o outro lado, e não cola.*

> **Palpite** — **uma vez por dia, role com vantagem um teste de perícia em que você não é treinado.**
> *Na mesa:* resolve a perícia que ninguém tem. *Exemplo: alguém precisa ler o rastro e nenhum de vocês é treinado; você chuta bem.*

##### Inteiro

> **Feito de Uma Peça** — **uma vez por descanso curto, refaça um Teste de Resistência de Vigor que você falhou.**
> *Na mesa:* serve em desgaste longo, fogo e frio. *Exemplo: você falha em aguentar a fumaça e tenta de novo.*

> **Teimosia** — **uma vez por cena, refaça um teste para continuar fazendo uma coisa que você já começou** — segurar, agarrar, sustentar, não largar.
> *Na mesa:* serve quando a equipe depende de você não largar. *Exemplo: você escorrega segurando a porta, e segura de novo.*

> **Peça Única** — **escolha uma perícia treinada na criação. Uma vez por cena, role com vantagem.**
> *Na mesa:* declara desde a criação para que serve o personagem. *Exemplo: a sua é `Atletismo`, e é você que sobe.*

##### Manutenção

> **Ajuste Fino** — **escolha um ofício na criação. Uma vez por cena, role com vantagem.**
> *Na mesa:* serve no ofício de quem te fez. *Exemplo: o seu é `Forja`, e o equipamento do grupo atravessa a campanha inteiro.*

> **Recarga** — **escolha duas perícias na criação. Uma vez por descanso curto, role uma delas com vantagem.**
> *Na mesa:* é o relógio mais rápido da Origem. *Exemplo: numa missão de quatro confrontos você usa quatro vezes.*

> **Fiado** — **uma vez por dia, refaça qualquer rolagem que você falhou. Escreva na ficha o que você passou a dever, e isso não sai no descanso.**
> *Na mesa:* a dívida cresce sessão a sessão. *Exemplo: você usa três vezes num arco, e na quarta quem te abastece vem cobrar.*

#### Desliga

> **Ferro Velho** — **os degraus de exaustão não te alcançam.** Em troca, você não sente quando está perto de quebrar: você não sabe quantos pontos de vida tem, é difícil discernir.
> *Na mesa:* serve em missão longa. *Exemplo: o grupo pega três degraus de exaustão na semana e você nenhum.*

## Restrição Celestial

*Você trocou uma coisa por outra antes de nascer.*

**São dois ramos opostos, e você escolhe um na criação.**

**Corpo pela técnica.** O corpo não funciona, e em troca a energia é enorme.

**Sem energia.** Você nasceu sem energia amaldiçoada nenhuma, e em troca o corpo recebeu a troca. Você não conjura, não canaliza e não sente energia, e fere maldição com ferramenta amaldiçoada. O que você não conjura é energia: a sua `Kata`, da Técnica Marcial, é o corpo, e continua. **A Origem fixa a perda e não o que você constrói em cima dela:** um restringido que nunca levantou peso e resolve tudo pela cabeça é uma ficha legítima.

**Na obra:** o Kokichi Muta, pelo corpo; a Maki e o Toji, pela falta de energia.

### Efeito na ficha

**Ramos da Restrição Celestial**
| Ramo | O que muda | Criação |
|---|---|---|
| **Corpo pela técnica** | Fundamento normal, corpo com limitação escrita na ficha | Fundamento, no capítulo 9 |
| **Sem energia** | sem Fundamento, sem feitiço de Toque, sem Sentir Energia, sem aptidão e sem refino. No lugar deles, **Bênçãos e Lapidação**, e acesso a ferramenta amaldiçoada como eixo de poder | Técnica Marcial, no capítulo 10, com o capítulo 13 no lugar do 11 |

O `PE` do seu Caminho continua chegando. Nesta rota ele se lê **Pontos de Esforço** em vez de Pontos de Energia: é a mesma sigla, o mesmo número e a mesma coluna.

#### Perícias

**Perícias por ramo**
| Ramo | Escolha uma |
|---|---|
| **Corpo pela técnica** | Sentir Energia · Tecnologia · Ocultismo · Percepção |
| **Sem energia** | Atletismo · Acrobacia · Furtividade · Pontaria |

Quem é do ramo sem energia não pode ter `Sentir Energia` de nenhuma forma.

Mais uma perícia livre, que a sua história justifique.

Os dois ofícios você teve de aprender: sem energia, sobrou a mão. Os dois se trocam por mais uma perícia livre.

#### Teste de Resistência

**Um Teste de Resistência treinado, à sua escolha entre os quatro** — o outro vem do seu Caminho.

*Ele vale igual em toda Origem, e os dois ofícios também: são livres, do quadro do capítulo 3, e os dois se trocam por mais uma perícia livre. **O Caminho não dá ofício** — quem dá é a sua Origem. O que muda de uma Origem para a outra é a lista de perícias e a razão pela qual você aprendeu o que aprendeu.*

#### Destrancas

Você começa toda a ficha com um `Destranca` e um `Ajusta` ou `Desliga`.

### Legados: Corpo pela Técnica

*O corpo não funciona, e a energia é enorme. Você conjura pelo Fundamento normal, como qualquer feiticeiro.*

#### Destranca

*Escolha um destes, obrigatoriamente.*

> **Nasci Assim** — **escreva na ficha o que o seu corpo não faz e o que isso te cobra todo dia. Quem diz quando aquilo complica a cena é você.** Não é segredo, e não tem conserto conhecido.
> *Na mesa:* serve quando a cena pede o corpo. *Exemplo: o grupo precisa subir a escada de incêndio, e você diz o que isso te custa.*

> **O Substituto** — **escreva na ficha a coisa pela qual o meio jujutsu te conhece, e que não é o seu corpo: um nome, uma voz, uma casca. Quase ninguém sabe que existe outra pessoa do outro lado.**
> *Na mesa:* põe você em duas cenas ao mesmo tempo. *Exemplo: a casca está na reunião enquanto o seu corpo está em casa.*

> **A Oferta** — **escreva na ficha o que você daria por um corpo que funcione. Existe gente que vende esse tipo de coisa, e uma delas sabe que você existe.**
> *Na mesa:* serve quando o preço fica fácil de pagar. *Exemplo: no meio do arco a proposta volta, e agora ela custa menos do que custava.*

#### Ajusta

> **Antena** — **uma vez por cena, refaça um teste de `Sentir Energia` que você falhou.**
> *Na mesa:* serve em varredura e em emboscada. *Exemplo: você não sente ninguém do outro lado da parede, e conta de novo.*

> **Do Meu Canto** — **uma vez por cena, role com vantagem um teste feito sem sair do lugar em que você está.**
> *Na mesa:* recompensa a posição fixa. *Exemplo: você escolhe o canto na primeira rodada e trabalha a cena inteira de lá.*

> **Insônia** — **uma vez por dia, refaça um teste de perícia feito enquanto os outros dormiam.**
> *Na mesa:* a cena de madrugada é sua. *Exemplo: o grupo dorme e você passa a noite no arquivo.*

> **Li Tudo** — **uma vez por cena, refaça um teste de `Ocultismo` ou `Investigação` que você falhou.**
> *Na mesa:* segura a investigação quando o dado trava. *Exemplo: a pista não sai no primeiro teste, e sai no segundo.*

### Legados: Sem Energia

*Sem energia nenhuma, e o corpo recebeu a troca. Você não tem feitiço de Toque nem Sentir Energia: o seu poder vem da Técnica Marcial, e o seu eixo de controle são as Bênçãos.*

#### Destranca

*Escolha um destes, obrigatoriamente.*

> **Descartado** — **escreva na ficha quem da sua família te descartou e o que fizeram você fazer enquanto esteve lá. Você conhece a casa por dentro.**
> *Na mesa:* você é o mapa da casa. *Exemplo: a missão leva o grupo até lá, e você sabe por onde se entra sem bater.*

> **Dividido** — **escreva na ficha quem nasceu junto de você e ficou com a outra metade da restrição, e onde essa pessoa está. Enquanto os dois existirem, nenhum dos dois está inteiro.**
> *Na mesa:* põe uma pessoa no mundo que mexe com o que você é. *Exemplo: ela aparece do outro lado de uma missão, e o grupo tem que decidir o que faz.*

> **Desde Criança** — **escreva na ficha uma ferramenta que anda com você desde antes de você escolher, e como ela veio parar na sua mão. Quem entende de ferramenta reconhece aquela.**
> *Na mesa:* a peça tem história e tem quem a reconheça. *Exemplo: o forjador da missão identifica a sua arma e quer saber como você a conseguiu.*

> **Aprendi a Ver** — **escreva na ficha como você resolveu não enxergar maldição: o que você usa, ou o que você treinou até substituir o que falta. O método tem limite próprio, e ele fica escrito junto.**
> *Na mesa:* serve quando o método falha. *Exemplo: o que você usa para enxergar quebra no meio da missão, e o grupo passa a ser os seus olhos.*

#### Ajusta

> **Sentido Treinado** — **uma vez por cena, role `Percepção` no lugar de `Sentir Energia`.**
> *Na mesa:* é como você entra na cena de detecção sem ter o sentido. *Exemplo: você não sente a maldição, e nota a poeira que ela move.*

> **Couro** — **uma vez por descanso curto, refaça um Teste de Resistência Físico que você falhou.**
> *Na mesa:* você atravessa o que devia parar a equipe. *Exemplo: a queda de dois andares não te tira da luta.*

> **Ninguém Viu** — **uma vez por cena, refaça um teste de `Furtividade` que você falhou.**
> *Na mesa:* nenhum feiticeiro te sente chegar. *Exemplo: em infiltração você entra sozinho e o resto espera.*

> **No Braço** — **uma vez por dia, refaça um teste de perícia de Força ou Destreza que você falhou.**
> *Na mesa:* segunda chance em perseguição, escalada e agarrão. *Exemplo: você escorrega na fachada e segura na segunda tentativa.*

### Legados: Desliga

*Vale para Corpo pela Técnica e para Sem Energia.*

> **Peso Real** — **você percebe ferramenta amaldiçoada, barreira e véu pelo tato e pelo peso, e o que engana feiticeiro não engana você.** Em troca, o aviso vem sem nome: você sente que tem alguma coisa ali, e nunca o que é.
> *Na mesa:* você é o detector do grupo em terreno preparado. *Exemplo: você sente que o corredor tem barreira, e ninguém sabe de que tipo até investigar.*

> **Assinado** — **uma vez por descanso longo, você não fica `Cego`.** Em troca, escreva na ficha uma coisa comum que você nunca vai conseguir fazer, e ela não volta em nível nenhum.
> *Na mesa:* a cena de escuro e de clarão não te tira do jogo. *Exemplo: a técnica estoura luz na sala e você continua agindo.*

## Criar o seu Legado

As listas de cada Origem são exemplo, e não limite. Se nenhuma entrada serve para o personagem que você escreveu, você escreve a sua — do grupo que quiser — e leva ao mestre antes da primeira sessão.

Use as publicadas como molde. **A forma de cada grupo está em *Como ler um Destranca*, *Como ler um Ajusta* e *Como ler um Desliga*, no começo deste capítulo**, e é ela que o mestre vai olhar.

**A conta não muda.** Você continua levando um `Destranca` e um `Ajusta` ou `Desliga`, seja escrito por você ou tirado da lista.

**Três coisas que nenhum Legado criado pode fazer**, e elas valem para os três grupos:

- **dar técnica.** Técnica vem da Origem e do Fundamento, e Legado nenhum concede uma.
- **decidir o que um personagem do mestre faz.** Você diz o que existe no mundo por sua causa; o que a pessoa faz com isso continua sendo dela.
- **entregar acerto, Defesa ou vida direto.** Esses três são a moeda do resto do sistema.

Lembre-se de que os Legados são, no fundo, o que forma a sua história inicial. As opções dadas não são obrigatórias: são bases para ajudar a criar ideias para o seu personagem. Um personagem pode ter vários `Destranca` em um só, desde que isso não afete mecanicamente nada — é a base da história dele.

---


# Capítulo 8 · Caminhos e Trilhas

*fonte: `manual/35-caminhos-e-trilhas.md`*

**O Caminho diz o seu lugar na equipe**, e você escolhe ele na criação. A Trilha diz quem você é dentro do Caminho, e ela nasce junto com ele, no nível 2. São seis Caminhos nesta edição, três Trilhas em cada um.


## Como ler um Caminho

Cada Caminho entrega cinco degraus, e eles chegam sempre nos mesmos níveis. A Trilha entrega outras quatro coisas, em níveis diferentes.

**Entregas por nível**
| Nível | O que chega |
|---|---|
| 2 | o primeiro degrau do Caminho, e a primeira entrega da Trilha |
| 7 | degrau de Caminho |
| 11 | entrega de Trilha, e aqui você pode trocar de Trilha |
| 15 | degrau de Caminho |
| 19 | entrega de Trilha, e aqui você pode trocar de Trilha |
| 23 | degrau de Caminho |
| 27 | entrega de Trilha, e aqui você pode trocar de Trilha |
| 30 | degrau de Caminho |

> **Você só possui uma Trilha, do nível 2 ao 30.** Nos níveis 11, 19 e 27 você pode trocar a sua por outra do mesmo Caminho, e a troca é total: tudo o que você tinha vira o equivalente da Trilha nova. Não existe acumular duas, e não existe pegar o degrau avançado de uma Trilha sem ter tido a base dela.

**Sem multiclasse.** Um Caminho por personagem.

### Vida e energia

Cada Caminho tem o próprio número de vida por nível e o próprio número de PE por nível, e os dois correm em sentidos contrários: quem tem mais vida por nível tem menos PE por nível.

**Vida e energia por Caminho**
| | Bastião | Vanguarda | Guia | Emanador | Evocador | Incursor |
|---|---|---|---|---|---|---|
| **Vida por nível** | 7 | 5 | 5 | 4 | 4 | 4 |
| **PE por nível** | 4 | 5 | 5 | 6 | 6 | 6 |

> **O seu PE máximo é o número da tabela vezes o seu nível.** Nenhum atributo entra nessa conta, e não existe valor inicial somado por cima. *Uma Trilha pode somar um atributo por cima dele, e quando soma ela diz qual.*

### Termos dos degraus

**PE** são pontos de energia ou de esforço, o combustível que paga as suas habilidades. **Maestria** é o número que cresce com o seu nível: `1` no nível 2 e `4` no 30. **Classe** é o tamanho de um feitiço, de `Classe 0` até `Classe 7`. **Vantagem** é jogar dois dados e ficar com o melhor.

E duas coisas que quase todo degrau daqui menciona:

> **Feitiço de Toque** — os dados da Classe, e nada mais. Arma e atributo ficam de fora da conta.
>
> **Golpe simples** — ataque de arma padrão. É o que você faz quando não conjura.

> **Se a sua ficha monta o poder na Técnica Marcial, onde um degrau daqui diz *feitiço* ou *conjurar*, leia `Kata`.** Mesma Classe, mesmo custo em PE, mesmo degrau. **São as duas rotas do capítulo 10, *Técnica Marcial***, e elas escolhem Caminho e Trilha como todo mundo.

> **Canalizar em Golpe** é o nome usado aqui para o **Dano na arma de Canalizar energia**, no capítulo 12, *Aptidões e Refino*. Use os dados e requisitos daquela aptidão. Uma habilidade que altera esse dano, como Golpe Cirúrgico, declara sua própria exceção. **Estímulo Muscular** é a Bênção correspondente para o personagem sem energia, no capítulo 14.

### Treino de arma

**O seu Caminho decide quais armas você pode empunhar.** Treino mora na categoria: treinar uma categoria libera todas as armas dela, e o catálogo inteiro está no capítulo 15, *Equipamento*.

> **Os três Caminhos de corpo a corpo — Bastião, Vanguarda e Incursor — treinam as treze categorias.** Qualquer arma do catálogo é deles.
>
> **Os três Caminhos conjuradores — Guia, Emanador e Evocador — treinam Arma de Fogo e Balestra**, que são as duas que se aponta e dispara sem anos de forma.

**Para um conjurador empunhar o resto, a porta é a Trilha.** É o que faz a `Arma Condutora` do Condutor Armado, no nível 2: ela concede uma categoria (Grupo das Armas) à sua escolha e ainda troca Força por Essência ou Inteligência naquela categoria. Um Emanador de espadão existe, e paga por isso com a escolha de Trilha.

> **Sem treino, você tem desvantagem na rolagem de ataque com aquela arma**, e sem o requisito de Força dela o seu deslocamento cai pela metade enquanto você a estiver empunhando, além de você também atacar com desvantagem. O capítulo 15, *Equipamento*, tem as duas.

### Limites

> **Cada habilidade altera somente as regras que menciona.** A técnica continua determinando a montagem e a Classe dos seus feitiços. Há exceções expressas para dano, vida temporária, cura e redução de dano: elas conservam os custos e requisitos escritos no próprio Caminho ou Trilha. **Cura é Forma de feitiço**; uma habilidade só contorna essa montagem quando declara sua própria recuperação, como Cuidado Preparado e Ainda Há Tempo, do Socorrista, e Ainda de Pé, do Bastião. Duro de Matar e Casca Grossa descontam dano do Bastião; Alicerce e Cobertura seguem suas próprias regras.

### Trilhas

**Trilhas**
| Trilha | Caminho |
|---|---|
| **Muro** | Bastião |
| **Punho** | Bastião |
| **Combatente Amaldiçoado** | Bastião |
| **Estocada** | Vanguarda |
| **Batedor** | Vanguarda, com três rotas: **Yumi**, **Besta** e **Arma de Fogo** |
| **Executor** | Vanguarda |
| **Condutor Armado** | Emanador |
| **Ressonante** | Emanador |
| **Catalisador** | Emanador |
| **Arquiteto** | Guia |
| **Analista** | Guia |
| **Socorrista** | Guia |
| **Invocação Principal** | Evocador |
| **Parceria** | Evocador |
| **Múltiplas Invocações** | Evocador |
| **Assassino** | Incursor |
| **Pugilista** | Incursor |
| **Malabarista** | Incursor |

## Bastião

*O corpo é sua resposta. Você atrai a atenção dos inimigos, assume golpes que atingiriam aliados e escolhe como transformar essa pressão em proteção ou resposta.*

### Características do Bastião

**Características do Bastião**
| | |
|---|---|
| **Vida por nível** | 7 |
| **PE por nível** | 4 |
| **Atributos naturais** | Força · Constituição |
| **Perícias fixas** | `Atletismo` · `Provocar` |
| **Perícias à sua escolha** | 5, de qualquer uma da lista de perícias do sistema |
| **Ofícios** | nenhum. Os dois vêm da sua Origem |
| **Teste de Resistência** | 1 treinado, à sua escolha. A sua Origem treina o outro |
| **Treino de arma** | **as treze categorias**: Simples, Marciais e Arma de Fogo |

*Perícia, ofício e Teste de Resistência entram na ficha uma vez, na criação. O quadro completo das vinte e três perícias e dos onze ofícios está no capítulo 3, __Perícias e Ofícios__.*

*O Caminho treina você nessa lista de armas; ele não te dá a arma. O que você leva na mão você compra na criação, e as tabelas de `Preços` estão no capítulo 15, __Equipamento__.*

Escolha uma Trilha no nível 2: **Muro, Punho ou Combatente Amaldiçoado**. Suas entregas chegam nos níveis 2, 11, 19 e 27.

### Degraus do Bastião

**Habilidades do Bastião**
| Nível | Habilidade |
|---|---|
| 2 | Olhos Em Mim |
| 7 | Ataque Extra, Nem Um Arranhão e Ainda de Pé |
| 15 | Duro de Matar |
| 23 | Chega Mais |
| 30 | Passa Pra Mim |

> **Nível 2: `Olhos Em Mim`.** Você usa **Força** nos testes de **Provocar e Intimidação**, no lugar de Essência.
>
> Com uma **Ação Bônus**, estabeleça uma área de **6 m ao seu redor**, que acompanha você e dura até o fim da cena. Pode encerrá-la como ação livre no seu turno.
>
> **Provocação inicial — uma vez por cena.** Ao ativar a área, escolha inimigos dentro dela, até o limite de metade da sua Força, arredondada para baixo, mais um. Faça um teste de Provocar contra o TR de Espírito de cada um. Quem falhar sofre o efeito de Provocar até o começo do seu próximo turno. Inimigos que entrarem depois não recebem essa provocação inicial.
>
> **Assumir um golpe.** Enquanto a área estiver ativa, quando uma criatura declarar um ataque com rolagem contra um aliado dentro dela, **antes da rolagem de acerto**, você pode gastar sua **Reação** para se tornar o alvo daquele ataque.
>
> O atacante faz a rolagem normalmente e compara o resultado com **sua Defesa**, ou com seu **Bloquear**, se você escolher bloquear. Bloquear não exige outra Reação. O ataque conserva seu alcance já declarado contra o aliado; esta habilidade permite interceptá-lo sem mover você. Se acertar, você recebe o dano e os efeitos que acompanham o golpe, inclusive o crítico. Se errar, nenhum dos dois recebe o golpe. Esta Reação protege somente o ataque declarado, não os demais ataques da ação.

> **Nível 7: Ataque Extra.** Sua Ação Atacar permite **um ataque simples adicional por rodada**.
>
> Você também recebe as duas habilidades abaixo.
>
> **`Nem Um Arranhão`.** Enquanto Olhos Em Mim estiver ativo, você tem **vantagem no TR Físico provocado por um ataque de uma criatura dentro da área**. Confira a posição do atacante quando fizer o teste. É um benefício passivo, sem gasto de Reação; o resultado e o dano do teste seguem as regras normais do ataque.
>
> **`Ainda de Pé`.** **Uma vez por cena**, quando sua vida for reduzida à metade ou menos, recupere **1d8 + metade do seu nível** de vida. Não exige ação.

> **Nível 15: `Duro de Matar`.** Sempre que seu Bloquear falhar, reduza o dano do golpe pelo **resultado dos dados do Bloquear + sua Constituição**.
>
> Use somente os dados, sem os modificadores de Destreza e proteção. Também vale para um ataque assumido por Olhos Em Mim se você escolheu Bloquear e falhou. A redução não pode deixar o dano abaixo de zero.

> **Nível 23: `Chega Mais`.** A área de Olhos Em Mim passa a **9 m**.
>
> Quando um inimigo entrar nela **voluntariamente**, faça contra ele uma nova tentativa de Provocar, com o mesmo teste e duração da provocação inicial.

> **Nível 30: `Passa Pra Mim`.** **Uma vez por cena, como ação livre**, quando um aliado dentro de Olhos Em Mim seria reduzido a 0 de vida, ele fica com **1 de vida** e você recebe o dano excedente necessário para preservar esse ponto.
>
> Se essa transferência reduzir sua vida a 0, você cai.

> **Exemplo.** Um aliado com 10 de vida receberia 16 de dano. Ele perde 9 e fica com 1; os 7 pontos restantes passam para você.

### Trilha: Muro

*Você assume a pressão e a transforma em uma defesa cada vez mais difícil de atravessar.*

**Habilidades do Muro**
| Nível | Habilidade |
|---|---|
| 2 | Alicerce |
| 11 | Guarda-Costas |
| 19 | Casca Grossa |
| 27 | Inabalável |

> **Nível 2: `Alicerce`.** Ao fim de cada descanso longo, escolha **dois tipos de dano**. Enquanto Olhos Em Mim estiver ativo, você recebe **metade do dano** desses tipos.
>
> **Nível 11: `Guarda-Costas`.** Um aliado **adjacente a você** recebe **Cobertura Parcial: +2 na Defesa e no TR Físico**, desde que o atacante também esteja adjacente a você **ou** esteja atacando à distância.
>
> **Nível 19: `Casca Grossa`.** Quando um ataque assumido por Olhos Em Mim acertar você, depois de resolver sua Defesa ou seu Bloquear, role **2d10 − 1** e acrescente sua Constituição. Reduza esse valor do dano recebido.
>
> Esta redução se soma às reduções aplicáveis ao golpe, inclusive Duro de Matar quando seu Bloquear falhou; não concede outra tentativa de Bloquear.
>
> **Nível 27: `Inabalável`.** Alicerce passa a proteger contra **quatro tipos de dano**, escolhidos ao fim de cada descanso curto ou longo.
>
> Olhos Em Mim permanece ativo mesmo quando você está caído, agarrado ou inconsciente. As ações e Reações ainda dependem de você poder realizá-las.

### Trilha: Punho

*Você responde à pressão com golpes desarmados, deslocando os inimigos e disputando o confronto de perto.*

**Habilidades do Punho**
| Nível | Habilidade |
|---|---|
| 2 | Trocação Franca |
| 11 | Mão Pesada |
| 19 | Minha Vez |
| 27 | Arrastão |

> **Nível 2: `Trocação Franca`.** Quando acertar um ataque de sua **Ação Atacar**, pode usar a **Ação Bônus** para realizar um golpe desarmado.
>
> Quando um ataque assumido por **Olhos Em Mim** acertar você, também pode realizar um golpe desarmado contra o atacante, se ele estiver ao alcance. Esse golpe integra a Reação já gasta para assumir o ataque.
>
> **Nível 11: `Mão Pesada`.** Quando acertar um golpe desarmado, pode empurrar o alvo até **4,5 m** na direção escolhida, **uma vez por alvo por rodada**.
>
> Além disso, **uma vez por rodada**, um alvo atingido por seu golpe desarmado faz **TR de Vigor contra CD 8 + sua Força + sua maestria**. Na falha, você escolhe: ele fica **Derrubado** ou **Agarrado por você**. Para agarrá-lo, ele precisa estar ao seu alcance corpo a corpo e você precisa ter uma mão livre para manter a contenção. Se também o empurrar, só pode mantê-lo Agarrado se ele continuar ao seu alcance. A condição segue suas regras normais de duração e término.
>
> **Nível 19: `Minha Vez`.** **Uma vez por rodada**, ao ter sucesso em Bloquear, pode gastar **2 PE** para realizar um golpe desarmado contra o atacante como **ação livre**, se ele estiver ao seu alcance.
>
> **Nível 27: `Arrastão`.** Use uma **Ação Padrão** para realizar um golpe desarmado contra até **um número de criaturas igual à sua Força**, dentro de Olhos Em Mim: um golpe por criatura, com rolagens próprias.
>
> Arrastão conta como Ação Atacar, mas substitui o conjunto de ataques dessa ação, sem acrescentar Ataque Extra. O empurrão de Mão Pesada se aplica normalmente.
>
> Ao declarar Arrastão, pode pagar **2 PE por criatura atacada além da primeira** para ampliar o controle de Mão Pesada a todos os alvos acertados. Declare os alvos e pague antes das rolagens: o custo depende dos ataques tentados, mesmo que errem. Cada alvo acertado faz seu próprio **TR de Vigor**; na falha, escolha Derrubado ou Agarrado, cumprindo os requisitos de Mão Pesada.
>
> **Exemplo:** atacar três criaturas com a ampliação custa 4 PE; cinco custam 8 PE. O custo não muda o número de ataques permitido por Arrastão.

### Trilha: Combatente Amaldiçoado

*A pressão recebida alimenta sua resposta técnica. Você aproveita a defesa e os golpes assumidos para manter a energia circulando.*

**Habilidades do Combatente Amaldiçoado**
| Nível | Habilidade |
|---|---|
| 2 | Retaliação |
| 11 | Embalo |
| 19 | Oportunista |
| 27 | Contra a Parede |

> **Nível 2: `Retaliação`.** Quando um ataque assumido por **Olhos Em Mim** acertar você, pode lançar um feitiço de **Classe 0** contra o atacante, como parte da mesma Reação. O feitiço segue seus requisitos e sua própria resolução.
>
> Seu **PE máximo aumenta em um valor igual à sua Força**.
>
> **Nível 11: `Embalo`.** Ao obter um crítico num ataque de sua **Ação Atacar**, ou passar num **TR Físico**, receba energia temporária igual à sua **maestria**.
>
> Essa reserva segue as regras de energia temporária: não acumula com outra reserva; mantenha o maior valor.
>
> **Nível 19: `Oportunista`.** Depois de ter sucesso em Bloquear, seu próximo feitiço de **Classe acima de 0** recebe **vantagem na rolagem de acerto**, ou impõe **desvantagem no TR do alvo**.
>
> Feitiços de Classe 0 não consomem essa preparação.
>
> A preparação dura **até o fim do seu próximo turno**, e vale para **um ataque do feitiço** ou para **o primeiro TR de uma criatura** contra ele.
>
> **Nível 27: `Contra a Parede`.** Enquanto estiver com **metade da vida ou menos**, sua **Ação Atacar** vem acompanhada de um feitiço de dano de **metade da sua maior Classe**, desde que você cumpra os requisitos dele.
>
> A metade arredonda **para baixo**. Escolha **o primeiro ou o segundo ataque** dessa Ação Atacar para acompanhar o feitiço. Resolva o ataque e depois o feitiço, **uma única vez na ação**, pagando o custo normal de PE e respeitando o alcance, os alvos e a resolução próprios do feitiço.
>
> **O feitiço não pode ser crítico, mesmo que o ataque seja. Você não pode usar Canalizar em Golpe no ataque escolhido.** O outro ataque conserva suas regras normais. Se a ação tiver apenas um ataque, o feitiço acompanha esse primeiro ataque.

## Vanguarda

*Você transforma ataques em preparação contra um adversário. Decide quando manter a pressão, quando mudar a abordagem e quando encerrar a Sequência com uma execução.*

### Características da Vanguarda

**Características da Vanguarda**
| | |
|---|---|
| **Vida por nível** | 5 |
| **PE por nível** | 5 |
| **Atributos naturais** | Destreza · Força |
| **Perícias fixas** | `Acrobacia` · `Percepção` |
| **Perícias à sua escolha** | 5, de qualquer uma da lista de perícias do sistema |
| **Ofícios** | nenhum. Os dois vêm da sua Origem |
| **Teste de Resistência** | 1 treinado, à sua escolha. A sua Origem treina o outro |
| **Treino de arma** | **as treze categorias**: Simples, Marciais e Arma de Fogo |

*Perícia, ofício e Teste de Resistência entram na ficha uma vez, na criação. O quadro completo das vinte e três perícias e dos onze ofícios está no capítulo 3, __Perícias e Ofícios__.*

*O Caminho treina você nessa lista de armas; ele não te dá a arma. O que você leva na mão você compra na criação, e as tabelas de `Preços` estão no capítulo 15, __Equipamento__.*

Escolha uma Trilha no nível 2: **Estocada, Batedor ou Executor**. O Batedor possui três rotas, das quais você escolhe uma.

### Degraus da Vanguarda

**Habilidades da Vanguarda**
| Nível | Habilidade |
|---|---|
| 2 | Sequência de Condução e Escola de Arma |
| 7 | Ataque Extra |
| 15 | Não Cede |
| 23 | Persistência |
| 30 | Conclusão Dupla |

> **Nível 2: `Sequência de Condução`.** **Golpe Inicial → Condução → Conclusão.** Cada etapa usa um ataque que você já pode realizar no seu turno. Você mantém uma Sequência contra um alvo e realiza **uma Condução ou uma Conclusão por turno próprio**. Golpe Inicial pode acontecer no mesmo turno, com outro ataque.
>
> Declare a etapa antes dos dados. O TR de um efeito adicional usa **CD = 8 + atributo do ataque + maestria**. Acertar o ataque conta para a preparação mesmo quando o alvo resiste ao efeito adicional.

#### Golpe Inicial

Antes de atacar com arma ou desarmado, declare a abertura. Se acertar, inicie a Sequência e reduza o dano total do golpe em **Xd4**, com **X igual à metade da maestria, arredondada para cima**, até o mínimo de zero.

Role essa redução uma vez, depois dos modificadores do atacante e antes das defesas que reduzem o dano recebido pelo alvo. Ela não dobra no crítico. O Golpe Inicial não custa PE e abre a Sequência mesmo quando seu dano final é zero.

Abrir contra outro alvo substitui a Sequência anterior. Você não reabre uma Sequência ativa contra o mesmo alvo nem abre outra no turno em que declarou uma Conclusão.

**Golpe Inicial e Condução por maestria**
| Maestria | Redução no Golpe Inicial | Custo de cada Condução |
|---|---|---|
| 1 ou 2 | 1d4 | 2 PE |
| 3 ou 4 | 2d4 | 3 PE |

#### Conduzir

Escolha uma Condução e pague **metade da maestria, arredondada para cima, + 1 PE**, antes do ataque, inclusive no erro.

Acertar causa o dano normal, acrescenta uma Condução acertada e renova o prazo da Sequência. Errar encerra a Sequência, salvo Persistência. Você pode continuar conduzindo sem um limite de acertos acumulados.

Ao declarar uma Condução diferente, abandone o efeito sustentado da anterior. Repetições não acumulam o mesmo benefício. Movimentos já realizados e acertos de Condução registrados permanecem.

**Conduções**
| Condução | Efeito após o acerto |
|---|---|
| **Mudar o Ângulo** | Desloque-se até **3 m adicionais**, respeitando o terreno, sem provocar ataque de oportunidade do alvo da Sequência. |
| **Pressionar a Guarda** | **+1 no acerto** de seus ataques contra o alvo até o fim do próximo turno. |
| **Proteger o Avanço** | **+1 de Defesa** contra ataques do alvo até o fim do próximo turno, inclusive ao Bloquear. Soma com Postura Firme. |
| **Acompanhar o Movimento** | Até o fim do próximo turno, quando o alvo terminar um deslocamento voluntário, você pode mover-se **uma vez até metade do seu deslocamento**, sem Reação ou gasto de movimento normal e sem provocar oportunidade daquele alvo. |
| **Explorar o Desequilíbrio** | Exige alvo **Derrubado ou Agarrado**. Até o fim do próximo turno, ele sofre **−1 no próximo TR Físico ou de Vigor de uma Conclusão sua**. Em Dupla, declare qual dos testes que cumprem essas condições virá primeiro. |
| **Fechar a Rota** | **TR Físico:** na falha, o alvo não pode se afastar voluntariamente de você até o fim do próximo turno dele. Pode se aproximar, ser movido por outra força ou se teleportar. |

Fechar a Rota não reduz, por si, o valor do deslocamento exigido por Fixar o Alvo.

#### Concluir

Escolha uma Conclusão compatível com a fonte do ataque e com seus requisitos. **A declaração consome a Sequência**, mesmo no erro ou na resistência. Concluir não custa PE adicional por si só.

Nas opções com TR, o ataque precisa acertar e o alvo precisa falhar no teste para sofrer o efeito. "Sem Condução mínima" permite Concluir logo depois do Golpe Inicial ou após Conduções.

> **Ponto Fraco.** Corpo a corpo; sem Condução mínima. Nesse ataque, sua margem crítica aumenta em uma unidade: normalmente **19–20**.
>
> **Explorar a Cobertura.** Distância; sem Condução mínima; alvo com cobertura. Nesse ataque, trate **Boa como Parcial** ou **Parcial como nenhuma**. Cobertura Total continua impedindo o ataque.
>
> **Rasteira.** Corpo a corpo ou distância; **uma Condução acertada**. **TR Físico:** na falha, deixe o alvo **Derrubado** e, se desejar, empurre-o até **1,5 m**. A mesma falha permite os dois resultados.
>
> **Desarme.** Corpo a corpo; **uma Condução acertada**; alvo empunhando arma ou objeto. **TR Físico:** na falha, o objeto sai da empunhadura e cai num espaço escolhido a até **3 m do alvo**.
>
> **Interromper a Resposta.** Distância; **uma Condução acertada**. **TR Físico:** na falha, o alvo não pode usar **Reações até o começo do seu próximo turno**. Bloquear é independente de Reação.
>
> **Quebrar o Ritmo.** Corpo a corpo ou distância; **uma Condução acertada**. **TR de Vigor:** na falha, o alvo fica **Lento até o fim do próximo turno dele**.
>
> **Fixar o Alvo.** Distância; **duas Conduções acertadas**; deslocamento do alvo já reduzido antes da declaração. **TR Físico:** na falha, fica **Impedido até o fim do próximo turno dele**. Terreno difícil conta como a redução prévia.

Lento e Impedido aplicados com essa duração terminam no prazo, sem novo TR para encerramento antecipado. Derrubado e Desarmado seguem suas regras próprias.

#### Prazo e troca de alvo

Um Golpe Inicial ou uma Condução acertados mantêm a Sequência até o **fim do segundo turno seu seguinte**. Um novo acerto de Condução reinicia esse prazo. Outras ações e feitiços não o renovam.

A Sequência termina ao expirar, ao errar uma Condução sem Persistência, ao declarar a Conclusão ou ao ser substituída por uma abertura contra outro alvo. Efeitos com duração própria seguem seu prazo.

Se uma Condução errada encerrar a Sequência, um ataque restante pode abrir outra no mesmo turno; o limite de uma Condução ou Conclusão naquele turno permanece.

#### Escola de Arma

> **Nível 2: `Escola de Arma`.** Escolha **uma categoria** e receba sua Manha. Ela acontece depois do dano de um **Golpe Inicial acertado** com essa categoria, uma vez por Sequência e no máximo uma vez por turno.

**Manhas**
| Categoria | Manha |
|---|---|
| Lâmina Curta, Arremesso, Yumi, Balestra ou Arma de Fogo | **Ritmo:** +1 no próximo ataque com essa categoria contra o alvo. A tentativa consome o benefício; o fim da Sequência o encerra. |
| Lâmina Longa, Manopla ou golpes desarmados | **Postura Firme:** +1 de Defesa até o começo do próximo turno, inclusive ao Bloquear. Trocar de Condução não encerra essa postura. |
| Massa, Porrete, Machado ou Armas Longas | **Empuxo:** TR Físico; na falha, empurre o alvo até **3 m para longe de você**. |
| Ceifa ou Flexível | **Mover Alvo:** TR Físico; na falha, mova o alvo até **1,5 m na direção escolhida**. |

> **`Versado`.** Em vez de uma categoria e sua Manha, escolha **Versado**: imediatamente após acertar um Golpe Inicial, guarde uma arma e saque outra sem ação, **uma troca por Sequência**.

> **Nível 7: Ataque Extra.** Sua Ação Atacar permite **um ataque simples adicional por rodada**. Uma habilidade específica, como Bote, pode permitir usar esse ataque em outra ação.

> **Nível 15: `Não Cede`.** Quando falhar num **Teste de Resistência**, pode repetir o teste e usar o segundo resultado.
>
> Você tem usos iguais à **maestria por descanso curto**, no máximo **um por rodada**. Não exige ação ou PE.

> **Nível 23: `Persistência`.** Depois das rerrolagens de uma Condução, se o ataque ainda errar, pode gastar um uso de Persistência para **manter a Sequência**.
>
> O ataque permanece errado: não aplica o efeito, não acrescenta Condução acertada e não renova o prazo. Custos pagos e preparações abandonadas não retornam.
>
> Você tem **metade da maestria, arredondada para baixo, + 1 usos por descanso curto ou longo**. Não exige ação ou PE adicional.

> **Nível 30: `Conclusão Dupla`.** **Uma vez por cena**, ao Concluir depois de **duas ou mais Conduções acertadas**, escolha **duas Conclusões diferentes da mesma fonte**: corpo a corpo, distância ou feitiço. Concluir por feitiço exige Estocada.
>
> Declare as duas antes dos dados, com todos os requisitos cumpridos. Um ataque ou feitiço resolve seu dano normal uma vez; cada Conclusão tem seu TR, quando houver. Resolva os testes antes de aplicar os novos efeitos. Explorar o Desequilíbrio modifica apenas um teste que cumpra essas condições.
>
> O uso é gasto na declaração. A fonte da preparação pode ser diferente da fonte da Conclusão.

### Trilha: Estocada

*Você integra arma e feitiço na mesma rotina e transforma a preparação armada numa Conclusão de feitiço.*

**Habilidades da Estocada**
| Nível | Habilidade |
|---|---|
| 2 | Compasso |
| 11 | Conclusões de feitiço |
| 19 | Bote |
| 27 | Ferrão |

> **Nível 2: `Compasso`.** Escolha **Essência ou Inteligência**. Some esse atributo ao seu **PE máximo** e use-o no lugar de Força ou Destreza para o acerto e dano das armas de suas categorias escolhidas. Os requisitos de Força permanecem.
>
> Escolha **uma categoria (Grupo das Armas)**. Se possuir Versado na Escola de Arma, escolha uma quantidade de categorias igual à sua **maestria**.
>
> Depois de conjurar na **Ação Padrão** um feitiço de **Classe igual ou superior à metade de sua maior Classe disponível, arredondada para cima**, pode usar a **Ação Bônus** para fazer um ataque com uma arma dessas categorias. O feitiço não precisa acertar.
>
> Esse ataque pode dar o Golpe Inicial, Conduzir ou Concluir, com os custos e limites da Sequência. Com maior Classe 7, Compasso exige Classe 4 ou superior.

> **Nível 11: `Conclusões de feitiço`.** Após **uma Condução acertada**, pode usar um feitiço de **Classe 1 ou maior que cause dano ou imponha condição ao alvo da Sequência** para Concluir. Algumas opções exigem duas Conduções.
>
> Escolha a Conclusão antes da resolução. Ela se aplica somente ao alvo da Sequência se o feitiço o acertar ou ele falhar no TR principal. Dano parcial após sucesso no TR não basta. Em uma aplicação com várias resoluções, indique antes dos dados qual resolução inicial poderá ativá-la.
>
> O feitiço mantém seu custo e sua ação. O TR adicional da Conclusão usa **CD = 8 + atributo escolhido em Compasso + maestria**. As condições novas do próprio lançamento só entram depois dos testes adicionais.

> **Cortar a Resposta.** **Duas Conduções; TR Físico.** Na falha, o alvo não pode usar Reação contra o **próximo ataque que sofrer**. Bloquear permanece independente.
>
> **Romper Fileira.** **Uma Condução; TR Físico.** Na falha, mova o alvo até **6 m** por um trajeto livre sobre a superfície que o sustenta. Em seguida, você pode mover-se até **metade do seu deslocamento**, sem ação, sem gastar movimento normal e sem provocar oportunidade daquele alvo.
>
> **Desorientar.** **Uma Condução; sem TR adicional.** A próxima rolagem do alvo, de qualquer natureza, tem **desvantagem**, se acontecer até o fim do próximo turno dele. O efeito pode afetar ataque, TR, perícia, Bloquear ou dano. Em rolagens de conjuntos, role o conjunto completo duas vezes e mantenha o resultado menos favorável ao alvo. A primeira tentativa consome o efeito.
>
> **Expor a Guarda.** **Duas Conduções; TR de Vigor.** Na falha, o próximo ataque de **um aliado seu** contra o alvo tem **vantagem**, se acontecer antes do começo do seu próximo turno. A primeira tentativa que cumpra essas condições consome o benefício.
>
> **Ancorar.** **Duas Conduções; TR Físico.** Na falha, o deslocamento do alvo fica em **zero até o fim do próximo turno dele**. Movimento forçado e teleporte continuam possíveis.
>
> **Refluxo.** **Uma Condução; sem TR adicional.** Escolha uma Condução acertada da Sequência e receba **energia temporária igual à metade do PE de fato gasto nela**, arredondada para baixo, com mínimo de 1 quando houve gasto de PE. Uma Condução gratuita gera zero. A reserva surge depois da resolução e segue as regras gerais de energia temporária: gasto antes do PE normal, maior reserva em vez de soma, limite de metade do PE máximo e término no fim da cena, salvo a permissão geral de preparação deliberada.

Desorientar e os outros efeitos novos não prejudicam outro TR do mesmo lançamento. Em Conclusão Dupla, escolha duas opções deste catálogo e respeite todos os requisitos da Dupla.

> **Nível 19: `Bote`.** Quando o feitiço de sua Ação Padrão **impuser uma condição e não causar dano imediato nem posterior**, e liberar Compasso, pode fazer **dois ataques** naquela Ação Bônus, usando Ataque Extra.
>
> Se ainda não Concluiu, esses ataques podem cumprir etapas normais: por exemplo, Golpe Inicial e Condução. Se o feitiço Concluiu, os ataques continuam disponíveis, mas não abrem nem desenvolvem outra Sequência naquele turno.
>
> **Bote e Ferrão são alternativas no mesmo turno.**

> **Nível 27: `Ferrão`.** Depois de Concluir com um feitiço da Ação Padrão que **acerte o alvo ou o faça falhar no TR principal**, o primeiro ataque da Ação Bônus de Compasso pode carregar **um feitiço de Classe 0**.
>
> Declare Ferrão antes do ataque da arma. Se ela errar, o Classe 0 não é lançado. Se acertar, ele resolve sua própria rolagem e requisitos, inclusive alcance e crítico. Não é necessário que o alvo tenha falhado no TR adicional da Conclusão principal.
>
> Se o Classe 0 causar dano, **substitui Canalizar energia ou Estímulo Muscular naquele golpe**, em vez de somar-se a esses dados. O ataque mantém o dano próprio da arma e seu atributo.
>
> Ferrão acompanha somente o primeiro ataque que cumpra essas condições e não é duplicado por Conclusão Dupla. A Sequência já terminou; permanecem as restrições de nova abertura e a incompatibilidade com Bote.

### Trilha: Batedor

Escolha uma rota no nível 2. Cada uma recebe uma facilidade inicial, três Conduções próprias, duas Conclusões e as entregas dos níveis 11, 19 e 27. Você continua usando as opções comuns da Vanguarda quando seus requisitos forem cumpridos.

**Rotas do Batedor**
| Nível | Yumi | Besta | Arma de Fogo |
|---|---|---|---|
| 2 | Soltura Preparada | Virotes Cravados | Combate Irregular |
| 11 | Segunda Leitura | Consumir a Farpa | Reorientar a Pressão |
| 19 | Soltura de Emergência | Fixação Cruzada | Romper o Contato |
| 27 | Última Leitura | Preparação Remanescente | Plano de Continuidade |

#### Rota: Yumi

*As flechas anteriores preparam a execução; você escolhe o momento de soltar a flecha que encerra a Sequência.*

> **Nível 2: `Soltura Preparada`.** Você recebe **deslocamento de escalada igual ao deslocamento normal**.

##### Armar uma Conclusão

Quando puder Concluir com Yumi no seu turno, pode **armar a Conclusão** em vez de disparar imediatamente. Declare a Conclusão, o alvo da Sequência e os detalhes necessários; comprometa um ataque disponível e consuma a Sequência. Ataque, dano e TR são rolados apenas na soltura.

Você precisa ter **Reação disponível**, mantém **uma flecha armada** e deve soltá-la gastando essa Reação **antes do começo do próximo turno**. Usar a Reação em outra coisa descarta a flecha, sem devolver o ataque ou a Sequência.

Mantenha o arco empunhado e pronto. Guardá-lo, perdê-lo, dispará-lo novamente ou ocupar suas mãos de maneira incompatível desfaz a armação. Movimento e dano sofrido, por si só, não a desfazem.

A soltura é feita da sua posição real contra o mesmo alvo. Confira os requisitos da Conclusão na armação e, na soltura, aqueles que dependem da situação atual. Pague custos adicionais do ataque na armação; eles não retornam se a flecha for perdida.

Essa resolução adiada é uma exceção própria do Yumi. Golpes Iniciais e Conduções continuam ocorrendo no seu turno. Você pode preferir uma Conclusão imediata, exceto quando a opção exigir armação.

##### Soltura Simples

Escolha um acontecimento **que todos possam identificar e que você consiga perceber** do alvo: terminar um ataque com arma ou desarmado, uma tentativa de Agarrar, um deslocamento voluntário, um feitiço ou o uso de um objeto.

Você pode soltar a flecha **depois** desse evento. Se o movimento for dividido, considere cada trecho percorrido.

##### Conduções do Yumi

As três usam o ataque, o custo e o acerto normais da Condução. Cada uma estabelece **um modo de soltura**. Trocar de Condução abandona o anterior na declaração, salvo Segunda Leitura. Uma Condução comum volta à Soltura Simples.

> **Antecipar o Gesto.** Depois de acertar, ao armar escolha o alvo declarar um ataque com arma ou desarmado, ou começar a sair voluntariamente do espaço ocupado. Se escolheu o ataque, solte antes da rolagem. Se escolheu o movimento, solte antes de o alvo sair do espaço. A arma e a criatura atacada já precisam estar declaradas.
>
> **Acompanhar a Abertura.** Depois de acertar, pode soltar **após qualquer evento da Soltura Simples**, sem fixar apenas um. Pode deixar uma janela passar e aproveitar outra. O acontecimento escolhido já foi resolvido.
>
> **Reter a Soltura.** Depois de acertar, escolha um evento da Soltura Simples. Se a flecha continuar armada **imediatamente antes do começo do próximo turno**, pode soltá-la mesmo sem o evento. Use a Reação que ainda restou naquele intervalo, antes da renovação.

##### Conclusões do Yumi

> **Flecha Intercessora.** **Requisitos:** uma Condução de Yumi acertada, modo **Antecipar o Gesto** e flecha armada para a declaração de um ataque com arma ou desarmado.
>
> Quando o alvo anunciar esse ataque contra uma criatura, **antes dos dados**, gaste sua Reação para disparar. Resolva a flecha e seu dano normal. Se acertar e o golpe anunciado ainda puder acontecer, o alvo faz **TR Físico**.
>
> Na falha, **a rolagem do ataque anunciado tem desvantagem**.

> **Flecha Desestabilizadora.** **Requisito:** uma Condução de Yumi acertada. Pode ser imediata ou armada.
>
> Após acertar, o alvo faz **TR de Vigor**. Na falha, sua próxima rolagem de dano contra uma criatura tem **desvantagem**, até o fim do próximo turno dele.
>
> Role o conjunto completo duas vezes, com os mesmos modificadores, e use o que causar menos dano. Não combine dados individuais. A primeira rolagem que cumpra essas condições consome o efeito. Dano inteiramente fixo não é reduzido.
>
> O efeito pode atingir dano de arma, desarmado ou feitiço. Se uma rolagem for compartilhada entre várias criaturas, o arqueiro escolhe **uma delas antes dos dados** para receber o resultado menor; as demais usam a primeira rolagem normal. A escolha não exige outra Reação.

##### Duração e Conclusão Dupla

O prazo de um efeito armado é fixado como se a Conclusão fosse resolvida no turno da armação. **Adiar não prolonga a duração.** Uma soltura tardia pode preservar o ataque quando o efeito temporário já perdeu sua janela.

**Conclusão Dupla com Yumi é imediata.** Desestabilizadora pode integrá-la; Intercessora permanece exclusiva de sua janela armada.

> **Nível 11: `Segunda Leitura`.** Ao acertar uma Condução própria **diferente da ativa**, pode guardar o modo anterior como **leitura de reserva**. Você mantém um modo ativo e uma reserva diferente, ambos preparados por Conduções realmente acertadas naquela Sequência.
>
> Ao armar, escolha qual usar. Só o modo escolhido funciona.
>
> Uma troca para outra Condução própria só mantém as leituras se acertar. No erro, perde ambas, mesmo usando Persistência. Repetir o mesmo modo mantém a reserva existente; um erro preservado por Persistência mantém somente os estados e prazos anteriores. Uma Condução comum apaga as duas leituras.

> **Nível 19: `Soltura de Emergência`.** **Uma vez por cena**, enquanto a flecha estiver armada, pode abandonar o efeito da Conclusão para soltá-la **como disparo comum**.
>
> Isso pode acontecer depois de qualquer evento da Soltura Simples ou imediatamente antes do próximo turno, mesmo fora do evento marcado. Use a Reação ainda disponível e faça o ataque contra o mesmo alvo.
>
> O uso é gasto na declaração. A Sequência e os custos permanecem consumidos. Uma flecha já descartada não pode ser recuperada por esta habilidade.

> **Nível 27: `Última Leitura`.** **Uma vez por cena**, se armou a flecha possuindo dois modos diferentes mantidos por Segunda Leitura, pode **trocar o modo escolhido pelo outro durante a espera**, sem ação adicional.
>
> O novo modo substitui o anterior. Declare o evento que ele exigir e respeite sua janela: Antecipar antes dos dados ou movimento; Acompanhar depois do evento; Reter com sua soltura de segurança.
>
> O uso da cena é gasto **na troca**. A flecha mantém Conclusão, alvo, custos e prazo, e sua soltura ainda exige Reação. Intercessora continua exclusiva da janela anterior ao ataque físico; fora dela, Emergência pode preservar apenas o disparo comum.

> **Exemplo.** Você armou Desestabilizadora com Acompanhar e guardou Antecipar. O inimigo anuncia um ataque em vez de se mover. Antes dos dados, Última Leitura permite mudar para Antecipar e soltar a mesma Desestabilizadora.

#### Rota: Besta

*Seus acertos deixam preparação no alvo. Você escolhe acrescentar, reforçar ou consumir os virotes.*

> **Nível 2: `Virotes Cravados`.** Suas bestas **dispensam a ação de recarga e as interrupções de Munição**. Você ainda precisa de virotes disponíveis.
>
> Um **Golpe Inicial acertado** pode estabelecer um virote comum vinculado à Sequência. O limite é **três virotes ativos**. Esse marcador não aplica condição por si só.
>
> Os virotes persistem entre as três Conduções desta rota. Uma Condução comum abandona os marcadores, preservando o número de Conduções acertadas. Ao terminar a Sequência, os virotes perdem sua função, salvo Preparação Remanescente.
>
> **Retirada.** O alvo ou um ajudante ao alcance pode remover um virote comum com **Ação Bônus e sucesso em TR Físico contra a CD da Trilha**, ou com **Ação Padrão sem teste**. Um farpado exige a Ação Padrão. Retirar não causa dano nem apaga Conduções acertadas.

##### Conduções da Besta

> **Cravar.** Após acertar, acrescente um virote comum, até o limite.
>
> **Farpar.** Exige um comum ativo. Após acertar, transforme-o em **farpado**. Um farpado substitui dois comuns somente nas Conclusões que permitirem isso.
>
> **Acionar.** Consuma um virote na declaração. Após acertar, **TR de Vigor**: na falha, o alvo não pode usar **Ação Bônus até o fim do próximo turno dele**. O virote é gasto mesmo no erro ou na resistência.

##### Conclusões da Besta

> **Interditar a Ferramenta.** **Requisitos:** uma Condução de Besta acertada, um virote ativo e alvo empunhando arma ou objeto.
>
> Consuma o virote e escolha o objeto na declaração. Após acertar, **TR Físico**: na falha, o alvo não pode usar o objeto até o fim do próximo turno dele. Pode largá-lo e recorrer a outro equipamento.
>
> A interdição não impede seus feitiços por ele estar empunhando o objeto.

> **Virote Debilitante.** **Requisitos:** uma Condução de Besta acertada e **dois comuns ou um farpado** ativos.
>
> Escolha **TR Físico ou de Vigor** e consuma os virotes na declaração. Após acertar, o alvo faz **TR de Vigor**. Na falha, o próximo TR do tipo escolhido tem **desvantagem**, até o fim do seu próximo turno.
>
> O primeiro TR do tipo escolhido consome o efeito, seja provocado por você ou por outra criatura. A penalidade começa depois dos testes do próprio ataque e não prejudica o outro TR da mesma Conclusão Dupla.

> **Nível 11: `Consumir a Farpa`.** **Uma vez por Sequência**, ao declarar Acionar, pode gastar apenas a qualidade de um farpado: transforme-o em **comum**, em vez de removê-lo.
>
> A farpa e o uso são consumidos na declaração, mesmo no erro ou na resistência. Esta conservação vale para Acionar, não para o pagamento das Conclusões.

> **Nível 19: `Fixação Cruzada`.** **Reação, uma vez por Sequência.** Depois de uma retirada bem-sucedida de um virote seu, pode transformar **outro comum ainda ativo naquele alvo** em farpado.
>
> Você precisa perceber a retirada e manter a Sequência. O virote retirado sai normalmente. Retirada falhada, consumo dos próprios marcadores ou fim da Sequência não ativam a habilidade.

> **Nível 27: `Preparação Remanescente`.** **Uma vez por cena**, ao declarar uma Conclusão com Besta, tendo uma Condução própria acertada, pode reservar **um virote que não será consumido na execução**.
>
> Ele é o único que mantém sua função após a Sequência terminar, mesmo se a Conclusão errar ou for resistida. Fica no mesmo alvo **até o fim do próximo turno**, sujeito à retirada normal.
>
> Se acertar um novo **Golpe Inicial de Besta contra o mesmo alvo** nesse prazo, incorpore a reserva e o comum que a nova abertura pode estabelecer, até o limite de três. A nova Sequência começa com **zero Conduções acertadas**.
>
> Abrir contra outro alvo ou com outra categoria abandona a reserva. Um erro não renova o prazo, mas outra tentativa que cumpra as condições do ataque pode aproveitá-la antes de expirar. Em Dupla, reserve somente material que sobre após pagar as duas Conclusões.

> **Exemplo.** Você consome um farpado em Debilitante e reserva o comum que sobrou. Na próxima abertura acertada contra aquele inimigo, pode começar com o comum preservado e um novo, mas ainda precisa Conduzir.

#### Rota: Arma de Fogo

*Você cria uma Oportunidade, escolhe quando aproveitá-la e mantém meios de continuar o confronto.*

> **Nível 2: `Combate Irregular`.** Seus disparos não sofrem a desvantagem causada por inimigo adjacente. O limite **X de disparos antes da recarga aumenta em um**. O gatilho de recarga por **1 ou 2 natural** permanece.

##### Oportunidade Tática

Você mantém **uma Oportunidade**, obtida por suas Conduções. Ela pode antecipar Pressão Dominante, habilitar a recarga de Ruptura e, no nível 19, pagar Romper o Contato.

Trocar de Condução abandona o preparo anterior e sua Oportunidade, salvo Reorientar a Pressão e Plano de Continuidade. Ela é consumida ao declarar seu uso, mesmo no erro ou na resistência, e não substitui Conduções acertadas.

##### Conduções da Arma de Fogo

> **Fogo de Supressão.** Gaste **dois usos de Munição** num ataque. Após acertar, se o alvo atacar ou conjurar um feitiço que prejudique alguém de maneira que você possa perceber até o começo do seu próximo turno, obtenha uma Oportunidade válida até o fim desse turno.
>
> **Queima-Roupa.** Exige alvo a até **1,5 m** e consumo normal de Munição. Após acertar, receba Oportunidade no começo do próximo turno se não escolheu se afastar voluntariamente do alvo. Ela dura até o fim desse turno. Movimento do inimigo ou imposto a você não desfaz o preparo por si só.
>
> **Tiro Controlado.** Consumo normal. Após acertar, permite gastar **um uso adicional de Munição** na próxima Conclusão própria para obter e consumir uma Oportunidade na declaração. Precisa ter usos disponíveis para o disparo e o gasto adicional.

##### Conclusões da Arma de Fogo

> **Pressão Dominante.** **Requisito:** duas Conduções de Arma de Fogo acertadas, ou **uma e uma Oportunidade consumida**.
>
> Após acertar, **TR de Espírito**: na falha, o alvo fica **Amedrontado por você até o fim do próximo turno dele**.

> **Ruptura Tática.** **Requisito:** uma Condução de Arma de Fogo acertada.
>
> Após acertar, **TR Físico**: na falha, o alvo não pode usar **Reações contra você até o começo do próximo turno**.
>
> Se consumiu Oportunidade e ele falhou no TR, pode gastar **uma Ação de Movimento inteira e ainda disponível**, naquele turno, para recarregar parcialmente a mesma arma. Recupere **metade de X, arredondada para baixo**, sem ultrapassar o limite.
>
> A recarga exige munição e acontece depois do disparo. Ela satisfaz uma necessidade normal de recarga surgida nesse ataque, mas não permite disparar com uma arma que já precisava ser recarregada. A Ação de Movimento parcialmente usada não pode pagar o custo com os metros restantes.

> **Nível 11: `Reorientar a Pressão`.** **Uma vez por Sequência**, ao declarar uma Condução diferente com Arma de Fogo, própria ou comum, pode tentar manter uma Oportunidade **já obtida**.
>
> Se acertar, mantenha uma Oportunidade até o **fim do próximo turno**. Se errar, perca-a, mesmo usando Persistência. O uso é gasto na declaração. O efeito sustentado da Condução anterior termina normalmente.
>
> Supressão ainda não respondida, Queima-Roupa antes de receber a Oportunidade e a possibilidade de Tiro Controlado não são Oportunidades prontas.

> **Nível 19: `Romper o Contato`.** **Reação; consome uma Oportunidade.** Depois que o alvo da Sequência terminar de resolver contra você um ataque ou feitiço que prejudique você, pode mover-se até metade do deslocamento que sua ficha oferece nessa situação, já considerando as reduções. Use esse valor, e não os metros que sobraram de um movimento anterior.
>
> A retirada não provoca ataque de oportunidade daquele alvo. Ao terminar um movimento efetivo, pode recarregar a mesma Arma de Fogo, recuperando **um uso de Munição**, até o limite X. A reposição exige munição e capacidade de manusear a arma e integra a mesma Reação.
>
> Você pode se retirar com a arma cheia ou sem munição para repor, mas não pode ficar parado e usar a habilidade somente para recarregar. A reposição também resolve a necessidade normal de recarga por X ou pelo gatilho natural.
>
> A ofensiva que ativou a retirada já aconteceu. A Oportunidade é consumida e o preparo que poderia produzi-la novamente é encerrado. A Sequência mantém seus acertos e seu prazo.
>
> Supressão pode fornecer a Oportunidade pelo ataque recém-resolvido. Queima-Roupa não faz a Oportunidade chegar antes, e Tiro Controlado não permite comprá-la fora da Conclusão. Cada uso exige uma Reação e uma nova Oportunidade válida; não há limite adicional por cena.

> **Nível 27: `Plano de Continuidade`.** **Uma vez por cena**, depois de uma Ruptura em que consumiu Oportunidade, o alvo falhou no TR e você pagou Movimento para **recuperar ao menos um uso de Munição**, escolha um inimigo percebido, o mesmo ou outro.
>
> Até o fim do próximo turno, se o próximo Golpe Inicial de Arma de Fogo que abrir uma Sequência for contra ele, comece com **uma Oportunidade**, válida até o fim do turno seguinte ao da abertura.
>
> O novo Golpe Inicial mantém sua redução de dano e a Escola. A nova Sequência começa com **zero Conduções**. Sua primeira Condução com Arma de Fogo não apaga a Oportunidade apenas por estabelecer um preparo; as trocas posteriores seguem as regras normais.
>
> Abrir contra outro alvo ou com outra categoria abandona o plano. Um erro não concede a Oportunidade nem renova o prazo. O uso da cena é gasto ao preparar a continuidade.
>
> A recarga de Romper o Contato não ativa esta habilidade. Permanece proibido abrir outra Sequência no turno em que concluiu.

> **Exemplo.** Depois de Ruptura e recarga por Movimento, escolha outro inimigo. No turno seguinte, um Golpe Inicial acertado começa com Oportunidade; você pode usá-la na execução futura ou gastá-la numa retirada, mas ainda precisa cumprir o preparo da Conclusão.

### Trilha: Executor

*Você anuncia uma execução, recebe a resposta do adversário e decide se aquele ainda será o desfecho.*

**Habilidades do Executor**
| Nível | Habilidade |
|---|---|
| 2 | Finta de Execução e catálogo próprio |
| 11 | Troca de Intenção |
| 19 | Dobrar a Aposta |
| 27 | Duas Intenções |

> **Nível 2: `Finta de Execução`.** **Ação Bônus, uma vez por turno próprio.** Com um ataque corpo a corpo disponível contra o alvo da Sequência, sem ter Conduzido ou Concluído naquele turno, anuncie uma **Conclusão corpo a corpo com TR cujos requisitos já foram cumpridos**. O alvo precisa perceber você.
>
> A ameaça ainda não consome a Sequência. Nenhuma rolagem acontece durante essa decisão.

#### Resposta do adversário

> **Não Antecipar.** O alvo mantém seus recursos. Se você confirmar a ameaça, o TR adicional da Conclusão recebe **desvantagem**.
>
> **Antecipar.** O alvo gasta sua **Reação** para retirar a desvantagem da Finta daquela ameaça. Ele só pode fazer isso **uma vez em cada Sequência sua**, mesmo que recupere a Reação antes de ela terminar. A Reação não volta se você recuar ou errar.

#### Decisão do Executor

> **Confirmar.** Declare a Conclusão anunciada, consuma a Sequência e resolva o ataque.
>
> **Recuar da execução.** Declare uma Condução que você já possa usar, pague seu custo e resolva o ataque como Condução. Ela não recebe a desvantagem da Finta no TR, se houver. A Ação Bônus já foi gasta.

#### Conclusões do Executor

Todas usam um ataque corpo a corpo e exigem **acerto e falha no TR**. Podem ser usadas sem Finta, com seus testes normais.

> **Abalar a Ofensiva.** Sem Condução mínima; **TR de Vigor**. Na falha, o próximo ataque do alvo **com arma ou desarmado** tem desvantagem, até o fim do próximo turno dele.
>
> **Desguarnecer.** **Uma Condução acertada; TR Físico.** Na falha, **seu próximo ataque corpo a corpo contra o alvo** tem vantagem, até o fim do seu próximo turno.
>
> **Cortar o Gesto.** Sem Condução mínima; **TR de Vigor**. Na falha, a próxima **rolagem de ataque de um feitiço** do alvo tem desvantagem, até o fim do próximo turno dele.
>
> **Quebrar a Guarda.** **Uma Condução acertada; TR Físico.** Na falha, o próximo **Bloquear contra um ataque corpo a corpo seu** tem desvantagem, até o fim do seu próximo turno. Compare dois conjuntos completos de Bloquear e mantenha o menos favorável ao defensor.

Cada efeito vale para a primeira tentativa que cumpra essas condições, mesmo quando ela já tiver o mesmo modificador. Desguarnecer e Quebrar a Guarda não afetam o ataque que os aplicou.

Rasteira, Desarme e Quebrar o Ritmo permanecem disponíveis pelos requisitos comuns. Ponto Fraco não participa da Finta porque não exige TR.

> **Nível 11: `Troca de Intenção`.** Depois da resposta à Finta, pode escolher **outra Conclusão corpo a corpo com TR**, diferente e cujos requisitos já tenham sido cumpridos.
>
> A alternativa usa seu **TR normal, sem a desvantagem da Finta**. A Antecipação não pode ser redirecionada. Finalize a escolha antes dos dados.

> **Nível 19: `Dobrar a Aposta`.** **Uma vez por cena**, depois de o alvo Antecipar, pode insistir na mesma Conclusão e manter a **desvantagem da Finta no TR**.
>
> O adversário precisa já poder realizar um ataque corpo a corpo contra você, dentro do alcance e das demais condições do ataque. Se sua execução errar ou ele passar no TR, pode realizar **um ataque corpo a corpo contra você como parte da Reação já gasta**.
>
> O contra-ataque ainda precisa poder ser realizado; não leva feitiço, não cumpre etapa de Sequência nem desencadeia outros ataques. O uso por cena é gasto na declaração.
>
> **Dobrar a Aposta não combina com Conclusão Dupla.**

> **Nível 27: `Duas Intenções`.** **Uma vez por cena**, anuncie **duas Conclusões diferentes cujos requisitos já foram cumpridos** ao iniciar a Finta.
>
> Se o alvo Antecipar, escolhe uma para proteger. Depois, escolha **uma** para executar: a protegida tem TR normal, salvo Dobrar a Aposta; a não protegida mantém a desvantagem da Finta. Sem Antecipação, qualquer das duas escolhida recebe a desvantagem.
>
> Você ainda pode recuar para uma Condução ou usar Troca de Intenção para uma terceira alternativa com TR normal. O uso por cena é gasto no anúncio, mesmo se recuar.

#### Finta e Conclusão Dupla

A Finta modifica **apenas uma** das Conclusões da Dupla. A outra fica fixada e informada antes da resposta. Duas Intenções oferece alternativas para aquele único lugar; elas devem ser diferentes da segunda Conclusão fixa.

Recuar para Condução não gasta o uso de Dupla. Confirmar gasta o uso mesmo no erro ou na resistência. Todos os TRs são resolvidos antes dos novos efeitos, sem usar uma condição recém-aplicada para prejudicar outro teste do mesmo ataque.

## Guia

*Coordenador de Aberturas. Você percebe o momento que outra pessoa pode aproveitar. Às vezes, é a passagem para alcançar uma posição; em outras, a oportunidade de executar uma ação importante ou atravessar uma resposta inimiga. Você prepara o auxílio. O aliado decide quando usá-lo.*

### Características do Guia

**Características do Guia**
| | |
|---|---|
| **Vida por nível** | 5 |
| **PE por nível** | 5 |
| **Atributo natural** | Essência |
| **Perícias fixas** | `Persuasão` · `Medicina` |
| **Perícias à sua escolha** | 5, de qualquer uma da lista de perícias do sistema. Duas delas podem virar treino em **uma arma** da lista — não a categoria e não o tipo, uma arma |
| **Ofícios** | nenhum. Os dois vêm da sua Origem |
| **Teste de Resistência** | 1 treinado, à sua escolha. A sua Origem treina o outro |
| **Treino de arma** | **Arma de Fogo** e **Balestra**, as duas que não pedem treino de verdade |

*Perícia, ofício e Teste de Resistência entram na ficha uma vez, na criação. O quadro completo das vinte e três perícias e dos onze ofícios está no capítulo 3, __Perícias e Ofícios__.*

*O Caminho treina você nessa lista de armas; ele não te dá a arma. O que você leva na mão você compra na criação, e as tabelas de `Preços` estão no capítulo 15, __Equipamento__.*

> **Nenhuma rota dá ataque extra ao Guia.** Quem quiser lutar de Guia paga pela técnica, como todo mundo.

Escolha uma Trilha no nível 2: **Arquiteto, Analista ou Socorrista**. Você recebe suas habilidades nos níveis 2, 11, 19 e 27.

### Degraus do Guia

**Habilidades do Guia**
| Nível | Habilidade | O que muda |
|---|---|---|
| 2 | Abrir Caminho | Prepara uma oportunidade para um aliado. |
| 7 | Resposta Coordenada | Converte o uso da oportunidade numa resposta imediata da equipe. |
| 15 | Reajustar o Plano | Muda uma oportunidade que ainda não foi usada. |
| 23 | Passar a Oportunidade | Depois do primeiro uso, outro aliado recebe uma abertura diferente. |
| 30 | Todos no Mesmo Plano | Coordena uma cadeia de três aliados e duas respostas imediatas. |

> **Nível 2: `Abrir Caminho`.** **Ação Bônus, 1 PE, uma vez por turno seu.** Escolha um aliado voluntário que você perceba a até **18 m** e que consiga ver ou ouvir sua orientação.
>
> Prepare uma **Abertura de Avançar, Executar ou Resguardar**, indicando a posição, o alvo ou a situação a que ela se refere. O aliado guarda a oportunidade e decide quando aproveitá-la.
>
> A Abertura dura até o começo do seu próximo turno. Você mantém uma por vez; criar outra substitui a anterior. Uma criatura também só guarda uma Abertura de cada vez, mesmo que haja mais de um Guia.
>
> Você entrega suas Aberturas aos companheiros, não a si mesmo. A orientação pode ser uma fala, um gesto ou um sinal combinado que o aliado consiga perceber.

#### Avançar

Indique um espaço livre que o aliado possa alcançar com **até 3 m de movimento** e, se houver, uma ameaça que você perceba.

O aliado pode consumir a Abertura para se mover até **3 m em direção ao espaço indicado**. Esse trecho não provoca ataque de oportunidade da ameaça escolhida. O trajeto respeita terreno e impedimentos.

No turno dele, esse movimento não exige outra ação e pode acontecer antes ou depois de uma ação. Fora do turno, ele gasta sua **Reação**, depois que uma ação ou um deslocamento terminar de ser resolvido.

#### Executar

Indique **uma criatura ou objeto para atacar**, ou **uma tarefa com perícia identificada**.

Antes de uma tentativa correspondente, o aliado pode consumir a Abertura para fazer **uma rolagem de ataque ou de perícia com vantagem**. A escolha vale para aquela tentativa, acertando ou falhando.

#### Resguardar

Indique **uma ameaça percebida**, como um inimigo ou um perigo do ambiente.

Antes de realizar um **Teste de Resistência provocado por essa ameaça**, o aliado pode consumir a Abertura para fazê-lo com vantagem. Isso também pode ajudar a manter concentração quando o teste for provocado pela ameaça indicada.

#### Fora de combate

A orientação dura **um minuto para iniciar a tentativa combinada**. Se a iniciativa começar antes do uso, a Abertura expira no começo do primeiro turno do Guia. Preparar Executar ajuda a tentativa do aliado; não substitui a ação que ele precisa realizar.

> **Exemplo.** Você indica uma passagem para que um aliado alcance a cobertura. Ele pode avançar no próprio turno, preservando sua Reação, ou usá-la para se mover depois de uma ação inimiga, se a urgência justificar.

> **Nível 7: `Resposta Coordenada`.** **Reação, uma vez por rodada.** Depois que um aliado consumir sua Abertura, termine de resolver a ação, o movimento ou o efeito em que ela foi usada.
>
> Você pode então convidar esse aliado ou **outro aliado voluntário a até 18 m**, que você perceba e que consiga receber sua orientação, a responder imediatamente.
>
> Se ele aceitar, vocês dois gastam suas **Reações**. O aliado escolhe uma das respostas da tabela **Respostas coordenadas**.

**Respostas coordenadas**
| Resposta | O que ele realiza |
|---|---|
| Golpe | Um ataque com arma ou desarmado contra um alvo que ele possa atingir. |
| Feitiço breve | Um feitiço conhecido de **Classe 0** que normalmente use Ação Padrão, com as condições e os custos normais. |

A resposta acontece mesmo se a tentativa apoiada tiver falhado. O aliado escolhe seu alvo e como agir. Se ele já gastou sua Reação para Avançar, outra pessoa ainda pode aceitar o convite.

O golpe é um ataque comum, e não uma Ação Atacar ou etapa de Sequência. A resposta não desencadeia outra ação concedida. A conjuração de Classe 0 continua respeitando o limite geral de feitiços por turno.

Resposta Coordenada é usada em combate. O limite por rodada destas habilidades conta do início de um turno do Guia até o início do seguinte.

#### Leitura de Equipe

Escolha **duas perícias em que seja proficiente** entre Percepção, Intuição, Investigação, Medicina, Ocultismo e História. Uma vez por cena, ao usar **Estudar, Vasculhar ou Ler o Ambiente** com uma delas, faça o teste com vantagem.

> **Exemplo.** O Vanguarda aproveita Executar no ataque de uma Condução que ele já podia realizar. Depois de resolver esse ataque, você oferece ao Emanador uma resposta de Classe 0. Cada personagem usa a própria ficha; você abre o momento de colaboração.

> **Nível 15: `Reajustar o Plano`.** **Reação.** Enquanto sua Abertura estiver guardada, você pode mudar **quem recebe a ajuda, o tipo e o alvo, posição ou ameaça indicados**, respeitando as condições de Abrir Caminho.
>
> Faça a mudança entre acontecimentos ou depois que uma ação for declarada, **antes das rolagens relacionadas a ela**. A Abertura mantém o prazo original, sem novo gasto de PE.
>
> Isso permite transformar uma tentativa planejada em uma saída de emergência, ou entregar a oportunidade a quem realmente ficou em condições de aproveitá-la. Uma Abertura já consumida não pode ser recuperada por esse reajuste.

> **Exemplo.** Você preparou Executar para uma arqueira, mas um inimigo anuncia um feitiço contra outro aliado. Antes dos testes, gasta sua Reação para entregar a ele Resguardar contra aquele inimigo. Você abriu mão da Reação que poderia usar em Resposta Coordenada.

> **Nível 23: `Passar a Oportunidade`.** Depois que um aliado consumir sua Abertura e todas as respostas imediatas forem resolvidas, você pode entregar **uma segunda Abertura**, sem ação ou PE adicionais.
>
> Escolha **outro aliado voluntário a até 18 m**, que você perceba e que consiga receber sua orientação, e **um tipo diferente do já utilizado**. Indique o novo alvo, posição ou ameaça normalmente.
>
> Essa é a continuação da mesma oportunidade: mantém o prazo original e pode passar apenas uma vez. Há somente uma Abertura guardada por vez.
>
> Nas cadeias, cada aliado só aproveita uma Abertura e cada tipo só é utilizado uma vez. Reajustar o Plano pode mudar a parte ainda guardada, mas não repetir um aliado ou tipo já utilizado. Criar uma nova Abertura por Abrir Caminho encerra a cadeia anterior.
>
> Resposta Coordenada mantém seu limite de uma vez por rodada; passar a oportunidade não o renova.

> **Exemplo.** Um aliado usa Avançar para alcançar uma posição. Depois das respostas imediatas, você passa Executar para outro, que guarda a oportunidade para uma tentativa importante. Se o prazo acabar antes, a segunda abertura se perde.

> **Nível 30: `Todos no Mesmo Plano`.** **Uma vez por cena**, ao usar Abrir Caminho, declare um plano conjunto.
>
> Essa Abertura pode passar por **até três aliados diferentes**, utilizando **Avançar, Executar e Resguardar uma vez cada**, na ordem que você construir durante a cadeia. O prazo continua sendo o da Abertura inicial.
>
> Durante essa cadeia, você pode oferecer **Resposta Coordenada até duas vezes**, respeitando estas condições:
>
> - A primeira exige sua Reação normalmente; a segunda dispensa somente a sua Reação.
> - Os aliados continuam gastando as próprias Reações, e uma mesma criatura não pode realizar as duas respostas.
> - O limite total naquela rodada passa a ser duas respostas.
>
> Reajustar o Plano continua disponível quando você tiver Reação. Se gastá-la antes da primeira Resposta Coordenada, ainda precisará recuperá-la normalmente para começar as respostas do plano.
>
> O uso por cena é gasto quando você anuncia o plano, mesmo se a cadeia não for concluída.

> **Exemplo.** Uma aliada Avança e a equipe aproveita uma primeira resposta. A oportunidade passa para outro aliado Executar uma tentativa; você oferece a segunda resposta a uma pessoa diferente. Por fim, Resguardar fica com um terceiro aliado para atravessar a reação inimiga. Uma oportunidade circula; os participantes não recebem os três efeitos ao mesmo tempo.

#### Usando as Trilhas com as Aberturas

Os custos das Trilhas se somam aos de Abrir Caminho, exceto a criação de Obras de Apoio: o preço da construção já inclui a Abertura. Quando alguém usa a Abertura, termine de resolver a ação ou o efeito em andamento. Resolva então a ajuda da Trilha, a possível Resposta Coordenada e, por último, Passar a Oportunidade. Uma intervenção que diga para acontecer antes dos dados ou das consequências acontece naquele momento.

Cada habilidade mantém seu custo de ação ou Reação. As cadeias mantêm os limites de tipos, participantes, prazo e Respostas Coordenadas. Gastar uma Abertura de outra maneira também consome o tipo escolhido.

### Trilha: Arquiteto

*Você constrói passagens, apoios e abrigos. O grupo escolhe quando usá-los, e você decide o que manter, consertar ou levar para outro lugar.*

> **Nível 2: `Obras de Apoio`.** Escolha **Inteligência ou Essência** ao receber esta Trilha. Use sempre esse atributo nas contas de suas obras; para essas contas, valores menores que 1 contam como 1.
>
> Ao usar Abrir Caminho, você pode criar uma obra temporária num local livre que enxergue a até 9 m. Criar a obra e preparar a Abertura custa 2 PE ao todo, com a mesma Ação Bônus. A obra surge antes de você indicar a posição ou ameaça da Abertura.

**Obras de Apoio**
| Característica | Valor |
|---|---|
| Obras ao mesmo tempo | 2 + metade do atributo escolhido, arredondada para baixo. |
| Duração de cada obra | 10 minutos × atributo escolhido. |
| Vida de cada obra | 10 + seu nível + 5 × atributo escolhido. |
| Defesa | 10 + sua maestria. |
| Peso suportado pela Passarela ou pelo Patamar | 100 kg × atributo escolhido, contando tudo que estiver sobre a obra. |

Calcule vida, duração e peso ao criar a obra, usando o nível do personagem. Anote esses valores na ficha, junto do limite de obras, para não refazer as contas a cada uso.

#### Modelos de construção

**Modelos de construção**
| Obra | Tamanho e uso |
|---|---|
| **Mureta** | Até 1,5 m de largura e 1 m de altura. Dá Cobertura Parcial a quem estiver protegido por ela contra algo que venha do outro lado. |
| **Passarela** | Até 3 m de comprimento e 1,5 m de largura. Serve de ponte ou rampa entre dois apoios firmes, com diferença de altura de até 1,5 m. |
| **Patamar** | Plataforma de até 1,5 m por 1,5 m, com até 1,5 m de altura, degraus de acesso e apoio no chão. |

A construção precisa caber no local. Ela não pode surgir prendendo, empurrando ou levantando alguém. Qualquer criatura pode usar a obra ou tentar destruí-la.

A obra desaparece quando sua duração termina ou sua vida chega a zero. Ao atingir o limite de obras, para criar outra desfaça uma anterior que não esteja sustentando ou protegendo ninguém. Se o limite diminuir, escolha obras nessas condições para encerrar assim que possível; enquanto estiver acima do novo limite, não crie outras.

#### Aberturas junto das obras

Ao entregar uma Abertura, você pode ligá-la a uma obra sua. Para as habilidades seguintes, **usar a obra** significa atravessar a Passarela, estar sobre o Patamar ou aproveitar a cobertura da Mureta contra a ameaça indicada. Apenas ficar perto não basta.

A duração da obra não muda o prazo da Abertura.

> **Exemplo.** No nível 11, com Inteligência 4, você mantém até quatro obras. Cada uma tem 41 de vida e dura 40 minutos; uma Passarela ou um Patamar suporta 400 kg.

> **Nível 11: `Obra em Uso`.** **Uma vez por rodada**, depois que um aliado aproveitar sua Abertura usando a obra ligada a ela, escolha uma opção, sem outra ação:
>
> **Consertar.** Pague metade do custo de construir a versão atual da obra: 1 PE para Básica, 3 PE para Ampliada ou 5 PE para Grande. Ela recupera até 5 × o atributo escolhido de vida, sem ultrapassar a vida inicial. O conserto mantém o prazo da obra.
>
> **Mudar de lugar.** Uma obra que não esteja sustentando ou protegendo ninguém reaparece num local livre que você enxergue a até **9 m**. Você pode mudar seu modelo. Ela conserva a vida restante, o tamanho que já foi pago e o prazo.
>
> **Ampliar.** Pague para aumentar uma obra existente conforme a tabela **Obras maiores**. O espaço adicional precisa estar livre. A obra conserva a vida restante e o prazo.

#### Obras maiores

Ao criar uma obra ou escolher Ampliar, você pode pagar por uma das duas versões maiores. O custo da tabela **Obras maiores** é adicional aos **2 PE da obra básica**.

**Obras maiores**
| Obra | Básica | +4 PE — Ampliada | +8 PE — Grande |
|---|---|---|---|
| **Mureta** | 1,5 m de largura × 1 m de altura; Cobertura Parcial. | 3 m de largura × 1,5 m de altura; Boa Cobertura. | Parede de 4,5 m de largura × 3 m de altura; Cobertura Total quando esconder completamente a criatura. |
| **Passarela** | 3 m de comprimento × 1,5 m de largura; diferença de altura de até 1,5 m. | 6 m de comprimento × 1,5 m de largura; diferença de altura de até 3 m. | 9 m de comprimento × 3 m de largura; diferença de altura de até 4,5 m. |
| **Patamar** | 1,5 m × 1,5 m; altura de até 1,5 m. | 3 m × 3 m; altura de até 3 m. | 4,5 m × 4,5 m; altura de até 4,5 m. |

Para passar de Ampliada para Grande, pague apenas a diferença de **4 PE**. Mudar o modelo não devolve PE. A obra mantém os limites de vida e peso do nível 2, mesmo nas versões maiores.

A parede é sólida para os dois lados. A cobertura depende da posição de quem ataca e de quem se protege; sair de trás dela pode expor a criatura. Ela também pode bloquear a visão e os disparos dos aliados.

As obras maiores continuam sendo criadas a até **9 m** de você. Aumentar uma passagem não aumenta os 3 m concedidos por Avançar.

**Custos finais de criação:** Básica, 2 PE; Ampliada, 6 PE; Grande, 10 PE. Esses preços já incluem a Abertura. Usar Abrir Caminho sem criar uma obra continua custando 1 PE.

> **Nível 19: `Obra de Emergência`.** **Uma vez por cena, Reação e 2 PE.** Depois que uma obra sua for destruída ou que um aliado com sua Abertura terminar um movimento provocado por outra criatura, crie uma nova obra.
>
> Ela deve ficar a até **3 m da obra destruída ou da posição final do aliado**, e a até **9 m de você**. Cumpra as condições de construção e seu limite de obras.
>
> A nova obra começa com a vida completa e a duração de Obras de Apoio. Você pode criar uma versão maior pagando os **4 ou 8 PE adicionais**; o investimento da obra destruída não passa para a nova.
>
> Resolva primeiro o ataque, a queda ou o movimento que provocou a emergência. Se ainda houver uma Abertura ligada à obra anterior, pode ligá-la à nova, mantendo tipo, aliado, alvo ou ameaça indicados e prazo. Isso também permite salvar a Abertura deixada numa obra por Plano Construído.

> **Nível 27: `Plano Construído`.** **Uma vez por cena**, ao usar Abrir Caminho, você pode deixar a Abertura **em uma obra sua**, em vez de escolher imediatamente quem a recebe. Escolha o tipo e indique o alvo, posição ou ameaça normalmente.
>
> Um aliado voluntário que use essa obra pode assumir e gastar a Abertura no momento apropriado. Ele precisa estar a até **18 m de você**, ser percebido por você e conseguir ver ou ouvir sua orientação. As distâncias e condições da Abertura continuam valendo.
>
> Com Passar a Oportunidade, pode deixar a próxima Abertura em outra obra, escolhendo um tipo ainda não usado. Com Todos no Mesmo Plano, isso pode alcançar três participantes.
>
> Existe apenas uma Abertura disponível de cada vez, com o prazo inicial. Se a obra for destruída, a Abertura se perde, salvo Obra de Emergência.

### Trilha: Analista

*Você observa a resposta do inimigo. O aliado pode aproveitar a orientação agora ou esperar uma leitura confirmada para agir com mais segurança.*

> **Nível 2: `Ler a Resposta`.** Ao preparar uma Abertura ligada a um inimigo que perceba a até **18 m**, escolha o que espera vê-lo fazer: **atacar com arma ou desarmado, conjurar um feitiço, usar Bloquear ou mover-se por vontade própria**.
>
> A previsão acompanha a Abertura. Se você perceber essa ação enquanto o inimigo estiver a até 18 m, a leitura fica **confirmada depois que a ação terminar**.
>
> O aliado pode usar a Abertura normalmente antes disso. Depois da confirmação, recebe outra maneira de aproveitá-la, pela tabela **Leitura confirmada**.

**Leitura confirmada**
| Abertura | Escolha depois da confirmação |
|---|---|
| **Avançar** | Usar o movimento fora do próprio turno sem gastar Reação, depois que uma ação ou um deslocamento terminar. |
| **Executar** | Em vez de vantagem, guardar a Abertura para repetir um ataque ou teste de perícia que acabou de falhar, ligado à referência indicada. |
| **Resguardar** | Em vez de vantagem, guardar a Abertura para repetir um TR que acabou de falhar contra a ameaça indicada. |

Gaste a Abertura depois de saber que falhou e antes das consequências. Use o novo resultado e o mesmo procedimento da primeira tentativa, incluindo vantagem ou desvantagem que venha de outra fonte. A mesma rolagem só pode ser repetida uma vez por esta habilidade.

Cada parte repassada começa com uma nova previsão, salvo **Padrão Decifrado**. Reajustar o Plano mantém a leitura se continuar tratando do mesmo inimigo; trocar de inimigo exige outra previsão e perde a confirmação anterior.

A ação que confirmou a leitura já terminou. A confirmação ajuda apenas nas tentativas seguintes, dentro do prazo da Abertura.

> **Nível 11: `Apontar a Brecha`.** Uma Abertura de **Executar confirmada** também pode ajudar uma ação do aliado que obrigue o inimigo observado a fazer um TR.
>
> Se ele **passar no primeiro TR dessa ação contra ele**, antes de aplicar as consequências, você pode pagar **3 PE** e o aliado gastar a Abertura para que o inimigo repita aquele teste.
>
> Use o novo resultado e o mesmo procedimento do primeiro teste, com as vantagens e desvantagens que já existiam. Esta habilidade não repete um teste que já tenha sido repetido.
>
> Essa escolha substitui a vantagem ou a repetição de ataque ou perícia de Executar. Vale somente para o inimigo observado e para aquele primeiro TR. Os demais alvos ou testes da ação seguem normalmente.
>
> Se o inimigo falhar na primeira tentativa, não é necessário gastar PE ou Abertura nesta opção. Não é preciso usar Reação para Apontar a Brecha.

> **Exemplo.** Um aliado lança um feitiço contra o inimigo observado. O inimigo passa no primeiro TR. O aliado aceita gastar Executar, você paga 3 PE e o teste é repetido. Você apoiou a aplicação escolhida por ele, sem alterar o feitiço.

> **Nível 19: `Rever a Leitura`.** **Reação e 1 PE.** Enquanto a Abertura ainda estiver guardada, se o inimigo terminar uma das ações da lista de previsão diferente da que você escolheu, pode reconhecer essa resposta como a confirmação que faltava.
>
> A Abertura fica confirmada a partir desse momento. Ela mantém o tipo, o aliado, o alvo ou ameaça indicados e o prazo.
>
> Você precisa perceber o inimigo a até **18 m**. Os resultados da ação que acabou de acontecer permanecem; a nova leitura ajuda apenas nas tentativas seguintes.

> **Nível 27: `Padrão Decifrado`.** **Uma vez por cena**, quando uma leitura sua for confirmada, você pode guardar o padrão daquele inimigo **até o começo do seu terceiro turno seguinte**. Uma confirmação obtida por Rever a Leitura também serve.
>
> Durante esse prazo, as Aberturas que você preparar ou repassar contra esse mesmo inimigo **já chegam confirmadas**, desde que você o perceba a até **18 m** ao entregar a orientação.
>
> Isso vale para novas Aberturas em seus próximos turnos, não apenas para a cadeia atual. Cada uma mantém seu próprio prazo e os limites normais de participantes, tipos e Resposta Coordenada.
>
> Trocar o plano para outro inimigo exige uma previsão normal contra ele. O padrão guardado não muda de alvo nem tem seu prazo renovado por novas confirmações.

> **Exemplo.** Você confirma a leitura depois de ver o inimigo conjurar. Nos dois próximos turnos seus, pode preparar novas orientações contra ele já confirmadas, mesmo que ele ainda não tenha repetido aquela ação.

### Trilha: Socorrista

*Você prepara o cuidado junto da oportunidade de agir. O aliado pode seguir o plano ou abrir mão dele para receber ajuda antes.*

> **Nível 2: `Cuidado Preparado`.** Escolha **Inteligência ou Essência** ao receber esta Trilha. Use sempre esse atributo nas curas abaixo; para essas contas, valores menores que 1 contam como 1.
>
> Ao entregar uma Abertura a um aliado com **pelo menos 1 ponto de vida e menos da metade de sua vida máxima atual**, você pode pagar **2 PE adicionais** para incluir um **Cuidado**. Ao passar a oportunidade, pode pagar por outro Cuidado para o novo aliado, seguindo a mesma condição.
>
> Depois que o aliado usar a Abertura e terminar a ação ou o efeito correspondente, ele recupera **1d8 + o atributo escolhido de vida**, se ainda estiver nessa faixa de vida.
>
> A cura pode ultrapassar a metade, até a vida máxima. O limite de metade determina quem pode receber essa cura; não corta o resultado dos dados.
>
> O Cuidado acompanha a Abertura e seu prazo. Reajustar o Plano pode levá-lo a outro aliado que cumpra as condições para receber o atendimento. Se a nova pessoa não puder recebê-lo, a Abertura continua funcionando, mas perde o Cuidado. O custo pago não retorna.

#### Receber o socorro antes

O aliado pode desistir do efeito da Abertura e gastá-la **somente para receber o Cuidado**, desde que ainda cumpra as condições do atendimento escolhido.

No próprio turno, faça isso entre ações, sem outra ação. Fora do turno, ele gasta sua **Reação**, depois que uma ação ou efeito terminar.

A Abertura fica gasta, incluindo seu tipo para os limites da cadeia. Resposta Coordenada e Passar a Oportunidade podem acontecer normalmente depois do socorro, se seus custos puderem ser pagos.

Se o aliado sair da faixa de vida enquanto a Abertura estiver guardada, pode conservá-la até o prazo. Ao usá-la, confira novamente as condições do Cuidado; a Abertura continua funcionando mesmo quando não houver cura.

> **Exemplo.** Um aliado com 45 de vida, de um máximo atual de 100 pode receber o Cuidado. Se recuperar 10, fica com 55. Nesse estado, já não pode receber outra cura comum por esta habilidade.

> **Nível 11: `Tratar e Retomar`.** Ao receber um Cuidado, o aliado pode escolher retirar **uma condição Leve**, em vez de recuperar vida.
>
> O tratamento pode ser preparado e recebido por um aliado com pelo menos 1 de vida, **mesmo que não esteja abaixo da metade**, desde que ele tenha uma condição Leve que possa ser tratada. A exigência de estar ferido continua valendo para a opção de cura.
>
> A condição precisa vir de um inimigo ou perigo, e não de uma Restrição escolhida para pagar um feitiço ou habilidade. Trate um dos efeitos que impõem a condição; outra causa ainda presente pode aplicá-la novamente.

**Condições tratadas**
| Condição Leve | Como o tratamento a encerra |
|---|---|
| **Lento, Surdo ou Incapacitado** | Encerra o efeito escolhido que estava impondo a condição. |
| **Derrubado** | O aliado se levanta no próprio espaço, sem gastar movimento. |
| **Agarrado** | Encerra um agarrão que estava prendendo o aliado. |
| **Desarmado** | O aliado pode pegar uma arma ao alcance da mão ou sacar outra que carregue e consiga empunhar, como parte do atendimento. |

Em Desarmado, é necessário que exista uma arma disponível: o tratamento não recupera uma arma distante ou empunhada pelo inimigo.

A escolha também vale quando o aliado abandona a Abertura para receber o socorro antes. Cura e retirada de condição continuam sendo alternativas do mesmo Cuidado.

> **Nível 19: `Ainda Há Tempo`.** **Uma vez por cena, Reação e 2 PE adicionais.** Quando um aliado com um Cuidado seu ainda disponível for reduzido a **zero de vida**, você pode ativar imediatamente a cura de emergência.
>
> Você precisa perceber o aliado a até **18 m**. Ele deve continuar vivo e poder recuperar vida. A ajuda não exige que ele veja, ouça ou reaja.
>
> Consuma a Abertura e o Cuidado. Role **um d8 para cada dois pontos do atributo escolhido, arredondando para baixo, com mínimo de um dado**, e acrescente o atributo ao resultado.
>
> Essa é a cura completa da emergência, no lugar de 1d8 + atributo. Se a Abertura já tiver sido usada na tentativa em que ele caiu, ative apenas o Cuidado ainda não resolvido; não há um segundo consumo da Abertura.
>
> Resolva primeiro o dano e os efeitos do golpe. Neste uso, o aliado recupera vida em vez de retirar uma condição.

> **Exemplo.** Com Essência 6, a cura de emergência é **3d8 + 6**. É preciso que o Cuidado já estivesse preparado antes do golpe.

> **Nível 27: `Atendimento em Cadeia`.** **Uma vez por cena**, ao pagar os 2 PE de Cuidado Preparado em Abrir Caminho, você pode estender o atendimento à cadeia inteira.
>
> As Aberturas seguintes passadas por Passar a Oportunidade ou Todos no Mesmo Plano também recebem um Cuidado, **sem repetir o custo de 2 PE**, quando o novo aliado cumprir as condições para receber cura ou tratamento. Quem não precisa do Cuidado ainda pode receber a Abertura normalmente.
>
> Cada aliado recebe apenas um Cuidado dessa cadeia. Cada pessoa escolhe entre recuperar vida, usar Tratar e Retomar ou abandonar o efeito da Abertura para receber o socorro antes.
>
> Ainda Há Tempo mantém seu limite de uma vez por cena, a Reação e os 2 PE adicionais. O atendimento em cadeia não amplia esses usos.
>
> Cada Cuidado termina com a parte da Abertura que acompanha. Criar outra Abertura por Abrir Caminho encerra o atendimento anterior.

## Emanador

*Você conhece sua técnica como poucos. Seus feitiços são aplicações que podem ser adaptadas, praticadas e recombinadas. O Emanador pode lutar de perto ou de longe: o que o distingue é a liberdade para explorar o próprio Fundamento.*

### Características do Emanador

**Características do Emanador**
| | |
|---|---|
| **Vida por nível** | 4 |
| **PE por nível** | 6 |
| **Atributos naturais** | Inteligência · Essência |
| **Perícias fixas** | `Ocultismo` · `Investigação` |
| **Perícias à sua escolha** | 5, de qualquer uma da lista de perícias do sistema. Duas delas podem virar treino em **uma arma** da lista — não a categoria e não o tipo, uma arma |
| **Ofícios** | nenhum. Os dois vêm da sua Origem |
| **Teste de Resistência** | 1 treinado, à sua escolha. A sua Origem treina o outro |
| **Treino de arma** | **Arma de Fogo** e **Balestra**, as duas que não pedem treino de verdade. O Condutor Armado acrescenta a categoria escolhida |

*Perícia, ofício e Teste de Resistência entram na ficha uma vez, na criação. O quadro completo das vinte e três perícias e dos onze ofícios está no capítulo 3, __Perícias e Ofícios__.*

*O Caminho treina você nessa lista de armas; ele não te dá a arma. O que você leva na mão você compra na criação, e as tabelas de `Preços` estão no capítulo 15, __Equipamento__.*

Escolha uma Trilha no nível 2: **Condutor Armado, Ressonante ou Catalisador**. Suas entregas chegam nos níveis 2, 11, 19 e 27.

### Degraus do Emanador

**Habilidades do Emanador**
| Nível | Habilidade | O que você aprende |
|---|---|---|
| 2 | Desdobramento Técnico | Trocar uma propriedade ou acrescentar uma Modulação. |
| 7 | Expressões Familiares | Dominar variações e economizar em feitiços escolhidos. |
| 15 | Forma Fluida | Alterar a Forma da aplicação. |
| 23 | Composição Técnica | Combinar duas alterações. |
| 30 | Expressão Instintiva | Tornar aplicações escolhidas muito mais econômicas. |

#### Antes de usar o Caminho

As alterações são escolhidas antes dos alvos e das rolagens e valem para aquela conjuração. Use os preços da Classe usada na conjuração, com os descontos de suas Famílias Livres.

**Toda versão respeita a criação de feitiços:** Regra do Fundamento, Famílias, limites, requisitos, incompatibilidades e limite total de dados. Restrições e Efeito Próprio permanecem. Uma alteração não pode anular a obrigação que uma Restrição impõe. Por exemplo, Aceleração não contorna Atrasar e Ocultação não apaga a Restrição Gesto.

Desdobramento trabalha feitiços conhecidos de Classe 1 ou maior. Classe 0, Passivas, Liberações Máximas, Técnica Máxima e Expansão de Domínio seguem seus próprios procedimentos. Efeito Próprio e gatilhos de Reação precisam estar previamente registrados.

> **Nível 2: `Desdobramento Técnico`.** Ao conjurar um feitiço que possa receber Desdobramento, escolha **Remodelar** ou **Forçar uma Modulação**.

#### Remodelar

Pague PE adicional igual à **metade da Classe, arredondada para cima**, e troque uma Melhoria por outra que possa ser usada nesse feitiço.

Os pontos da Melhoria retirada pagam a nova. Se faltarem pontos, reduza o resultado da aplicação:

**Remodelar: o que retirar**
| Para pagar 1 ponto | Retire |
|---|---|
| De um feitiço de dano | 1d8 de dano. |
| De um feitiço de cura | 1d8 de cura. |
| De um feitiço de Apoio | 3 de vida temporária. |

Se sobrarem pontos da troca, a sobra é perdida. Recalcule o feitiço com as Restrições que ainda precisam ser cumpridas; a troca nunca aumenta o resultado original. Em feitiços com divisões ou repetições, ajuste primeiro os dados de base e depois suas distribuições.

> **Exemplo.** Trocar uma Melhoria de custo 2 por outra de custo 3 exige retirar 1d8 do dano ou da cura, além de pagar o PE de Remodelar.

#### Modulações Dominadas

Escolha **duas** opções da tabela **Modulações Dominadas**. Sempre que subir de nível, pode trocar uma Modulação conhecida por outra disponível e permitida por seu Fundamento.

**Modulações Dominadas**
| Modulação | Melhoria | Uso principal |
|---|---|---|
| Extensão | Longe | Aumentar o alcance. |
| Amplitude | Maior | Aumentar a área. |
| Divisão | Mais Um | Acrescentar um alvo, dividindo os dados. |
| Recorte | Escolher | Decidir quem é afetado dentro da área. |
| Trajetória | Contorno | Fazer a área contornar obstáculos. |
| Impulso | Passo | Mover-se junto da conjuração. |
| Ocultação | Silencioso | Conjurar sem os sinais dispensados pela Melhoria. |

#### Forçar uma Modulação

Acrescente uma Modulação Dominada ao feitiço e pague, em PE adicional, o **custo em pontos da Melhoria, depois dos descontos de suas Famílias Livres.** Você mantém as propriedades e os dados que o feitiço já tinha.

A Modulação pode exceder em **uma** o limite normal de Melhorias. Há, no máximo, uma Modulação Forçada por conjuração, incluindo as repetidas por Eco Amaldiçoado. Restrições não pagam esse custo adicional.

> **Exemplo.** Você pode trocar Fura por Longe com Remodelar ou manter Fura e pagar Extensão para acrescentar Longe. A primeira escolha troca uma função; a segunda gasta mais energia para manter ambas.

> **Nível 7: `Expressões Familiares`.** Escolha **dois feitiços conhecidos de Classe 1 ou maior**. Escreva para cada um uma versão alternativa feita por uma Remodelagem. Registre os efeitos, dados e custos já calculados.
>
> Ao conjurar, escolha a versão original ou sua **Expressão Familiar**. A Expressão não ocupa outro espaço de feitiço e dispensa o PE adicional de Remodelar. Você pode Forçar uma Modulação sobre qualquer versão.
>
> Aprenda sua **terceira Modulação Dominada**.

#### Afinidade Técnica

Escolha também **dois feitiços conhecidos**, de Classe 1 até **metade da sua maior Classe disponível, arredondada para baixo**.

A primeira conjuração de cada um por cena custa **metade do PE normal, arredondada para cima**. Quando o limite de Classe aumentar, pode substituir suas escolhas. Original e Expressão Familiar compartilham o mesmo uso reduzido.

**Afinidade Técnica por Classe**
| Maior Classe disponível | Pode escolher | Custo da primeira conjuração |
|---|---|---|
| 2–3 | Classe 1 | 2 PE. |
| 4–5 | Até Classe 2 | Classe 1: 2 PE; Classe 2: 3 PE. |
| 6–7 | Até Classe 3 | Classe 1: 2 PE; Classe 2: 3 PE; Classe 3: 5 PE. |

As escolhas de Afinidade e de Expressão Familiar podem ser os mesmos feitiços ou feitiços diferentes.

**Ampliar:** preserve o desconto da Classe original e pague a diferença completa da ampliação. Um Classe 2 com Afinidade custa 3 PE; Ampliado para Classe 4, custa 3 + 6 = **9 PE**. Os custos de Desdobramento são acrescentados depois.

> **Nível 15: `Forma Fluida`.** Ao Remodelar, você pode trocar a **Forma** em vez de uma Melhoria. Os pontos da Forma retirada ajudam a pagar a nova; a diferença segue a mesma regra de Remodelar.
>
> Recalcule o que depende da Forma, inclusive os pontos devolvidos pelas limitações que fazem parte dela. A nova versão deve continuar compatível com as Melhorias e Restrições preservadas.
>
> Suas Expressões Familiares podem usar uma Forma diferente. Ao receber esta habilidade, pode reescrever as duas.
>
> Aprenda sua **quarta Modulação Dominada**. A partir daqui, a lista também inclui as três da tabela **Modulações do nível 15**.

**Modulações do nível 15**
| Modulação | Melhoria | Uso principal |
|---|---|---|
| Aceleração | Rápido | Conjurar com Ação Bônus. |
| Preparação | Armado | Comprometer o feitiço com um gatilho futuro. |
| Sustentação | Concentrada | Prolongar estados mediante concentração. |

> **Nível 23: `Composição Técnica`.** Um Desdobramento pode fazer **até duas alterações**: trocar duas Melhorias, trocar Forma e Melhoria, ou Remodelar uma parte e Forçar uma Modulação.
>
> Pague o PE de Remodelar uma vez por conjuração. A Modulação Forçada mantém seu custo separado.
>
> Aprenda sua **quinta Modulação Dominada**.

> **Exemplo.** Transforme Explosão em Linha e troque Derrubado por Empurrão, pagando as diferenças. A técnica deixa de cercar uma posição e passa a trabalhar o corredor.

> **Nível 30: `Expressão Instintiva`.** Afinidade Técnica passa a incluir **quatro feitiços**. Você pode refazer as escolhas ao receber esta habilidade.
>
> Entre eles, escolha **um feitiço de Classe 1 e um de Classe 2**. Quando conjurar um desses dois com **Ação Padrão**, seu custo na Classe original é **1 PE**, em todas as conjurações.
>
> A Expressão Familiar correspondente recebe o mesmo benefício quando usada como Ação Padrão.
>
> Ao Ampliar, pague **1 PE + a diferença integral de custo entre as Classes**. Um Classe 2 Instintivo Ampliado para Classe 5 custa 1 + 9 = **10 PE**. Custos adicionais de Desdobramento continuam separados.
>
> Se a conjuração usar outra ação, aplique os custos normais e a Afinidade Técnica quando disponível. As duas reduções não se somam na mesma conjuração.

### Trilha: Condutor Armado

*Sua arma é uma maneira de expressar a técnica. Você alterna golpe e feitiço e escolhe como o vínculo entre os dois se manifesta.*

**Habilidades do Condutor Armado**
| Nível | Habilidade |
|---|---|
| 2 | Arma Condutora e Cadência Técnica |
| 11 | Artes do Vínculo |
| 19 | Manifestação Condutora |
| 27 | Ritmo Convergente |

> **Nível 2: `Arma Condutora`.** Escolha **uma categoria (Grupo das Armas)** e receba proficiência com suas armas. Escolha **Essência ou Inteligência**: você pode usar esse atributo nas rolagens de acerto e dano com a categoria, mantendo os requisitos de Força do equipamento.
>
> Ao fim de um descanso curto ou longo, escolha uma arma dessa categoria que esteja com você como sua **arma vinculada**. Um novo vínculo substitui o anterior.

#### Cadência Técnica

Uma vez por turno seu, combine suas ações de uma destas maneiras:

**Cadência Técnica**
| Ação Padrão | Ação Bônus |
|---|---|
| Atacar com uma arma da categoria. | Conjurar um feitiço de Classe 0. |
| Conjurar um feitiço de Classe 0. | Fazer um ataque com uma arma da categoria. |

O feitiço precisa normalmente usar Ação Padrão. Resolva uma parte antes de começar a outra.

> **Nível 11: `Artes do Vínculo`.** Escolha **uma Arte de Cadência** e **uma Propriedade de Vínculo**. No nível 19, aprenda uma segunda Propriedade diferente. Pode refazer suas escolhas ao receber os níveis 19 e 27 da Trilha, mantendo uma Arte e a quantidade de Propriedades do seu nível.

#### Artes de Cadência

> **Cadência Marcial.** Sua Ação Atacar permite **dois ataques** com armas da categoria. Se fizer os dois, não conjura pela Cadência Técnica naquele turno. Você pode optar pela cadência original de um ataque e um Classe 0.
>
> **Cadência Expandida.** A Cadência Técnica aceita feitiços de **Classe até metade da sua maior Classe disponível, arredondada para baixo**, nas duas ordens de execução. Pague os custos normais.
>
> O limite considera a Classe usada na conjuração, inclusive após Ampliar. Com maior Classe 3, o limite é 1; com 4 ou 5, é 2; com 6 ou 7, é 3.

#### Propriedades de Vínculo

Você conhece **uma Propriedade no nível 11 e duas a partir do nível 19**, escolhidas entre as oito abaixo. Elas acompanham sua arma vinculada; com Vínculo Duplo, acompanham ambas. Os limites de uso pertencem ao personagem, não a cada arma.

> **Chamado da Arma.** Você pode recolher a arma em sua técnica e manifestá-la ao sacá-la. Se estiver solta a até **18 m**, uma **Ação Bônus** a faz retornar à sua mão.
>
> **Forma Mutável.** Apenas uma arma comum ou de **Grau 4 ou 3** pode receber esta propriedade. Ao sacá-la ou manifestá-la, mude seu perfil para outra arma da mesma categoria cujo requisito de Força cumpra. A arma mantém Grau, Integridade, munição restante e efeitos próprios compatíveis. A transformação não recarrega nem repara o item.
>
> **Retorno Vinculado.** Sua arma corpo a corpo vinculada pode ser arremessada a até **6 m** e retorna à sua mão depois de resolver o ataque.
>
> **Passo da Arma.** **Uma vez por cena, Ação Bônus:** transporte-se para um espaço livre adjacente à arma vinculada, se ela estiver solta, você conseguir percebê-la e ela estiver a até **9 m**. Ela termina em sua mão.
>
> **Âncora Gravada.** Com uma **Ação Bônus**, fixe a arma numa superfície sólida ao alcance. Ela permanece presa até você liberá-la ou alguém gastar **Ação Padrão** e passar em um **TR Físico** contra a CD da técnica para removê-la. Pode sustentar uma corda ou travar um mecanismo conforme a resistência da arma e da superfície.
>
> **Vínculo Duplo.** Mantenha duas armas vinculadas da categoria. Pode sacar ou guardar fisicamente as duas no mesmo ato e usar qualquer uma nas habilidades da Trilha. Elas têm munição, Integridade e efeitos próprios separados.
>
> **Sentido do Vínculo.** Enquanto a arma estiver a até **1 km**, você sabe em que direção ela está e se está sendo empunhada. Essa percepção acompanha o objeto, sem revelar a identidade de quem o segura.
>
> **Memória da Arma.** Com uma **Ação Bônus, tocando a arma**, inicie o registro de até **uma hora dos sons e imagens que poderiam ser percebidos a partir da posição dela**, conforme a visibilidade e a audição no local. A gravação continua quando a arma é arremessada ou deixada em algum lugar. Ao tocá-la, você ou uma criatura autorizada pode rever e ouvir o registro. Cada arma mantém uma gravação até que outra a substitua.

> **Nível 19: `Manifestação Condutora`.** Aprenda **uma Propriedade de Vínculo adicional**, totalizando duas.
>
> Durante a Cadência Técnica, arma e feitiço podem transmitir um ao outro o ponto de manifestação.
>
> **Arma primeiro:** se o ataque com a arma vinculada acertar uma criatura ou objeto a até **9 m**, o feitiço seguinte pode partir de um ponto do espaço atingido. Meça alcance, área e direção a partir dele.
>
> **Feitiço primeiro:** escolha um ponto percebido que a aplicação alcançou a até **9 m**. O ataque da Cadência pode partir dali, com o alcance normal da arma. Depois do golpe, a arma retorna à sua mão.
>
> A nova origem precisa ser compatível com a Forma e com as Restrições da aplicação. Confira visão, trajeto e alcance na hora de cada parte.

> **Exemplo.** Depois de atingir o inimigo à frente de uma passagem, você faz um Cone partir daquele espaço em direção ao corredor. Se conjurar primeiro, pode levar o golpe até um ponto alcançado pelo feitiço.

> **Nível 27: `Ritmo Convergente`.** **Uma vez por cena**, use a Cadência Técnica com um feitiço de **Classe até sua maior Classe disponível menos um**, independentemente da Arte escolhida.
>
> Realize **um ataque e uma conjuração**, na ordem que preferir: uma parte usa Ação Padrão e a outra usa Ação Bônus. Pague o feitiço e seus Desdobramentos normalmente. Manifestação Condutora pode ligá-los.
>
> O limite vale para a Classe final da aplicação. Com acesso à Classe 7, esta cadência aceita até **Classe 6**. O uso da cena é gasto na declaração.
>
> **Afinidade e Instintiva:** a redução de primeira conjuração pode acompanhar a Cadência; o custo de 1 PE de Expressão Instintiva exige que o feitiço use a Ação Padrão.

### Trilha: Ressonante

*Uma aplicação deixa uma alteração preparada para a seguinte. Você escolhe o que manter, quando reaproveitar e quando mudar o rumo da técnica.*

**Habilidades do Ressonante**
| Nível | Habilidade | Ecos Amaldiçoados permitidos |
|---|---|---|
| 2 | Eco Técnico | Leves. |
| 11 | Contraponto | Leves. |
| 19 | Reverberação | Leves e Médios. |
| 27 | Acorde Ressonante | Dois Ecos Amaldiçoados; Leves e Médios. |

> **Nível 2: `Eco Técnico`.** Depois de resolver um feitiço de **Classe 1 ou maior com Desdobramento**, guarde como **Eco Amaldiçoado** uma alteração que você realmente fez: a Melhoria obtida por Remodelar ou a Modulação Forçada.
>
> O Eco Amaldiçoado registra a alteração e a maneira pela qual foi feita. Você mantém **um Eco Amaldiçoado até o fim do próximo turno**; criar outro substitui o anterior.
>
> Inicialmente, apenas alterações **Leves** podem virar Eco Amaldiçoado. A categoria é a do catálogo, **antes dos descontos de Família**.
>
> Em uma conjuração posterior de Classe 1 ou maior, consuma o Eco Amaldiçoado ao declarar o feitiço para reaproveitar sua alteração. Nesse nível, ele ocupa o Desdobramento da conjuração.

#### Eco de Remodelagem

Faça uma troca para obter a Melhoria guardada, pelas regras de Remodelar. A Melhoria retirada e a redução de resultado pagam os pontos necessários. **Você dispensa apenas o PE adicional de Remodelar.**

Depois de receber Forma Fluida, também pode guardar e repetir uma troca de Forma permitida. Formas sem custo podem ser guardadas; as demais seguem o limite de categoria do Eco Amaldiçoado.

#### Eco de Modulação

Repita a Modulação guardada pagando **metade de seu custo adicional em PE, arredondada para cima**. Use o preço na Classe da nova conjuração.

Uma alteração reaproveitada não cria outro Eco Amaldiçoado por si só. O consumo ocorre na declaração, mesmo se o feitiço errar ou for resistido.

#### Limites da aplicação

O resultado continua respeitando **todas as regras de criação de feitiços**, inclusive Restrições, Famílias, orçamento, repetições e incompatibilidades. Uma troca obtida por Eco Amaldiçoado não ganha pontos extras nem espaço adicional de Melhoria.

Há, no máximo, **uma Modulação Forçada por conjuração**, contando o Eco Amaldiçoado e o Desdobramento normal. Só ela pode exceder o limite normal de Melhorias em uma unidade.

> **Exemplo.** Numa Classe 3, Longe sem desconto custa 2 PE como Modulação. Seu Eco Amaldiçoado permite repeti-la em outro feitiço Classe 3 por 1 PE. Se a Modulação já custava 1 PE, o Eco Amaldiçoado continua custando 1 PE.

> **Nível 11: `Contraponto`.** Ao consumir um Eco Amaldiçoado, você também pode fazer **um Desdobramento normal** na mesma conjuração, pagando o custo normal.
>
> Depois da resolução, uma alteração feita por esse Desdobramento pode ser guardada como o próximo Eco Amaldiçoado. O efeito trazido pelo Eco Amaldiçoado antigo não se copia novamente.
>
> Com Composição Técnica, o Desdobramento normal pode trazer duas alterações, para um máximo de **três alterações ao todo**. Isso não aumenta o limite de Melhorias do feitiço.
>
> O novo Eco Amaldiçoado continua limitado a alterações **Leves**. Uma Melhoria Média ou Pesada feita pelo Desdobramento normal não pode ser armazenada nesse nível.

> **Exemplo.** Repita uma troca que trouxe Longe e pague uma Remodelagem nova para obter Empurrão. Você aproveita a distância que preparou e deixa Empurrão como possibilidade para a próxima aplicação.

> **Nível 19: `Reverberação`.** Seus Ecos Amaldiçoados passam a aceitar alterações **Médias**, além das Leves.
>
> Quando gastar Eco Amaldiçoado numa conjuração, escolha uma criatura antes das rolagens. Se o ataque contra ela errar ou ela passar no primeiro TR da aplicação, você pode gastar sua **Reação** para manter o Eco Amaldiçoado até o fim do próximo turno.
>
> Se o Contraponto também produziu outro Eco Amaldiçoado, escolha qual guardar, respeitando sua capacidade. Reutilizar o Eco Amaldiçoado em outra conjuração continua cobrando seu custo normal de uso.
>
> Melhorias **Pesadas permanecem fora dos Ecos Amaldiçoados**, mesmo com desconto. Podem participar normalmente do Desdobramento pago, quando cumprirem as regras do feitiço.

> **Nível 27: `Acorde Ressonante`.** Você pode manter **dois Ecos Amaldiçoados diferentes**, e cada um passa a durar até o fim do **segundo turno seguinte** à sua criação ou conservação. Ao criar outro além da capacidade, escolha qual substituir.
>
> **Uma vez por cena**, consuma os dois na mesma conjuração. Você também pode fazer um Desdobramento normal, respeitando o máximo de **três alterações no total** e uma Modulação Forçada.
>
> Cada Eco Amaldiçoado mantém seus custos. Reverberação pode preservar apenas **um** dos Ecos Amaldiçoados gastos naquela conjuração.

> **Exemplo.** Num turno você registra uma troca para Longe. No seguinte, registra outra para Contorno. No terceiro, pode usar os dois Ecos Amaldiçoados em trocas compatíveis e pagar uma alteração nova, escolhendo qual delas preparará a próxima conjuração.

### Trilha: Catalisador

*Você alterna preparação e descarga. Uma aplicação reúne o impulso que a seguinte pode gastar em velocidade, precisão ou controle da execução.*

**Habilidades do Catalisador**
| Nível | Habilidade |
|---|---|
| 2 | Impulso Técnico |
| 11 | Correção de Fluxo |
| 19 | Sobre Carregar Energia |
| 27 | Fluxo Contínuo |

> **Nível 2: `Impulso Técnico`.** Depois de resolver, com **Ação Padrão**, um feitiço de **Classe 1 ou maior** que tenha sido Remodelado, recebido uma Modulação ou usado uma Expressão Familiar, você ganha **um Impulso Energético até o fim do próximo turno**.
>
> Você mantém um Impulso Energético. Em outra aplicação dessas, pode gastá-lo e pagar PE adicional igual à **metade da Classe utilizada, arredondada para cima**, escolhendo uma opção:
>
> **Acelerar.** Um feitiço de Ação Padrão passa a usar **Ação Bônus**. A mudança precisa respeitar o tempo exigido pelas Restrições e as incompatibilidades de Rápido.
>
> **Intensificar.** Escolha **um ataque do feitiço**, que recebe vantagem, ou **o primeiro TR de uma criatura contra ele**, que recebe desvantagem.
>
> Declare a escolha antes dos dados. A conjuração que gasta Impulso Energético não produz outro por si só. Conjurar como Ação Bônus mantém a regra geral: o outro feitiço permitido naquele turno é de Classe 0.

> **Nível 11: `Correção de Fluxo`.** Você ganha uma opção de correção e uma nova maneira de Intensificar.
>
> **Corrigir a tentativa.** Se um ataque de sua aplicação errar ou uma criatura passar no primeiro TR contra ela, pode gastar seu Impulso Energético e **PE adicional igual à Classe utilizada** para repetir aquela rolagem. Use o novo resultado.
>
> Indique antes dos dados qual ataque ou criatura você pretende acompanhar. A decisão de pagar acontece depois da rolagem, antes de aplicar suas consequências. Se a tentativa tinha vantagem ou desvantagem, repita o mesmo procedimento.
>
> **Aperfeiçoar o dano.** Ao escolher Intensificar, pode beneficiar **uma rolagem de dano do feitiço**, em vez de um ataque ou TR.
>
> Nessa rolagem, repita **uma vez cada dado que mostrar 1 ou 2**, mantendo os novos resultados. Declare essa aplicação de Intensificar junto da conjuração, antes das rolagens; ela usa o custo normal de metade da Classe em PE e consome Impulso Energético.
>
> Se uma única rolagem for compartilhada entre alvos, todos usam o resultado corrigido. Feitiços com várias rolagens escolhem apenas uma delas.

> **Nível 19: `Sobre Carregar Energia`.** **Uma vez por cena**, ao gastar Impulso Energético, escolha duas opções diferentes entre **Acelerar, Intensificar e Corrigir a tentativa**.
>
> Pague cada custo separadamente. Se reservar Corrigir junto da outra opção, pague a parcela da correção somente se a rerrolagem acontecer. Declare a combinação antes da primeira rolagem.
>
> Intensificar oferece uma escolha entre ataque, TR ou dano. Sobre Carregar Energia não permite escolher Intensificar duas vezes.
>
> Depois do Sobre Carregar Energia, você não ganha outro Impulso Energético até o fim do próximo turno.

> **Exemplo.** Acelerar e Aperfeiçoar o dano permitem uma conjuração de Ação Bônus com repetição dos dados baixos. Intensificar um ataque e reservar Correção permite insistir se ele ainda errar.

> **Nível 27: `Fluxo Contínuo`.** **Uma vez por cena**, depois de gastar Impulso Energético numa conjuração que não usou Sobre Carregar Energia, recupere **um Impulso Energético** após resolver o feitiço. Ele dura até o fim do próximo turno.
>
> Você pode usá-lo numa aplicação seguinte, inclusive num Sobre Carregar Energia. Os custos de cada opção continuam sendo pagos.

> **Exemplo.** Conjure uma Expressão Familiar para reunir Impulso Energético. No turno seguinte, gaste-o e use Fluxo Contínuo para manter o ritmo. Na aplicação posterior, escolha entre outra descarga normal ou a combinação de Sobre Carregar Energia.

## Evocador

*Você conhece o potencial de suas invocações e sabe como fazê-lo aparecer. Escolhe qual delas aprimorar e emprega o vínculo para corrigir falhas, mudar sua atuação e conservar uma resposta para o momento certo.*

### Características do Evocador

**Características do Evocador**
| | |
|---|---|
| **Vida inicial** | 6 (d6), antes da Constituição |
| **Vida por nível** | 4 |
| **PE por nível** | 6 |
| **Atributos naturais** | Inteligência · Essência |
| **Perícias fixas** | `Religião` · `Lidar com Animais` |
| **Perícias à sua escolha** | 5, de qualquer uma da lista de perícias do sistema. Você pode trocar duas dessas escolhas por treino em uma arma específica. |
| **Ofícios** | nenhum. Os dois vêm da sua Origem |
| **Teste de Resistência** | 1 treinado, à sua escolha. A sua Origem treina o outro |
| **Treino de arma** | Arma de Fogo e Balestra |

*O Caminho treina você nessa lista de armas; ele não te dá a arma. O que você leva na mão você compra na criação, e as tabelas de `Preços` estão no capítulo 15, __Equipamento__.*

**Vida máxima:** `(6 + Constituição) + (4 + Constituição) × (nível − 1)`.

Escolha uma Trilha no nível 2. Suas entregas chegam nos níveis **2, 11, 19 e 27**. Nos níveis 11, 19 e 27, a troca de Trilha é integral: você substitui as entregas da anterior pelas da nova. Cada personagem possui um Caminho e uma Trilha.

### Progressão do Caminho

| Nível | Habilidade |
|---|---|
| 2 | Aprimoramentos e Pontos de Vínculo. |
| 7 | Atuação Complementar. |
| 15 | Combinar Aprimoramentos. |
| 23 | Intervenção Eficiente. |
| 30 | Especial Combinada. |

### Antes de jogar

**Aprimoramento de Vínculo** é o benefício que você mantém em uma invocação. **Intervenção de Vínculo** é um efeito pontual do catálogo. **Pontos de Vínculo** são a reserva usada para pagar essas intervenções.

**Conjunto** significa você e suas invocações. A **Reação coletiva** pertence às invocações; a **Reação pessoal** pertence a você.

**Usos por rodada:** renovam no começo do seu turno. Até o começo do próximo, conserve os usos marcados, inclusive durante os turnos das outras criaturas.

Cada invocação usa sua ficha e cumpre sua intenção. Entrada, substituição, primeira intenção, redirecionamento, preparo, comando especial e retorno seguem o capítulo 17, *Invocações*. O Caminho altera esses procedimentos somente nos casos escritos nas suas habilidades.

### Nível 2 — Aprimoramentos e Pontos de Vínculo

#### Pontos de Vínculo

Você começa o combate com **0 Pontos de Vínculo**. No começo de cada turno seu, enquanto consciente, recebe **1 ponto**, até o máximo de **3**.

Conserve os pontos não gastos até usá-los ou o combate terminar. A reserva pertence ao conjunto.

#### Escolher o aprimoramento

No começo do seu turno, depois das resoluções obrigatórias de início de turno, escolha **uma invocação sua ativa que perceba a até 18 m** e um aprimoramento conhecido. A escolha é gratuita.

Você mantém um aprimoramento em uma invocação por vez. Na próxima janela, pode conservar a escolha ou mudar a beneficiária, o benefício ou ambos.

**Duração:** até ser substituído, a beneficiária sair do campo ou ficar inativa, ou o combate terminar. Confira alcance e percepção ao escolher ou modificar o aprimoramento.

#### Usos compartilhados dos aprimoramentos

Os usos pertencem ao conjunto. Registre cada benefício quando ele for aproveitado.

**Uso ofensivo.** Precisão à Distância, Avanço Corpo a Corpo e Dificultar a Resistência compartilham **um uso ofensivo por rodada**: vantagem em um ataque elegível ou desvantagem no primeiro TR de um alvo contra uma especial comandada. A tentativa favorecida consome esse uso.

**Proteção e perícia.** Proteção Reforçada tem um uso por rodada. A vantagem em perícia de Execução de Tarefas também tem um uso por rodada.

**Movimento.** Cada benefício fica vinculado à primeira invocação que o aproveitar na rodada, enquanto ela mantiver o aprimoramento correspondente. Precisão oferece um saldo extra de 3 m; Avanço protege um trajeto; Execução de Tarefas beneficia o deslocamento inteiro da destinatária no seu turno.

**Mudanças.** Mudar o aprimoramento ou a beneficiária conserva os usos marcados e os metros gastos. Benefícios diferentes podem ser usados na mesma rodada. A repetição da mesma tentativa por Corrigir uma Falha conserva a vantagem original.

#### Catálogo de aprimoramentos

Você conhece os quatro aprimoramentos de nível 2. No nível 7, acrescenta Dificultar a Resistência.

##### Precisão à Distância — nível 2

**Ataque preciso.** No seu turno, o primeiro ataque à distância de uma básica ou especial normal da invocação recebe **vantagem**, usando o benefício ofensivo da rodada.

**Posicionamento.** Ela pode percorrer **até 3 m extras** no seu turno, usando uma modalidade de movimento que possua. Esse trecho tem saldo próprio, respeita terreno e impedimentos e fica disponível enquanto ela mantiver o aprimoramento. Correr usa o deslocamento normal da ficha, separado desse saldo.

##### Avanço Corpo a Corpo — nível 2

**Ataque preciso.** No seu turno, o primeiro ataque corpo a corpo de uma básica ou especial normal da invocação recebe **vantagem**, usando o benefício ofensivo da rodada.

**Mudar de confronto.** Uma vez por rodada, ao deixar o alcance corpo a corpo de um inimigo, ela pode declarar outro inimigo percebido e um trajeto que termine numa posição de onde consiga atacá-lo corpo a corpo. Sua intenção deve permitir o trajeto, e o Movimento restante precisa bastar para concluí-lo.

Durante o trajeto, ela fica protegida dos ataques de oportunidade das criaturas que está deixando para trás. O novo adversário conserva seus gatilhos normais. Uma interrupção externa encerra a travessia onde ocorrer.

##### Proteção Reforçada — nível 2

Uma vez por rodada, antes dos dados, escolha uma proteção para a invocação:

**Contra um ataque:** imponha desvantagem à rolagem de acerto contra ela.

**Contra um efeito:** faça um Teste de Resistência próprio com vantagem.

As opções compartilham o mesmo uso. A proteção integra aquela tentativa, sem Reação adicional.

##### Execução de Tarefas — nível 2

No seu turno, a invocação recebe **vantagem no primeiro teste de perícia** feito como parte de uma básica que não cause dano.

Durante esse turno, **todo o seu deslocamento ignora o custo adicional de terreno difícil**.

##### Dificultar a Resistência — nível 7

Quando a invocação executar uma especial ativa comandada no seu turno, escolha uma criatura afetada antes das rolagens.

O **primeiro Teste de Resistência desse alvo contra a especial recebe desvantagem**, usando o benefício ofensivo da rodada.

#### Catálogo de Intervenções de Vínculo

Você aprende cada intervenção quando alcança o nível indicado.

**Requisitos comuns:** você está consciente e percebe a destinatária ativa a até **18 m**. Ela pode ser qualquer invocação sua que cumpra os requisitos da intervenção.

Cada intervenção tem **um uso por rodada para o conjunto inteiro**. Intervenções diferentes podem ser combinadas. Elas integram a janela indicada, pagando os custos escritos; as que exigem Reação coletiva indicam isso no custo.

Orientações de movimento, preparo e recolhimento precisam ser percebidas e compreendidas pela invocação. A capacidade original conserva seus custos, seus requisitos e suas durações.

##### Corrigir uma Falha — nível 2

**1 Ponto de Vínculo · Qualquer turno.**

Logo depois que uma invocação falhar num ataque de básica ou especial normal, teste de perícia ou Teste de Resistência, e antes das consequências, repita a rolagem inteira e use obrigatoriamente o novo resultado.

Mantenha os modificadores, a vantagem ou desvantagem, o alvo e a dificuldade da tentativa. Com dois d20, repita os dois. A tentativa admite uma única repetição, considerando todas as fontes.

O preço de **1 ponto** também vale para um ataque de especial.

##### Mudar o Aprimoramento — nível 2

**2 Pontos de Vínculo · Qualquer turno.**

Enquanto mantiver um aprimoramento, use esta intervenção entre resoluções ou depois que uma ação for declarada, antes de sua resolução e dos dados.

Escolha uma invocação sua ativa que perceba a até 18 m e um aprimoramento conhecido. Você pode mudar **a beneficiária, o benefício ou ambos**. A escolha anterior termina, e a nova segue a duração comum.

Conserve os usos já marcados no conjunto.

##### Superar Cobertura — nível 2

**1 Ponto de Vínculo · Seu turno.**

Depois de escolher o alvo e antes dos dados de um ataque à distância de básica ou especial normal da invocação, desconsidere o benefício da **Cobertura Parcial** naquele ataque.

##### Reposicionar a Invocação — nível 2

**1 Ponto de Vínculo e a Reação coletiva · Turno de outra criatura.**

Logo depois que um inimigo percebido por você e pela invocação terminar um deslocamento voluntário, ela pode se mover **até metade de seu deslocamento**, gastando o Movimento que ainda possui.

Use o deslocamento da modalidade escolhida, com seus modificadores atuais. Durante o trecho, ela fica protegida dos ataques de oportunidade daquele inimigo.

Ela precisa poder reagir e cumprir sua intenção pelo trajeto. Gastar a coletiva encerra as preparações que dependiam dessa reserva, pelo procedimento de Preparar.

*Exemplo: com deslocamento de 9 m e 6 m de Movimento restantes, ela pode percorrer até 4,5 m em terreno comum. Se restarem somente 3 m, esse é o limite disponível.*

##### Ajustar a Preparação — nível 7

**1 Ponto de Vínculo · Turno de outra criatura.**

Entre resoluções, escolha uma invocação que mantenha uma especial preparada válida e mude **o alvo ou o gatilho** dessa preparação.

Conserve a destinatária, a especial, o prazo e os recursos investidos. O novo gatilho corresponde a uma ocorrência futura. A execução segue os custos normais do preparo.

##### Recolher sob Ataque — nível 7

**2 Pontos de Vínculo e a Reação coletiva · Turno de outra criatura.**

Depois de resolver inteiramente um ataque que atingiu sua invocação, com dano e consequências, recolha-a antes do próximo ataque separado.

Ela precisa estar ativa, acima de zero de vida, apta a usar a coletiva e pertencer a um tipo que você possa recolher normalmente.

Resolva a saída, os estados da entidade, os compromissos encerrados e sua eventual volta pelos procedimentos de recolhimento e entrada. O aprimoramento termina com a saída.

### Nível 7 — Atuação Complementar

**Ação Bônus · Uma vez por rodada, no seu turno · Alcance de 18 m.**

Gaste sua Ação Bônus para que a invocação beneficiada por seu aprimoramento **principal** realize imediatamente uma ação da tabela.

Você precisa estar consciente e percebê-la. A invocação deve estar ativa, sem Atordoado, compreender sua orientação e cumprir os requisitos da ação e de sua intenção.

| Aprimoramento principal | Escolha uma ação complementar |
|---|---|
| Precisão à Distância | Correr, Esconder ou Desengajar. |
| Avanço Corpo a Corpo | Correr ou Desengajar. |
| Proteção Reforçada | Esquivar. |
| Execução de Tarefas | Ajudar, Vasculhar, Estudar ou Usar objeto numa tarefa sem dano. |
| Dificultar a Resistência | Desengajar ou Estudar. |

Resolva essa ação antes ou depois da atuação básica da invocação, que continua disponível para seu uso normal. Os efeitos e custos próprios seguem a ação comum.

Para receber os benefícios dos aprimoramentos, essa execução conta como uma básica. Registre o uso da habilidade no conjunto, separado das básicas individuais.

**Principal e adicional.** A tabela é determinada somente pelo aprimoramento principal. O adicional de Combinar Aprimoramentos concede seus efeitos próprios. Mudanças de beneficiária ou principal conservam o uso já marcado de Atuação Complementar.

### Nível 15 — Combinar Aprimoramentos

**4 PE · Na janela de escolha ou mudança · Adicional até o começo do seu próximo turno.**

Ao escolher o aprimoramento no começo do seu turno ou ao usar **Mudar o Aprimoramento**, você pode pagar **4 PE** para escolher dois aprimoramentos diferentes para a mesma invocação sua ativa que perceba a até **18 m**.

Indique um como **principal** e outro como **adicional**. A invocação recebe ambos. O principal segue a duração comum; o adicional termina no começo do seu próximo turno. Para manter uma combinação na rodada seguinte, pague novamente.

Enquanto a combinação durar, Mudar o Aprimoramento permite alterar a beneficiária, os dois aprimoramentos ou ambos, pelo custo normal de **2 Pontos de Vínculo**. Indique novamente o principal e conserve o prazo já pago.

Os 4 PE são pagos para iniciar ou renovar a combinação. Reorganizar uma combinação ainda ativa conserva esse pagamento. Os usos dos benefícios permanecem compartilhados pelo conjunto.

### Nível 23 — Intervenção Eficiente

Ao receber a habilidade, escolha **Essência ou Inteligência**. Você tem usos iguais à **metade do atributo escolhido, arredondada para baixo, com mínimo de 1**. Recupere todos os usos ao concluir um descanso longo.

Quando usar uma Intervenção de Vínculo, pode gastar um uso para reduzir seu custo em **1 Ponto de Vínculo, até o mínimo de zero**. Declare o desconto no momento da intervenção, sem ação adicional.

Cada utilização de uma intervenção pode receber um desconto. Ela conserva seus requisitos, demais custos e limite de uso.

| Atributo escolhido | Usos por descanso longo |
|---|---:|
| 0 a 3 | 1 |
| 4 ou 5 | 2 |
| 6 | 3 |

### Nível 30 — Especial Combinada

**Ação Completa · Uma vez por combate · Participantes a até 18 m.**

Escolha a invocação beneficiada por seu aprimoramento principal e uma destas combinações:

| Forma | Execuções |
|---|---|
| Uma invocação | A beneficiária executa duas especiais normais diferentes que conhece. |
| Duas invocações | A beneficiária e outra invocação sua executam uma especial normal cada. |

Todas as participantes precisam estar ativas, ser percebidas por você a até 18 m, compreender o comando e estar com **todas as suas básicas da rodada disponíveis**.

**Declare a combinação.** Escolha as participantes, as especiais e sua ordem. Use especiais imediatas que, separadamente, seriam comandadas com sua Padrão e a básica da entidade.

**Pague as ações.** Ao começar a primeira especial, gaste sua **Padrão, Bônus, Movimento e todas as básicas das participantes**. Suas três ações precisam estar disponíveis. Marque o uso da habilidade no combate.

**Resolva em sequência.** Pague os PE da primeira especial e resolva-a completamente. Depois das respostas que ela provocar, a segunda começa imediatamente: escolha seus alvos, confira seus requisitos e pague os PE e demais custos dela. Cada capacidade conserva seu alcance e suas propriedades.

Se uma consequência impedir a segunda execução, a combinação termina com os recursos já gastos. A Reação pessoal, a Reação coletiva e o Movimento das invocações seguem seus usos normais.

Esta habilidade permite as duas especiais no mesmo turno, inclusive quando ambas têm Classe positiva. Elas ocupam suas conjurações daquele turno. Conserve os usos compartilhados dos aprimoramentos e intervenções. A orientação posterior de cada especial segue o procedimento de sua destinatária.

### Exemplos de turno

#### Favorecer a ave e depois o lobo

Você começa com a ave aprimorada por Precisão à Distância. Ela ataca com vantagem, e você marca o uso ofensivo. Depois, paga Mudar o Aprimoramento para entregar Proteção Reforçada ao lobo. O benefício defensivo ainda pode ser usado naquela rodada.

#### Combinar sem ampliar a ação auxiliar

Você escolhe Precisão à Distância como principal e paga 4 PE para acrescentar Proteção Reforçada. A ave recebe ambos. Atuação Complementar continua consultando Precisão; para escolher Esquivar pela habilidade, Proteção precisa ser o principal.

#### Intervir sem pontos guardados

Sua invocação erra uma especial, e sua reserva de Pontos de Vínculo está vazia. Gaste um uso de Intervenção Eficiente para usar Corrigir uma Falha por zero. A repetição segue o procedimento normal.

#### Dedicar o turno à combinação

Você posiciona suas invocações usando os Movimentos próprios delas e conserva suas ações. Usa a Ação Completa para combinar duas especiais, pagando também todas as básicas participantes. Os PE são cobrados quando cada execução começa.

### Trilha: Invocação Principal

*Você concentra o potencial das invocações em uma criatura de cada vez. Ela assume mais atuações, desenvolve um repertório amplo e recebe intervenções próprias para permanecer útil na luta.*

#### Progressão da Trilha

| Nível | Habilidade |
|---|---|
| 2 | Duas Atuações Básicas e Repertório Ampliado. |
| 11 | Intervenções da Invocação Principal. |
| 19 | Especial de Continuidade. |
| 27 | Intervenção Reflexa. |

#### Quando a Trilha funciona

Os benefícios se aplicam enquanto você mantém **exatamente uma invocação ativa**. Outras invocações podem permanecer no seu repertório.

Registre na ficha de cada possível principal os acréscimos da Trilha. Quando uma capacidade tiver versão comum e versão ampliada, anote ambas e use a correspondente à situação em campo. Efeitos já resolvidos seguem suas próprias durações.

Na abertura de cada turno seu, a única invocação ativa recebe sua básica comum e a atuação adicional da Trilha, desde que possa atuar. Os usos por rodada renovam no começo do seu turno e ficam registrados no conjunto.

**Invocação principal** é sua única invocação ativa. **Aprimoramento principal** é o benefício escolhido pelo Caminho; ele precisa ser atribuído pelos seus próprios procedimentos.

#### Nível 2 — Duas Atuações Básicas

**Duas básicas no seu turno · Uma invocação ativa.**

Sua invocação principal pode realizar **duas atuações básicas** no seu turno. Ela pode repetir uma capacidade conhecida ou escolher opções diferentes, seguindo sua ficha e sua intenção. Conclua uma resolução antes de começar a outra.

##### Especial primeiro

Para combinar uma especial normal imediata com uma básica, comande a especial **antes de gastar qualquer uma das duas básicas**.

Você deve perceber a invocação a até **18 m**, e ela precisa compreender o comando. Gaste sua **Ação Padrão e a primeira básica da entidade**, pagando os PE e demais custos da especial.

Depois de resolver a especial, suas respostas e a orientação posterior, ela pode executar imediatamente **uma capacidade básica própria**, usando a segunda oportunidade. Cada capacidade conserva o alcance e os requisitos escritos em sua ficha.

A sequência **especial → básica** usa as duas atuações da Trilha.

##### Outras escolhas

Você pode usar sua Padrão pessoalmente enquanto a principal realiza duas básicas. Ela pode combinar capacidades próprias com ações gerais permitidas: atacar e Esquivar, Ajudar e realizar outra tarefa, ou outras opções compatíveis.

A partir do nível 7, sua Bônus pode pagar Atuação Complementar, consultando somente o aprimoramento principal. No nível 30, Especial Combinada usa a Ação Completa do dono e todas as básicas participantes.

#### Nível 2 — Repertório Ampliado

A ficha da principal passa a ter **quatro Famílias Fechadas e cinco abertas**. Escolha duas das Famílias que eram Fechadas para abrir.

Entre as abertas, escolha uma **Família Livre adicional**, totalizando duas. Aplique o desconto normal de montagem. As Famílias e capacidades escolhidas continuam respeitando a definição da entidade.

**Nos níveis 8, 16 e 24 da invocação**, acrescente uma escolha à ficha: **uma capacidade básica, uma especial normal ou uma passiva de Classe Passiva 1**, além das quantidades normais do construtor.

Registre seus efeitos, requisitos e custos. A capacidade básica ou especial segue a Classe permitida pelo nível da entidade. Toda passiva concedida por Repertório Ampliado é de **Classe Passiva 1**, inclusive nas escolhas dos níveis 16 e 24. As escolhas seguem os procedimentos normais de revisão da ficha.

Essas três escolhas fazem parte da progressão de Repertório Ampliado. As entregas da Trilha continuam nos níveis 2, 11, 19 e 27.

#### Substituir a principal

Numa substituição direta que mantenha exatamente uma invocação ativa antes e depois, **a substituta assume os benefícios da Trilha e o saldo das duas básicas ainda disponíveis da anterior**.

A substituta usa sua própria ficha. Conserve os gastos, limites compartilhados e registros de identidade. A atuação adicional precisa ter sido disponibilizada no começo do turno; a troca transmite o saldo existente.

| Saldo da anterior | Saldo transmitido à substituta elegível |
|---|---:|
| Duas básicas disponíveis | Duas. |
| Uma básica disponível | Uma. |
| Ambas gastas | Zero. |

O histórico de cada corpo continua valendo nos retornos, inclusive as travas de uma entidade que já atuou ou transmitiu seu saldo naquela rodada.

**Mais de uma ativa.** Se uma entrada deixar duas ou mais entidades ativas, os benefícios da Trilha terminam e a oportunidade adicional ainda não usada se encerra. A básica comum de cada corpo conserva seu registro.

**Entrada adicional.** A chegada que apenas acrescenta um corpo, inclusive depois de uma queda, segue o procedimento comum. As oportunidades cabíveis à única ativa renovam na próxima abertura do turno.

**Aprimoramento do Caminho.** A saída encerra os aprimoramentos da anterior. A intervenção Preservar o Aprimoramento, recebida no nível 11, trata da transferência desse benefício separado.

#### Nível 11 — Intervenções da Invocação Principal

Você aprende as três intervenções abaixo. Elas ficam disponíveis enquanto houver exatamente uma invocação sua ativa.

**Requisitos comuns:** você está consciente e percebe a destinatária a até **18 m**. Cada intervenção tem **um uso por rodada para o conjunto**, renovado no começo do seu turno.

Pague os Pontos de Vínculo indicados. A intervenção integra sua janela sem outra ação ou Reação; as entradas, trocas e capacidades originais conservam seus custos.

##### Proteger a Manifestação

**2 Pontos de Vínculo · Qualquer turno.**

Use no seu turno, entre resoluções, ou quando um ataque ou efeito que afete sua invocação for declarado, **antes da resolução e dos dados**.

Ela recebe **vida temporária igual a 5 × a Classe correspondente ao nível dela**. A proteção dura **até o começo do seu próximo turno**, enquanto a criatura permanecer sua única invocação ativa.

A vida temporária absorve dano antes dos PV, mantém somente a maior reserva disponível e tem teto de metade da vida máxima, arredondada para baixo.

| Nível da invocação | Classe | Vida temporária antes do teto |
|---|---:|---:|
| 1–4 | 1 | 5 |
| 5–8 | 2 | 10 |
| 9–12 | 3 | 15 |
| 13–16 | 4 | 20 |
| 17–20 | 5 | 25 |
| 21–25 | 6 | 30 |
| 26–30 | 7 | 35 |

*Exemplo: uma invocação de nível 11 recebe 15 de vida temporária. Com 40 PV máximos e atuais, se sofre 20 de dano que alcance essa proteção, consome os 15 temporários e fica com 35 PV. O teto de metade da vida máxima permite os 15 temporários nesse exemplo.*

##### Adaptar o Aprimoramento

**1 Ponto de Vínculo · Seu turno.**

Depois que a invocação aprimorada terminar a primeira das duas atuações da Trilha, com suas respostas e a orientação posterior de uma especial, e enquanto a segunda estiver disponível, substitua seu aprimoramento principal por outro conhecido.

Faça a mudança antes da segunda atuação. O novo benefício segue a duração comum; conserve os usos já marcados no conjunto.

Com Combinar Aprimoramentos, mantenha o adicional e seu prazo. Escolha como novo principal um aprimoramento diferente do adicional. Atuação Complementar consulta o principal que estiver ativo quando for usada.

##### Preservar o Aprimoramento

**1 Ponto de Vínculo · Seu turno.**

Quando concluir uma substituição direta da sua única invocação ativa por outra, sendo a anterior beneficiada por seu aprimoramento principal, transfira para a substituta **os aprimoramentos que a anterior mantinha imediatamente antes de sair**.

A substituta deve cumprir o alcance e a percepção da intervenção. Conserve os prazos e os usos já marcados no conjunto. A troca mantém seus custos e o saldo de básicas transmitido.

#### Nível 19 — Especial de Continuidade

**Seu turno · Uma vez por rodada para o conjunto · Alcance do comando de 18 m.**

Depois que sua única invocação ativa concluir uma especial normal imediata comandada por sua Padrão, você pode usar a **segunda básica** dela para executar **outra especial normal diferente e imediata**, em vez da capacidade básica de continuidade.

A segunda especial pode ter Classe até **metade da maior Classe permitida pelo nível da invocação, arredondada para baixo, com mínimo de 1**.

| Nível da entidade, acompanhando o dono | Maior Classe dela | Limite da continuação |
|---|---:|---:|
| 19–20 | 5 | Classe 2. |
| 21–25 | 6 | Classe 3. |
| 26–30 | 7 | Classe 3. |

Escolha essa especial e seus alvos **depois de resolver a primeira, suas respostas e a orientação posterior**. Você precisa perceber a entidade a até 18 m; ela deve compreender o comando e continuar apta a executar.

Resolva a continuação imediatamente, usando a básica restante e pagando seus PE e demais custos. O comando original cobre as duas especiais. Esta habilidade permite executá-las no mesmo turno, inclusive quando ambas têm Classe positiva, e elas ocupam seu limite de conjurações naquele turno. Cada capacidade conserva seu alcance e suas propriedades.

As duas básicas precisam estar disponíveis antes do comando da primeira especial, como no nível 2. Os usos compartilhados dos aprimoramentos e intervenções continuam marcados.

#### Nível 27 — Intervenção Reflexa

**Reação pessoal · Uma vez por rodada para o conjunto · Alcance de 18 m.**

Enquanto mantiver exatamente uma invocação ativa, você pode gastar sua **Reação pessoal em vez dos Pontos de Vínculo** para usar uma destas intervenções:

| Intervenção elegível | Origem |
|---|---|
| Proteger a Manifestação | Trilha. |
| Adaptar o Aprimoramento | Trilha. |
| Preservar o Aprimoramento | Trilha. |
| Corrigir uma Falha | Caminho. |

Use a intervenção na sua janela, cumprindo seus requisitos e limites. O efeito e a duração permanecem iguais.

Marque o uso da intervenção escolhida e de Intervenção Reflexa. Eles renovam no começo do seu próximo turno. A Reação coletiva continua pertencendo às invocações.

#### Exemplos de jogo

##### A principal luta enquanto você age

Você usa sua Padrão para conjurar pessoalmente. A principal realiza suas duas básicas, respeitando sua intenção. Com Atuação Complementar, pode investir sua Bônus numa tarefa auxiliar permitida pelo aprimoramento principal.

##### Especial seguida de escolha

Você comanda a especial antes de gastar as básicas. Depois da resolução, decide conservar energia com a básica própria ou, a partir do nível 19, pagar a especial menor de continuidade.

##### Mudar a função entre atuações

A ave executa a primeira especial com Precisão à Distância. Você usa Adaptar o Aprimoramento para passar a Proteção Reforçada. A ave realiza a segunda atuação e conserva a proteção para a próxima ameaça pertinente.

##### Trocar sem renovar o saldo

Sua principal ainda tem uma básica e mantém dois aprimoramentos. Você paga a substituição: a nova criatura recebe a básica restante pelos benefícios da Trilha. Se também pagar Preservar o Aprimoramento, recebe os dois benefícios com o prazo anterior, mantendo todos os usos já consumidos.

##### Escolher onde gastar sua Reação

No nível 27, você pode dedicar sua Reação pessoal a Proteger a Manifestação antes de um ataque ou a Corrigir uma Falha na janela da tentativa. Depois de utilizá-la, outras intervenções ainda podem ser pagas pelos Pontos de Vínculo disponíveis, respeitando seus usos próprios.

### Trilha: Parceria

*Você e suas invocações combinam atuações diferentes. Uma especial abre espaço para seu golpe; outra escolha concentra o ataque em você; uma criatura que ficou em apoio conserva uma resposta contra quem o atingir.*

#### Progressão da Trilha

| Nível | Habilidade |
|---|---|
| 2 | Entrada Ágil, Treino de Combate, Repertório de Parceria e Aprimoramentos de Parceria. |
| 11 | Intervenções de Parceria. |
| 19 | Técnicas em Conjunto. |
| 27 | Resposta Técnica da Dupla. |

A Trilha funciona com uma ou duas invocações, usando o teto comum do Caminho. Seus usos por rodada renovam no começo do turno do invocador e permanecem registrados no conjunto nas mudanças de beneficiária.

#### Nível 2 — Abertura da Parceria

##### Entrada Ágil

No seu turno, você pode usar uma **Ação de Movimento inteira e ainda disponível**, em vez da Ação Bônus, para manifestar ou ativar **uma invocação numa entrada que acrescente um corpo ativo ao campo**.

Pague os PE e siga a posição, a primeira intenção e a disponibilidade de recursos da entrada adicional. Substituição e recolhimento seguem seus procedimentos habituais.

##### Treino de Combate

Escolha uma **categoria de armas** e receba treino com suas armas.

##### Repertório de Parceria

Para cada invocação, escolha uma de suas Famílias Fechadas para abrir. A ficha passa a ter **cinco Famílias Fechadas, quatro abertas e uma Livre**.

Registre a escolha e as capacidades compatíveis com a definição da entidade. As quantidades normais de capacidades e passivas seguem o construtor.

##### Aprimoramentos de Parceria

Acrescente os três aprimoramentos abaixo ao catálogo do Caminho. Cada um é atribuído à invocação pela janela e pela duração normais de Aprimoramentos de Vínculo.

**Usos compartilhados:** os três efeitos usam o benefício ofensivo dos aprimoramentos, uma vez por rodada para o conjunto, renovado no começo do turno do invocador. Marque o uso quando iniciar a execução concedida — o ataque ou, a partir do nível 19, o feitiço que o substitui. Os usos anteriores permanecem registrados nas mudanças e trocas.

Os ataques do invocador usam sua própria posição, ficha e equipamento. São ataques individuais com arma ou desarmados. O uso de Golpe Acompanhado é registrado como básica ofensiva gasta da entidade.

###### Acompanhar a Especial

**Seu turno · Ação Bônus do invocador.**

Depois que a beneficiária concluir uma especial normal no seu turno, incluindo suas respostas e a orientação posterior, você pode gastar sua **Ação Bônus** para realizar imediatamente **um ataque com arma ou desarmado** contra um alvo ao seu alcance.

Confira a capacidade de agir do personagem e resolva o ataque com sua ficha. A especial mantém seus próprios custos.

###### Golpe Acompanhado

**Seu turno · Básica disponível da invocação.**

Escolha um inimigo que você consiga atacar e que a beneficiária possa alcançar com uma capacidade básica ofensiva própria, a partir das posições atuais. A criatura precisa perceber o alvo e poder participar contra ele conforme sua intenção.

Gaste a **básica da invocação** para realizar imediatamente **um ataque seu com arma ou desarmado, com vantagem**.

Resolva uma rolagem e o dano de seu ataque. Registre a básica da entidade como gasta e o uso ofensivo do aprimoramento no conjunto.

###### Resposta ao Agressor

**Turno de outra criatura · Reação coletiva.**

Depois de resolver um ataque que acertou o invocador, a beneficiária pode gastar a **Reação coletiva** para executar imediatamente **uma capacidade básica própria ofensiva contra o agressor**.

A invocação precisa perceber o agressor, poder reagir e alcançá-lo com essa capacidade. Desde o começo do último turno do invocador, ela deve ter permanecido **sem atacar, executar especial ou participar de Golpe Acompanhado**.

A resposta é paga com a Reação coletiva e os custos próprios da capacidade. Uma básica sem ataque realizada anteriormente, como Ajudar ou Esquivar, é compatível com a resposta. A execução reativa é adicional e usa a coletiva; a básica já utilizada permanece gasta.


#### Atuação Complementar — interação com o nível 7 do Caminho

A habilidade do Caminho continua consultando somente o aprimoramento principal. Para tornar os novos cartões utilizáveis nela, utilize estas linhas:

| Principal | Ações complementares |
|---|---|
| Acompanhar a Especial | Correr ou Desengajar. |
| Golpe Acompanhado | Correr ou Desengajar. |
| Resposta ao Agressor | Esquivar. |

Cada utilização continua pagando a Bônus e marcando o uso compartilhado de Atuação Complementar.

#### Exemplos

##### Especial e golpe do dono

A ave mantém Acompanhar a Especial. Você comanda sua especial pela Padrão e pela básica da ave, pagando os PE. Depois, usa sua Bônus para um ataque com sua arma. Se houver uma segunda invocação, ela conserva a básica normal.

##### Técnica e ataque acompanhado

O lobo mantém Golpe Acompanhado. Você usa sua Padrão para uma técnica pessoal. Depois, gasta a básica do lobo para realizar um ataque próprio com vantagem contra um inimigo alcançável pelos dois. A Bônus continua disponível para outra utilização legal.

##### Apoio e resposta

O lobo mantém Resposta ao Agressor. Ele usa a básica em Ajudar numa tentativa que possa apoiar legalmente. Depois, no turno inimigo, você é atingido. Se os requisitos ainda forem cumpridos, o lobo usa a coletiva para executar sua básica ofensiva contra o agressor. A ação de apoio anterior é compatível com essa resposta.

---

#### Nível 11 — Intervenções de Parceria

*Vocês abrem espaço um para o outro, corrigem a execução conjunta e se protegem quando a distância permite.*

Você aprende as três intervenções abaixo.

**Requisitos comuns:** você está consciente e percebe a invocação participante ativa a até **18 m**. Cada uso envolve você e **uma** invocação, que pode ser qualquer uma das suas ativas. A entidade precisa perceber o acontecimento ao qual responde e cumprir os requisitos de sua participação.

**Usos:** cada intervenção fica disponível uma vez por rodada para o conjunto. Os usos renovam no começo do seu turno. Corrigir o Ataque Conjunto compartilha especificamente seu uso com Corrigir uma Falha.

##### Abrir Espaço para o Parceiro
**1 Ponto de Vínculo · Seu turno · Sem outra ação ou Reação**

Depois que você ou a invocação participante resolver um ataque contra um inimigo, o outro participante pode se mover **até metade de seu deslocamento**, gastando o Movimento que ainda possui.

Durante esse trecho, quem se move fica protegido dos ataques de oportunidade do inimigo atacado. O trajeto respeita terreno, impedimentos e, para a invocação, sua intenção.

Se o ataque fizer parte de uma especial, conclua a especial e suas respostas. Resolva esta movimentação antes do possível **Acompanhar a Especial**.

*Exemplo: a ave executa uma especial ofensiva. Você usa a abertura para percorrer até 4,5 m de seu Movimento restante e alcançar uma posição para o ataque de arma que pretende pagar com a Bônus.*

##### Corrigir o Ataque Conjunto
**1 Ponto de Vínculo · Seu turno · Sem outra ação ou Reação**

Quando você errar o ataque concedido por **Acompanhar a Especial** ou **Golpe Acompanhado**, antes das consequências, a invocação participante ajuda a corrigir a execução. Repita sua rolagem inteira e use o novo resultado.

Aplique o procedimento de **Corrigir uma Falha**, conservando alvo, dificuldade, modificadores e vantagem ou desvantagem. Marque o uso compartilhado entre estas duas intervenções.

*Exemplo: você erra Golpe Acompanhado mesmo com vantagem. Paga um ponto e repete os dois d20, conservando a mesma tentativa. A correção da rodada fica utilizada pelo conjunto.*

##### Cobrir o Parceiro
**1 Ponto de Vínculo e a Reação de quem protege, ou 2 Pontos de Vínculo · Qualquer turno**

Quando um inimigo percebido pelos dois declarar um ataque contra você ou contra a invocação participante, **antes da rolagem de acerto**, o outro pode cobrir o alvo se estiver a até **3 m** dele e apto a reagir.

Aquela rolagem de ataque recebe **desvantagem**. Escolha o pagamento ao usar a intervenção:

- **1 Ponto de Vínculo e a Reação de quem cobre:** sua Reação pessoal quando você protege; a Reação coletiva quando a invocação protege.
- **2 Pontos de Vínculo:** a proteção dispensa o gasto e a disponibilidade dessa reserva de Reação.

A proteção vale para aquela tentativa. Marque o uso de Cobrir o Parceiro no conjunto.

*Exemplo: o lobo ajudou no seu turno e conserva Resposta ao Agressor. Você paga dois pontos para ele cobrir você. Se o ataque ainda acertar, o lobo pode responder pela Reação coletiva, cumprindo os requisitos do aprimoramento.*


#### Nível 19 — Técnicas em Conjunto

**Ação Bônus · Seu turno · Integra Acompanhar a Especial.**

Quando a invocação beneficiada por **Acompanhar a Especial** concluir uma especial normal no seu turno, incluindo suas respostas e a orientação posterior, você pode usar a **Ação Bônus para conjurar um feitiço conhecido que normalmente utilize Ação Padrão**, em lugar do ataque concedido por esse aprimoramento.

O feitiço pode ter Classe até **metade da sua maior Classe disponível, arredondada para baixo**. A Classe final utilizada na conjuração, inclusive após Ampliar, precisa caber nesse limite.

Escolha a aplicação e seus alvos depois de resolver a especial e confira os requisitos a partir de sua própria posição. Pague os PE e demais custos normais. A invocação conserva os custos e o alcance da especial que executou.

A continuação usa o mesmo benefício ofensivo compartilhado de Acompanhar a Especial. Quando a continuação for de Classe positiva, esta habilidade autoriza a especial da invocação e o feitiço pessoal no mesmo turno; os dois ocupam suas conjurações daquele turno.

| Nível do invocador | Sua maior Classe | Limite da continuação |
|---|---:|---:|
| 19–20 | 5 | Classe 2 |
| 21–25 | 6 | Classe 3 |
| 26–30 | 7 | Classe 3 |

**Exemplo:** no nível 19, a invocação executa sua especial de Classe 5. Você escolhe depois uma aplicação pessoal de até Classe 2, paga sua Bônus e o PE do feitiço, e o resolve. Outra invocação conserva sua básica normal.

#### Nível 27 — Resposta Técnica da Dupla

*Quando um de vocês recebe o golpe, o outro responde com uma aplicação da própria técnica.*

**Reação de quem executa · Uma vez por combate · Turno de outra criatura · Invocação a até 18 m.**

Depois de resolver um ataque inimigo que acertou você ou a invocação beneficiada por seu aprimoramento principal, o outro participante pode executar uma resposta técnica contra o agressor.

Você precisa estar consciente. Ambos precisam perceber o agressor; a invocação deve estar ativa e ser percebida por você a até **18 m**. Quem responde precisa estar apto a reagir e ter sua Reação disponível.

| Quem foi atingido | Resposta e pagamento | Limite de Classe |
|---|---|---|
| Você | A invocação executa uma especial normal imediata, por seu comando, pagando a **Reação coletiva**. Ela precisa compreender sua condução. | **Maior Classe permitida pelo nível dela menos 1.** |
| A invocação | Você conjura um feitiço normal imediato que normalmente utilize Ação Padrão, pagando sua **Reação pessoal**. | **Metade da sua maior Classe disponível, arredondada para cima.** |

Escolha uma capacidade conhecida que possa afetar o agressor. Confira a Classe efetivamente utilizada, inclusive após Ampliar, e os requisitos e alcance a partir de quem executa.

A Reação indicada paga essa execução adicional, mesmo depois das atuações anteriores da rodada. Pague os PE e os demais custos próprios da capacidade quando a resposta começar e marque o uso da habilidade no combate.

Resolva a capacidade normalmente. Conserve os usos já marcados dos Aprimoramentos e das Intervenções de Vínculo.

##### Exemplos

**Você foi atingido.** Com a invocação no nível 27, ela conhece especiais de até Classe 7 e pode responder com uma de até **Classe 6**, usando a coletiva e pagando o custo da especial. Sua Reação pessoal permanece disponível se ainda não foi utilizada.

**A invocação foi atingida.** No nível 27, sua maior Classe é 7: você pode responder com um feitiço de até **Classe 4**, usando sua Reação pessoal. A disponibilidade da coletiva não é requisito para essa resposta pessoal.

**Conservar recursos.** Cobrir o Parceiro por dois pontos preserva as Reações. Se o ataque ainda acertar e os requisitos continuarem satisfeitos, a dupla pode responder pela modalidade correspondente. O uso por combate pertence ao conjunto, mesmo que a beneficiária seja substituída.

### Trilha: Múltiplas Invocações

*Você reúne criaturas com funções diferentes. Algumas enfrentam a ameaça; outras preparam posições, protegem o portador e permitem que o repertório do grupo trabalhe em conjunto.*

#### Progressão da Trilha

| Nível | Habilidade |
|---|---|
| 2 | Conjunto Ampliado, Famílias do Conjunto, Manifestação em Grupo, Entrada Ágil e Aquisição em Duplas. |
| 11 | Intervenções do Conjunto. |
| 19 | Aprimoramentos Distribuídos. |
| 27 | Formação Renovada e Repertório do Conjunto. |

Os usos por rodada renovam no começo do seu turno. O conjunto conserva esses registros quando as criaturas entram, saem ou são substituídas.

#### Nível 2 — Conjunto Ampliado

**Durante o combate**, seu limite é de **quatro invocações ativas**. Fora dele, use o limite comum de duas.

Cada invocação conserva ficha, básica e Movimento próprios. O conjunto tem uma Reação coletiva, separada da sua Reação pessoal.

##### Atuação ofensiva

O conjunto pode executar **uma atuação básica que cause dano e uma especial comandada por rodada**. A especial ocupa a básica de sua destinatária e cobra a Padrão do invocador e seus custos próprios; outra entidade pode realizar a básica ofensiva. As demais atuações básicas trabalham capacidades e ações sem dano.

Os usos são compartilhados e renovam no começo do turno do invocador. Transferências e substituições conservam os registros.

A exceção expressa de **Especial Combinada**, do nível 30 do Caminho, continua permitindo as duas especiais de seu próprio procedimento.


#### Nível 2 — Famílias do Conjunto

Para cada invocação, escolha uma Família Fechada para abrir. Sua ficha passa a ter **cinco Famílias Fechadas e quatro abertas**, mantendo **uma Família Livre**.

Registre a escolha e as capacidades que respeitem a definição da entidade.

#### Nível 2 — Manifestação em Grupo

**Ação Bônus · Seu turno.** Escolha uma operação:

| Operação | Quantidade |
|---|---|
| Entrada adicional | Manifestar ou ativar até duas entidades. |
| Substituição | Realizar até duas substituições diretas. |
| Recolhimento | Recolher ou desativar até duas entidades, conforme seu tipo. |

Nas duas substituições, declare os pares antes de resolver: quem sai e quem assume seu lugar. Cada par transmite a básica restante e legalmente transferível de sua antecessora. Conserve o histórico de identidade e os usos já marcados do conjunto.

A orientação incluída na substituição acompanha cada par. As entradas adicionais seguem sua própria primeira intenção e a disponibilidade normal de básicas.

Pague o PE de cada entrada ou retorno. Confira a posição e os requisitos de cada entidade.

#### Nível 2 — Entrada Ágil

**Ação de Movimento · Seu turno.** Use uma Ação de Movimento inteira e ainda disponível para manifestar ou ativar uma entidade por entrada adicional, em vez da Bônus.

Pague seu PE e siga os outros procedimentos da entrada. Substituir e recolher usam suas ações próprias.

#### Nível 2 — Aquisição em Duplas

Os **dois primeiros espaços de feitiço conhecido** que você comprometer para obter invocações concedem **duas entidades cada**. Os espaços seguintes seguem a proporção comum.

Identifique os espaços e as respectivas duplas na ficha. As criaturas seguem a origem de aquisição por espaço, inclusive seu nível e sua progressão.

No nível 2, comprometer dois dos três espaços disponíveis permite adquirir quatro entidades e conservar um espaço para outra escolha legal. Ter quatro no repertório é diferente de ter quatro já manifestadas antes da iniciativa.

#### Repertório na abertura

Use as quantidades e a progressão normais das capacidades e passivas da entidade, além da Família aberta por esta Trilha. As escolhas adicionais de Repertório do Conjunto são recebidas no nível 27.


---

#### Nível 11 — Intervenções do Conjunto

Você aprende as quatro intervenções abaixo.

**Requisitos comuns:** você está consciente e percebe as invocações participantes ativas a até **18 m**. Elas precisam perceber a situação e compreender a orientação necessária à participação. Cada intervenção tem **um uso por rodada para o conjunto**, renovado no começo do seu turno.

Pague os custos indicados junto dos custos normais das capacidades envolvidas. As intervenções de proteção exigem que a invocação protetora possa reagir. Os aprimoramentos e as outras intervenções conservam seus usos compartilhados.

##### Dificultar o Ataque

**1 Ponto de Vínculo e Reação coletiva · Qualquer turno.**

Quando um ataque contra você ou um aliado seu — incluindo outra invocação — for declarado, **antes da rolagem de acerto**, escolha uma invocação protetora diferente do alvo, que perceba o agressor e esteja a até **4,5 m da criatura atacada**.

A protetora interfere no ataque. Aquela rolagem recebe **desvantagem**.

*Exemplo: a guardiã está a 3 m de um aliado da equipe. Antes dos dados do ataque contra ele, você paga um ponto e ela gasta a coletiva para dificultar a tentativa.*

##### Proteger um Aliado

**1 Ponto de Vínculo e Reação coletiva · Qualquer turno.**

Antes de você ou um aliado seu — incluindo outra invocação — realizar um **Teste de Resistência contra um projétil visível ou um efeito em área**, escolha uma invocação protetora diferente do protegido, que perceba o efeito e esteja a até **4,5 m dele**.

A invocação protege essa criatura durante a resolução. Aquele Teste de Resistência recebe **vantagem**.

*Exemplo: uma explosão alcança dois companheiros. A guardiã cobre um deles, a 4,5 m dela, favorecendo o teste escolhido. A intervenção usa sua única Reação coletiva disponível.*

##### Conduzir a Especial

**1 Ponto de Vínculo e a básica de uma segunda invocação · Seu turno.**

Ao comandar uma especial normal imediata de uma invocação, antes de escolher os alvos, escolha outra participante com uma básica disponível para servir de origem à aplicação.

**A segunda invocação precisa estar dentro do alcance da própria especial, medido a partir da executora, antes de mudar a origem.** A executora precisa perceber esse ponto de manifestação. Ambas também cumprem o alcance comum de 18 m em relação a você.

Gaste a básica da segunda invocação. A especial se manifesta a partir da posição dela: meça dali o alcance até os alvos, a área e a direção.

**Precisão da cooperação.** Depois de escolher os alvos e antes de qualquer rolagem da especial, escolha um dos benefícios: **vantagem em uma rolagem de ataque da especial** ou **desvantagem no primeiro Teste de Resistência de um alvo contra essa execução**.

A executora usa sua ficha e cumpre os requisitos de percepção, trajeto, Forma e Restrições da capacidade. Ela paga sua básica; você paga a Padrão do comando. Os PE e demais custos seguem o procedimento normal da especial.

Cada especial continua sendo uma única execução e marca os usos do conjunto normalmente. A precisão pertence à intervenção Conduzir a Especial; os usos de Aprimoramento de Vínculo continuam em seus registros próprios.

*Exemplo: uma especial com alcance de 9 m pode ser conduzida por uma invocação situada a até 9 m da executora. Seus alvos precisam estar a até 9 m da nova origem. A apoiadora gasta a básica, e você indica antes dos dados o ataque ou TR favorecido.*

##### Retirada em Conjunto

**1 Ponto de Vínculo · Seu turno.**

Depois que uma invocação participante usar sua básica para **Desengajar**, escolha outra invocação sua ativa a até **9 m** dela, também dentro do alcance comum da intervenção.

A segunda recebe o efeito de **Desengajar até o fim do seu turno**. Ela usa seu Movimento e sua básica nos momentos normais.

*Exemplo: a serpente usa sua básica para Desengajar e cobre a retirada da ave, a 7,5 m dela. A ave pode sair do confronto usando seu próprio Movimento e conservar sua básica para uma especial comandada ou outra tarefa.*

---

#### Um turno com quatro corpos

A ave executa a especial, o auxiliar gasta sua básica para conduzi-la e o cão realiza a única básica ofensiva do conjunto. Uma quarta invocação conserva sua atuação para outra tarefa.

Quando surgir uma ameaça, uma protetora pode usar a Reação coletiva em Dificultar o Ataque ou Proteger um Aliado. Os dois usos disputam a mesma reserva coletiva, como as outras respostas das invocações.

Em outra rodada, uma criatura pode usar Desengajar e compartilhar a retirada com outra a até 9 m. A composição do grupo determina quem oferece a capacidade, quem oferece a posição e quem protege o portador.

---

#### Nível 19 — Aprimoramentos Distribuídos

**Escolha gratuita no começo do seu turno · Até duas invocações ativas percebidas a até 18 m.**

Na janela normal de escolha dos Aprimoramentos de Vínculo, atribua **um aprimoramento principal diferente a cada uma de até duas invocações suas**. Cada escolha segue a duração comum do Caminho.

**Usos compartilhados.** Conserve o único uso ofensivo dos aprimoramentos e os registros de proteção, perícia e movimento do conjunto. Marque os benefícios quando forem aproveitados; eles renovam no começo do seu próximo turno.

**Mudar uma escolha.** Pelo custo normal de **2 Pontos de Vínculo**, Mudar o Aprimoramento modifica uma das escolhas por uso. Indique a escolha e altere seu benefício, sua destinatária ou ambos. Se a nova destinatária já mantiver outra escolha, encerre a anterior dela. O novo principal deve ser diferente dos demais principais que permanecerem ativos. A escolha que não for alterada conserva seus efeitos.

**Atuação Complementar.** Ao usar a habilidade, escolha uma das beneficiárias e consulte a tabela do principal dela. O custo continua sendo sua Bônus, com um uso por rodada para o conjunto.

**Combinar Aprimoramentos.** Você pode pagar **4 PE** para manter **um adicional em uma das duas beneficiárias**, até o começo do seu próximo turno. O adicional pode repetir o principal da outra criatura, conservando o mesmo registro compartilhado de uso. Ele deve ser diferente do principal da própria beneficiária. Ao modificar uma combinação pela intervenção, conserve o prazo já pago.

**Entradas e saídas.** A escolha gratuita acontece no começo do seu turno. Quando uma beneficiária sair ou ficar inativa, somente sua escolha termina; as outras continuam pela duração comum. As oportunidades de básica e os saldos de substituição seguem seus próprios procedimentos.

**Especial Combinada.** No nível 30 do Caminho, escolha uma das beneficiárias de principal como a participante exigida pelo comando. A habilidade conserva a Ação Completa, todas as básicas participantes e seus custos normais.

##### Exemplo

A atiradora recebe Precisão à Distância e a executora da especial recebe Proteção Reforçada. Uma terceira invocação pode conduzir a especial, pagando a básica e o ponto da intervenção e oferecendo a precisão própria dela. A atiradora usa a única básica ofensiva; a executora conserva a proteção para uma tentativa posterior. Os usos ofensivos dos aprimoramentos continuam compartilhados.

#### Nível 27 — Formação Renovada

**Uma vez no começo do seu turno, em combate · Sem ação adicional.**

Depois de resolver os efeitos e as atuações obrigatórias de início de turno e antes de escolher seus Aprimoramentos de Vínculo, estando consciente, escolha uma operação:

| Operação | O que você faz |
|---|---|
| Entrada adicional | Manifeste ou ative uma invocação dentro do limite de campo. |
| Substituição direta | Retire uma invocação ativa e coloque outra em seu lugar. |

Pague os **PE normais da entrada ou retorno**. Confira a legalidade, a posição de chegada e os requisitos dos tipos envolvidos pelo capítulo de Invocações.

**Entrada pronta.** Na entrada adicional feita por Formação Renovada, a entidade recebe **uma básica disponível para a rodada**, se suas condições permitirem e ela ainda não tiver usado, investido ou transferido sua básica nessa rodada. A primeira intenção segue seu procedimento normal.

**Substituição.** A substituta recebe somente a básica ainda disponível e legalmente transferível da antecessora. Conserve os registros de identidade, o Movimento de cada corpo e todos os usos compartilhados.

Depois da operação, faça a escolha gratuita dos aprimoramentos; a recém-chegada pode ser uma das duas beneficiárias do nível 19.

##### Exemplo — completar o grupo

Você começa o turno com três invocações ativas. Depois dos efeitos obrigatórios, usa Formação Renovada para trazer uma quarta e paga sua entrada. A nova criatura recebe a básica prevista por esta habilidade e pode ser escolhida para um aprimoramento.

Você pode orientá-la com sua Bônus ou comandar uma especial pela Padrão quando cumprir os requisitos, aplicando a orientação posterior normal. As demais entradas feitas nesse turno seguem seus próprios procedimentos.

##### Exemplo — mudar a composição

Uma invocação ferida já não oferece as capacidades de que você precisa. Na abertura do turno, substitua-a por uma reserva apropriada e pague os PE dessa entrada. A nova criatura assume o saldo de básica elegível; em seguida, escolha os aprimoramentos considerando a nova composição. Sua Bônus permanece disponível para outra utilização legal.

#### Nível 27 — Repertório do Conjunto

Ao receber esta habilidade, escolha **Essência ou Inteligência**. Cada uma de suas invocações recebe uma quantidade de escolhas adicionais igual à **metade do valor permanente do atributo escolhido, arredondada para baixo**.

Para cada escolha, acrescente à ficha **uma capacidade básica de Classe 0, uma especial normal ou uma passiva de Classe Passiva 1**.

As capacidades respeitam a definição, as Famílias, a montagem e a Classe permitida pelo nível da própria entidade. A metade do atributo determina a quantidade de escolhas; a Classe das capacidades ativas continua sendo a que o nível da invocação permite.

| Valor permanente do atributo | Escolhas adicionais por invocação |
|---|---:|
| 0 ou 1 | 0 |
| 2 ou 3 | 1 |
| 4 ou 5 | 2 |
| 6 | 3 |

Registre as escolhas na ficha. Ao entrar ou ser substituída, a invocação utiliza esse repertório registrado. A capacidade é executada com suas ações, PE, requisitos e limites próprios.

Uma entidade adquirida depois recebe as escolhas ao ser registrada. Se um aumento permanente do atributo elevar a quantidade, complete as escolhas adicionais. Alterações temporárias conservam o repertório registrado.

##### Exemplo — funções complementares

Com Essência 6 escolhida, cada invocação recebe três escolhas adicionais. Uma pode desenvolver especiais de proteção; outra, capacidades básicas utilitárias; uma terceira, passivas de Classe Passiva 1 coerentes com sua definição.

Em cada rodada, você decide qual composição precisa estar em campo e pode usar Formação Renovada para realizar uma entrada ou substituição. Permanecem o limite de uma básica com dano e uma especial comandada, os usos compartilhados e a exceção de Especial Combinada do nível 30.

## Incursor

*Você atravessa o confronto, aproveita uma abertura e decide quando avançar ou conservar uma resposta. Fluidez sustenta essas escolhas; a Trilha determina como você luta.*

### Características do Incursor

**Características do Incursor**
| | |
|---|---|
| **Vida inicial** | 6 (d6), antes da Constituição |
| **Vida por nível** | 4 |
| **PE por nível** | 6 |
| **Atributos naturais** | Destreza · Força |
| **Perícias fixas** | `Acrobacia` · `Intuição` |
| **Perícias à sua escolha** | 5, de qualquer uma da lista de perícias do sistema. |
| **Ofícios** | nenhum. Os dois vêm da sua Origem |
| **Teste de Resistência** | 1 treinado, à sua escolha. A sua Origem treina o outro |
| **Treino de arma** | **as treze categorias**: Simples, Marciais e Arma de Fogo |

*O Caminho treina você nessa lista de armas; ele não te dá a arma. O que você leva na mão você compra na criação, e as tabelas de `Preços` estão no capítulo 15, __Equipamento__.*

**Vida máxima:** `(6 + Constituição) + (4 + Constituição) × (nível − 1)`.

Escolha uma Trilha no nível 2. Suas entregas chegam nos níveis **2, 11, 19 e 27**. A troca de Trilha nos níveis permitidos é integral: substitua os benefícios da anterior pelos da nova. Você mantém um Caminho e uma Trilha.

### Progressão do Caminho

| Nível | Habilidades |
|---|---|
| 2 | Agilidade de Combate, Movimento Acrobático e Fluidez. |
| 7 | Duas obtenções de Fluidez e Correr ou Esquivar pela Bônus. |
| 15 | Melhorias de Fluidez e Passo Guardado. |
| 23 | Retomar o Ritmo e Movimento Acrobático ampliado. |
| 30 | Um Passo à Frente. |

Uma Reação pessoal se renova no começo do seu turno. Os usos que exigem Reação disputam essa mesma reserva. **Bloquear não gasta Reação.** A virada da rodada global não renova Fluidez nem seus usos.

### Nível 2 — Agilidade de Combate

Durante seu turno, você pode usar **Desengajar ou Esconder como Ação Bônus**. Esconder continua exigindo as condições e os testes normais. Essas ações não geram Fluidez por si mesmas.

### Nível 2 — Movimento Acrobático

Seu deslocamento aumenta em **3 m**. Um deslocamento comum de 9 m passa a 12 m.

Durante seu movimento, pode percorrer até **metade do seu deslocamento** por paredes ou atravessando espaços ocupados por criaturas de até uma categoria de tamanho maior que você. Esse limite é compartilhado pelos trechos acrobáticos.

Termine o trecho em um espaço livre com apoio normal. Isso usa seu movimento disponível, não aumenta a distância que pode percorrer e não impede ataques de oportunidade. Não exige PE, Fluidez ou uma ação adicional. Obstáculos, testes necessários e demais regras de movimento continuam valendo.

### Nível 2 — Fluidez

Você ganha Fluidez quando:

- **Acerta uma criatura hostil**, durante seu turno, com um ataque de arma ou desarmado.
- **Uma criatura hostil erra um ataque contra você.**

Pode ganhar Fluidez **uma vez entre o começo de um turno seu e o começo do próximo**. O limite de obtenções é renovado no começo do seu turno.

Guarda apenas uma Fluidez por vez. Se já estiver com ela, um novo acerto ou erro inimigo não acumula outra nem fica reservado para depois; esse evento não consome uma obtenção. Sofrer dano não remove Fluidez.

Resolva cada gatilho de obtenção uma única vez. Se um acontecimento não forneceu outra Fluidez porque você já a possuía, gastar o estado depois não permite aproveitar esse mesmo acontecimento novamente.

Ela dura até ser gasta, você ficar Incapacitado ou o combate terminar. Os usos abaixo não custam PE.

| Uso | Custo e efeito |
|---|---|
| Investida | Antes de um ataque de arma ou desarmado, gaste Fluidez para fazê-lo com vantagem. Se acertar durante seu turno e ainda puder ganhar Fluidez nesse ciclo, pode recuperá-la. |
| Instante Decisivo | Após rolar o d20, antes de finalizar o ataque, gaste Fluidez para ampliar sua margem de crítico em 1, normalmente de 20 para 19–20. Não pode recuperar Fluidez com esse mesmo acerto. |
| Passo Rápido | Depois de resolver um ataque seu, durante seu turno, gaste Fluidez para se mover até metade do seu deslocamento como movimento adicional. Esse movimento não provoca oportunidade do alvo daquele ataque; outras criaturas ainda podem reagir normalmente. Não usa sua Bônus. |
| Evasão | Quando um inimigo declarar um ataque contra você, antes da rolagem, gaste Fluidez e sua Reação para impor desvantagem ao ataque. Se ele errar e você ainda puder ganhar Fluidez nesse ciclo, pode recuperá-la. |
| Reflexo | Quando um inimigo errar um ataque contra você, gaste Fluidez e sua Reação para fazer um ataque de oportunidade corpo a corpo contra ele, se estiver ao seu alcance. Você precisa já ter Fluidez quando o ataque inimigo foi declarado. |
| Esquiva Instintiva | Antes de fazer um TR Físico, gaste Fluidez para realizá-lo com vantagem. Esse uso não exige Reação. |

Evasão e Reflexo disputam a mesma Reação. O ataque de Reflexo feito fora do seu turno não gera Fluidez. O erro que acionou Reflexo não repõe a Fluidez gasta nessa resposta.

### Nível 7

#### Mais oportunidades de Fluidez

Passa a poder ganhar Fluidez **duas vezes entre o começo de um turno seu e o começo do próximo**. Continua guardando apenas uma por vez. Os gatilhos permanecem os mesmos.

#### Correr ou Esquivar pela Bônus

Durante seu turno, pode gastar **Fluidez e sua Ação Bônus** para:

- **Correr:** recebe movimento adicional igual ao seu deslocamento, até o fim do turno; oportunidades normais.
- **Esquivar:** até o começo do seu próximo turno, recebe os benefícios normais de Esquivar: desvantagem nos ataques contra você e vantagem nos seus TR Físicos, respeitando as condições dessa ação.

Passo Rápido continua separado. O Caminho base não recebe Ataque Extra.

### Nível 15 — Melhorias de Fluidez

- **Instante Decisivo:** o crítico realizado com esse uso também impede o alvo de usar Reações até o começo do seu próximo turno.
- **Evasão:** também pode proteger um aliado voluntário a até 1,5 m de você contra um ataque declarado contra ele. O erro contra o aliado não gera Fluidez para você.
- **Passo Rápido:** pode ser utilizado em qualquer momento do seu turno, sem precisar atacar antes. Escolha uma criatura percebida; o movimento não provoca oportunidade dela. Mantém custo e distância.
- **Reflexo — Inverter a Pressão:** também pode ser usado depois de passar num TR Físico provocado por um efeito hostil, fora do seu turno. Você precisa ter Fluidez antes do teste. A resposta pode atacar qualquer criatura hostil ao seu alcance corpo a corpo, mesmo que outra tenha provocado a resposta. Mantém Fluidez e Reação como custos.

#### Passo Guardado

Uma vez entre o começo de um turno seu e o começo do próximo, **fora do seu turno e enquanto tiver Fluidez**, depois de resolver um ataque contra você ou um TR Físico provocado por uma criatura hostil, pode se mover imediatamente até **metade do seu deslocamento**, como movimento adicional.

Não exige Reação nem gasta Fluidez. Esse movimento não provoca oportunidade da criatura responsável pelo ataque ou efeito; outras criaturas podem reagir normalmente. Precisa continuar capaz de se mover após a resolução.

Quando o mesmo acontecimento permitir Passo Guardado e Reflexo, pode primeiro realizar o movimento e depois resolver o contra-ataque. Mantenha os requisitos de Reflexo: depois de um erro de ataque, o alvo continua sendo o inimigo que errou; depois de um TR Físico bem-sucedido, pode escolher uma criatura hostil ao seu alcance. O ataque ou efeito que provocou a resposta é resolvido antes de ambos.

### Nível 23

#### Retomar o Ritmo

No começo do seu turno, se estiver sem Fluidez, pode gastar sua **Ação de Movimento inteira** para ganhar Fluidez. Essa obtenção não conta no limite das duas obtenções normais.

#### Movimento Acrobático ampliado

Passa a poder percorrer paredes e atravessar espaços de criaturas até o limite do **seu deslocamento completo**, mantendo os demais requisitos. Amplia a travessia permitida; não concede movimento adicional. O novo limite também vale para as modalidades acrescentadas ao Movimento Acrobático pela sua Trilha, como a travessia de líquidos do Pugilista.

### Nível 30 — Um Passo à Frente

**Uma vez por combate**, pode ativar imediatamente antes de **outra criatura** começar um turno.

Ao ativar, antecipa seu turno e o realiza imediatamente. Não pode usar se seu turno já ocorreu naquela rodada.

Durante esse turno:

- Seu deslocamento dobra.
- Seus movimentos não provocam ataques de oportunidade.
- Movimento Acrobático permite atravessar espaços de criaturas de qualquer tamanho, mantendo a exigência de terminar em espaço livre com apoio.

Esse turno substitui seu turno habitual daquela rodada. Depois de terminá-lo, a criatura que iria agir começa o turno dela. Não joga novamente quando chegar sua posição habitual na iniciativa; nas rodadas seguintes, conserva essa posição.

Suas ações e os demais custos e requisitos das habilidades continuam funcionando normalmente.

### Trilha: Assassino

*Você estuda uma vítima, escolhe o percurso até ela e concentra sua força no momento de atacar. Paredes, bordas e até o corpo do inimigo podem se tornar parte desse percurso.*

#### Progressão da Trilha

| Nível | Habilidades |
|---|---|
| 2 | Alvo Estudado, Estudar a Guarda, Golpe Cirúrgico, Cortar a Fuga e Parkour. |
| 11 | Desaparecer no Percurso e Escolher a Próxima Vítima. |
| 19 | Brecha Fatal e usos de execução entre começos de turnos. |
| 27 | Sentença Final. |

#### Nível 2 — Alvo Estudado

**Ação Bônus · Sem custo de PE.**

Escolha uma criatura que você consiga ver a até **18 m**. Ela se torna seu **Alvo Estudado** até o fim da cena ou até você escolher outra criatura. Você só pode manter um Alvo Estudado por vez.

Você possui uma **oportunidade de abate** contra ele quando, ao declarar o ataque, pelo menos uma destas condições estiver presente:

- Você está **oculto dele**.
- Ele está **sem Reação disponível**.
- Seu ataque cumpre uma das aproximações descritas em **Parkour**.
- Seu ataque se beneficia de **Estudar a Guarda**, descrito abaixo.

Ao acertar seu Alvo Estudado com uma **arma de Volume leve ou com Fineza**, havendo uma oportunidade de abate, você pode utilizar **Golpe Cirúrgico** ou **Cortar a Fuga**.

##### Estudar a Guarda

Durante seu turno, você pode usar sua **Ação Bônus** para estudar a guarda de uma criatura que consiga ver a até **18 m**. Você pode escolhê-la como seu Alvo Estudado com essa mesma ação ou estudar novamente seu alvo atual.

Você só pode utilizar essa opção se **ainda não tiver se deslocado por vontade própria naquela rodada**. Depois de utilizá-la, **não pode se deslocar por vontade própria até o fim da rodada**, incluindo movimentos adicionais concedidos por habilidades, como Passo Rápido e Passo Guardado. Deslocamentos forçados continuam sendo resolvidos normalmente.

Seu **próximo ataque corpo a corpo contra esse alvo, antes do fim desse turno, possui uma oportunidade de abate**. A oportunidade é consumida quando você declara o ataque, mesmo que erre.

Estudar a Guarda continua exigindo sua **Ação Bônus** após o nível 11, mesmo quando escolher ou trocar seu Alvo Estudado não exige ação.

**Exemplo.** Se ainda não se moveu naquela rodada e a vítima já está ao alcance da sua arma, pode estudar a guarda e atacá-la sem se mover. Se usou Passo Guardado antes do seu turno naquela rodada, não pode utilizar essa preparação. Depois de estudar, também não pode usar Passo Rápido ou Passo Guardado até a rodada terminar.

##### Golpe Cirúrgico

**Fluidez + PE · Uma vez por turno seu.**

Depois de confirmar o acerto, antes de rolar o dano, escolha **Destreza ou Inteligência**. Calcule **X = atributo escolhido − 1**, com mínimo de zero, e gaste **Fluidez e X PE**.

Role os **dados de dano da arma normalmente**. Golpe Cirúrgico não maximiza dados.

Além disso, acrescente **X dados** ao dano normal de **Canalizar em Golpe**. Os dados adicionais têm o mesmo tamanho dos dados utilizados normalmente em Canalizar e são rolados normalmente.

O atributo escolhido define o custo normal de PE e a quantidade de dados adicionais. O atributo utilizado no acerto e no dano normal da arma continua seguindo suas próprias regras.

**Em um crítico com Golpe Cirúrgico**, a arma segue a regra normal de crítico, com seus dados dobrados e rolados, e você **dobra tanto os dados normais de Canalizar em Golpe quanto os dados adicionais concedidos por esta habilidade**. Role todos esses dados normalmente. Os demais efeitos seguem suas próprias regras.

O reforço vale somente para aquele ataque e exige que ele possa receber o dano de Canalizar normalmente.

**Restringido.** Aplique o reforço ao dano equivalente de **Estímulo Muscular**, seguindo os mesmos cálculos de custo e quantidade por Destreza ou Inteligência − 1. Os dados adicionais têm o mesmo tamanho dos dados normais de Estímulo Muscular. Em um crítico com Golpe Cirúrgico, dobre tanto os dados normais de Estímulo Muscular quanto os dados adicionais da habilidade.

**Exemplo.** Com Destreza 5, Golpe Cirúrgico custa **4 PE e Fluidez** e concede **4 dados adicionais**. Se seu Canalizar normal for `3d4`, uma arma de `1d8` causa **1d8 + atributo do ataque + 7d4**: os `3d4` normais de Canalizar e `4d4` adicionais. Em um crítico que dobre os dados da arma, causa **2d8 + atributo do ataque + 14d4**: os `6d4` normais de Canalizar já dobrados e os `8d4` adicionais também dobrados. Role todos esses dados normalmente. Uma ficha com Inteligência 5 também pode usar esse atributo para obter o mesmo custo e os mesmos 4 dados adicionais.

###### Combinação com Instante Decisivo

Se você utilizou **Instante Decisivo naquele ataque**, pode aplicar **Golpe Cirúrgico sem gastar outra Fluidez**, desde que acerte e cumpra todos os requisitos da habilidade.

Nesse caso, pague o custo normal de Golpe Cirúrgico **mais 4 PE**. O gasto de Fluidez feito em Instante Decisivo paga a combinação.

Esses **4 PE adicionais não concedem dados de dano**. O ataque continua sem poder recuperar Fluidez, e Golpe Cirúrgico mantém seu limite normal de uso.

**Exemplo.** Com Destreza 5, a combinação custa **8 PE ao todo**: 4 PE de Golpe Cirúrgico e 4 PE adicionais. Você gasta uma Fluidez ao utilizar Instante Decisivo. Se seu Canalizar normal for `3d4` e o ataque acertar como crítico, uma arma de `1d8` causa **2d8 + atributo do ataque + 14d4**, como no exemplo anterior; os 4 PE adicionais não acrescentam dados.

##### Cortar a Fuga

**Fluidez · Uma vez por turno seu.**

Depois de resolver o acerto, gaste Fluidez. O alvo realiza um **TR Físico** contra:

**CD = 8 + atributo utilizado no ataque + sua maestria.**

Na falha, fica **Derrubado**, e você pode **empurrá-lo até 3 m para longe de você**, respeitando obstáculos e as regras normais de deslocamento forçado.

##### Obtenção e gasto de Fluidez

Fluidez obtida pelo acerto pode pagar Golpe Cirúrgico ou Cortar a Fuga. Resolva essa obtenção antes do gasto.

Uma mesma Fluidez paga apenas um uso, **exceto pela combinação com Instante Decisivo descrita acima**. O mesmo acerto não gera Fluidez novamente depois de ela ser gasta.

#### Nível 2 — Parkour

Seu **Movimento Acrobático** recebe os benefícios abaixo.

Durante seu Movimento Acrobático, você pode usar **Acrobacia no lugar de Atletismo** nos testes exigidos para saltar ou alcançar os apoios utilizados pelo Parkour.

Os testes continuam usando suas dificuldades normais. Esse benefício não aumenta a distância disponível nem elimina obstáculos ou consequências de uma falha.

##### Apoios de infiltração

Você pode terminar o percurso **pendurado em uma borda ou agarrado a uma superfície com apoios capazes de sustentá-lo**, mantendo pelo menos uma mão ocupada.

Você também pode realizar ataques corpo a corpo durante o percurso, antes de alcançar o apoio final.

##### Aproximação de abate

O primeiro ataque corpo a corpo contra seu Alvo Estudado, realizado durante ou imediatamente ao terminar uma destas aproximações, possui uma **oportunidade de abate**:

- **Percorrer pelo menos metade do seu deslocamento por uma parede e, na sequência, saltar de um ponto de apoio ou borda para alcançar o alvo.**
- **Descer pelo menos 4,5 m de uma posição elevada com apoio para alcançar o alvo, usando Movimento Acrobático.**

A aproximação usa seu movimento disponível. Os trechos de Movimento Acrobático respeitam o limite da habilidade, e os saltos seguem suas regras normais.

##### A vítima como apoio

**Uma vez por turno seu**, depois de acertar um ataque corpo a corpo contra uma criatura hostil durante seu Movimento Acrobático, você pode usar o corpo dela como apoio para **saltar até uma borda, superfície com apoios ou posição elevada**.

Escolha um destino livre que você possa alcançar com o salto e com o **movimento que ainda tem disponível**. Esse salto **não provoca ataques de oportunidade** e não exige gasto adicional de ação, PE ou Fluidez.

Resolva o ataque e seus efeitos antes do salto. A vítima não precisa ser seu Alvo Estudado.

##### Movimento e aterrissagem

Parkour utiliza os ataques e o movimento que você já possui. Termine o percurso numa posição permitida.

Os testes necessários, obstáculos e regras de queda continuam valendo normalmente. A proteção contra ataques de oportunidade aplica-se somente ao salto feito usando a vítima como apoio.

**Exemplo.** Você desce de uma plataforma para atacar seu Alvo Estudado. A aproximação permite usar Golpe Cirúrgico ou Cortar a Fuga, caso acerte e pague seus custos.

Depois de resolver o ataque, você usa o corpo da vítima como apoio para saltar até uma borda próxima, alcançável com seu movimento restante. Esse salto não provoca ataques de oportunidade.

#### Nível 11 — Desaparecer no Percurso

**Uma vez por turno seu**, depois de realizar um ataque contra seu Alvo Estudado com uma **arma de Volume leve ou com Fineza**, você pode **Esconder sem gastar uma ação**, ao terminar um movimento daquele turno.

Você precisa terminar numa posição que permita Esconder e realizar o teste normal de Furtividade. O movimento usa sua distância disponível e segue normalmente as regras de ataques de oportunidade.

##### Escolher a Próxima Vítima

Durante seu turno, você pode escolher ou trocar seu **Alvo Estudado sem gastar uma ação**, uma vez por turno, mantendo os requisitos normais de alcance e visão.

**Exemplo.** Você escolhe seu Alvo Estudado sem gastar uma ação e usa sua Bônus para Desengajar. Ataca, move-se até uma posição onde possa se esconder e, ao terminar o movimento, faz o teste de Furtividade sem gastar outra ação. Se conseguir permanecer oculto da vítima até o próximo ataque, terá uma oportunidade de abate contra ela.

#### Nível 19 — Brecha Fatal

**Reação + 2 PE.**

Quando seu **Alvo Estudado gastar uma Reação**, depois que ela terminar de ser resolvida, você pode gastar sua Reação e **2 PE** para realizar **um ataque corpo a corpo com uma arma de Volume leve ou com Fineza** contra ele.

O alvo precisa estar ao alcance da arma no momento desse ataque.

##### Execução fora do turno

Você pode utilizar **Golpe Cirúrgico ou Cortar a Fuga nesse ataque**, desde que possua Fluidez e cumpra os requisitos normais, pagando seus respectivos custos.

A partir deste nível, o limite de cada um desses usos passa a ser **uma vez entre o começo de um turno seu e o começo do próximo**, permitindo utilizá-los dentro ou fora do seu turno.

Usar Golpe Cirúrgico na Brecha Fatal consome o mesmo uso que estaria disponível no seu turno. O mesmo vale para Cortar a Fuga.

O ataque segue as regras normais de obtenção de Fluidez: um acerto fora do seu turno não gera Fluidez por si só.

#### Nível 27 — Sentença Final

**Uma vez por combate**, ao utilizar **Golpe Cirúrgico**, pode transformar aquele golpe em uma Sentença Final. **Você deve estar oculto do Alvo Estudado no momento em que declara o ataque.**

O acerto se torna um **crítico**. Resolva o dano seguindo as regras de crítico de Golpe Cirúrgico.

Depois do dano, o alvo realiza um **TR Físico** contra:

**CD = 8 + atributo utilizado no ataque + sua maestria.**

Na falha, fica **Derrubado**, e você pode **empurrá-lo até 3 m**, respeitando obstáculos e as regras normais de deslocamento forçado.

Sentença Final utiliza **uma Fluidez e o custo normal de PE de Golpe Cirúrgico**, consumindo o uso dessa habilidade naquele intervalo. O derrube e o empurrão fazem parte da execução e não exigem outro gasto de Fluidez.

O ataque precisa ser realizado com uma **arma de Volume leve ou com Fineza**.

### Trilha: Pugilista

*Você luta com o corpo inteiro. Seus golpes alternam pressão e guarda, quebram o equilíbrio do adversário e permitem usar o contato sem depender de uma contenção.*

#### Progressão da Trilha

| Nível | Habilidades |
|---|---|
| 2 | Corpo Treinado, Quebrar o Compasso e Recuperar a Base. |
| 7 | Rajada Marcial, evolução de Corpo Treinado. |
| 11 | Guarda Marcial, Interceptar e Prender e Movimento sobre líquidos. |
| 19 | Golpe Desarticulador e Projeção Marcial. |
| 27 | Corpo em Harmonia: Rajada e Guarda, e Redirecionar a Força. |

Rajada Marcial é a evolução da habilidade recebida no nível 2. Não acrescenta um novo degrau de Trilha no nível 7.

#### CD das habilidades da Trilha

Os efeitos da Trilha que exigem resistência são resolvidos por um **TR do adversário contra a CD do Pugilista**, sem teste oposto de Atletismo do Pugilista.

**CD do Pugilista = 8 + Força ou Destreza + maestria.** Escolha o atributo ao utilizar a habilidade. Se o efeito estiver vinculado a um ataque seu, utilize o atributo daquele ataque.

Cada habilidade indica o tipo de TR e as consequências de sucesso ou falha. Esta regra se aplica às habilidades da Trilha; os testes gerais do personagem seguem suas próprias regras.

Tentar escapar de uma contenção criada pela Trilha também exige um **TR Físico contra a CD do Pugilista**, em vez de um teste oposto de Atletismo.

#### Nível 2 Corpo Treinado

Você pode utilizar **Força ou Destreza no acerto e no dano dos ataques desarmados**, escolhendo a cada ataque.

Seu dano desarmado utiliza a progressão abaixo, no lugar da progressão comum:

| Maestria | Níveis | Dano desarmado |
|---|---|---|
| 1 | 2 a 9 | 1d6 |
| 2 | 10 a 17 | 1d8 |
| 3 | 18 a 25 | 1d10 |
| 4 | 26 a 30 | 1d12 |

Canalizar ou Estímulo Muscular continua sendo acrescentado normalmente, seguindo seus requisitos e impedimentos.

Depois de realizar a **Ação Atacar**, você pode usar sua **Ação Bônus para realizar um ataque desarmado adicional**, mesmo que o primeiro ataque tenha errado.

##### Rajada Marcial a partir do nível 7

Ao utilizar essa **Ação Bônus**, você pode gastar **3 PE** para realizar **dois ataques desarmados**, em vez de um. Declare e pague o custo antes do primeiro ataque da Bônus.

Cada ataque possui sua própria rolagem e pode atingir uma criatura diferente. Ambos causam seu dano desarmado normal, incluindo Canalizar ou Estímulo Muscular quando aplicável.

Rajada Marcial só pode ser utilizada com a Ação Bônus concedida por Corpo Treinado, depois da Ação Atacar. Ela não exige Fluidez e segue os limites normais de obtenção e gasto desse estado.

#### Nível 2 Quebrar o Compasso

**Fluidez · Uma vez por turno seu.**

Depois de acertar um ataque desarmado, gaste Fluidez. O alvo realiza um **TR de Vigor contra a CD do Pugilista**, utilizando o atributo daquele ataque na CD.

Na falha, fica **Lento até o fim do próximo turno dele**: seu deslocamento fica pela metade e ele não pode utilizar Ação Bônus.

#### Nível 2 Recuperar a Base

Você pode gastar Fluidez para utilizar uma das opções abaixo. Nenhuma delas exige gasto de ação ou Reação.

- **Depois de ficar Derrubado:** levante imediatamente após resolver o efeito que o derrubou, sem gastar sua Ação de Movimento.
- **Enquanto estiver Agarrado por uma criatura:** ela realiza um **TR Físico contra a CD do Pugilista**. **Na falha, você escapa da contenção e pode deixar o agressor Agarrado por você, sem outro teste, desde que cumpra os requisitos normais para agarrá-lo.** No sucesso, ela mantém a contenção e a Fluidez permanece gasta.
- **Depois de ser empurrado por um único efeito por uma distância igual ou superior à metade do seu deslocamento:** mova-se imediatamente até **metade do seu deslocamento**, em direção à posição que ocupava antes do empurrão. Esse retorno é movimento adicional; resolva primeiro o efeito que o empurrou. Você precisa conseguir se mover, e o percurso segue as regras normais de movimento e ataques de oportunidade.

**Exemplo.** Com deslocamento de 12 m, um empurrão de 6 m permite gastar Fluidez para retornar até 6 m. Se for empurrado 9 m, também pode retornar até 6 m.

Todos os usos seguem os limites normais de obtenção e gasto de Fluidez do Caminho. Um mesmo acerto não gera Fluidez novamente depois de ela ser gasta.

#### Nível 11 — Guarda, contenção e travessia

##### Guarda Marcial

Você combina seus golpes com movimentos de defesa, mantendo a guarda durante a troca.

Ao utilizar a **Ação Bônus de Corpo Treinado**, pode gastar **3 PE** para realizar **um ataque desarmado e receber os efeitos de Esquivar até o começo do seu próximo turno**:

- Ataques contra você têm **desvantagem**.
- Seus **TR Físicos têm vantagem**.

Declare e pague o custo antes do ataque. Você recebe os efeitos de Esquivar mesmo que erre.

**Guarda Marcial e Rajada Marcial são alternativas para essa Ação Bônus:** escolha uma delas a cada utilização. Guarda Marcial não exige Fluidez.

##### Interceptar e Prender

**Fluidez e Reação.**

Quando uma criatura errar um ataque corpo a corpo contra você, se você já possuía Fluidez quando o ataque foi declarado, pode gastar Fluidez e sua Reação para tentar prender a arma ou o membro utilizado no ataque.

A criatura precisa estar ao alcance do seu ataque desarmado e ser de até uma categoria de tamanho maior que você. Você precisa de uma mão livre.

O alvo realiza um **TR Físico contra a CD do Pugilista**. Na falha, fica **Agarrado por você** e não pode atacar com a arma ou o membro preso. Você mantém uma mão ocupada na contenção e pode atacar com as outras partes do corpo.

O alvo pode gastar uma **Ação Padrão** para realizar outro **TR Físico contra a CD do Pugilista**, escapando no sucesso. Se a contenção prender uma arma, ele também pode soltá-la: a contenção termina e a arma fica na sua mão.

A contenção termina se você liberar o alvo, deixar de manter a mão ocupada nela, ficar Incapacitado ou o alvo sair do alcance do seu ataque desarmado. Soltar o alvo não exige ação.

##### Movimento sobre líquidos

Seu **Movimento Acrobático também permite percorrer a superfície de líquidos durante o movimento**.

Essa travessia usa seu movimento disponível e compartilha o limite de distância com os demais trechos de Movimento Acrobático. Termine o trecho em uma posição com apoio normal; a superfície do líquido não sustenta você depois que a travessia termina. Os efeitos normais de contato com o líquido continuam valendo.

#### Nível 19 Golpe Desarticulador

Seus golpes comprometem a coordenação do adversário, interrompendo seus movimentos.

Ao utilizar **Quebrar o Compasso**, você pode gastar **6 PE adicionais** para tentar bloquear os movimentos do alvo. Declare e pague esse custo antes do TR de Vigor.

Na falha, o alvo fica **Impedido**, em vez de Lento, até o fim do próximo turno dele: seu deslocamento fica em zero, ele recebe desvantagem nos seus ataques e TR Físicos, e os ataques contra ele têm vantagem.

O efeito utiliza o mesmo acerto, gasto de Fluidez, TR de Vigor e limite de uso de Quebrar o Compasso. O dano do ataque é resolvido normalmente; o alvo não precisa estar Agarrado. No sucesso do TR, o bloqueio não se aplica e os custos permanecem gastos.

O prazo indicado é o limite da condição. As regras gerais de remoção e recuperação continuam valendo; falhar num teste de recuperação não prolonga esse prazo.

#### Nível 19 Projeção Marcial

**3 PE · Uma vez por turno seu.**

Ao realizar a **Ação Atacar**, você pode substituir um de seus ataques por uma projeção de uma criatura **Agarrada por você**, de até uma categoria de tamanho maior que você.

Escolha um espaço livre a até **6 m de você**, alcançável pelo lançamento, e pague **3 PE**. O alvo realiza um **TR Físico contra a CD do Pugilista**.

Na falha, a contenção termina, ele é lançado até o espaço escolhido, sofre **o dano de um golpe desarmado seu**, incluindo Canalizar ou Estímulo Muscular quando aplicável, e fica **Derrubado**. No sucesso, ele permanece na posição original e a contenção continua; os PE ficam gastos.

##### Resolução da projeção

Projeção Marcial é resolvida pelo **TR do alvo, sem rolagem de ataque**. Ela não causa crítico, não gera Fluidez por acerto e não ativa efeitos que exigem acertar um ataque, como Quebrar o Compasso.

Ela continua fazendo parte da **Ação Atacar**. Depois de concluir essa ação, você pode utilizar a **Ação Bônus de Corpo Treinado normalmente**, incluindo Rajada Marcial ou Guarda Marcial quando disponíveis, mesmo que o alvo resista à projeção.

Os ataques realizados com essa Bônus seguem suas próprias regras de acerto, crítico e obtenção de Fluidez.

##### Colisão

Se o espaço escolhido estiver adjacente a outra criatura que possa ser atingida pela trajetória, você pode lançar o alvo contra ela.

Depois que o alvo original falhar no TR, a segunda criatura realiza seu próprio **TR Físico contra a CD do Pugilista**. Na falha, sofre **a mesma quantidade de dano da projeção** e também fica **Derrubada**. No sucesso, evita o impacto.

O alvo lançado termina no espaço livre escolhido em ambos os resultados da segunda criatura. O lançamento precisa de um percurso livre de obstáculos sólidos.

#### Nível 27 Corpo em Harmonia

Você integra seus golpes, sua guarda e o redirecionamento da força adversária.

##### Rajada e Guarda

Ao utilizar a **Ação Bônus de Corpo Treinado**, você pode gastar **6 PE ao todo** para combinar **Rajada Marcial e Guarda Marcial**: realize **dois ataques desarmados** e receba os efeitos de **Esquivar até o começo do seu próximo turno**.

Declare e pague o custo antes do primeiro ataque. Você recebe os efeitos de Esquivar mesmo que erre os ataques. Cada ataque é resolvido normalmente. Essa opção não exige Fluidez e substitui o uso separado de Rajada ou Guarda naquela Bônus.

##### Redirecionar a Força

**Fluidez, Reação e 6 PE.**

Quando uma criatura errar um **ataque corpo a corpo com arma ou desarmado que tenha apenas você como alvo**, você pode redirecionar esse golpe, como alternativa a Interceptar e Prender. Você precisa já possuir Fluidez quando o ataque for declarado.

Para utilizar a habilidade, cumpra os requisitos abaixo:

- **O agressor está ao alcance do seu ataque desarmado**, é de até uma categoria de tamanho maior que você, e você tem uma mão livre.
- Você percebe **outra criatura hostil**, diferente de você e do agressor, **ao alcance da arma ou do membro utilizado naquele ataque**. Esse alcance é medido a partir do agressor.
- O ataque pode alcançar o novo alvo sem atravessar obstáculos que impeçam o golpe. A habilidade não aumenta alcances nem movimenta nenhuma criatura.

Escolha o novo alvo e pague os custos. O agressor realiza um **TR Físico contra a CD do Pugilista: 8 + sua Força ou Destreza + sua maestria**. No sucesso, o golpe continua sendo um erro contra você e os custos permanecem gastos.

Na falha, resolva o mesmo ataque contra o novo alvo:

- Reutilize **o resultado do d20 já escolhido**, mantendo a vantagem ou desvantagem já resolvida. Não role novamente o ataque. Mantenha os modificadores do atacante e ajuste somente aqueles que dependam especificamente do alvo.
- Compare o resultado com a **Defesa do novo alvo**, que pode **Bloquear normalmente**, incluindo as regras de Aparar e Brecha.
- Se acertar, aplique o dano e os efeitos daquele golpe normalmente. **O agressor continua sendo o autor do ataque**; use os recursos já pagos e as regras de crítico dele. Nenhum custo do ataque original é pago de novo.

**O erro que ativou Redirecionar a Força não pode repor a Fluidez gasta nessa resposta.** O ataque redirecionado não é um ataque seu e não gera Fluidez para você por acerto. Um mesmo ataque só pode ser redirecionado uma vez por esta habilidade. Como o d20 já foi escolhido, o redirecionamento não abre outra janela anterior à rolagem desse d20. Bloquear e as respostas cuja janela ainda seja válida continuam possíveis.

### Trilha: Malabarista

*Você maneja armas de uma mão, mistura contato e arremesso e usa os ângulos do cenário para manter a pressão. A energia amplia sua execução; Fluidez permite escolher o destino de cada lançamento.*

#### Progressão da Trilha

| Nível | Habilidades |
|---|---|
| 2 | Manejo de Combate, Ofensiva em Movimento, Ricochete, Lançamento Cruzado e Mudar o Destino. |
| 11 | Trajetória de Retorno e Manejo Contínuo. |
| 19 | Finta de Retorno e Manejo Contínuo ampliado. |
| 27 | Trajetória Perfeita. |

#### Como as continuações funcionam

**Lançamento Cruzado, Trajetória de Retorno e Finta de Retorno compartilham uma utilização por turno seu.** Escolha a forma de execução e pague seu custo; elas não concedem continuações separadas para o mesmo turno.

| Execução | Custo | Destino da continuação |
|---|---|---|
| Lançamento Cruzado | Fluidez e 3 PE. | Outra criatura, depois de um arremesso acertar. |
| Trajetória de Retorno, nível 11 | Fluidez e 4 PE. | A mesma criatura, por uma superfície, depois de acertar. |
| Finta de Retorno, nível 19 | Fluidez e 6 PE. | A mesma criatura, mesmo depois de errar, com as defesas alteradas pela Finta. |

Uma correção por Mudar o Destino continua sendo parte do ataque corrigido. Depois da correção, considere o alvo final para os requisitos de uma continuação. Fluidez obtida por um acerto só pode ser aproveitada uma vez pelo mesmo acontecimento, conforme o Caminho.

Trajetória Perfeita substitui um ataque da Ação Atacar e consome essa mesma utilização de continuação, com seu próprio procedimento. Os demais ataques disponíveis continuam seguindo suas regras normais.

#### Nível 2 Manejo de Combate

Você pode usar **Força ou Destreza no acerto e no dano dos ataques corpo a corpo e de arremesso com armas de uma mão**, escolhendo a cada ataque. Os demais requisitos da arma continuam valendo.

Durante seu turno, pode realizar **duas manipulações gratuitas de itens, em vez de uma**. A segunda precisa ser usada para **sacar, guardar ou recolher uma arma solta ao seu alcance**, com uma mão disponível. Isso não permite recarregar nem retirar uma arma empunhada por outra criatura. As manipulações seguintes seguem seus custos normais.

#### Nível 2 Ofensiva em Movimento

**3 PE · Uma vez por turno seu.**

Ao realizar a **Ação Atacar**, pode gastar **3 PE antes do primeiro ataque** para realizar **dois ataques com armas de uma mão**, em vez do ataque único normalmente disponível. Se outra regra já conceder mais ataques nessa ação, use a maior quantidade; as quantidades não se somam.

Pode combinar ataques corpo a corpo e arremessos, usar a mesma arma ou armas diferentes e atacar a mesma criatura ou criaturas diferentes. Cada ataque é resolvido separadamente, com seu dano e seus requisitos normais. Canalizar em Golpe ou Estímulo permanece sujeito às próprias regras.

Sua Ação Bônus permanece disponível. Essa execução não exige Fluidez; seus ataques seguem os limites normais de obtenção desse estado.

#### Nível 2 Ricochete

Durante seu turno, **antes de rolar um ataque de arremesso com uma arma de uma mão**, pode gastar **Fluidez** para fazê-la ricochetear em uma superfície sólida do cenário antes de atingir o alvo.

Escolha o alvo que você percebe e o ponto de ricochete antes da rolagem. A arma percorre dois trechos: da sua posição até a superfície e da superfície até o alvo. Ambos precisam estar livres de obstáculos que impeçam sua passagem. O ponto de ricochete precisa estar dentro do alcance original da arma.

**Depois de alcançar o ponto de ricochete, a arma recebe 6 m adicionais de alcance**, além da distância que ainda restava do arremesso. Esse acréscimo vale uma vez no ataque, após um único ricochete.

Some as distâncias dos dois trechos. A faixa normal do percurso completo aumenta em 6 m, e a faixa longa também aumenta em 6 m. O ataque recebe desvantagem por faixa longa se **o primeiro trecho ultrapassar a faixa normal original** ou se **o percurso completo ultrapassar a faixa normal aumentada**. O primeiro trecho nunca pode ultrapassar a faixa longa original, e o percurso completo nunca pode ultrapassar a faixa longa aumentada.

Para determinar a cobertura do alvo, considere a direção do trecho que sai do ponto de ricochete. Isso permite contornar uma cobertura quando existir esse caminho, inclusive se a linha direta estiver bloqueada. Uma trajetória inteiramente bloqueada continua inviável, e o ricochete não revela alvos que você não percebe.

Resolva **um único ataque contra o alvo**, com a rolagem, o dano e o crítico normais da arma. A superfície não recebe um ataque separado. O ricochete não devolve a arma à sua mão. As demais causas de vantagem ou desvantagem continuam valendo, inclusive faixa longa e atacar colado a um inimigo.

Esse gasto modifica um ataque disponível; não acrescenta outro. Um acerto pode gerar Fluidez quando ainda houver uma obtenção disponível, seguindo as regras do Caminho.

**Exemplo.** Seu chakram tem faixas de 6 m e 18 m. Ao atingir uma parede a 3 m, restam 3 m da faixa normal. Ricochete acrescenta 6 m: o alvo pode estar a até 9 m da parede sem desvantagem por distância. O percurso total máximo passa a 24 m, com desvantagem quando a faixa normal é ultrapassada. Se a parede já estiver a 9 m de você, o ataque recebe desvantagem mesmo que o alvo esteja logo depois dela, porque o primeiro trecho ultrapassou os 6 m originais da faixa normal.

#### Outros usos de Fluidez

##### Lançamento Cruzado

**Fluidez + 3 PE · Uma vez por turno seu.** Durante seu turno, depois de resolver um arremesso seu com arma de uma mão que acertou uma criatura hostil, pode gastar Fluidez e **3 PE** para fazer a mesma arma continuar contra **outra criatura hostil percebida a até 6 m da primeira**.

Essa continuação é **um ataque adicional, sem consumir outro ataque disponível nem exigir uma ação**, resolvido imediatamente. Pague antes da nova rolagem. O ataque causa o dano normal da arma, incluindo Canalizar em Golpe ou Estímulo quando aplicável, e resolve seu crítico normalmente. A distância e a cobertura são conferidas a partir da primeira criatura; o trajeto precisa estar livre. Os 6 m são o limite dessa continuação e não recebem outro acréscimo de Ricochete. As demais condições da sua posição continuam relevantes, inclusive estar colado a um inimigo ao arremessar.

A arma utilizada no primeiro ataque pode fazer a continuação sem ter sido recuperada. Isso não devolve a arma à sua mão. Fluidez obtida pelo primeiro acerto pode pagar esse uso, quando ainda houver uma obtenção disponível. O primeiro acerto não gera Fluidez novamente após o gasto. O segundo ataque segue seus próprios gatilhos e os limites do Caminho.

**Exemplo.** Você paga 3 PE pela Ofensiva em Movimento e acerta o primeiro arremesso. Usa a Fluidez obtida nesse acerto e mais 3 PE para continuar com a mesma arma contra outro inimigo a 4,5 m da primeira vítima. Depois da continuação, ainda possui o segundo ataque da Ação Atacar. O total é de três ataques, por 6 PE e Fluidez. O acerto da continuação não permite repetir Lançamento Cruzado naquele turno.

##### Mudar o Destino

**Fluidez · Uma vez por turno seu.** Durante seu turno, depois de errar um arremesso com arma de uma mão contra uma criatura hostil, pode gastar Fluidez para redirecionar a arma contra **outra criatura hostil percebida a até 6 m do alvo original**, realizando uma nova rolagem. A Fluidez precisa estar disponível após o erro; errar não fornece esse estado.

A nova criatura também precisa estar dentro do alcance da arma, medido a partir da origem daquele ataque, com caminho válido. Se o ataque utilizou Ricochete, mantenha o mesmo ponto de ricochete e o mesmo acréscimo de alcance; confira novamente o percurso até o novo alvo. Se estiver corrigindo Lançamento Cruzado, meça desde a primeira vítima e mantenha seu limite de 6 m; a nova criatura também precisa ser diferente dela.

Essa é uma correção da tentativa que errou: não consome outro ataque disponível, não repete a tentativa contra a mesma criatura e não permite outra correção se a nova rolagem também errar. Use a nova rolagem para determinar acerto e crítico, e resolva o dano normal da arma no acerto. Considere a correção como parte do mesmo ataque para gatilhos que contam ataques realizados; o erro contra o primeiro alvo permanece um erro. A correção tem suas próprias condições de vantagem, desvantagem e cobertura. Efeitos escolhidos antes da rolagem continuam sujeitos aos próprios requisitos contra o novo alvo; efeitos vinculados ao resultado do primeiro d20 não são transferidos para o novo resultado.

Um acerto da correção pode gerar Fluidez, respeitando o limite normal do Caminho. Se corrigiu um ataque comum e ainda não usou Lançamento Cruzado, esse acerto pode permitir o lançamento adicional, pagando seus custos normalmente. Se corrigiu o próprio Lançamento Cruzado, o limite de uso já foi consumido.

#### Nível 11 Trajetória de Retorno

Ao utilizar **Lançamento Cruzado**, pode pagar **4 PE, em vez de 3**, para fazer a arma ricochetear em uma superfície sólida e atacar **novamente a criatura atingida pelo primeiro arremesso**.

**Esse ataque substitui a continuação contra outra criatura de Lançamento Cruzado.** Não realiza um ataque de Cruzado e outro de Retorno: escolhe uma das duas formas para a mesma utilização.

Escolha o ponto de ricochete antes da nova rolagem. O percurso **da vítima até a superfície e da superfície de volta à vítima** deve estar livre e somar **até 6 m**. Determine a cobertura pela direção do trecho de retorno.

Essa execução utiliza **a mesma Fluidez e o mesmo limite de uso de Lançamento Cruzado**. Não exige gastar outra Fluidez com Ricochete e não recebe seu alcance adicional. O ataque de retorno tem sua própria rolagem, dano e crítico normais. A vítima conserva suas defesas e respostas normais.

**Exemplo.** Você acerta um inimigo com um kunai. Gasta Fluidez e 4 PE para fazê-lo atingir uma parede a 1,5 m da vítima e voltar contra ela. O percurso de retorno soma 3 m. Faça a nova rolagem de ataque. Se utilizou Ofensiva em Movimento, ainda possui seu outro ataque da Ação Atacar: o pacote completo custa 7 PE e Fluidez e conserva o total de até três ataques próprios.

#### Nível 11 Manejo Contínuo

**Uma vez por turno seu**, ao encerrar um arremesso com uma arma de uma mão, incluindo suas correções e continuações, pode fazê-la **retornar à sua mão**, desde que:

- A arma esteja a até **6 m de você**, com caminho livre até sua posição.
- Você tenha uma mão livre para recebê-la.
- Nenhuma criatura esteja empunhando a arma e nenhum efeito impeça sua recuperação.

Esse retorno não exige ação, Fluidez ou PE e **não é um ataque**. Você pode voltar a usar a arma com os ataques que ainda tiver disponíveis.

#### Nível 19 Finta de Retorno

Depois de resolver um ataque de arremesso no seu turno, pode gastar **Fluidez e 6 PE** para utilizar **Trajetória de Retorno contra o alvo desse ataque, mesmo que o arremesso tenha errado**.

Os 6 PE substituem o custo normal de 4 PE de Trajetória de Retorno. Esta execução consome a mesma utilização de Lançamento Cruzado e mantém o limite de uma continuação por turno, seus requisitos de arma, o ricochete em uma superfície sólida, o percurso livre de até 6 m e a nova rolagem de ataque. Não acrescenta outra continuação ao kit.

O alvo **não pode utilizar Bloquear contra o ataque de retorno**; compare a rolagem com sua Defesa normal. Se utilizou Bloquear contra o arremesso inicial, **o ataque de retorno também tem vantagem**, independentemente de o primeiro arremesso ter acertado.

O primeiro arremesso conserva sua resolução, dano e respostas normais. A Finta não desfaz um Aparar ou uma resposta já resolvida contra ele. O retorno continua sujeito às demais defesas, modificadores e efeitos aplicáveis, inclusive cancelamento normal de vantagem e desvantagem. Dano e crítico são normais; não há dados adicionais de dano.

Se o arremesso inicial errar, você precisa ter Fluidez disponível para pagar a Finta: o erro não fornece Fluidez. Se acertar, pode utilizar a Fluidez obtida por esse acerto, respeitando as regras normais de ganho.

Se utilizar Mudar o Destino para redirecionar um retorno que errou, a nova vítima conserva suas defesas normais e não recebe os benefícios específicos desta Finta: a proibição de Bloquear e a vantagem por ter bloqueado o arremesso inicial valem somente contra o alvo original desse retorno.

**Exemplo.** Um inimigo bloqueia seu primeiro arremesso e evita o acerto. Você ainda possui Fluidez e paga 6 PE para utilizar Trajetória de Retorno. A arma ricocheteia em uma parede e volta contra ele. Você faz uma nova rolagem com vantagem, comparada à Defesa normal do alvo, sem outro Bloquear. O arremesso inicial permanece um erro.

#### Nível 19 Manejo Contínuo ampliado

Você também pode utilizar **Manejo Contínuo fora do seu turno**.

O limite passa a ser **uma recuperação entre o começo de um turno seu e o começo do próximo**. Se já recuperou uma arma no seu turno, essa utilização não fica disponível novamente antes do próximo começo de turno. Mantém alcance de 6 m, caminho livre, mão disponível e demais requisitos de recuperação.

#### Nível 27 Trajetória Perfeita

**Uma vez por combate · Fluidez e 12 PE.**

Ao realizar a **Ação Atacar**, pode substituir **um dos seus ataques** por Trajetória Perfeita, utilizando uma **arma de uma mão apropriada para arremesso**. Você precisa ter Fluidez antes da execução e ainda não ter utilizado Lançamento Cruzado, Trajetória de Retorno ou Finta de Retorno naquele turno. Declare o percurso e pague os custos antes de rolar.

Escolha até **quatro criaturas hostis que você percebe** e a ordem em que a arma passará por elas. O percurso completo pode somar **até 24 m**, incluindo todos os trechos desde sua posição, e pode utilizar até **três pontos de ricochete em superfícies sólidas**. Use esses pontos para mudar a direção da arma. Cada trecho precisa estar livre de obstáculos que impeçam sua passagem. Uma mesma criatura só pode ser atacada uma vez nessa execução.

Resolva um ataque contra cada alvo na ordem escolhida:

- **Você tem vantagem nessas rolagens**, sujeita ao cancelamento normal com desvantagem.
- **Os alvos não podem Bloquear esses ataques**; compare cada rolagem com a Defesa normal da criatura.
- Cada acerto causa **o dano normal da arma**, incluindo Canalizar em Golpe ou Estímulo quando aplicável, e resolve seu crítico normalmente.
- **A arma continua pelo percurso mesmo se um ataque errar.** Um erro não fornece Fluidez nem causa dano àquela criatura.

Nesta execução, o limite de 24 m substitui as faixas de alcance da arma e não impõe desvantagem por faixa longa. Determine a cobertura a partir da direção do trecho que alcança cada alvo. As demais condições e defesas continuam aplicáveis, inclusive desvantagem por arremessar colado a um inimigo. A execução não atravessa barreiras, não revela alvos e não ignora efeitos que efetivamente capturem ou impeçam a passagem da arma. Se o percurso deixar de ser viável, encerre os trechos restantes.

Trajetória Perfeita **consome sua utilização de Lançamento Cruzado daquele turno**. Seus ataques não podem receber Ricochete, Lançamento Cruzado, Trajetória de Retorno, Finta de Retorno ou Mudar o Destino. As superfícies e a mudança de defesa descritas acima já fazem parte desta execução, sem novos custos. Não há ataques de continuação depois da sequência.

Ganhos de Fluidez pelos acertos seguem os limites normais do Caminho, sem novas obtenções extras. Manejo Contínuo pode recuperar a arma depois do último ataque, se estiver disponível e a arma cumprir seus requisitos. A execução não garante retorno à mão.

---


# Capítulo 9 · Fundamento

*fonte: `manual/40-fundamento.md`*

## Técnica e feitiços

Todo personagem nasce com uma única técnica, e ela nunca muda. Essa técnica se chama **Fundamento**, e é uma descrição e uma regra, escritas por você na criação do personagem. Tudo que o personagem faz de único nasce dela.

O que você usa em mesa são os **feitiços**: aplicações concretas da técnica, cada uma com nome próprio. Você mesmo monta os seus feitiços, gastando pontos.

### Classe do feitiço

Todo feitiço tem uma **Classe**, que mede o tamanho dele. A Classe diz quantos pontos você tem para gastar na montagem.

> **Pontos = 3 × Classe.**
> Um feitiço de Classe 3 tem **9 pontos**.

Cada ponto que você não gastar em mais nada vira **1d8 de dano**. Uma Classe 3 que põe tudo em dano causa 9d8.

Os pontos também compram **Melhorias**: alcance maior, área, derrubar o alvo, conjurar como ação bônus. E, se quiser recuperar pontos, você pode aceitar **Restrições**, que são desvantagens devolvendo pontos ao orçamento em troca de o feitiço ficar mais difícil de usar.

Os pontos devolvidos por Restrição só servem para pagar Melhoria: **Restrição nunca aumenta o dano**. E, contra um alvo só, feitiço comum não passa dos pontos da Classe em dados. Quem rompe esse limite é a **Liberação Máxima**, que chega no nível 10.

São oito Classes.

**Classe do feitiço**
| Classe | O que é | Quando aparece |
|---|---|---|
| **0** | O feitiço grátis. Não custa PE e não ocupa espaço na lista. | Nível 1 |
| **1 a 5** | Os feitiços montados. É onde o jogo acontece, e é o que este capítulo ensina a construir. | Níveis 1 a 20 |
| **6 e 7** | A faixa lendária. Mesma montagem, números maiores. | Níveis 21 a 30 |

Cada feitiço é montado na Classe que o seu nível já liberou, e *Números da montagem* mostra quando cada uma chega. Daqui para a frente, quando o texto disser só "a Classe", vale para a escala inteira.

### Exemplo

> **`Lança Negra` · Classe 2 · Projétil**
> Classe 2 dá **6 pontos**.
> A Melhoria `Fura` custa 2 e faz o feitiço ignorar até 4 de Redução de Dano.
> A Restrição `Atrasar` devolve 2, em troca de a conjuração custar a rodada inteira.
> 6 − 2 + 2 = **6 pontos sobrando**.
> **Dano: 6d8 (média 27). Custo: 6 de PE.**
>
> A Restrição pagou a Melhoria inteira, e o feitiço saiu com o dano cheio da Classe. É exatamente para isso que Restrição serve, e ela para aí: 6 pontos continuam sendo o máximo de dados de uma Classe 2 contra um alvo.

### Atributo da técnica

**Toda técnica usa um atributo, e você escolhe qual quando escreve ela.** Um dos cinco, na criação, e ele não pode ser mudado depois.

> **Ataque de conjuração = d20 + o atributo da sua técnica + maestria**
> **Maestria** começa em 1 e sobe um ponto a cada oito níveis.

**É recomendado escolher o atributo que o seu personagem já ia querer alto.** As perícias que ele usa, o Teste de Resistência que ele quer aguentar, uma Trilha que soma o mesmo atributo no dano: se alguma dessas coisas já puxa um atributo para cima, aponte a técnica para ele.

> Nada te obriga a escolher Inteligência ou Essência. Elas são as mais comuns porque quase toda técnica é análise ou percepção — mas qualquer opção é possível.
### CD de feitiço

Alguns feitiços podem fazer com que o alvo tenha de resistir com um teste. O número que ele precisa passar é a sua **CD de feitiço**.

> **CD de feitiço = 8 + o atributo da sua técnica + maestria.**

Ela não muda de feitiço para feitiço, não sobe com a Classe e não se compra com pontos. É um número da ficha, como a sua Defesa.

**O que o alvo rola.** Um **Teste de Resistência**: `d20 + o atributo daquele Teste`, mais a maestria se ele for treinado nele. Igualou ou passou a sua CD, ele resistiu. Nos feitiços de área (`Explosão`, `Aura`, `Cone`, `Linha`) resistir faz o alvo receber metade dos dados, a não ser que uma regra diga o contrário ou que você tenha comprado a Restrição `Tudo ou Nada`.

> **Exemplo.** Kaito consegue usar feitiços de Classe 3, maestria 2: CD 14. Ele monta o mesmo feitiço em duas versões, uma de acerto e uma de Teste de Resistência, e escolhe na hora conforme o alvo. Contra a maldição de Defesa 12 e Vigor alto, ele usa a de acerto. Contra a de Defesa 19 e Vigor baixo, a de resistência. **O feitiço é o mesmo; o que muda é qual número do inimigo está mais baixo.**

### Peças da técnica

**Peças da técnica**
| Peça | O que é |
|---|---|
| **Fundamento** | Sua técnica. Uma descrição, uma Regra, Famílias Livres e Fechadas, um Selo e as Passivas. |
| **Feitiços** | As aplicações da técnica. Você monta cada uma. |
| **Passivas** | Efeitos que ficam ligados sozinhos. Custam espaços de feitiço. |
| **Liberação Máxima** | O feitiço que rompe o limite de dano num alvo só. Nos níveis 10, 20 e 30. |
| **Técnica Máxima** | O golpe de dano fixo que carrega o nome da técnica. Do nível 17 em diante. |

## Números da montagem

> **Pontos** = 3 × Classe
> **Teto de dano** = 4 × Classe em dados
> **Devolução máxima** = 2 × Classe
> **Liberação Máxima** = + Classe em dados
> **Custo em PE** = 3 × Classe (o mesmo número dos pontos)
> Melhoria `Leve` custa metade da Classe · `Média` custa a Classe · `Pesada` custa Classe e meia. Arredonde para cima.

**Números da montagem**
| Classe | Nível | Pontos e PE | Leve | Média | Pesada | Devol. máx | Liberação | Teto | Dano cheio | Cura cheia |
|---|---|---|---|---|---|---|---|---|---|---|
| **1** | 1 | 3 | 1 | 1 | 2 | 2 | +1 | 4 | 3d8 = 13 | 2d8 = 9 |
| **2** | 5 | 6 | 1 | 2 | 3 | 4 | +2 | 8 | 6d8 = 27 | 4d8 = 18 |
| **3** | 9 | 9 | 2 | 3 | 5 | 6 | +3 | 12 | 9d8 = 40 | 6d8 = 27 |
| **4** | 13 | 12 | 2 | 4 | 6 | 8 | +4 | 16 | 12d8 = 54 | 8d8 = 36 |
| **5** | 17 | 15 | 3 | 5 | 8 | 10 | +5 | 20 | 15d8 = 67 | 10d8 = 45 |
| **6** | 21 | 18 | 3 | 6 | 9 | 12 | +6 | 24 | 18d8 = 81 | 12d8 = 54 |
| **7** | 26 | 21 | 4 | 7 | 11 | 14 | +7 | 28 | 21d8 = 94 | 14d8 = 63 |

A coluna **Nível** é quando aquela Classe abre para você. **Leve**, **Média** e **Pesada** são os três preços de Melhoria, e **Devol. máx** é o total que as Restrições de um feitiço podem devolver.

A coluna **Teto** é o máximo de dados de dano de um feitiço quando você soma todos os alvos e repetições. Contra um alvo só o limite é mais baixo: um feitiço comum para nos pontos da Classe. Quem alcança o teto num alvo só é a **Liberação Máxima**.

### Melhorias e Restrições por Classe

**Melhorias e Restrições por Classe**
| Classe do feitiço | Melhorias | Restrições |
|---|---|---|
| **1 e 2** | 2 | 2 |
| **3 e 4** | 3 | 2 |
| **5 em diante** | 4 | 2 |

A Forma não conta como Melhoria. O Efeito Próprio conta como uma Melhoria.

**Duas Melhorias escritas como uma** custam a soma dos preços das partes e contam no limite como as partes. É atalho de leitura na ficha, e não desconto. O mestre pode aprovar por menos pontos ou menos espaço, mas é decisão inteiramente dele, por conta e risco, e o manual não recomenda: o limite de Melhorias não segura o pico de dano, ele segura a largura do feitiço — sem ele, toda ficha converge para o mesmo pacote de sinergia.

### Energia

Conjurar um feitiço custa **3 × Classe** de PE, o mesmo número dos pontos dele. Classe 0 é grátis.

**Liberação Máxima** custa 50% a mais que a Classe dela, arredondando para cima. **Técnica Máxima** custa 5 × a sua maior Classe de PE.

Com um conjurador ganhando 6 PE por nível, isso dá:

**Valores dos feitiços de Classe 1 a 7**
| Nível | PE total | Maior Classe | Custo |
|---|---|---|---|
| 1 | 6 | 1 | 3 |
| 5 | 30 | 2 | 6 |
| 9 | 54 | 3 | 9 |
| 13 | 78 | 4 | 12 |
| 17 | 102 | 5 | 15 |
| 20 | 120 | 5 | 15 |

### Classe 0

Feitiços de Classe 0 não gastam PE e não ocupam espaço na lista: escolha uma Forma e pronto. São o golpe de todo turno em que o PE precisa ser poupado.

**Classe 0**
| Seu nível | 1 | 5 | 11 | 17 | 25 |
|---|---|---|---|---|---|
| Quantos você tem | 2 | 3 | 4 | 5 | 5 |
| Dano | 2d8 | 3d8 | 4d8 | 5d8 | 6d8 |

Cabe uma Melhoria `Leve` e uma Restrição `Leve` numa Classe 0, tirando um dado para pagar. A base de alcance da Classe 0 fica um degrau abaixo da normal, e o valor está em *Criando feitiços*.

**Classe 0 não cura.** As Formas `Cura` e `Onda` ficam de fora dela. A tabela `Cura`, em *Criando feitiços*, começa na Classe 1.

### Dado

Monte sempre em d8: pontos, Melhorias e Restrições só existem em d8. Se a sua mesa rola outro dado, converta o total final na hora de rolar.

**Dado**
| d8 | d6 | d12 | d8 | d6 | d12 | d8 | d6 | d12 |
|---|---|---|---|---|---|---|---|---|
| 1 | 1 | 1 | 11 | 14 | 8 | 21 | 27 | 15 |
| 2 | 3 | 1 | 12 | 15 | 8 | 22 | 28 | 15 |
| 3 | 4 | 2 | 13 | 17 | 9 | 23 | 30 | 16 |
| 4 | 5 | 3 | 14 | 18 | 10 | 24 | 31 | 17 |
| 5 | 6 | 3 | 15 | 19 | 10 | 25 | 32 | 17 |
| 6 | 8 | 4 | 16 | 21 | 11 | 26 | 33 | 18 |
| 7 | 9 | 5 | 17 | 22 | 12 | 27 | 35 | 19 |
| 8 | 10 | 6 | 18 | 23 | 12 | 28 | 36 | 19 |
| 9 | 12 | 6 | 19 | 24 | 13 | | | |
| 10 | 13 | 7 | 20 | 26 | 14 | | | |

A média nunca se afasta mais de 3 pontos da conta em d8.

## Escrevendo o seu Fundamento

**Você escreve o Fundamento**, na criação, junto com o mestre: o que evolui com os níveis são os feitiços que saem dele. Um Fundamento completo tem cinco partes.

> **Na criação, você escreve:**
> **1.** A **Descrição** da técnica, com o tipo de dano dela.
> **2.** A **Regra**: a frase que resume o que a técnica faz.
> **3.** As **Famílias**: duas Livres e três Fechadas.
> **4.** O **Selo**: o que você sempre faz para conjurar.
> **5.** A **Passiva Livre**, e, se a técnica pedir, uma `Regra Própria`, de graça, em Classe Passiva 1.

### Descrição

Escreva a sua técnica como quiser: de onde ela veio, como aparece, o que as pessoas veem quando ela age. A Descrição não tem efeito mecânico direto, mas é dela que o mestre vai tirar a régua para aprovar ou recusar os seus feitiços.

Anote junto o **tipo de dano** da técnica, um ou dois: corte, fogo, ácido, o que a Descrição trouxer sentido. Esse tipo vale para todos os seus feitiços.

> **Exemplo.** *Duas relíquias respondem ao chamado dela: um bastão com uma tranca na ponta, outro com uma chave. A tranca segura o instante: o que ela prende para de acontecer e continua parado até ela soltar. A chave abre distância: o que ela destrava deixa de estar onde estava. Ninguém sabe se os bastões são a técnica ou se a técnica só precisa deles para caber num corpo humano.*

### Regra

Depois da Descrição, resuma a técnica numa única frase: a Regra. Ela é o contorno da técnica, e todo feitiço que você criar, do primeiro ao último, precisa caber dentro dela.

*"Prender um instante no lugar, ou abrir a distância entre duas coisas."*
*"Cortar tudo o que eu enxergo em duas metades."*
*"Emprestar o meu peso para o que eu encostar."*

Uma boa Regra exclui coisas. "Controlar fogo" não exclui nada e vira um cheque em branco; "acender o que já passa pela minha mão" exclui bastante, e é isso que a torna interessante. O limite é o que obriga a criatividade na montagem dos feitiços.

Se estiver travado, o **Catálogo de temas** no apêndice traz 70 pontos de partida que podem ajudar.

### Famílias

As Melhorias, que são as peças que você compra para os seus feitiços, estão divididas em nove Famílias, cada uma cuidando de um tipo de efeito:

**Famílias**
| Família | Do que trata |
|---|---|
| **Alcance** | Chegar longe, se mexer, mexer o inimigo de lugar |
| **Área** | Pegar mais de um alvo, aumentar tamanho, dividir o ataque |
| **Mira** | Acertar, não errar, atravessar defesa |
| **Controle** | Derrubar, prender, calar, barreira, terreno |
| **Auxiliares** | Somar e tirar número: vantagem, defesa, CD, deslocamento |
| **Castigo** | Fazer o dano render mais |
| **Tempo** | Ação bônus, reação, deixar armado, conjurar escondido |
| **Marca** | Preparar o próximo golpe, roubar vida, rastrear |
| **Amparo** | Curar, limpar condição, levantar aliado |

Na criação, o seu Fundamento define a relação dele com essas Famílias, e é aqui que duas técnicas com a mesma Regra viram personagens diferentes.

**Duas Famílias Livres:** as Melhorias delas custam metade da Classe a menos, com mínimo de 1 ponto — tanto para a redução quanto para o mínimo que ela ainda tem de custar. *Numa Classe 1, uma Melhoria `Leve` e uma `Média` continuam custando 1, e uma `Pesada` custa 1 em vez de 2, pela redução.* É onde a sua técnica é naturalmente boa.

**Três Famílias Fechadas:** você nunca compra nada delas, em Classe nenhuma. É o que a sua técnica simplesmente não consegue fazer.

As outras quatro ficam no preço normal, e são neutras.

Na prática: uma Melhoria `Média` num feitiço de Classe 4 custa 4 pontos. Se ela for de uma Família Livre sua, o desconto de metade da Classe (2) derruba o preço para 2. Se for de uma Família Fechada, ela não está à venda.

As Formas, que são o jeito como o feitiço sai, também têm Família: `Explosão`, `Aura`, `Cone` e `Linha` são de **Área**; `Cura`, `Apoio` e `Onda` são de **Amparo**. Fechar uma dessas Famílias bloqueia as Formas dela junto. `Projétil`, `Toque` e `Efeito` são de todo mundo.

### Selo

Para conjurar, o seu personagem sempre faz a mesma coisa, seja qual for o feitiço: um gesto, um som, uma condição visível. É a assinatura da técnica, o que a mesa vê ou ouve toda vez que ela entra em cena.

Bater palma. · Dizer o nome do feitiço. · Estar enxergando o alvo. · Ter tocado no alvo nesta cena. · Estar pisando no chão.

O Selo não mexe em ponto nenhum: não custa e não dá bônus. Ele dá corpo à técnica, e quem conhece o seu Selo sabe o que procurar quando você se mexe. A única regra mecânica ligada a ele aparece nas Restrições: como o Selo já é uma obrigação sua, **uma Restrição que cobra a mesma coisa que ele não devolve ponto**.

O seu Selo tem de ser uma coisa simples, e a mesa consegue apontar o momento em que ela aconteceu. Se você precisa de mais de uma frase para explicar, aquilo virou condição de cena ou de alvo, e isso se compra por feitiço, com a Restrição `Condicional`.

**É Selo ou é `Condicional`**
| É Selo | Vira `Condicional` |
|---|---|
| Bater palma | Bater palma três vezes no ritmo certo |
| Estar enxergando o alvo | Enxergar o alvo sem que ele te enxergue |
| Ter tocado no alvo nesta cena | Ter tocado no alvo e saber o nome dele |
| Gastar o próprio sangue | Gastar sangue de alguém do seu clã |

O Selo pode mudar de forma sem perder a função: se você perde a mão que batia palma, arruma outra coisa que faça o mesmo som.

**Selos da obra**
| Selos de Jujutsu Kaisen | O Selo |
|---|---|
| Nobara (Boneco de Palha) | Martelo e prego na mão. |
| Nobara (Ressonância) | Um pedaço do alvo: sangue, cabelo, um membro. |
| Todo (Boogie Woogie) | Bater palma. Depois que perdeu a mão, um vibraslap: o som mudou de fonte, o Selo continuou. |
| Inumaki (Fala Amaldiçoada) | Falar o comando, e a garganta cobra o preço. |
| Megumi (Dez Sombras) | Um sinal de mão para cada shikigami. |
| Mahito (Transfiguração Ociosa) | Tocar no alvo. |
| Choso (Manipulação de Sangue) | Gastar o próprio sangue. |
| Nanami (Proporção) | Mirar o ponto 7:3 do corpo do alvo. |

### Passivas

Passiva é o que a sua técnica faz sem você exigir uma ação: o efeito que fica ligado enquanto você existe. Cada Passiva tem uma **Classe Passiva**, e é paga com **espaços de feitiço conhecido**. Você abre mão de saber mais feitiços para que a técnica trabalhe sozinha.

**Passivas**
| Classe Passiva | Custa | Libera no nível | O que cabe |
|---|---|---|---|
| **Livre** | nada | 1 | Narrativa pura. Não rola dado, não muda número, não faz ninguém rolar. Todo personagem pode ter uma. |
| **1** | 1 espaço | 1 | Efeito pequeno, condicional, ou de informação. |
| **2** | 2 espaços | 7 | Efeito reativo, com limite de uso por cena ou por descanso. |
| **3** | 3 espaços | 13 | Permanente. Muda como você joga. |

Máximo de cinco Passivas pagas. A Passiva Livre e a `Regra Própria` não contam.

#### Passiva Livre

Todo personagem começa com uma Passiva Livre, de graça. Ela não rola dado, não muda número nenhum e não faz ninguém rolar. Dentro desses limites, use quando e quanto quiser.

*"Você enxerga emoção como cor."* · *"Planta murcha quando você passa."* · *"Você nunca se perde."* · *"Seu reflexo aparece um segundo atrasado."* · *"Metal fica frio na sua mão."*

A Livre entrega narrativa simples: você vê o medo na cor de alguém, e descobrir o motivo do medo continua dependendo de você.

#### Limites

- Bônus de dano ou acerto que vale o tempo todo, sem condição.
- Uma ação a mais por rodada.
- Imunidade completa a um tipo de dano ou condição.
- Cura sem limite de uso por descanso.
- Redução de Dano passiva, ou seja, descontar um número fixo de todo golpe que te acerta.

#### Lista

**Lista**
| Passiva | Classe Passiva | O que faz |
|---|---|---|
| `Leitura` | 1 | Você identifica a Classe e a Forma de qualquer feitiço conjurado a até 18 m. |
| `Instinto` | 1 | Você não é pego de surpresa enquanto estiver acordado. |
| `Raiz` | 1 | Você não é movido à força nem derrubado contra a sua vontade. |
| `Mão Firme` | 1 | Você não perde concentração nem carga por dano de 10 ou menos. |
| `Farejador` | 1 | Você sente se alguém conjurou num lugar nas últimas 24 horas, e de que Classe. |
| `Aviso` | 1 | Você sabe qual foi o último feitiço que um inimigo à vista usou. |
| `Fluxo` | 2 | Ao conjurar Classe 3 ou mais, você ganha 2 × Classe de vida temporária. |
| `Recomposição` | 2 | Uma vez por descanso curto, gasta a ação e recupera 5 × a sua maior Classe em vida. |
| `Segunda Natureza` | 2 | Uma vez por dia, conjura um feitiço de Classe até metade da sua maior sem gastar PE. |
| `Eco` | 2 | Quando você derruba um inimigo com feitiço, o próximo feitiço da cena custa metade. |
| `Costura` | 2 | Uma vez por cena, um aliado a até 9 m que cairia a 0 fica com 1. |
| `Contramedida` | 2 | Como Reação, quando alguém conjura a até 9 m, gasta PE e sobe em 2 a CD daquele feitiço. |
| `Peso da Presença` | 2 | Inimigos fracos que começam o turno a até 6 m fazem Teste de Resistência ou ficam `Amedrontados` por uma rodada. |
| `Escama` | 3 | Escolha um tipo de dano que a sua Regra justifique. Você tem resistência a ele: todo dano daquele tipo cai pela metade. |
| `Afinidade` | 3 | Escolha um tema da sua Regra. Feitiços daquele tema ignoram cobertura `Parcial` e resistência ao seu tipo de dano. |
| `Reserva Profunda` | 3 | Seu PE máximo sobe em 3 × a sua maior Classe. |
| `Regra Própria` | 1 a 3 | Sua técnica impõe uma regra ao mundo. Ver abaixo. |
| `Passiva Própria` | 1 a 3 | Qualquer outra coisa, montada com o mestre na escala das outras entradas desta tabela. |

#### Regra Própria

Algumas técnicas funcionam impondo uma regra ao mundo: julgamento, aposta, contrato, dívida, sorte. Para essas existe a `Regra Própria`, escrita junto com o mestre antes de a campanha começar, obedecendo cinco travas:

- Uma frase.
- Verificável: a mesa aponta o momento em que ela disparou.
- Simétrica: vale contra você nas mesmas condições.
- Sem dano direto: gera recurso, condição ou obrigação.
- Com limite por cena.

Na criação, a `Regra Própria` vem de graça em Classe Passiva 1: ela não gasta espaço de feitiço, e a Classe Passiva 1 é o teto dela até os níveis liberarem as alturas maiores. Quando isso acontecer, ela sobe para 2 e 3 pagando só a diferença para a Classe Passiva 1: 1 espaço para a Classe Passiva 2, e 2 para a 3.

*"Quem me atacar sabendo que eu não revidei acumula uma Dívida. Cobro uma por cena."*
*"Quando eu aposto e ganho, meu próximo teste na cena tem vantagem. Uma vez por cena."*
*"Duas coisas que eu tocar na mesma rodada ficam ligadas até o fim da cena."*

## Fundamentos prontos

Três Fundamentos completos, prontos para usar como estão ou para servir de régua na hora de escrever o seu. A **Régua** volta em *Criando feitiços* para montar o primeiro feitiço do capítulo.

Os três param onde a criação de personagem para: Descrição, Regra, Famílias, Selo e, quando a técnica pede, a Passiva.

### Régua

**Ficha de feitiço**
| | |
|---|---|
| **Descrição** | Ele mede. Aponta o dedo, calcula a distância até o alvo e cobra essa distância do corpo do outro. A mão dele fica parada, e o corte aparece sozinho no outro lado. Quanto mais longe, mais fundo. Tipo de dano: corte. |
| **Regra** | *"Medir a distância entre dois pontos e cobrar por ela."* |
| **Livres** | Mira · Alcance |
| **Fechadas** | Área · Amparo · Auxiliares |
| **Selo** | Apontar com o dedo e falar o alvo em voz alta. |

### Sentença

**Ficha de feitiço**
| | |
|---|---|
| **Descrição** | Ela só registra. Cada coisa que acontece perto dela fica anotada em algum lugar que ninguém vê, e uma hora a conta fecha. O que ela cobra quando fecha é o que a pessoa devia. Tipo de dano: psíquico. |
| **Regra** | *"Registrar o que foi feito e cobrar quando fechar a conta."* |
| **Livres** | Marca · Castigo |
| **Fechadas** | Área · Alcance · Amparo |
| **Selo** | Ter visto o ato com os próprios olhos. |
| **Passiva** | `Regra Própria` (Classe Passiva 3): *"quem ferir alguém desarmado na minha frente acumula uma Dívida. Posso cobrar uma Dívida por cena: o alvo tem desvantagem no próximo teste e eu tenho vantagem contra ele até o fim do meu próximo turno."* |

### Banca

**Ficha de feitiço**
| | |
|---|---|
| **Descrição** | Ele joga. É a pura representação de uma aposta: moeda no ar, carta virada, um dado rolando, pura sorte. O golpe em si paga pouco, porque o prêmio de verdade fica guardado com a banca, e a banca fecha a conta quando ele ganha. Tipo de dano: impacto. |
| **Regra** | *"Apostar contra a sorte e cobrar o prêmio."* |
| **Livres** | Auxiliares · Marca |
| **Fechadas** | Área · Alcance · Castigo |
| **Selo** | Falar a aposta em voz alta. |
| **Passiva** | `Regra Própria` (Classe Passiva 1 na criação, subindo com os níveis): *"quando eu aposto e ganho, meu próximo teste na cena tem vantagem. Uma vez por cena."* |

## Criando feitiços

Com o Fundamento escrito, os feitiços saem dele. Montar um feitiço é uma conta curta: escolher o tamanho, escolher como ele sai, gastar os pontos e dar um nome.

### Teto de feitiços

Antes de montar o primeiro, veja quantos você tem direito de escrever. A conta é do capítulo 19, *Experiência e Progressão*.

> **Espaços de feitiço conhecido = `2 + (nível ÷ 2)`, arredondando para baixo. Mais um por marco já alcançado.**
> Os marcos são os níveis **6, 10, 14, 18, 22, 26 e 30**.

Na prática, você abre um espaço novo **a cada nível par**, e nos marcos abre dois de uma vez.

**Teto de feitiços**
| Seu nível | 1 | 2 | 5 | 10 | 14 | 20 | 26 | 30 |
|---|---|---|---|---|---|---|---|---|
| **Espaços** | 2 | 3 | 4 | 9 | 12 | 16 | 21 | 24 |

Duas coisas dividem esses espaços com os seus feitiços: cada **Passiva** paga custa de 1 a 3 espaços, e a **Expansão de Domínio** custa 2 ou 3. O resto vira feitiço montado.

Ficam **fora** da conta os feitiços de **Classe 0**, que são contados à parte, e as **Liberações Máximas**, que não ocupam espaço nenhum.

> **Exemplo.** Mei está no nível 10. São 9 espaços: `2 + 5` da conta, mais 2 dos marcos 6 e 10. Ela já gastou 2 numa **Passiva de Classe Passiva** 2, então tem **7 feitiços montados** na ficha, mais os 3 de **Classe 0** e a **Liberação Máxima** que o nível 10 acabou de dar.

### Passos

1. Escolha a **Classe**, até a maior que o seu nível liberou. Ela define os pontos (3 × Classe), o custo em PE (o mesmo número) e quantas Melhorias e Restrições cabem.
2. Escolha a **Forma**: como o feitiço sai de você. Algumas Formas custam pontos; nenhuma conta no limite de Melhorias.
3. Compre **Melhorias** e, se quiser recuperar pontos, venda **Restrições**.
4. O que sobrar de ponto vira dado: **1 ponto = 1d8 de dano**.
5. Dê um nome e escreva na ficha.

> **Dados de dano = Pontos − Melhorias + Devolução**
> A devolução das Restrições nunca passa do que você gastou em Melhoria: se devolver mais, o excedente some. É por isso que Restrição barateia o feitiço e nunca aumenta o dano dele.

### Exemplo guiado: o primeiro feitiço da Régua

A **Régua** mede distâncias e cobra por elas. As Famílias Livres dela são Mira e Alcance; as Fechadas são Área, Amparo e Auxiliares. O jogador quer o golpe básico da técnica: um corte disparado à distância, que atravesse armadura.

**Passo 1, Classe.** O personagem está no nível 5, então a maior Classe dele é 2. Isso dá **6 pontos**, custo de 6 PE, e os limites da Classe: até 2 Melhorias, até 2 Restrições, devolução máxima de 4.

**Passo 2, Forma.** `Projétil`: 18 m, um alvo, rolagem de acerto. Não custa ponto.

**Passo 3, Melhorias e Restrições.** `Fura` (Mira, `Média`) custaria 2 pontos numa Classe 2, mas Mira é Família Livre da Régua: o desconto de metade da Classe (1) derruba o preço para **1 ponto**. `Precisão` (Mira, `Leve`) custa 1 e fica em 1, porque o desconto nunca leva um preço abaixo de 1. Foram 2 pontos em Melhoria, sobrariam 4. Para recuperar um, ele vende `Parado` (devolve 1): a Régua precisa dos pés no chão para medir, então não se move no turno em que conjura. A devolução paga 1 dos 2 pontos gastos.

**Passo 4, dano.** 6 − 2 + 1 = **5 pontos sobrando: 5d8 de corte**, uma média de 22.

**Passo 5, nome.** Está pronto, e vai para a ficha assim:

**Ficha de feitiço**
| | |
|---|---|
| **Nome** | `Corte Medido` |
| **Classe / Pontos / PE** | 2 · 6 pontos · 6 PE |
| **Forma** | `Projétil` (18 m, um alvo) |
| **Resolve com** | Rolagem de acerto, com +2 da `Precisão` |
| **Melhorias** | `Fura` (−1, Livre) · `Precisão` (−1, Livre) |
| **Restrições** | `Parado` (+1) |
| **Dano** | 5d8 = 22, ignorando até 4 de Redução de Dano (2 × Classe) |
| **Ação** | Padrão |
| **Como é** | Ele para, aponta, diz o nome do alvo, e a distância medida abre no corpo do outro, como um corte de papel do tamanho do caminho. |

> **Erros comuns**
> **Vender Restrição sem Melhoria para pagar.** A devolução some. O `Golpe Cru`, em *Feitiços prontos*, é um exemplo disso.
> **Contar que Restrição vira dado.** Nunca vira: contra um alvo só, 6 pontos continuam sendo o máximo de dados de uma Classe 2, com ou sem Restrição.
> **Empilhar duas Restrições de frequência** (`Uma Vez`, `Condicional`, `Aquecer`, `Dívida`). Não pode, e *Combinações inviáveis* explica a trava.

### Formas

A Forma define quem o feitiço atinge e como ele se resolve. Escolha uma por feitiço.

**Formas**
| Forma | Custa | O que é | Como resolve |
|---|---|---|---|
| `Projétil` | — | 18 m, um alvo | Rolagem de acerto |
| `Toque` | — | 1,5 m, um alvo. `Projétil` com a Restrição `Corpo a Corpo` embutida (devolve `Média`). | Rolagem de acerto |
| `Explosão` | `Leve` | Esfera de raio 3 m, num ponto a até 18 m | Teste de Resistência, metade no sucesso |
| `Aura` | `Leve` | Esfera de raio 3 m centrada em você. `Explosão` com `Corpo a Corpo` embutida (devolve `Média`). | Teste de Resistência, metade no sucesso |
| `Cone` | `Leve` | 4,5 m saindo de você. A largura do cone em qualquer ponto é igual à distância daquele ponto até você. | Teste de Resistência, metade no sucesso |
| `Linha` | `Leve` | 18 m por 1,5 m. Quando o comprimento chega ao topo da escada, `Maior` passa a subir a largura: 1,5 m → 3 m → 4,5 m. | Teste de Resistência, metade no sucesso |
| `Cura` | `Média` | Um aliado a até 9 m. Os dados viram cura. Pode escolher alvo hostil. | Automático no aliado, acerto no hostil |
| `Apoio` | — | Um aliado a até 9 m. Sem dano. Cada ponto que sobra vira 3 de vida temporária. | Automático |
| `Onda` | `Pesada` | Esfera de raio 3 m centrada em você. A cura ou o apoio pega todos os aliados dentro, sem dividir. | Automático |
| `Efeito` | — | Fora de combate. Sem dano. Ver *Fora de combate*. | Automático |

Trocar rolagem de acerto por Teste de Resistência, ou o contrário, é de graça.

Cada Forma pertence a uma Família: `Explosão`, `Aura`, `Cone` e `Linha` à **Área**; `Cura`, `Apoio` e `Onda` ao **Amparo**. Fundamento com a Família Fechada fica sem essas Formas. `Projétil`, `Toque` e `Efeito` são de todo mundo.

#### Base por Classe

**Base por Classe**
| Forma | Classe 0 | Classes 1 a 5 | Classes 6 e 7 |
|---|---|---|---|
| `Projétil` e `Toque` | 9 m | 18 m | 36 m |
| `Explosão` | raio 3 m, a 9 m | raio 3 m, a 18 m | raio 4,5 m, a 36 m |
| `Aura` | raio 3 m, em você | raio 3 m, em você | raio 4,5 m, em você |
| `Cone` | 3 m | 4,5 m | 9 m |
| `Linha` | 9 × 1,5 m | 18 × 1,5 m | 30 × 1,5 m |
| `Apoio` | 4,5 m | 9 m | 18 m |
| `Cura` e `Onda` | — | 9 m | 18 m |

`Toque` fica em 1,5 m em qualquer Classe.

### Escadas

Alcances e tamanhos crescem por degraus fixos. As Melhorias de Alcance e Área (`Longe`, `Maior` e as irmãs) sobem degraus nestas escadas:

**Escadas**
| Escada | Degraus |
|---|---|
| **Alcance** | 1,5 m → 9 m → 18 m → 36 m → 90 m → o que você enxergar |
| **Esfera (raio)** | 3 m → 4,5 m → 6 m → 9 m → 15 m |
| **Cone e Linha** | 4,5 m → 9 m → 18 m → 30 m → 60 m |

O degrau "o que você enxergar" vale para olho nu. Câmera, luneta, espelho e visão emprestada não contam.

Se uma Melhoria subir mais degraus do que a escada tem, ela para no último degrau.

### Ampliar

Você pode lançar qualquer feitiço que conhece numa Classe maior que a original, até a sua Classe máxima, pagando o PE da Classe nova. Refaça a conta inteira com os números novos: pontos, preços de Melhoria e devoluções de Restrição mudam todos juntos.

**Ampliar**
| `Palma Trovejante` · Classe | Pontos | `Cone` (Leve) | `Derrubado` (Leve) | `Atrasar` (devolve) | Dano | PE |
|---|---|---|---|---|---|---|
| Classe 2 (original) | 6 | −1 | −1 | +2 | 6d8 = 27 | 6 |
| Classe 3 | 9 | −2 | −2 | +3 | 8d8 = 36 | 9 |
| Classe 5 | 15 | −3 | −3 | +5 | 14d8 = 63 | 15 |

Ampliar aumenta o número e não muda a natureza do feitiço.

### Cura

A Forma `Cura` custa `Média` e transforma em cura os dados que sobrarem, aplicados automaticamente num aliado a até 9 m. Não existe Liberação Máxima de cura: a linha de baixo é o teto por Classe.

Para pegar mais gente: `Junto` (Amparo) soma um aliado dividindo o efeito, e a Forma `Onda` cura em área sem dividir.

A Forma `Cura` pode escolher um alvo hostil em vez de um aliado. Nesse alvo ela deixa de ser automática e pede rolagem de acerto, como qualquer feitiço de dano. Contra uma maldição os dados viram dano, com `50%` a mais; contra qualquer outra coisa ela não faz nada. É energia positiva machucando maldição, e ela precisa da aptidão `Energia Reversa` para funcionar — sem ela, apontar este feitiço num inimigo não produz nada.

Os `50%` não são bônus. A cura já rende dois terços do dano da mesma Classe, e somar metade em cima devolve exatamente a linha cheia: um `Classe 5` assim causa `67`, que é o dano daquela Classe. E esta rota nunca é a melhor escolha, porque ela custa a `Média` da Forma e um `Projétil` custa nada e fere qualquer coisa.

**Cura**
| Classe | 1 | 2 | 3 | 4 | 5 |
|---|---|---|---|---|---|
| **Cura cheia** | 2d8 = 9 | 4d8 = 18 | 6d8 = 27 | 8d8 = 36 | 10d8 = 45 |
| **`Onda` (área)** | 1d8 = 4 | 3d8 = 13 | 4d8 = 18 | 6d8 = 27 | 7d8 = 31 |
| **Dano da mesma Classe** | 13 | 27 | 40 | 54 | 67 |

### Controle

Feitiço que carrega pelo menos uma Melhoria da família **Controle** ganha um bônus quando abre mão da maior parte do dano dele.

> Se o dano final for **um quarto do teto** (o teto é 4 × Classe): os efeitos de Controle duram uma rodada a mais.
> **Sem dano nenhum**, ou seja, o feitiço gastou tudo em Controle e outras Melhorias: além da rodada extra, a CD contra esses efeitos sobe **+2**.

O bônus vale só contra os efeitos de Controle do feitiço. O Teste de Resistência do dano, quando existe, fica como está.

Por exemplo, num Classe 4 o teto é 16 dados: sobrar até 4 dados de dano já dá a rodada extra, e sobrar zero dá também o `+2` na CD.

**Controle**
| Feitiço de Classe 5 · 15 pontos · teto 20 · um quarto = 5 | Dano final | O que ganha |
|---|---|---|
| 15d8 puro, sem Controle | 15d8 | nada |
| `Condição` Leve (−3) | 12d8 | nada: ainda bate como feitiço de dano |
| `Condição` Média (−5) | 10d8 | nada |
| `Condição` Pesada (−8) | 7d8 | nada |
| `Condição` Pesada (−8) · `Condição` Média (−5) | 2d8 | dura uma rodada a mais |
| `Explosão` (−3) · `Cond.` Média (−5) · `Prende` (−5) · `Puxa` (−5) · `Parado` (+3) | 0d8 | uma rodada a mais e CD +2 |

Uma condição sozinha nunca dispara o bônus. Para chegar no primeiro degrau você compra duas peças de Controle, ou uma condição e alguma outra coisa cara. E para o segundo, o feitiço precisa sair sem um único dado de dano.

## Melhorias por família

O preço de cada uma depende da Classe do feitiço em que ela entra: `Leve` custa metade da Classe, `Média` custa a Classe inteira, `Pesada` custa Classe e meia, sempre arredondando para cima.

Exemplo: num feitiço de Classe 3, uma `Leve` custa 2 pontos, uma `Média` custa 3 e uma `Pesada` custa 5. Nas suas duas Famílias Livres, tire metade da Classe do preço, com mínimo de 1; nas três Fechadas, não há o que comprar.

### Alcance

Essas Melhorias resolvem distância: o feitiço chega mais longe, ou você se move junto com ele.

**Alcance**
| Melhoria | Custo | O que faz |
|---|---|---|
| `Longe` | `Leve` | Sobe um degrau na escada de alcance. Pode comprar duas vezes. |
| `Muito Longe` | `Média` | Sobe três degraus de uma vez. |
| `Sem Ver` | `Pesada` | Você conjura contra um alvo fora da sua linha de visão, desde que saiba onde ele está. Alcance normal do feitiço. |
| `Passo` | `Leve` | Você anda até 6 m antes ou depois do feitiço, sem provocar ataque de oportunidade. |
| `Empurrão` | `Leve` | Move o alvo até 6 m na direção que você quiser. |
| `Troca` | `Média` | Você e o alvo trocam de lugar. |
| `Perseguir` | `Média` | Se o alvo sair do alcance antes de o feitiço concluir, o feitiço vai atrás. |

### Área

Aqui o feitiço para de mirar uma pessoa só: ele cresce, se divide em vários tiros, ou pula de alvo em alvo.

**Área**
| Melhoria | Custo | O que faz |
|---|---|---|
| `Maior` | `Leve` | Sobe um degrau de tamanho de área. Pode comprar duas vezes. |
| `Muito Maior` | `Pesada` | Sobe três degraus de tamanho de uma vez. |
| `Escolher` | `Média` | Você decide quem, dentro da área, é atingido. |
| `Fica` | `Média` | A área continua ali por 1 minuto. Quem entrar ou começar o turno nela leva metade dos dados. Exige concentração. |
| `Mais Um` | `Leve` | Um alvo a mais. Os dados são divididos entre os alvos. Pode comprar duas vezes. |
| `Rajada` | `Leve` | Divide o feitiço em (Classe + 1) tiros, cada um com sua rolagem de acerto, distribuídos como você quiser. |
| `Salto` | `Média` | Depois do primeiro alvo, pula para o inimigo mais perto a até 9 m com metade dos dados. |
| `Contorno` | `Leve` | A área faz curva. Ignora cobertura e dobra esquinas. |

### Mira

Garantem o acerto: menos chance de errar, mais chance de atravessar a defesa do outro.

**Mira**
| Melhoria | Custo | O que faz |
|---|---|---|
| `Precisão` | `Leve` | +2 na rolagem de acerto, ou +2 na CD do Teste de Resistência. |
| `Certeiro` | `Média` | Sem rolagem de acerto. O alvo ainda faz o Teste de Resistência para metade. |
| `Inescapável` | `Média` | Sem acerto e sem Teste de Resistência: o dano é automático. Este feitiço não pode ter mais nenhuma peça, nem Melhoria nem Restrição, e não pode ser uma Liberação Máxima. |
| `Fura` | `Média` | Ignora até 2 × Classe de Redução de Dano. |
| `Corrói` | `Pesada` | Resistência ao seu tipo de dano deixa de valer neste feitiço. Só pode ser comprada se Mira for uma das suas Famílias Livres. |
| `Sem Cobertura` | `Leve` | Cobertura `Parcial` não atrapalha. A `Total` não se fura: ela não é bônus, é a ausência de alvo legal. |
| `De Novo` | `Média` | Se você errar, rola de novo. Uma vez por cena. |
| `Toca a Alma` | `Leve` | Só da Classe 3 em diante, e só para Fundamento cuja Regra seja direta sobre alma. Os dados de dano deste feitiço viram dano na alma, e você fica com metade deles, arredondando para baixo. Não entra numa Liberação Máxima. |

### Controle

O inimigo sai da luta sem cair morto: no chão, preso, ou lutando contra o próprio terreno.

**Controle**
| Melhoria | Custo | O que faz |
|---|---|---|
| `Condição` | o nível dela | Aplica uma das treze condições. O preço é o nível dela (`Leve`, `Média` ou `Pesada`), e a seção *Condições* traz as três listas. Dura uma rodada, a não ser que o feitiço tenha a `Concentrada` ou a `Duradoura`. As de nível `Pesada` dão Teste de Resistência no fim de cada turno do alvo, e só pode ser colocada uma delas por feitiço. |
| `Terreno` | `Leve` | A área vira terreno difícil, ou fica obscurecida, por uma rodada. |
| `Anteparo` | `Média` | Deixa uma parede ou escudo com 10 × Classe de pontos de vida, por 1 minuto. Ocupa os mesmos quadrados que a `Linha` da Classe dele, arrumados como você quiser, cada um partilhando um lado com outro. Altura mínima 2 quadrados. Colocado num ponto a até o alcance do feitiço. |
| `Prende` | `Média` | O alvo não sai do lugar até o fim do próximo turno dele. Ele pode gastar uma ação — qualquer uma, menos livre — para tentar um Teste de Resistência e se soltar. O Teste é decidido na criação do feitiço. |
| `Cerca` | `Leve` | O alvo não consegue se aproximar de você até o fim do próximo turno dele. Acaba assim que você causar dano a ele — inclusive o dano do próprio feitiço que comprou esta Melhoria. |
| `Puxa` | `Média` | Todo mundo na área é puxado 6 m na direção do centro. |
| `Desarma o Feitiço` | `Média` | Cancela um efeito contínuo ou uma barreira de Classe igual ou menor que a sua. |

### Condições

São treze, e cada uma tem um **nível**: `Leve`, `Média` ou `Pesada`. O nível faz duas coisas ao mesmo tempo. Ele é o **preço** da Melhoria `Condição` que aplica ela, e é o que custa em energia para **tirar** ela de alguém (1 ponto por nível). Uma condição dura uma rodada, a não ser que o feitiço tenha a `Concentrada` ou a `Duradoura`.

Numa Classe 5, aplicar uma `Leve` custa 3 pontos, uma `Média` custa 5 e uma `Pesada` custa 8.

**Condições `Leve`**
| Nível `Leve` | O que faz |
|---|---|
| `Lento` | Deslocamento pela metade, e sem Ação Bônus. |
| `Incapacitado` | Você não pode Bloquear, e todo ataque corpo a corpo que acertar você é crítico. Só ele: conjuração e ataque à distância não, e o feitiço de Toque é conjuração mesmo encostado em você. |
| `Derrubado` | No chão. Só se move rastejando, desvantagem nos seus ataques, e quem ataca de até 1,5 m tem vantagem; de longe, desvantagem. |
| `Agarrado` | Deslocamento 0. Acaba se quem agarrou ficar `Incapacitado`, ou se algo te tirar do alcance dele. Ataque à distância contra quem está agarrando tem 50% de chance de errar o alvo: role `1d10`, e em 6 ou mais você acerta o alvo desejado; em 5 ou menos, acerta quem está agarrando. |
| `Desarmado` | A sua arma está no chão ou na mão de outro. Você bate desarmado até pegar de volta. |
| `Surdo` | Não ouve. Falha automática em teste que precise de audição, e −2 na iniciativa. |

**Condições `Média`**
| Nível `Média` | O que faz |
|---|---|
| `Calado` | Você não conjura. Nada que precise de voz, gesto ou Selo que envolva voz sai. |
| `Enfeitiçado` | Você não ataca quem enfeitiçou nem mira efeito nocivo nele, e ele tem vantagem em teste social contra você. |

**Condições `Pesada`**
| Nível `Pesada` | O que faz |
|---|---|
| `Impedido` | Deslocamento 0, desvantagem nos seus ataques e no Teste de Resistência Físico, e vantagem para quem te ataca. |
| `Cego` | Não enxerga. Falha automática em teste que precise de vista, desvantagem nos seus ataques, vantagem para quem te ataca. |
| `Amedrontado` | Desvantagem em ataque e teste enquanto enxergar a fonte do medo, e você não se aproxima dela de vontade própria. |
| `Envenenado` | Desvantagem nos seus ataques e em todo teste de perícia. |
| `Atordoado` | Você perde a Ação Padrão e não usa reação. Quem tem mais de uma Ação Padrão no turno perde só UMA delas, e guarda as demais. |

### Auxiliares

Pequenos empurrões de sorte, pros dois lados da mesa: números em cima de alguém. Em feitiço de dano valem contra o alvo; nas Formas de Amparo, valem no aliado.

**Auxiliares**
| Melhoria | Custo | O que faz |
|---|---|---|
| `Impulso` | `Leve` | O alvo tem vantagem no próximo teste dele, até o fim do próximo turno. |
| `Trava` | `Leve` | O alvo tem desvantagem no próximo ataque dele. |
| `Abre Ferida` | `Leve` | O alvo fica com −2 em um Teste de Resistência até o fim do próximo turno dele. |
| `Sobrecarga` | `Leve` | Até o fim do próximo turno do alvo, ele não usa Reação, e o feitiço dele sai com a CD 2 menor. |
| `Firmeza` | `Média` | O alvo tem vantagem no próximo Teste de Resistência dele. |
| `Guarda` | `Média` | Até o fim do próximo turno, o alvo tem +2 de defesa. |
| `Pressa` | `Média` | O alvo ganha +6 m de deslocamento e não provoca ataques de oportunidade até o fim do próximo turno. |
| `Enfraquece` | `Média` | O dano do alvo cai `Xd4` até o fim do próximo turno dele, com X sendo metade do seu atributo de técnica. |
| `Ecoa` | `Média` | O próximo ataque de um aliado contra o alvo tem vantagem. |

### Castigo

O dano que continua doendo depois do golpe: queima que volta, corte que piora contra quem já está machucado.

**Castigo**
| Melhoria | Custo | O que faz |
|---|---|---|
| `Queima` | `Média` | Metade dos dados de novo, no começo do próximo turno do alvo. |
| `Acúmulo` | `Média` | +1 dado por rodada seguida usando este feitiço no mesmo alvo. Para de somar em +3. |
| `Remate` | `Média` | +25% de dano contra alvo abaixo de metade da vida. Não entra num feitiço que tenha uma `Condicional` ligada à vida do alvo ou à duração, nem num feitiço com a Restrição `Aquecer`. |
| `Estilhaço` | `Leve` | Em crítico, ou quando o alvo falha o Teste de Resistência por 5 ou mais, metade dos dados respinga em quem estiver do lado. |
| `Quebra Coisa` | `Leve` | Dano dobrado contra barreiras, objetos e estruturas. |
| `Rasga Escudo` | `Média` | O dano ignora `vida temporária` e barreiras: bate direto na vida. Não ignora Redução de Dano. |
| `Sem Cura` | `Média` | O alvo não pode receber cura até o fim do próximo turno dele. |

### Tempo

Aqui você compra o momento do feitiço: mais rápido que o normal, disparado escondido, ou fora da sua vez.

**Tempo**
| Melhoria | Custo | O que faz |
|---|---|---|
| `Rápido` | `Pesada` | Custa Ação Bônus em vez de Ação Padrão. Não entra no mesmo feitiço que `Reação` nem com a Restrição `Atrasar`. |
| `Reação` | `Pesada` | Você conjura como Reação, a um gatilho que você declara quando monta o feitiço. Não entra no mesmo feitiço que `Rápido` nem que `Armado`, nem com as Restrições `Atrasar` e `Parado`. |
| `Armado` | `Leve` | Você gasta a ação e o PE do feitiço, e ele fica armado até o fim da cena. Na hora de armar, escolha um gatilho que a mesa consiga ver acontecer e que não seja um momento do seu próprio turno. Quando ele acontece, o feitiço sai sem gastar Reação, com alcance e alvo conferidos naquela hora. Um armado por vez. Se ele não sair, porque a cena acabou ou porque você armou outro, metade do PE volta. Não entra no mesmo feitiço que `Reação` nem com a Restrição `Carregar`. |
| `Silencioso` | `Leve` | Sem gesto, sem palavra. Usar não revela a sua posição e não exige nenhum sinal. Dispensa Selo de gesto ou de som; Selo de condição, como enxergar o alvo, continua valendo. |
| `Adianta` | `Média` | Se você conjurar antes de qualquer inimigo agir na rodada, +2 na CD. |
| `Segura` | `Leve` | Você pode adiar o efeito por até uma rodada e disparar no seu próximo turno, de graça. |
| `Concentrada` | `Leve` | Os efeitos de estado do feitiço, que hoje duram uma rodada ou até o fim do próximo turno, passam a durar o tempo da tabela `Quanto dura`. Exige concentração. Não vale para o dano, para a `Fica` nem para o `Anteparo`. |
| `Duradoura` | `Média` | A mesma coisa que a `Concentrada`, só que sem exigir concentração, e com o tempo da coluna `Duradoura` da tabela `Quanto dura`. |

> Se você conjurar um feitiço como Ação Bônus ou Reação, o único outro feitiço que cabe naquele turno é de **Classe 0**.

O tempo depende do que o feitiço faz, e o feitiço inteiro leva a menor duração entre os efeitos dele.

**Quanto dura**
| O que o efeito faz | Concentrada | Duradoura |
|---|---|---|
| Condição, buff ofensivo e debuff | 1 minuto | 1 minuto |
| Buff defensivo numérico: um bônus fixo na Defesa ou num Teste de Resistência (a `Guarda`) | 10 minutos | 1 minuto |
| Buff defensivo mecânico: resistência, imunidade, pontos de vida ou dividir dano (a `Divide`) | 10 minutos | Classe 1 e 2: 1 hora · Classe 3: 8 horas · Classe 4 em diante: 24 horas |

### Marca

O que sobra depois que o feitiço passou: uma marca no alvo, um fio que puxa energia de volta pra você.

**Marca**
| Melhoria | Custo | O que faz |
|---|---|---|
| `Marca` | `Leve` | O alvo fica marcado até o fim do seu próximo turno. **Você** tem vantagem no seu próximo ataque contra ele. Só você. |
| `Alvo de Caça` | `Leve` | O alvo fica marcado até o fim do seu próximo turno. Daí em diante, cada ataque **seu** que acertar ele causa 1d4 a mais, e o feitiço que marcou não ganha o dado. Vale arma, desarmado e feitiço com rolagem de acerto, e cada tiro da `Rajada` conta. Se este feitiço tiver o `Rápido`, o dado é 1d8. Não entram feitiço de Teste de Resistência, dano que volta em rodada seguinte como o da `Queima`, respingo, nem ataque da sua invocação. Um alvo marcado por vez: marcar outro apaga a marca anterior. |
| `Rastro` | `Leve` | Você sabe onde o alvo está por 1 hora, desde que ele esteja no mesmo plano. |
| `Sugar` | `Média` | Você recupera um quarto do dano causado, até no máximo 5 × Classe. |
| `Isca` | `Leve` | Até o fim do próximo turno do alvo, ele tem desvantagem em qualquer ataque que não mire você. |
| `Cobrança` | `Média` | Se o alvo cair nesta cena, o seu próximo feitiço custa metade. |
| `Aviso` | `Leve` | Você sabe qual foi o último feitiço que o alvo usou e de que Classe ele era. |

### Amparo

A mão que segura quem caiu. Funcionam com as Formas `Cura`, `Apoio` e `Onda` e, quando fizer sentido, em feitiço de dano que atinja aliados.

**Amparo**
| Melhoria | Custo | O que faz |
|---|---|---|
| `Limpa` | `Média` | Remove de um aliado uma condição de nível `Leve` ou `Média`. |
| `Limpa Fundo` | `Pesada` | Remove de um aliado uma condição de qualquer nível. |
| `Levanta` | `Pesada` | Um aliado caído em 0 pontos de vida volta de pé com 5 × Classe, seja qual for a vida máxima dele. Uma vez por cena. |
| `Divide` | `Média` | Um aliado a até 9 m passa a receber metade do dano que você receberia, até o fim do próximo turno. Você escolhe na hora de conjurar. |
| `Junto` | `Leve` | A cura ou o apoio pega um aliado a mais. O efeito é dividido entre eles. Pode comprar duas vezes. |
| `Reserva` | `Média` | A cura fica guardada no aliado e é usada sozinha quando ele cair abaixo da metade da vida. Dura até o fim da cena. |
| `Remenda` | `Pesada` | Devolve 5 × Classe de Integridade a um aliado. Uma vez por cena, por alvo. |

### Fora de família

**Fora de família**
| Melhoria | Custo | O que faz |
|---|---|---|
| `Efeito Próprio` | o mestre decide | Uma mecânica que não existe em lugar nenhum desta lista. Um deslocamento junto com o dano, um efeito que só funciona em superfície molhada, o que for. Um por feitiço, e ele conta como uma Melhoria no limite da Classe. Combinado antes da sessão e nunca no meio dela. Não pertence a nenhuma Família, então Família Fechada não bloqueia. |

## Restrições

Restrição é a desvantagem que você aceita em troca de pontos: o preço que a mesa vê o personagem pagando antes do golpe sair, um turno parado, um corte na própria pele, uma condição que sobra pra depois. Um feitiço carrega no máximo duas, e a devolução total não passa de **2 × Classe**. O que a Restrição devolve serve só para pagar Melhoria: se devolver mais do que você gastou, o excedente se perde. Restrição nunca vira dano.

Uma Restrição devolve `Leve` ou `Média`, nunca `Pesada`. Duas `Média` já batem no teto de devolução da Classe, então o catálogo inteiro cabe dentro do fecho.

**Restrições**
| Restrição | Devolve | O que muda |
|---|---|---|
| `Corpo a Corpo` | `Média` | `Projétil` vira `Toque` (1,5 m). `Explosão` vira `Aura`, centrada em você. `Cone` e `Linha` já saem de você, então não podem pegar esta. |
| `Atrasar` | `Média` | Custa a rodada inteira (Ação Completa): você não se move, não usa ação bônus e não faz mais nada naquele turno. |
| `Parado` | `Leve` | Você não se move no turno em que conjura. A ação bônus continua sua. |
| `Gesto` | `Leve` | Precisa das duas mãos livres e de falar em voz audível. |
| `Sangra` | `Média` | Você toma 2 × Classe de dano que não pode ser reduzido. |
| `Recuo` | `Leve` ou `Média` | Você fica com uma condição até o fim do seu próximo turno. Ela devolve o nível dela: uma condição `Leve` devolve `Leve`, uma `Média` devolve `Média`. Nível `Pesada` não entra, porque Restrição nunca devolve `Pesada`. |
| `Carregar` | `Média` | Você gasta um turno carregando o feitiço antes de disparar. Se tomar dano nesse meio-tempo, faz um Teste de Resistência de Espírito contra a CD de quem te feriu para manter. Se falhar, perde o feitiço. Carregar não é concentração: o feitiço ainda não saiu. |
| `Tudo ou Nada` | `Leve` | Quem passa no Teste de Resistência não toma nada, em vez de tomar metade. Só em feitiços de Teste de Resistência. |
| `Uma Vez` | `Leve` | Uma vez por cena. |
| `Condicional` | `Leve` ou `Média` | Só funciona quando uma condição de cena ou de alvo, escrita na ficha, é verdadeira: no escuro, marcado por você, abaixo de metade da vida, perto de água corrente. Falha em menos de uma cena a cada três: devolve `Leve`. Falha na maioria das cenas: devolve `Média`. |
| `Fraqueza` | `Leve` ou `Média` | Depois de usar, você fica com desvantagem num dos quatro Testes de Resistência, escolhido na montagem, até o fim da cena. Vigor ou Intelecto: `Leve`. Físico ou Espírito: `Média`. |
| `Frágil` | `Leve` | Se você tomar dano antes do seu próximo turno, o efeito do feitiço acaba na hora. Só serve em feitiço que deixa algo durando. |
| `Barulho` | `Leve` | Todo mundo num raio de 90 m ouve, e sabe de onde veio. |
| `Assinatura` | `Leve` | O feitiço deixa uma marca visível que dura 1 hora e aponta para você. |
| `Aquecer` | `Leve` | Não pode ser usado na primeira rodada do combate. |
| `Dívida` | `Média` | Depois de usar, o próximo feitiço que você conjurar nesta cena custa **`2 ×` a Classe deste feitiço** de energia a mais — **mesmo que ele seja de Classe 0**. |
| `Peso Morto` | `Leve` | Seu deslocamento cai pela metade até o fim do próximo turno, e você recebe `−1` no seu Teste de Resistência Físico. |
| `Sem Volta` | `Média` | Se o feitiço não acertar ninguém, você não conjura nada no seu próximo turno. |

### Restrição Própria

Se a desvantagem que você imaginou não está na lista, escreva ela. Você propõe a desvantagem e o mestre define quanto ela devolve, do mesmo jeito que o `Efeito Próprio` funciona do outro lado.

**Restrição Própria**
| Restrição | Devolve | O que muda |
|---|---|---|
| `Restrição Própria` | `Leve` ou `Média` | Uma desvantagem que não existe nesta lista. Escrita com o mestre antes da sessão, nunca no meio dela, e vale só para o feitiço onde nasceu. Conta no limite de duas Restrições e obedece as mesmas travas de todas as outras. |

**Quanto ela devolve.** A pergunta é uma só: em quantas cenas isso vai realmente atrapalhar?

- Atrapalha em menos de uma cena a cada três: `Leve`.
- Atrapalha na metade das cenas ou mais: `Média`.
- Não dá para imaginar uma cena em que atrapalhe: **não devolve nada**, e não vale como Restrição.

Nenhuma Restrição do capítulo devolve `Pesada`, e a Própria também não. Duas `Média` já batem exatamente no teto de devolução da Classe (2 × Classe). Se a dor que você escreveu parece valer mais que uma `Média`, ela provavelmente são duas Restrições disfarçadas de uma. Separe.

> **Na dúvida, para que lado errar.**
> `Efeito Próprio` na dúvida é `Pesada`. `Restrição Própria` na dúvida é `Leve`, ou não serve como uma.

As travas valem igual: a Própria precisa ser uma coisa que a mesa consegue apontar acontecendo, não pode cobrar o que a outra Restrição do feitiço já cobra, e não pode repetir o que o seu Selo já obriga. Se ela limita **quando** o feitiço sai, ela conta como Restrição de frequência para a regra abaixo.

### Combinações inviáveis

Restrição precisa ser uma coisa que a mesa consegue apontar acontecendo, e algumas combinações são proibidas de saída.

**As suas duas Restrições não podem ser as duas de frequência.** `Uma Vez`, `Condicional`, `Aquecer`, `Dívida` e qualquer `Restrição Própria` que faça a mesma coisa limitam quando o feitiço sai; escolha no máximo uma delas.

**Duas Restrições não podem cobrar a mesma coisa:** dois turnos de preparo, duas condições no seu corpo, dois jeitos de te entregar. Se as duas doem no mesmo momento, a segunda não devolve nada.

**Restrição que o seu Selo já obriga não devolve ponto.** Você já carrega o Selo de qualquer jeito, e vender a mesma dor duas vezes não vale ponto novo.

Depois de três sessões, o mestre revisa as Restrições em jogo. As que nunca atrapalharam são trocadas, a não ser que o feitiço nunca tenha vindo a uso.

## Fora de combate

Nem tudo que a sua técnica faz precisa de rolagem ou de montagem. Fora de combate, duas regras cobrem o resto: o Uso Livre, para coisa pequena, e a Forma `Efeito`, para coisa grande.

### Uso Livre

De graça e sem rolar nada, você faz qualquer coisa que caiba na sua Regra e passe nos três testes:

1. Não rola dado e não faz ninguém rolar.
2. Não tira nem dá vida, não aplica condição, não mexe em rolagem de ninguém e não move nada que resista.
3. A escala cabe na Classe 0 da tabela `Forma Efeito`: coisa de mão.

Falhou em um dos três, é feitiço: monte e pague. Passou nos três, funciona, mesmo que resolva a cena.

A régua geral é essa: **perceber é Livre, interferir é feitiço**. E o que você percebe vem cru: a cor do medo aparece, o motivo continua por sua conta.

**Uso Livre**
| Uso Livre | Vira feitiço |
|---|---|
| Aquecer uma xícara | Aquecer uma sala inteira |
| Marcar uma parede | Marcar uma pessoa |
| Saber de onde vem o vento | Saber onde está uma pessoa |
| Iluminar um corredor | Cegar quem está no corredor |
| Ver a cor da emoção de alguém | Saber o que a pessoa vai fazer |
| Fazer uma folha cair mais devagar | Fazer uma pessoa cair mais devagar |
| Abafar o som dos seus passos | Abafar o som de uma sala |
| Achar a fechadura no escuro | Abrir a fechadura sem chave |
| Saber se mexeram num objeto seu | Saber quem mexeu |
| Estabilizar a própria mão | Estabilizar a mão de outra pessoa |

### Forma Efeito

Quando a coisa é grande o bastante para mudar uma cena, monte um feitiço com a Forma `Efeito`. Ele não causa dano e não rola dado: a Classe define sozinha o que o efeito alcança e por quanto tempo dura, pela tabela `Forma Efeito`.

Em um feitiço de `Efeito`, os pontos da Classe servem só para comprar Melhorias. Ponto que sobrar não vira nada, porque a escala já está paga pela Classe.

**Forma Efeito**
| Classe | O que cabe | Quanto dura |
|---|---|---|
| **0** | Coisa de mão: acender uma vela, trancar uma porta, marcar um objeto. | até você desfazer |
| **1** | Uma pessoa, um objeto pequeno, um cômodo apertado. | um minuto |
| **2** | Um cômodo grande, uma parede, um carro, meia dúzia de pessoas. | dez minutos |
| **3** | Uma casa, um quarteirão, uma dúzia de pessoas. | uma hora |
| **4** | Um prédio, uma rua inteira, uma multidão. | um dia |
| **5** | Um bairro, uma noite inteira, o clima do lugar. Um prédio dormindo ao mesmo tempo, um rio parando de correr, uma ponte que não deixa ninguém passar. | uma semana |
| **Máxima** | Uma cidade, uma coisa que vira notícia. Todo mundo esquecendo um nome, um bairro de onde ninguém sai, uma noite que não amanhece. | até alguém desfazer |

Melhorias funcionam normalmente: `Longe` e `Maior` sobem alcance e escala, `Fica` estende a duração para o degrau seguinte da tabela, `Silencioso` esconde a conjuração.

Feitiço de `Efeito` custa PE igual a qualquer outro e ocupa espaço na sua lista.

> **Exemplo.** `Hora Morta` · Classe 3 · `Efeito` · `Longe` (−2)
> Um quarteirão inteiro para de fazer barulho por uma hora. Portas não rangem, tiro não estala, ninguém grita alto o bastante para ser ouvido de fora.
> Custa 9 de PE.

## Liberação Máxima

No nível 10, o personagem aprende a romper o próprio limite. **Só a Liberação Máxima passa dos pontos da Classe em dano contra um alvo só.** É o pico de dano que a ficha alcança, sem uma Técnica Máxima ou bônus.

Liberação não se improvisa. Ela é escrita antes da sessão, montada como qualquer feitiço, e fica anotada na ficha com nome próprio.

> **Liberação Máxima**
> Você ganha uma no **nível 10**, outra no **20** e outra no **30**.
> Cada uma é um feitiço de **Classe 3 ou mais**, montado normalmente, que **não ocupa espaço** na sua lista de feitiços conhecidos.
> **+Classe em dados de dano** em cima do que a montagem der. Numa Classe 5, +5d8.
> Custa a rodada inteira e **+50% de PE**, arredondando para cima.
> Escolha o preço na hora de disparar:
> **Vazio**: você conjura nada no seu próximo turno.
> **Sangue**: você toma 4 × Classe de dano irredutível, direto na vida.
> **Peso**: você fica `Lento` e com desvantagem em Testes de Resistência até o fim do seu próximo turno.
> Não serve para cura, e a Técnica Máxima não é uma Liberação.

Fora isso, ela é um feitiço como os outros: aceita Melhorias e Restrições dentro dos limites da Classe, obedece a Regra e as Famílias Fechadas, e pode ser Ampliada. Ao subir de nível, você pode reescrevê-la do zero, como qualquer feitiço.

> **Exemplo.** `Golpe do Voto` · Liberação Máxima · Classe 5 · `Projétil`
> Sem Melhoria e sem Restrição: os 15 pontos viram 15d8, e a Liberação soma +5d8.
> **20d8 = 90 de dano**, o pico do nível 20.
> PE: 15 + 50% = 22,5, arredondando para cima: **23**.
> Rodada inteira, mais o preço escolhido na hora.

## Técnica Máxima

No nível 17, a técnica ganha o golpe que carrega o nome dela. O dano da Técnica Máxima é **fixo**, definido pela sua faixa de nível, e nenhum ponto compra mais dados. O que você monta é a Forma e as Melhorias que vestem esses dados.

**Técnica Máxima**
| Nível | Dano (fixo) | Pontos de montagem | PE |
|---|---|---|---|
| **17 a 20** | 24d8 = 108 | 8 | 25 |
| **21 a 25** | 28d8 = 126 | 8 | 30 |
| **26 a 30** | 32d8 = 144 | 12 | 35 |

> **Três números, três papéis.**
> **O dano é fixo.** Os 24d8 da faixa 17 a 20 já vêm prontos: você não compra dado, não vende dado, e Restrição não entra aqui.
> **Os pontos de montagem compram só a Forma e as Melhorias.** São um orçamento à parte, gasto nos preços da sua **maior Classe**. Na faixa 17 a 20, isso significa preços de Classe 5: `Leve` 3, `Média` 5, `Pesada` 8. Ponto de montagem que sobrar se perde, e não vira dado.
> **O PE tem fórmula própria.** A Técnica Máxima não tem Classe, então não custa 3 × Classe como um feitiço: custa **5 × a sua maior Classe**, ou seja, 25, 30 e 35 PE por faixa.

### Montagem

1. Escolha a **Forma**. `Projétil` e `Toque` são de graça; as outras custam o preço normal delas, pago do orçamento de montagem.
2. Gaste o resto do orçamento em **Melhorias**, nos preços da sua maior Classe. Melhoria que escala com Classe, como `Fura`, que ignora 2 × Classe de RD, também usa a sua maior Classe.
3. Dê um nome e escreva na ficha. Como a Liberação, a Técnica Máxima não se improvisa na mesa.

Custa **a rodada inteira** e 5 × a sua maior Classe de PE. Depois de usar, você só usa de novo depois do fim do seu **terceiro turno seguinte**.

Ela aceita qualquer Forma. Numa Forma que não causa dano, os dados viram escala pela linha `Máxima` da tabela de `Efeito`, ou viram cura.

**Não aceita Restrição.** Ela também não conta como Liberação Máxima, porque os dados dela já são fixos. Quem passa no Teste de Resistência reduz o dano em **um quarto**, não pela metade. Famílias Fechadas continuam fechadas.

Se a sua mesa quiser que pese mais, use uma vez por cena em vez do recarregamento por turnos.

> **Exemplo: duas Técnicas Máximas da faixa 17 a 20.**
> `O Fim da Linha`: Forma `Linha` (`Leve` na Classe 5: 3 pontos) + `Muito Longe` (`Média`: 5 pontos) = 8 dos 8 pontos de montagem. A linha sobe da base de 18 m até o fim da escada: 60 m. **24d8 = 108 de dano** em tudo na linha. Rodada inteira, 25 de PE.
> `Ponto Final`: `Projétil` (grátis) + `Fura` (`Média`: 5 pontos) = 5 dos 8; os 3 que sobram se perdem. **24d8 = 108**, ignorando 10 de Redução de Dano (2 × Classe 5). Rodada inteira, 25 de PE.

## Expandindo o seu Domínio

Estender a sua técnica sobre o terreno: por alguns instantes, o lugar em volta deixa de obedecer ao mundo e passa a obedecer a você. É o topo do que um feiticeiro consegue alcançar, e quase nenhum chega lá.

Ela é **comprada**, com espaços de feitiço conhecido, e só abre quando o seu nível e o seu **refino** alcançam os dois mínimos.

> **Refino, em uma linha.**
> O refino é o eixo de controle da sua ficha: quanto da sua energia você não desperdiça. Ele é do capítulo 12, *Aptidões e Refino*, sobe com os seus marcos e vai de 1 a 10.
> Aqui ele é lido em cinco lugares e nada mais: **o requisito**, **o tamanho do domínio**, **o desconto lá dentro**, **quanto tempo o domínio fica de pé** e **quem conquista quando dois domínios se sobrepõem.**

### Degraus

**Degraus**
| Degrau | Custa | Abre em | O Acerto dela |
|---|---|---|---|
| **Incompleta** | 2 espaços | nível 10 e refino 4 | resolve por rolagem, como um feitiço |
| **Completa** | 3 espaços (+1) | nível 14 e refino 5 | **acontece.** Sem rolagem e sem Teste de Resistência |
| **Sem Barreiras** | 5 espaços (+2) | refino 10 e especialização em `Ocultismo` | **acontece**, com barreira ou sem, e você escolhe a cada abertura |

**A completa exige ter a incompleta**, e paga só a diferença: um espaço a mais, no molde da `Regra Própria`.

**A Expansão sem Barreiras exige ter a completa**, e paga só a diferença: dois espaços a mais. O requisito é o refino no teto e **especialização em `Ocultismo`**, a perícia que cobre barreira, sem nível mínimo.

**A completa fecha barreira, e a incompleta não:** a incompleta é a técnica derramada no terreno, sem parede em volta. **A Expansão sem Barreiras escolhe a cada abertura.**

O teto do feitiço não muda por causa dela, e as três ficam **fora** da conta de Liberações Máximas.

### Acerto e Efeito

Um domínio tem duas peças, e elas fazem coisas diferentes. Escreva as duas com o mestre antes da campanha, uma frase cada, e as duas precisam caber na **Regra** da sua técnica.

**Acerto e Efeito**
| Peça | A pergunta que ela responde |
|---|---|
| **Acerto** | O que o domínio *garante que acontece* com quem está lá dentro. |
| **Efeito** | O que o domínio *permite você fazer* lá dentro que você não faria fora. |

**O Acerto vem em três formas, e a sua é uma delas:** o que a sua técnica já faz passa a acertar, todos no ambiente recebem alguma coisa, ninguém no ambiente pode fazer alguma coisa.

> **Duas réguas para o Acerto.**
> **Se o seu Acerto é dano que sempre acerta**, a régua é a Melhoria `Inescapável`: ela custa uma `Média` e proíbe o feitiço de ter qualquer outra peça. Um Acerto que entrega dano garantido paga o mesmo tipo de preço: ele é o feitiço inteiro, e não sobra orçamento para mais nada em cima.
> **Se o seu Acerto é uma regra sobre o ambiente**, a régua são os requisitos da `Regra Própria`: uma frase, verificável, sem número solto. O mestre aponta o momento em que ela vale, e ela vale igual para todo mundo lá dentro, inclusive para você.
### Abrir o Domínio

**Custa a rodada inteira**, e as duas cobram **6 × a sua maior Classe** de PE.

**O Acerto acontece no momento em que você abre**, e de novo no começo de cada turno seu.

**Lá dentro os seus feitiços ficam mais baratos:** −⅓ do refino de PE na incompleta, **−metade do refino** na completa. **Nenhum feitiço custa menos de 1 PE.**

**Você pode mover o domínio, desde que ele seja o completo.** Se estiver com os pés no chão, gaste o seu deslocamento e a expansão inteira vai junto, e quem está lá dentro não percebe que se mexeu.

**Dura metade do refino em rodadas**, no mínimo uma.

**O domínio tem raio de `1,5 m` × refino.** A incompleta para em `7,5 m`.

**Raio do domínio**
| Refino | 4 | 5 | 6 | 8 | 10 |
|---|---|---|---|---|---|
| Incompleta | 6 m | 7,5 m | 7,5 m | 7,5 m | 7,5 m |
| Completa | — | 7,5 m | 9 m | 12 m | 15 m |

> **A expansão conta como feitiço para a regra de ouro nº 6:** *feitiço em Ação Bônus ou Reação só permite mais um de Classe 0 no turno.*

### Barreira e Rescaldo

Só a completa levanta barreira, e a Expansão sem Barreiras quando você escolhe fechar. Por dentro ela **não quebra**. *A única chance de quebrá-la é achar a borda da expansão, o que é considerado quase impossível. Se o mestre decidir que existe uma borda, a vida do interior é o dobro da do exterior, e ela tem resistência a todos os tipos de dano.* Por fora ela tem 50 × metade do refino de vida, e cair antes da hora é o único jeito de alguém encurtar o seu domínio.

*O mestre pode declarar que uma barreira cede fora dessa conta*: três domínios se atravessando, uma fraqueza que a ficção já estabeleceu, uma cena que pede. É exceção declarada, e não a régua.

> **Quando o domínio acaba, de qualquer jeito, a sua técnica queima.** Vale igual nos três casos: você desfez por vontade, o tempo correu, ou estilhaçaram a barreira.
> Pelo resto da cena a sua técnica não responde, e você fica com o Classe 0, com o corpo e com o que não for técnica.
> Isso é **preço**: acontece em todo uso, e você já sabia disso quando abriu.
> Rescaldo e a exaustão do descanso não somam: são escadas diferentes, e esta aqui tem um degrau só.
> A aptidão `Regravação`, no capítulo 12, *Aptidões e Refino*, acaba com o Rescaldo antes do fim da cena.

### Abrir sem barreira

**A Expansão sem Barreiras é pintar o domínio no ar, sem tela.** Na obra só dois fazem isso. Quem tem o degrau escolhe a cada abertura: **fecha a barreira e ela é a completa em tudo** — preço, desconto, barreira e mover —, **ou abre sem barreira.**

**Sem barreira, abrir cobra `7 ×` a sua maior Classe de PE**, e lá dentro **cada feitiço custa maestria `× 2` a menos**. Nenhum feitiço custa menos de 1 PE.

**O raio é de `200 m`, e o centro fica onde você abriu.** Você anda livre, e a área não vai junto.

**Ela não prende ninguém.** Quem está lá dentro pode sair andando, e leva o Acerto enquanto estiver no raio.

**Quem não tem energia amaldiçoada só é atingido se o seu Acerto alcança o que não tem energia**, como o corte do Sukuna, que alcança objeto.

**Ela não tem borda.** Sem barreira não há casca para quebrar nem borda para apagar: ela acaba pelo tempo, pela corrida, pela concentração, ou com você em `0` de vida.

> **Exemplo.** No nível 26 a sua maior Classe é 7, a maestria é 4 e o refino é 10. Abrir sem barreira custa 49 PE, e um feitiço de Classe 5, que custaria 15, sai por 7. Fechando a barreira, abrir custa 42 e o mesmo feitiço sai por 10.

### Domínios da obra

**Domínios da obra**
| Quem | Acerto | Efeito |
|---|---|---|
| Megumi *(incompleta)* | todas as invocações dele ganham reforço | invocar todos os shikigami de uma vez |
| Sukuna *(sem barreiras)* | clivar e desmantelar acertam de forma garantida | alcança todos no ambiente |
| Mahito | ninguém desvia do toque dele | alcança todos no ambiente, e o toque dele passa a atravessar a expansão por completo |
| Jogo | queima todos no ambiente | amplifica a técnica |
| Dagon | os shikigami dele acertam | amplifica a técnica |
| Yuta | os feitiços das espadas acertam | todas as técnicas copiadas, em forma de espada |
| Gojo | a enxurrada de informação | tocar em alguém para poupá-lo do Acerto |
| Hakari | todos recebem a informação do domínio | o pachinko, e a regeneração que ele paga |
| Higuruma | ninguém no ambiente pode causar dano | o julgamento, e as punições que ele libera |

O Acerto do Megumi *reforça* em vez de *atingir*, e é o que dá para fazer com uma incompleta, cujo Acerto ainda rola. Os completos da lista entregam coisas que não falham.

**Efeito quase nunca é dano.** Alcance, repertório, amplificação, uma mecânica nova, controle sobre quem o Acerto pega. O dano, quando existe, mora no Acerto.

### Domínios sobrepostos

**Só existe disputa quando as áreas se sobrepõem:** você está dentro do domínio dele, ou ele abriu dentro do raio do seu. *Abrir domínio longe de um que já está de pé não encosta nele.*

**Enquanto os dois estiverem de pé, nenhum dos dois acerta garantido.** Os dois Acertos ficam desligados, e lá dentro sobra o que não dependia deles: feitiço, corpo, e o Efeito de cada um.

**São três perguntas, nesta ordem.** A primeira que separar decide, e as de baixo nem chegam a ser feitas.

**Quem conquista o domínio**
| | A pergunta | Quem leva |
|---|---|---|
| 1 | Quem tem mais refino? | o mais refinado conquista, e o domínio do outro cai na hora |
| 2 | Refino igual — o Acerto de um dos dois **não causa dano**? | esse conquista, porque um Acerto que não fere se estabelece antes |
| 3 | Iguais nas duas — os dois rolam **1d12** | separaram por **4 ou mais**: o maior conquista |
| 4 | O d12 não separou | ninguém conquista ainda, e vale a corrida |

**A corrida.** Os dois domínios seguem de pé, os dois Acertos seguem desligados, e a luta corre normal. **O primeiro dos dois que perder o domínio** — barreira derrubada por fora, o tempo acabou, ou falhas de concentração demais — **ou chegar a `0` de vida recebe o Acerto do outro na hora.**

**Na corrida, segurar o domínio pede concentração.** Quem mantém um domínio e toma dano faz um **Teste de Resistência de Vigor contra a CD de quem te feriu**, a mesma rolagem da Concentração. Cada falha fica marcada até a corrida acabar, e **quando as falhas chegam a metade da sua Essência, o seu domínio cai**.

**Personagem de jogador testa a cada dano que toma, sem limite. Inimigo testa no máximo uma vez por jogador que acertou ele na rodada**, por mais golpes que esse jogador dê, e contra a maior CD entre eles. **Golpe de invocação não conta:** ele tira vida do inimigo, e não faz o inimigo testar.

**Este teste não ocupa a sua Concentração, e a Mão Firme não protege dele.** Você pode segurar o domínio na corrida e seguir concentrando num efeito, e as duas rolagens são separadas.

**Falhas que derrubam o domínio**
| Essência | 0 a 3 | 4 e 5 | 6 |
|---|---|---|---|
| Falhas | 1 | 2 | 3 |

> **Exemplo.** A sua Essência é 5, então a segunda falha derruba o seu domínio. Na corrida você toma três golpes numa rodada e falha no segundo e no terceiro: o seu domínio cai na terceira rolagem, e o Acerto do outro te pega na hora.
>
> *A metade arredonda para baixo e nunca fica abaixo de 1: é a regra de arredondamento, em que o que você ganha desce.* **É a mesma rolagem de Vigor da Concentração, com a contagem trocada**, e ela só existe enquanto dura a corrida.

**Quem perde recebe o Acerto do vencedor, e não tem como recusar.** O domínio dele já caiu, e quem cai não abre saída na barreira que continua de pé.

**O Rescaldo dispara dos dois lados**, em toda saída. O domínio acabou, e ele acaba de qualquer jeito.

**Contra a Expansão sem Barreiras aberta sem barreira**, os dois Acertos se anulam só dentro da área do outro domínio, e **fora dessa área o Acerto da sem barreiras continua.** Se esse Acerto causa dano, ele **bate na barreira do outro por fora** cada vez que acontece. Acerto que não fere não encosta na barreira.

**Uma incompleta entra na disputa e não pode vencer.** Ela não fecha barreira, então não tem barreira para conquistar nem para perder. O que ela faz é o que a sobreposição já faz: desliga o Acerto do completo, **e a barreira do completo deixa de prender — quem está lá dentro pode sair**, e o Acerto dela, que rola, continua rolando. **Custa a sua expansão inteira**, e o que ela compra é desligar o Acerto dele. **Contra a Expansão sem Barreiras aberta sem barreira, ela desliga o Acerto só dentro do próprio raio.**

> **A segunda pergunta é uma troca, e ela não paga escrever Acerto inútil.**
> Um Acerto que causa dano rende em todo uso do seu domínio, na abertura e no começo de cada turno seu. **O desempate da pergunta 2 só rende contra outro domínio, de refino igual ao seu.**
> Quem escreve um Acerto que não fere está comprando o desempate com o que a Melhoria `Inescapável` cobraria, e não ganhando de graça. *É a mesma troca que o Hakari e o Higuruma fizeram.*

> **Por que `1d12` e por que `4`.**
> **O dado não leva bônus, e não é economia de regra: não sobrou nada para somar nele.** *Refino já empatou — é o que a pergunta 3 quer dizer. Maestria vem do nível, e os dois estão no mesmo. E o atributo da técnica bate no teto de `6` antes do primeiro clash da campanha, pelas três rotas.*
> **De todas as combinações de dado e margem, `1d12` separando por `4` é a única que cai na metade exata** — `72` dos `144` resultados. *Metade das vezes o choque resolve, metade continua e vale a corrida.*
> **Você rola uma vez**, quando as áreas se sobrepõem, e não a cada rodada. *Rolar toda rodada resolveria o choque em `88%` até a terceira, e aí quem está de fora batendo na barreira deixaria de decidir o combate.*

> **Três ou mais domínios com barreira: caem todos.**
> Dois domínios se empurram. **Três ou mais não se acomodam:** as condições que cada barreira exige por dentro e por fora não fecham juntas, e **todas as barreiras caem**.
> Ninguém conquista, ninguém recebe Acerto, e o Rescaldo pega todo mundo que abriu.
> **A Expansão sem Barreiras aberta sem barreira não entra nessa conta.** Com três ou mais barreiras, as barreiras caem e a sem barreiras fica de pé. Com duas barreiras e a sem barreiras, as duas barreiras disputam como sempre, e a sem barreiras ataca as duas por fora.

## Regras de ouro

Oito regras seguram o sistema inteiro. Se um feitiço passar pelas oito, ele é legal.

**Regras de ouro**
| # | Regra |
|---|---|
| **1** | Restrição paga Melhoria. Nunca vira dado de dano. O excedente some. |
| **2** | O dano total, somando alvos e repetições, nunca passa de 4 × Classe em dados. Contra um alvo só, feitiço comum para nos pontos da Classe: 4 × Classe num alvo é coisa de Liberação Máxima. |
| **3** | Melhorias: 2 nas Classes 1 e 2, 3 nas Classes 3 e 4, 4 da Classe 5 em diante. Restrições: até 2. A Forma não conta; o Efeito Próprio conta. |
| **4** | Restrição devolve no máximo 2 × Classe. |
| **5** | Liberação Máxima é Classe 3 ou mais, custa a rodada inteira, e você só tem as que o nível deu. |
| **6** | Feitiço em Ação Bônus ou Reação só permite mais um de Classe 0 no turno. |
| **7** | Duas Restrições não podem ser as duas de frequência, nem cobrar a mesma coisa. |
| **8** | Restrição que não atrapalhou em três sessões é trocada. |

## Progressão

**Progressão**
| Nível | O que ganha |
|---|---|
| **1** | Fundamento com três Famílias Fechadas. Dois feitiços de Classe 0 (grátis). Classe 1. Passiva Livre. |
| **5** | Classe 2. Um feitiço de Classe 0 a mais. |
| **7** | Libera Passiva de Classe Passiva 2. |
| **9** | Classe 3. |
| **10** | A primeira Liberação Máxima. |
| **11** | Um feitiço de Classe 0 a mais. |
| **13** | Classe 4. Libera Passiva de Classe Passiva 3. |
| **17** | Classe 5. Técnica Máxima. Um feitiço de Classe 0 a mais. |
| **20** | A segunda Liberação Máxima. |
| **21** | Classe 6. |
| **26** | Classe 7. |
| **30** | A terceira Liberação Máxima. |

O Fundamento manda na Classe, na Liberação Máxima e em quando cada Classe Passiva abre. Quantos feitiços você conhece é conta de *Experiência e Progressão*: a fórmula está resumida em *Criando feitiços*, e a progressão nível a nível mora no capítulo 19, *Experiência e Progressão*.

O que continua valendo aqui: **Passiva é paga com espaços dessa lista**, a **Expansão de Domínio** também, e as **Liberações Máximas ficam de fora**, porque elas não ocupam espaço.

Ao subir de nível você pode reescrever um feitiço que já conhece, do zero. Uma Liberação Máxima conta como feitiço para isso.

Se um feitiço que você conhece deixar de ser legal — ou seja, deixar de seguir as regras —, por regra nova ou revisão da mesa, você o reescreve de graça na hora, sem gastar a troca de nível.

## Feitiços prontos

Trinta e cinco feitiços montados e conferidos, para usar como estão ou como referência de montagem. Na coluna do meio, **−** é o que a peça custou e **+** é o que ela devolveu.

### Classe 1 · 3 pontos · 3 PE

**Classe 1 · 3 pontos · 3 PE**
| Nome | Como foi montado | Resultado |
|---|---|---|
| `Estalo` | `Projétil` | 3d8 = 13 |
| `Chicote` | `Linha` (−1) | 2d8 = 9 numa linha de 18 m |
| `Perfurar` | `Projétil` · `Precisão` (−1) · `Parado` (+1) | 3d8 = 13, +2 no acerto |
| `Golpe Cru` | `Toque` (`Corpo a Corpo` +1), sem Melhoria para pagar | 3d8 = 13 no toque. A devolução some |

### Classe 2 · 6 pontos · 6 PE

**Classe 2 · 6 pontos · 6 PE**
| Nome | Como foi montado | Resultado |
|---|---|---|
| `Palma Trovejante` | `Cone` (−1) · `Derrubado` (−1) · `Atrasar` (+2) | 6d8 = 27 + `Derrubado` por uma rodada |
| `Lança Negra` | `Projétil` · `Fura` (−2) · `Atrasar` (+2) | 6d8 = 27, fura 4 de RD. O `Atrasar` pagou a `Fura` inteira |
| `Faísca em Cadeia` | `Projétil` · `Salto` (−2) · `Gesto` (+1) | 5d8 = 22 e 2d8 = 9 no segundo alvo |
| `Sopro` | `Cura` (−2) | cura 4d8 = 18 |
| `Vento a Favor` | `Apoio` · `Impulso` (−1) · `Pressa` (−2) | 9 de vida temporária, vantagem no próximo teste, +6 m sem provocar ataque |

### Classe 3 · 9 pontos · 9 PE

**Classe 3 · 9 pontos · 9 PE**
| Nome | Como foi montado | Resultado |
|---|---|---|
| `Marca do Carrasco` | `Projétil` · `Marca` (−2) · `Queima` (−3) · `Uma Vez` (+2) | 6d8 = 27 e 3d8 = 13 no turno seguinte |
| `Domo de Gelo` | `Explosão` (−2) · `Terreno` (−2) · `Maior` (−2) · `Condicional`: no escuro (+2) | 5d8 = 22 num raio de 4,5 m + terreno difícil por uma rodada |
| `Passo Cortante` | `Toque` (`Corpo a Corpo` +3) · `Passo` (−2) · `Precisão` (−2) | 8d8 = 36 no toque, anda 6 m, +2 no acerto |
| `Costura` | `Cura` (−3) · `Limpa` (−3) · `Gesto` (+2) | cura 5d8 = 22 e tira uma condição de nível `Leve` ou `Média` |
| `Rede` | `Explosão` (−2) · `Atordoado` (−5) · `Terreno` (−2) | zero dano: `Atordoado` + terreno difícil, CD +2, tudo durando uma rodada a mais |
| `Hora Morta` | `Efeito` · `Longe` (−2) | um quarteirão em silêncio absoluto por uma hora |
| `Fissura` | `Projétil` · `Toca a Alma` (−2) | 7 dados viram 3d8 = 13 na alma |

### Classe 4 · 12 pontos · 12 PE

**Classe 4 · 12 pontos · 12 PE**
| Nome | Como foi montado | Resultado |
|---|---|---|
| `Prisão de Sombras` | `Explosão` (−2) · `Atordoado` (−6) · `Escolher` (−4) · `Sangra` (+4) | 4d8 = 18 + `Atordoado` durando uma rodada a mais; você toma 8 |
| `Julgamento Vertical` | `Linha` (−2) · `Fura` (−4) · `Precisão` (−2) · `Atrasar` (+4) | 8d8 = 36, fura 8 de RD, +2 na CD |
| `Roubo de Fôlego` | `Projétil` · `Sugar` (−4) · `Remate` (−4) · `Condicional`: o alvo te acertou desde o seu último turno (+4) | 8d8 = 36, cura 9, +25% em alvo abaixo de metade |
| `Passo do Espelho` | `Toque` (`Corpo a Corpo` +4) · `Rápido` (−6) · `Passo` (−2) · `Recuo` (+4) | 12d8 = 54 como Ação Bônus, no toque |
| `Muralha` | `Apoio` · `Anteparo` (−4) · `Guarda` (−4) · `Parado` (+2) | parede com 40 de vida, aliado com +2 de defesa e 18 de vida temporária |
| `Maré Branca` | `Onda` (−6) | cura 6d8 = 27 em todos os aliados num raio de 3 m |
| `Alinhavo` | `Cura` (−4) · `Remenda` (−6) · `Gesto` (+2) | cura 4d8 = 18 e devolve 20 de Integridade |

### Classe 5 · 15 pontos · 15 PE

**Classe 5 · 15 pontos · 15 PE**
| Nome | Como foi montado | Resultado |
|---|---|---|
| `Purga Escarlate` | `Projétil` · `Inescapável` (−5) | 10d8 = 45 automático, sem acerto e sem resistência |
| `Chuva de Agulhas` | `Projétil` · `Rajada` (−3) · `Precisão` (−3) · `Parado` (+3) | 12d8 = 54 em 6 tiros, +2 cada |
| `Vala Comum` | `Explosão` (−3) · `Maior` (−3) · `Derrubado` (−3) · `Atrasar` (+5) | 11d8 = 49 num raio de 4,5 m, todos `Derrubados` por uma rodada |
| `Fim de Turno` | `Explosão` (−3) · `Escolher` (−5) · `Atrasar` (+5) | 12d8 = 54 num raio de 3 m, só em quem você escolher |
| `Segunda Vida` | `Cura` (−5) · `Levanta` (−8) · `Uma Vez` (+3) · `Gesto` (+3) | cura 8d8 = 36, ou levanta um aliado caído com 25 |
| `Fio Preso` | `Efeito` · `Fica` (−5) | um bairro de onde ninguém sai, até alguém desfazer |
| `Sete Palmos` | `Toque` (`Corpo a Corpo` +5) · `Toca a Alma` (−3) | 15 dados viram 7d8 = 31 na alma, no toque |

### Liberações Máximas

Escritas antes da sessão, Classe 3 ou mais, fora da lista de feitiços conhecidos. Todas custam a rodada inteira, 50% a mais de PE e o preço escolhido na hora.

Repare na `Rachadura`: o `Atrasar` devolveria 3 pontos, mas a `Linha` só custou 2, e devolução nunca passa do que foi gasto em Melhoria, então o terceiro ponto some sem virar dado.

**Liberações Máximas**
| Nome | Como foi montado | Resultado |
|---|---|---|
| `Golpe do Voto` | Classe 5 · `Projétil` (nada mais) | 20d8 = 90, o máximo do nível 20. 23 PE |
| `Rachadura` | Classe 3 · `Linha` (−2) · `Atrasar` (+3, só 2 aproveitados) | 12d8 = 54 numa linha de 18 m, o teto da Classe 3. 14 PE |
| `Sentença Final` | Classe 5 · `Explosão` (−3) · `Escolher` (−5) · `Atrasar` (+5) | 17d8 = 76 num raio de 3 m, só em quem você escolher. 23 PE |

### Técnicas Máximas

Montadas com o orçamento da faixa 17 a 20: 8 pontos nos preços da Classe 5.

**Técnicas Máximas**
| Nome | Como foi montado | Resultado |
|---|---|---|
| `O Fim da Linha` | `Linha` (−3) · `Muito Longe` (−5), 8 do orçamento | 24d8 = 108 numa linha de 60 m |
| `Ponto Final` | `Projétil` · `Fura` (−5), 5 do orçamento, 3 se perdem | 24d8 = 108 furando 10 de RD |

## Apêndice

*Os termos deste capítulo estão no vocabulário do sistema.*

### Ficha de feitiço

**Ficha de feitiço**
| | |
|---|---|
| **Nome** | |
| **Classe / Pontos / Teto / PE** | |
| **Forma** | `Projétil` · `Toque` · `Explosão` · `Aura` · `Cone` · `Linha` · `Cura` · `Apoio` · `Onda` · `Efeito` |
| **Resolve com** | Acerto · Teste de Resistência · Automático |
| **Melhorias** | |
| **Restrições** | |
| **É Liberação Máxima?** | Sim ☐   Não ☐        Preço na hora: Vazio · Sangue · Peso |
| **Dano ou cura** | ____ d8  =  ____ |
| **Ação** | Padrão · Bônus · Reação · Rodada inteira |
| **Como é** | |

### Catálogo de temas

Não têm regra nenhuma amarrada, são só ideias para ajudar na criação do Fundamento.

**Catálogo de temas**
| Grupo | Temas |
|---|---|
| **Corpo e matéria** | Corte · Impacto · Perfuração · Peso · Elasticidade · Carne · Sangue · Osso · Doença · Crescimento |
| **Elementos** | Fogo · Gelo · Raio · Vento · Água · Terra · Metal · Ácido · Veneno · Fumaça |
| **Força e movimento** | Gravidade · Vetor · Velocidade · Inércia · Rotação |
| **Espaço e tempo** | Distância · Espaço · Tempo · Direção · Reflexo |
| **Sentidos** | Som · Silêncio · Luz · Sombra · Cheiro |
| **Mente e alma** | Medo · Memória · Sono · Ilusão · Voz · Nome · Emoção · Vontade · Instinto · Loucura |
| **Conceito** | Vínculo · Troca · Cópia · Contrato · Dívida · Sorte · Aposta · Julgamento · Regra · Registro · Valor · Verdade · Segredo · Herança · Ausência |
| **Criação** | Invocação · Construção · Marionete · Ferramenta · Selamento · Bloqueio · Semente · Enxame · Máquina · Molde |

Os do grupo Conceito quase sempre pedem uma Passiva de `Regra Própria` para funcionarem bem, e sempre precisam de uma aprovação bem cuidadosa do mestre.

---


# Capítulo 10 · Técnica Marcial

*fonte: `manual/42-tecnica-marcial.md`*

Duas rotas de criação montam o poder aqui em vez de montar no Fundamento: o **Corpo Amaldiçoado** e a **Restrição Celestial pelo ramo sem energia**. As duas estão no capítulo 7, *Origens e Legados*.

> **Técnica Marcial é o Fundamento com o corpo no lugar da energia.** Mesma máquina, mesmo orçamento, mesma conta de montagem.
>
> **Onde o Fundamento escreve um Selo, você escolhe três grupos de arma ou uma ferramenta sob medida.**

## Máquina herdada

**Tudo que o capítulo 9, *Fundamento*, diz vale aqui.** Pontos são `3 × Classe`, o custo em PE é o mesmo número, o que sobra de ponto vira `1d8` de dano, Melhorias e Restrições obedecem os mesmos tetos, e a sua lista tem `2 + (nível ÷ 2)` espaços, mais um por marco.

Três coisas mudam de nome e duas somem.

### `Kata`

**`Kata`** (型, a forma que se treina) — a sua aplicação concreta, montada com pontos. Mesma Classe, mesmos pontos, mesmo custo em PE, mesmo teto de Melhoria e de Restrição. **Onde qualquer capítulo escreve *feitiço*, leia também `Kata`: a regra vale para a sua e para a de qualquer um.** Quando a Restrição Celestial sem energia diz que não conjura e não tem feitiço de Toque, ela fala de energia: a `Kata` é o corpo, e continua. E o `Calado` segue o mesmo padrão do feitiço: a `Kata` não sai se precisar de voz, como a Restrição `Gesto`, ou de uma ferramenta que precise de som. Os degraus de Trilha que conjuram valem igual: a Classe é a mesma, o custo em PE é o mesmo, e o que sai da sua mão é Kata.

### `Ruptura`

**`Ruptura`** — a única Kata que passa do limite de dano contra um alvo só. Uma no nível 10, uma no 20 e uma no 30. **`+Classe` em dados, custa a rodada inteira, `+50%` de PE**, e o preço se escolhe na hora: `Vazio`, `Sangue` ou `Peso`.

Onde qualquer capítulo escreve *Liberação Máxima*, leia `Ruptura`. As regras são as mesmas.

### `Ōgi`

**`Ōgi`** (奥義, a técnica que a escola guarda) — o golpe de dano fixo, do nível 17 em diante. **Dano pela faixa de nível, orçamento de montagem à parte, `5 × maior Classe` de PE**, e não aceita Restrição.

Onde qualquer capítulo escreve *Técnica Máxima*, leia `Ōgi`.

### Selo e Expansão de Domínio

> **Você não tem Selo.** O equipamento ocupa o lugar dele.
>
> **Você não tem Expansão de Domínio.** Nem incompleta, nem completa, tenha a sua ficha energia amaldiçoada ou não. Uma Expansão estende a técnica inata sobre o território em volta, e esta rota não tem técnica inata para estender.

**E quem não tem energia amaldiçoada troca refino e aptidões por Lapidação e Bênçãos**, no capítulo 13.

## Rotas

Na criação, depois da Descrição e da Regra, você escolhe uma das duas. **A escolha é uma vez e não muda**, como o Caminho e a Trilha.

### Rota de arma

> **Escolha três das treze categorias de arma, diferentes entre si.** As treze estão no capítulo 15, *Equipamento*.
> **Você recebe uma arma de cada uma, de grau 4.** Grau 4 fere maldição e não dá `Estigma` nenhum — capítulo 16, *Ferramenta Amaldiçoada*.
> **Você é treinado nas três**, seja qual for a lista de treino do seu Caminho.
> **As suas Katas valem com qualquer arma amaldiçoada desses três grupos.**

#### Limites

**Os três grupos entregam arma, treino e o Selo. Manha nenhuma.** Uma Vanguarda desta rota continua escolhendo **uma** categoria na `Escola de Arma`, e pode escolher uma que não seja das três.

**As três armas começam em grau 4, e param aí.** Subir de grau é assunto do capítulo 15, pelo mesmo ritmo que vale para todo mundo.

**Três armas na mochila não são três `Estigma`.** O teto conta pelo que está na mão, e não pelo que está guardado.

#### Atributo

A sua técnica não declara um atributo na criação, diferente do que uma técnica amaldiçoada declara — capítulo 9, *Fundamento*, na seção *Atributo da técnica*.

> **Atributo de arma.** A CD das suas Katas, as rolagens de acerto e o resto exigem uma rolagem de conjuração usando o atributo principal da arma usada na Kata.

**Grupos por atributo de acerto**
| Atributo | Grupos | Quais |
|---|---|---|
| **Força** | 8 | Lâmina Longa · Massa · Porrete · Manopla · Machado · Ceifa · Armas Longas · Flexível |
| **Destreza** | 6 | Lâmina Curta · Lâmina Longa · Arremesso · Yumi · Balestra · Arma de Fogo |

A `Lâmina Longa` está nas duas porque a Rapieira e a Katana carregam `Fineza`.

### Rota de ferramenta

> **Escolha uma ferramenta amaldiçoada sob medida, de grau 4, na forma de objeto de apoio** — a categoria que o capítulo 15 abre ao lado do catálogo de armas.
> **Ela não tem dado de arma**, e não precisa ter: as suas Katas nunca somaram o dado do equipamento.
> **Ela declara na criação se o seu golpe simples usa ela.**
> **As suas Katas valem só com ela.**
> **Ela declara qualquer um dos cinco atributos**, e quem justifica é a narrativa da ferramenta.

Uma armadura construída por engenharia, uma câmera amaldiçoada, uma maleta, um instrumento. Uma armadura de engenharia usaria Inteligência; um instrumento com senciência usa Essência.

> **Se a narrativa for armadura, ela É o seu uniforme.** Não some com o `Traje` nem com o `Revestimento` do capítulo 14 — ela é um dos dois, e usa os números de lá.
>
> **Se a narrativa for a sua arma, ela É a sua arma.** Não some a ferramenta junto da arma em ataque simples, nem nas suas Katas — Katas já não somam dano de arma.

## Selo

> **O seu Selo é ter o equipamento em uso.** Uma das três armas, ou a ferramenta.

Ele funciona como qualquer outro Selo: não custa ponto, não devolve ponto e não dá bônus. E cobra as duas mesmas coisas que o capítulo 9 cobra de todo Selo:

**Restrição contra o Selo**
| A Restrição | O que acontece |
|---|---|
| qualquer uma que peça *"estar com a minha arma"* | **não devolve ponto.** O Selo já obriga isso |
| `Gesto`, que pede as duas mãos livres | quase impossível de vender nesta rota, e impossível numa arma de duas mãos |

## Ferir maldição

Uma arma comum não fere maldição. Quem tem energia resolve isso com `Canalizar energia`, a aptidão de graça do refino 1 — e quem não tem energia não tem aptidão nenhuma.

> **Toda Kata passa pelo equipamento, e o equipamento é ferramenta amaldiçoada de grau 4.** Então toda Kata fere maldição, nas duas rotas.

**Golpe simples e maldição**
| Rota | O golpe simples |
|---|---|
| **arma** | sai por uma das três ferramentas ganhas, que são grau 4. **Fere maldição** |
| **ferramenta** | é o soco, e soco não fere maldição. **Depende do objeto** |

Na rota de ferramenta, o objeto declara qual dos dois é na criação — uma linha da ficha, junto da Descrição, no mesmo lugar em que o Fundamento anota o tipo de dano.

> **Coisa que dá para usar para atacar** — armadura, manopla, máscara, coturno. O seu golpe simples fere maldição.
> **Coisa que você só carrega** — câmera, lanterna, maleta, instrumento. O seu golpe simples não fere maldição, e você depende das suas Katas para isso.

> **O Corpo Amaldiçoado fere maldição com o golpe simples, seja qual for o objeto.** Ele tem energia amaldiçoada, então tem aptidões e refino normais — e com eles o `Canalizar energia` de graça no refino 1. **Mas o equipamento continua obrigatório**, porque ele é o Selo, e sem Selo não dá para usar Kata.

## Passivas

Passiva é o que a sua técnica faz sem você exigir, e aqui ela funciona igual ao capítulo 9, *Fundamento*: a Livre é de graça, e as pagas custam espaços de Kata pela Classe Passiva.

Onde o capítulo 9 escreve energia, aqui se escreve físico, treino e ferramenta.

Passiva se escreve na hora, com o mestre, e as de baixo são exemplo do que cada Classe Passiva pode comprar.

### `Calo`

> **`Calo`** — vale sobre qualquer arma que você já empunhou uma vez.
>
> **O que você reconhece.** Só de segurar uma arma você sabe qual é, sem precisar ver: basta sentir o peso.
>
> Classe Passiva Livre. Como toda Livre, ela não rola dado, não muda número e não faz ninguém rolar.

### `Maldição do Inventário`

> **`Maldição do Inventário`** — vale sobre o que você carrega, o tempo todo.
>
> **Saque.** Você saca ou guarda **dois** itens de graça por turno, em vez de um.
>
> **O que guarda.** Não é o seu corpo: é uma maldição pequena, presa a você, que engole o que você põe nela. Ela encolhe até caber na mão, e é ela que você engole — a carga vai junto.
>
> **Energia.** Item amaldiçoado guardado ali para de emanar. `Barreira Simples` e `Cortina` deixam de segurar ele, e ele atravessa com você.
>
> Classe Passiva 1.

> **Contra Expansão de Domínio a `Maldição do Inventário` não muda nada.** O Acerto garantido lê alvo, e item nunca foi alvo — o que você carrega atravessa domínio de qualquer jeito.
### `Leitura`

> **`Leitura`** — vale quando alguém conjura a até `18 m` de você.
>
> **O que você lê.** Você identifica a Classe e a Forma do feitiço.
>
> Classe Passiva 1.

### `Segundo Fôlego`

> **`Segundo Fôlego`** — vale quando você chega a `0` de vida.
>
> **A escolha sai de graça.** Escolher `Insistir` não custa a sua rodada.
>
> **Relógio.** Uma vez por descanso longo.
>
> Classe Passiva 2.

### `Contragolpe`

> **`Contragolpe`** — vale quando alguém erra um ataque corpo a corpo contra você.
>
> **A resposta.** A sua próxima Kata contra ele tem **vantagem**.
>
> **Relógio.** `maestria`× por cena.
>
> Classe Passiva 2.

### `Aliança`

> **`Aliança`** — vale sobre a sua arma (uma arma), o tempo todo.
>
> **Desarmar.** A sua arma nunca é desarmada.
>
> **Quem empunha.** Ninguém além de você a empunha.
>
> Classe Passiva 3.

## Técnicas Marciais prontas

### Fisga

**Ficha de Técnica Marcial**
| | |
|---|---|
| **Descrição** | Ela não aprendeu nada elegante. Aprendeu a segurar peso, a alcançar mais longe do que o braço dela alcança, e a não largar. O que ela faz com uma arma é o que qualquer um faria, feito rápido demais para dar tempo de responder. Tipo de dano: corte. |
| **Regra** | *"Alcançar antes, e não soltar."* |
| **Atributo** | Força |
| **Grupos** | Armas Longas · Ceifa · Flexível |
| **Livres** | Alcance · Controle |
| **Fechadas** | Amparo · Auxiliares · Área |

`Amparo` está Fechada porque nenhuma das três cura ninguém.

### Bancada

**Ficha de Técnica Marcial**
| | |
|---|---|
| **Descrição** | Ele nasceu sem nada e teve de ler tudo para chegar aonde chegou. A armadura é dele: fez, refez, e conhece cada solda. Ela não tem energia amaldiçoada nenhuma dentro — o que ela tem é a maldição que ele prendeu no chassi e um sistema que ele entende melhor que o fabricante entenderia. Tipo de dano: impacto. |
| **Regra** | *"Resolver o problema com a peça certa."* |
| **Atributo** | Inteligência |
| **Ferramenta** | uma armadura de corpo inteiro. **Coisa que dá para usar para atacar** — os punhos dela são dele |
| **Livres** | Auxiliares · Amparo |
| **Fechadas** | Área · Marca · Castigo |
| **Passiva** | `Leitura` (Classe Passiva 1): você identifica a Classe e a Forma de qualquer feitiço conjurado a até 18 m |

A armadura da Bancada é o `Revestimento` do capítulo 14, com os números publicados lá. E `Amparo` é Livre porque a narrativa aguenta: uma arma que cura é difícil de justificar, e uma bancada de engenharia não é.

---


# Capítulo 11 · Sem Técnica

*fonte: `manual/43-sem-tecnica.md`*

Uma rota de criação monta o poder aqui em vez de montar no Fundamento: a sub-origem **Sem Técnica**, que se soma a qualquer uma das cinco Origens principais. Ela está no capítulo 7, *Origens e Legados*.

> **Sem Técnica é o Fundamento com uma aptidão no lugar do dom.** Mesma máquina, mesmo orçamento, mesma conta de montagem.
>
> **A sua técnica existe. Ela só não nasceu com você:** você montou ela em cima de uma coisa que qualquer feiticeiro pode aprender, e foi mais fundo nela do que ninguém tinha ido.

Não é a rota do personagem fraco. O feiticeiro de grau 1 sem técnica inata existe na obra, e o que ele aprendeu foi montado para que os fracos revidassem contra os fortes.

## Máquina herdada

**Tudo que o capítulo 9, *Fundamento*, diz vale aqui.** Pontos são `3 × Classe`, o custo em PE é o mesmo número, o que sobra de ponto vira `1d8` de dano, Melhorias e Restrições obedecem os mesmos tetos, e a sua lista tem `2 + (nível ÷ 2)` espaços, mais um por marco.

Duas coisas mudam de nome e uma some.

### `Manejo`

**`Manejo`** — a sua aplicação concreta, montada com pontos. Mesma Classe, mesmos pontos, mesmo custo em PE, mesmo teto de Melhoria e de Restrição. **Onde qualquer capítulo escreve *feitiço*, leia também `Manejo`: a regra vale para o seu e para o de qualquer um.** Os degraus de Trilha que conjuram valem igual: a Classe é a mesma, o custo em PE é o mesmo, e o que sai da sua mão é Manejo.

O nome não é enfeite. A categoria inteira de técnicas que não nascem com a pessoa se chama manipulação de energia amaldiçoada, e é literalmente o que esta rota faz.

### `Auge`

**`Auge`** — o golpe de dano fixo, do nível 17 em diante. **Dano pela faixa de nível, orçamento de montagem à parte, `5 × maior Classe` de PE**, e não aceita Restrição.

Onde qualquer capítulo escreve *Técnica Máxima*, leia `Auge`.

### Liberação Máxima

**Você tem Liberação Máxima, e ela não muda de nome.** Uma no nível 10, uma no 20 e uma no 30, com as mesmas regras do capítulo 9.

> **O nome fala da *sua* técnica, e a sua técnica é sua.** Ela não veio com você — mas você a escreveu, e ela é a única daquele jeito no mundo.

### Expansão de Domínio

> **Você não tem Expansão de Domínio.** Nem incompleta, nem completa.

Uma Expansão é a mesma técnica estendida sobre o território em volta. A sua nasce de uma aptidão que qualquer feiticeiro alcança.

**Em troca, a sua semente vem aberta.** É a seção seguinte, e ela chega no nível 2 com o que a maior parte das fichas só alcança lá na frente.

## Semente

Na criação, antes da Descrição e da Regra, você escolhe uma **semente**: uma aptidão que vem aberta, sem os gates de nível e de refino que ela pede de todo mundo. **Ela é o assunto do seu Fundamento.**

> **A semente não gasta marco**, e o primeiro marco continua sendo o do nível 6, comprando o que sempre comprou.
> **Ela conta como uma aptidão a mais para a lista.**
> **A escolha é de uma vez e não muda**, como o Caminho e a Trilha.

As aptidões e os gates delas estão no capítulo 12, *Aptidões e Refino*.

**Sementes**
| Semente | O que ela desenha |
|---|---|
| **`Domínio Simples`** | você fecha um pedaço de chão em volta de você, e o que entrar ali é problema seu |
| **`Energia Reversa`** | você reverte o que já quebrou, e não conserta o que está inteiro |
| **aptidão própria** | a que você escreve, com o mestre, consumindo o slot de aptidão única que a ficha pode ter |

### `Domínio Simples`

A rota da escola que ensina gente sem técnica a matar maldição. **Ela é anti-domínio**, e a arma é o jeito mais comum de usar — não o requisito.

A semente é o **motor**, e não o assunto: o que você escreve em cima dela é seu.

Ela nasce com o voto do iniciante, do capítulo 12: o Domínio Simples fica no ponto em que você o ergueu, e se os seus dois pés saírem desse ponto ele se desfaz. Você larga o voto quando o seu refino chega a 5.

### `Energia Reversa`

A rota de quem aprendeu a desfazer estrago. **Ela cura você**, pelas regras do capítulo 12 — e nesta rota ela cura um pouco mais, na seção *Cura* mais abaixo.

> **Curar os outros não entra na criação.** É o degrau raro do material, e ele mora numa Trilha do Guia, no capítulo 8, *Caminhos e Trilhas*. Quem quiser isso paga uma Trilha inteira, como qualquer um.

### Aptidão própria

Você escreve a sua, com o mestre, em cima do que o sistema já tem — a Classe, a arma, a proteção, o que for. **Ela obedece a mesma trava de qualquer aptidão escrita na mesa**, no capítulo 12: ela cabe em `Classe Passiva 1` ou `2`, e nunca em `3`.

**E ela não repete uma das aptidões do catálogo com outro nome.** Se o que você escreveu faz o que uma delas já faz, troque.

## Regra

No Fundamento comum, a Regra é uma frase sobre o que a sua técnica faz com o mundo, e ela é livre. **Aqui ela é uma frase sobre como você usa a sua semente.**

> *"O meu domínio não me protege: ele prende quem entrou junto."*
> *"Eu reverto energia no que já está quebrado, e não no que está inteiro."*

**A trava é uma só: a Regra tem de ser sobre a semente.** Um Fundamento de `Energia Reversa` que descreve fogo não é desta rota — ele é uma técnica que nasceu com a pessoa, e quem tem uma dessas não é Sem Técnica.

Isso aperta menos do que parece. A semente diz **de que matéria** a técnica é feita; ela não diz o que a técnica faz. Duas fichas com a mesma semente continuam sendo coisas completamente diferentes, porque a Regra, as Famílias e os `Manejos` são de cada uma.

## Cura

> **Quem tem a semente `Energia Reversa` soma `1/3 do refino` em toda rolagem de cura sua.**

Arredondando para baixo, como todo arredondamento do sistema. **No refino 10 são `+4`, e não `+3`** — o teto ganha um degrau a mais, do mesmo jeito que o `Canalizar energia` troca o `d4` por `d6` ali.

Vale sobre a cura da própria `Energia Reversa` e sobre qualquer outra que role dado e cure você. **Não vale sobre cura em terceiro**, porque esta rota não cura terceiros até você adquirir a aptidão `Liberação de Energia Reversa`.

## Passivas

Passiva é o que a sua técnica faz sem você mandar, e aqui ela funciona igual ao capítulo 9, *Fundamento*: a Livre é de graça, e as pagas custam espaços de `Manejo` pela Classe Passiva.

**Os exemplos do capítulo 9 e do capítulo 10, *Técnica Marcial*, servem todos.** Passiva se escreve na hora, com o mestre, e nenhuma delas é catálogo.

## Fundamentos prontos

Dois, um de cada semente nomeada. Os dois param onde a criação de personagem para: Descrição, Regra, semente, Famílias e a Passiva.

### Redoma

**Ficha de Fundamento**
| | |
|---|---|
| **Semente** | `Domínio Simples` |
| **Descrição** | Ela aprendeu a fechar dois metros de chão e não sair deles. O que entra ali dentro é problema dela, e o que fica de fora é problema de outra pessoa. Não tem nada de bonito: é uma linha no chão e a paciência de não cruzar ela. Tipo de dano: corte. |
| **Regra** | *"O meu domínio não me protege: ele prende quem entrou junto."* |
| **Livres** | Controle · Auxiliares |
| **Fechadas** | Área · Alcance · Amparo |

As duas Livres caem da Regra: `Controle` é prender, e `Auxiliares` é o que ela faz com quem está preso. As três Fechadas caem da semente — um domínio de raio pequeno em volta de você não tem alcance nem área para comprar, e ele prende em vez de socorrer.

### Sutura Fria

**Ficha de Fundamento**
| | |
|---|---|
| **Semente** | `Energia Reversa` |
| **Descrição** | Ele não conserta ninguém. Ele reverte o que já quebrou, e a diferença importa: o corpo tem de estar errado antes de ele poder mexer. É trabalho de plantão, feito com as mãos sujas, e ele aprendeu vendo gente morrer de coisa que dava para desfazer. Tipo de dano: nenhum. |
| **Regra** | *"Eu reverto energia no que já está quebrado, e não no que está inteiro."* |
| **Livres** | Amparo · Auxiliares |
| **Fechadas** | Área · Castigo · Marca |
| **Passiva** | `Recomposição`: uma vez por descanso curto, gasta a ação e recupera 5 × a sua maior Classe em vida |

> **Um Fundamento pode não causar dano nenhum, e este é o exemplo.** A Forma `Apoio` não causa, a Forma `Efeito` também não, e nada obriga a sua técnica a machucar alguém.

A cura dele soma `1/3 do refino`, pela seção *Cura*. Curar os outros ele não faz: para isso ele precisaria do Guia e da Trilha que entrega aquilo, como qualquer um.

---


# Capítulo 12 · Aptidões e Refino

*fonte: `manual/45-aptidoes-e-refino.md`*

Aptidão é o que qualquer feiticeiro pode aprender, venha a energia de onde vier: cobrir-se de energia, levantar uma barreira, ficar de pé dentro de uma Expansão de Domínio. Ela não depende da sua técnica.

Aptidão se ensina ou se aprende. Ela passa de mestre para aluno, de escola de espada para escola de espada, e dois feiticeiros de técnicas opostas sabem exatamente as mesmas quatro coisas contra um domínio. É o repertório comum da profissão.

Quem compra aptidão é o **refino**, o eixo de controle da sua ficha. Poder é quanto você tem. Refino é quanto você não desperdiça.

> **Sem energia amaldiçoada não existe refino nem aptidão.** Uma ficha nessa situação usa **Lapidação** e **Bênçãos** no lugar dos dois, no capítulo 14, *Bênçãos e Lapidação*. A máquina é a mesma casa por casa; o que muda é o conteúdo do catálogo.

## Refino

Energia amaldiçoada vaza. Ela escapa do corpo de quem produz, o tempo todo, e é por isso que um feiticeiro fareja outro a um quarteirão de distância. O refino mede quanto da sua você segura.

A camada em volta do corpo de um feiticeiro de refino 1 sai fina, o domo que ele levanta desmancha no primeiro empurrão, e o que sobra dele no ar avisa qualquer maldição de que ele está chegando. Um feiticeiro de refino 10 entrega a energia inteira onde deseja: a mesma quantidade rende o dobro, a camada aguenta a luta toda, o domo aguenta o cerco, e o que ele solta no ar é só o que ele decidiu soltar.

É por isso que o refino é a moeda que compra aptidão. Aptidão se aprende manejando energia, com a técnica fora da conta, e quem maneja melhor aprende mais coisas.

Na ficha, o refino é um número de 1 a 10. Toda ficha começa em 1, e ele sobe nos marcos: os níveis **6, 10, 14, 18, 22, 26 e 30**, sete ao longo da campanha inteira.

> **Cada marco te dá +1 de refino de graça. Se você escolher Refino no marco, você ganha mais +1.**

**Refino por marco**
| marco | quem nunca escolhe Refino | quem sempre escolhe |
|---|---|---|
| começo da ficha | 1 | 1 |
| 6 | 2 | 3 |
| 10 | 3 | 5 |
| 14 | 4 | 7 |
| 18 | 5 | 9 |
| 22 | 6 | **10** |
| 26 | 7 | 10 |
| 30 | **8** | 10 |

### Efeito do refino

> Ele fica fora de acerto, CD, defesa e Teste de Resistência.

**Efeito do refino**
| onde o refino não entra | onde ele entra |
|---|---|
| acerto | custo: quanto PE a aptidão cobra |
| CD | frequência: quantas vezes por cena, por descanso, por dia |
| defesa | escopo: alcance, duração, quantos alvos |
| Teste de Resistência | magnitude fora de disputa: Redução de Dano e proteção |
| dano de feitiço | dano fora da rodada de feitiço, e disputa contra outro refino |

**Duas entradas põem refino em dano, e as duas só valem na rodada em que você não conjura:** `Projetar energia` e o dano na arma do `Canalizar energia`. **Feitiço nunca cresce com refino** — ele tem orçamento próprio, no capítulo 9, *Fundamento*.

A proteção de `Cobrir-se de energia` entra na sua Defesa, e usa `1/3 do refino`.

> **Arredondamento.** Toda divisão de refino arredonda para baixo: refino 5 dividido por 2 dá 2.

## Marco

A cada marco a ficha ganha três coisas de graça e escolhe uma quarta.

> **Passivo:** +1 ponto de atributo, +1 de refino e +1 espaço de feitiço.
>
> **Escolha, uma das três:**
>
> **Corpo** — mais um ponto de atributo, **e mais uma perícia ou um ofício treinado**.
> *Do nível 10 em diante, no lugar da perícia ou do ofício novo, você pode **especializar** um que já treina: some **metade da maestria** de novo naquela rolagem, arredondando para baixo.*
>
> **Refino** — mais um de refino, e uma aptidão. **Se o seu refino já estiver no teto, você leva duas aptidões no lugar.**
>
> **Leque** — mais um feitiço, que só pode ser feitiço, e uma Passiva.

Quem escolhe Refino em todo marco bate no teto no nível 22. Dali em diante escolher a rota entrega uma segunda aptidão no lugar do refino extra.

> **Quem nunca escolhe Refino termina a campanha com zero aptidões.** A rota existe e é jogável.
Mesmo essa ficha não fica sem nada. `Cobrir-se de energia` e `Canalizar energia` vêm de graça no refino 1, e a primeira continua crescendo com o refino passivo até 8. O que ela nunca vai ter é `Energia Reversa` nem `Barreira Simples`.

*O marco é do capítulo 19, __Experiência e Progressão__: é lá que estão os sete níveis em que ele cai, quanto refino cada rota junta marco a marco, e o que Corpo e Leque compram.*

## Aptidões

Um marco de Refino compra **uma aptidão**, de qualquer altura que o seu refino alcance. Duas do catálogo não custam marco nenhum: `Cobrir-se de energia` e `Canalizar energia` já estão na sua ficha desde o refino 1.

> **Aptidão não custa espaço de feitiço.** Espaço de feitiço é a moeda das Passivas e da Expansão de Domínio. As duas economias são separadas: aptidão custa marco, e só marco.

`Sua maior Classe` aparece no texto de várias aptidões. Ela é a variável do capítulo 9, *Fundamento*, e é lá que ela é definida.

### Classe Passiva

**A Classe Passiva é o tamanho da aptidão**, e diz o quanto aquela entrada pode entregar. As aptidões usam a mesma escala das Passivas: a escala, e o que cabe em cada nível de Classe, estão no capítulo 9, *Fundamento*, na seção `Passivas`.

O marco compra uma aptidão de qualquer escala, e o preço é o mesmo. Quem separa e limita as escalas são só os requisitos.

**E se você for escrever uma `Aptidão Própria`, a escada do capítulo 9 é a base:** escolha a escala que a sua ideia alcança, e escreva dentro do que aquela linha permite.

### Requisito

Cada aptidão declara o próprio requisito, e ele está na linha dela no catálogo: nenhum, nível, refino, os dois juntos, outra aptidão, ou Origem.

Três exigem outra aptidão, e nas três a exigida é a mesma coisa em tamanho menor: `Cortina` pede `Barreira Simples`, `Circulação` pede `Energia Reversa`, e `Regravação` pede `Circulação`. As duas de kokusen são alternativas entre si, e nenhuma exige a outra.

## Catálogo

### Como uma aptidão funciona

Cada entrada aparece duas vezes. Primeiro nesta tabela, com quatro campos: **nome**, **requisito**, **Classe Passiva** e **o que o refino escala**. Depois na seção dela, na caixa de regra.

Traço na coluna de Classe Passiva quer dizer que a entrada não tem uma. Traço na última coluna quer dizer que o refino não mexe naquela aptidão.

**Como ler uma aptidão**
| Aptidão | Requisito | Classe Passiva | O que o refino escala |
|---|---|---|---|
| Cobrir-se de energia | grátis no refino 1 | — | a proteção, e a Redução de Dano da Reação |
| Canalizar energia | grátis no refino 1 | — | — |
| Projetar energia | sem requisito | — | o dano |
| Energia Reversa | refino 7 e nível 14 | 3 | — |
| Circulação | `Energia Reversa`, refino 8 | 3 | — |
| Regravação | `Circulação` | 3 | — |
| Kokusen Melhorado | refino 5 e nível 14 | — | vantagem no d100 |
| Kokusen Constante | refino 5 | — | a chance no d100 |
| Cesta Oca de Vime | ser Reencarnado, ou treinado em `História` | 1 | — |
| Domínio Simples | ter visto um sendo usado, ou ter aprendido com alguém; refino 5, ou 4 com o voto | 2 | o raio |
| Pétala | ser Descendente, ou ter aprendido com alguém de um clã; refino 4 e nível 10 | 2 | — |
| Extensão de Domínio | ter visto uma sendo usada, ou ter estudado, ou aprendido com alguém; refino 7 e nível 18; o Corpo Amaldiçoado não compra | 3 | a duração |
| Barreira Simples | sem requisito | — | a vida do domo |
| Cortina | exige a `Barreira Simples` | — | a vida dela |
| Aptidão Própria | uma vez na ficha inteira | 1 ou 2 | conforme o que for escrito |

## Aptidões de graça

Estas duas chegam com a ficha, no refino 1, sem custar marco nenhum. Elas são o que separa alguém que tem energia amaldiçoada de alguém que sabe usar energia amaldiçoada.

### Cobrir-se de energia

> **Cobrir-se de energia** — sem Traje e sem Revestimento, a sua proteção é `1/3 do refino + 1`. Escudo soma com ela.
>
> Como Reação, você concentra a energia no impacto: Redução de Dano de `1,5 × refino` num golpe, por **2 PE**. Você fica sem proteção até o fim do seu próximo turno.
>
> Requisito: grátis no refino 1. O refino escala a proteção e a Redução de Dano da Reação.

> **Exemplo.** Com refino 6 a sua proteção passiva é 3, e a Reação desconta 9 de um golpe por 2 PE.

### Canalizar energia

> **Canalizar energia** — você ataca com uma arma ou com o soco, e o ataque vem imbuído de energia amaldiçoada, o que permite a um item mundano matar maldição.
>
> **Dano na arma.** Os seus ataques **com arma** causam `1d4` de dano a mais a cada `3` pontos de refino — `1d4` no refino `1`, `2d4` no `3`, `3d4` no `6`, `4d4` no `9`. **No refino `10` os dados viram `d6`: `4d6`.**
>
> **Só arma.** Ele não entra em feitiço nem em Kata. E se o mesmo ataque já estiver carregando um feitiço de dano de `Classe 0` ou mais — como no `Ferrão`, o nível 27 da Estocada, em que o golpe leva um Classe 0 junto —, este dano **não** se soma por cima.
>
> Requisito: grátis no refino 1. O refino escala o dano na arma.

Ela é a porta de toda arma de contato, e é ela que põe energia no que a sua mão carrega.

> **Exemplo.** Com refino 6, o soco e a lâmina levam `3d4` de dano a mais.

## Energia crua

### Projetar energia

> **Projetar energia** — você dispara energia crua. O dano é `Xd6`, e ela gasta PE num valor menor ou igual ao seu refino: cada `1` PE aumenta o `X` em `1`. O alcance segue o da sua maior Classe disponível.
>
> Requisito: nenhum. O refino escala o dano.

`Projetar energia` é o que sobra quando o combustível acaba: o turno em que o seu PE zerou, a luta ainda não terminou e você continua precisando fazer alguma coisa.

### Energia Reversa

> **Energia Reversa** — ação padrão. Gaste até `a sua maior Classe` de PE e recupere `1d8` de vida por PE gasto, em você.
>
> Requisito: refino 7 e nível 14. Classe Passiva 3.

> **A `Energia Reversa` cura só você.** Curar outra pessoa é o degrau raro.

Ela muda a forma das lutas longas e muda o que acontece entre elas: um personagem com Energia Reversa não precisa voltar para casa depois de cada cena.

### Circulação

> **Circulação** — o teto por uso da sua `Energia Reversa` sobe para `1,5 × a sua maior Classe` de PE, arredondando para baixo.
>
> Você também pode usá-la como **Ação Bônus**. Usada assim, os dados de cura são `d4` em vez de `d8`.
>
> E você **recompõe o que foi arrancado** — braço, olho, o que a mesa tiver tirado de você. Isso gasta o teto inteiro do uso, e naquele uso você não cura vida nenhuma.
>
> Requisito: ter a `Energia Reversa` e refino 8.

Energia positiva reconstrói sangue, osso, carne e órgão, e quem chega aqui tem ela andando pelo corpo o tempo todo em vez de ligar e desligar. É o degrau mais alto da cura, e ele é caro: você gasta um marco na `Energia Reversa`, outro nesta, e o refino 8 pede mais quatro de sete.

Na Ação Bônus você cura e ainda ataca na mesma rodada. O dado menor é o preço disso — é a diferença entre segurar um golpe e ficar inteiro.

Recompor membro é a mesma aptidão fazendo a coisa mais difícil que a energia positiva faz. Em combate ela custa a sua rodada e o combustível, e você continua machucado. Fora de combate é barata, e é lá que ela deve ser usada.

> **Membro perdido.** Não tem regra neste livro, e isso é decisão: quem tira é o mestre ou um pacto, e as penalidades são as que a mesa combinar, do mesmo jeito que o d20 faz. Esta aptidão desfaz.

**Curar outra pessoa continua fora daqui.**

### Regravação

> **Regravação** — Ação Bônus, durante o seu Rescaldo. Gaste o teto inteiro da sua `Energia Reversa`, e o Rescaldo acaba: a sua técnica volta a responder. Nesse uso você não cura vida nenhuma.
>
> Cada uso deixa uma **marca**, e as marcas somem no descanso longo. Com `metade da sua Inteligência + metade da sua maestria` marcas, cada metade arredondando para baixo, você não abre Expansão de Domínio.
>
> Requisito: ter a `Circulação`. Classe Passiva 3.

Quando o domínio acaba, a técnica queima pelo resto da cena: é o Rescaldo, do capítulo 9, *Fundamento*. Quem chega aqui destrói a gravação queimada com energia e refaz com energia reversa, e o estrago acumula até a Expansão não abrir mais.

Ela só serve a quem abre Expansão de Domínio, e regravar é escolha. Sem regravar, o Rescaldo acaba com a cena, e na luta seguinte você abre de novo.

> **Exemplo.** No nível 26, com Inteligência 5, você tem `2 + 2 = 4` marcas. Você abre a Expansão, regrava, e repete até a quarta regravação. Ela devolve a técnica, e a Expansão fica fechada até o descanso longo.

## Aptidões de kokusen

### Kokusen

> **Kokusen** — em crítico no corpo a corpo, role d100. `2 × refino` ou menos é kokusen: o dano leva +50% depois de todos os valores resolvidos.
>
> Cada d100 falhado empurra o próximo em **+2**, e o acumulado zera no descanso longo.
>
> Requisito: nenhum, e ele não gasta marco. O refino escala a chance no d100.

O +50% entra em cima do crítico que já dobrou os dados. Um crítico entrega dois punhados de dado; um kokusen entrega três. Por exemplo, com refino 6 o kokusen sai em 12 ou menos no d100 — 12% dos seus críticos corpo a corpo.

O Kokusen em si não é uma aptidão: é uma mecânica, e todo feiticeiro que tem energia consegue usar. Ele não ocupa vaga de catálogo e não custa marco. Abaixo estão as duas aptidões que melhoram essa fonte.

### Kokusen Melhorado

> **Kokusen Melhorado** — mesma regra do `Kokusen`, exceto que você rola dois d100 e fica com o melhor.
>
> Requisito: refino 5 e nível 14. O refino escala a vantagem no d100.

### Kokusen Constante

> **Kokusen Constante** — mesma regra do `Kokusen`, exceto que a base sobe para `3 × refino`.
>
> Requisito: refino 5. O refino escala a chance no d100.

## Aptidões anti-domínio, e a `Extensão de Domínio`

Uma Expansão de Domínio completa não erra. O Acerto dela simplesmente acontece com quem está lá dentro, sem rolagem e sem Teste de Resistência, e nenhuma defesa da ficha encosta nele.

> **As quatro protegem do Acerto de uma Expansão de Domínio. Algumas delas servem contra a Expansão incompleta.**
>
> Erguer qualquer uma das quatro custa a sua maior Classe em PE, toda vez que ela sobe.
>
> A incompleta não tem acerto garantido: o Acerto dela rola. Contra ela você se defende com Defesa e com Teste de Resistência, como se defende de tudo o mais no jogo.

**Aptidões anti-domínio**
| | protege | e cobra | PE por rodada |
|---|---|---|---|
| **Cesta Oca de Vime** | só você, dentro de uma esfera | as duas mãos presas no símbolo, e ela cai com os golpes em você | nenhum |
| **Domínio Simples** | um raio em volta de você, e quem estiver nele | aguenta poucas rodadas de Expansão, menos contra quem tem mais Essência | `2` |
| **Pétala** | o seu corpo, e rebate o que toca | cede contra quem tem mais Essência, e cai com os golpes em você | `1` |
| **Extensão de Domínio** *(não é anti-domínio: ela serve como uma)* | você inteiro, contra tudo o que a Expansão faz | nenhum feitiço nem `Manejo` enquanto ela estiver de pé, e é a mais cara | `1,5 × maior Classe` |

### Cesta Oca de Vime

> **Cesta Oca de Vime** — você faz o símbolo e uma esfera se fecha em volta de você. Enquanto você o segurar, o Acerto de uma Expansão não te alcança, e as suas duas mãos ficam presas nele: nada de arma, escudo, feitiço com `Gesto` ou `Agarrar`. Andar e chutar, pode. Ela levanta com uma Reação quando uma Expansão abre, ou com uma Ação Bônus no seu turno. Erguer custa a sua maior Classe em PE, toda vez que ela sobe; de pé, ela não custa nada.
>
> Ela cai pelos golpes em você, e não pela Expansão. Cada golpe que te acerta pede o teste do `Carregar`: um Teste de Resistência de Espírito contra a CD de quem te feriu. As falhas se acumulam, e com metade da sua Essência em falhas (no mínimo 1) a esfera se desfaz. Esse teste não ocupa a sua Concentração, e a Mão Firme não protege dele.
>
> Se você soltar o símbolo, ela fica de pé e você recupera as mãos, mas cada Acerto letal da Expansão conta uma falha, no máximo uma por rodada. Quando ela cai, a Expansão te alcança na hora, com um Acerto a mais: o do começo do turno do dono continua vindo. Você pode levantar de novo sem espera, com as falhas zeradas, gastando a Ação Bônus do seu turno.
>
> Requisito: ser Reencarnado, ou ser treinado em `História`. Classe Passiva 1.

A `Cesta Oca de Vime` anula o Acerto e mais nada: o Efeito da Expansão continua acontecendo em cima de você. Contra uma Expansão pequena ela segura quase tudo; contra uma grande ela cede, porque a luta dura mais e quem bate tem CD mais alta.

### Domínio Simples

> **Domínio Simples** — um domínio pequeno em volta de você, de raio `1,5 m + refino ÷ 2`, que cobre quem estiver nele. Lá dentro a Expansão não alcança ninguém: nem o Acerto dela, nem o que ela faz com as pessoas ou com o lugar. Ele levanta com uma Reação quando uma Expansão abre, ou com uma Ação Bônus no seu turno, e custa `2` PE por rodada. Erguer custa a sua maior Classe em PE, toda vez que ele sobe.
>
> Ele aguenta a Expansão por 3 rodadas, 4 se a sua Essência for maior que a do dono dela e 2 se for menor. Cada Acerto que ele segura gasta uma rodada, a começar pelo de quando ela abre. Quando as rodadas acabam, o Acerto seguinte o derruba e alcança quem ele protegia. Golpe em você não o derruba.
>
> Cada Acerto que ele segura pede o teste do `Carregar`: um Teste de Resistência de Espírito contra a CD do dono da Expansão. Uma falha tira uma rodada, mas as falhas nunca levam a duração abaixo de metade da sua Essência (no mínimo 1). Esse teste não ocupa a sua Concentração, e a Mão Firme não protege dele.
>
> Se ele cair pelo voto, no meio da rodada, a Expansão alcança na hora, com um Acerto a mais: o do começo do turno do dono continua vindo. Você pode erguer de novo sem espera, mas da segunda vez em diante, na mesma Expansão, isso custa a Ação Padrão, e ele aguenta metade das rodadas (no mínimo 1).
>
> Requisito: ter visto um sendo usado, ou ter aprendido com alguém (anote na ficha de quem, ou onde); refino 5, ou refino 4 com o voto do iniciante. Classe Passiva 2. O refino escala o raio.

**Rodadas que o Domínio Simples aguenta**
| a sua Essência, contra a do dono da Expansão | maior | igual | menor |
|---|---|---|---|
| rodadas que ele aguenta | `4` | `3` | `2` |
| erguendo de novo, na mesma Expansão | `2` | `1` | `1` |

O refino não entra nas rodadas: ele dá o raio. A mesa só fica sabendo das rodadas, então a Essência do dono da Expansão continua escondida, a não ser no empate.

Uma Expansão de refino 10 solta seis Acertos, então contra ela nenhum Domínio Simples aguenta até o fim, nem erguido de novo.

**O voto do iniciante.** Com refino 4 você só firma o Domínio Simples com um voto: ele fica no ponto em que você o ergueu, e se os seus dois pés saírem desse ponto ele se desfaz, e a Expansão alcança na hora quem ele protegia. Andar, ou ser empurrado, tira os pés do ponto. Quando o seu refino chega a 5 você larga o voto, e ele passa a andar com você.

O que a Expansão dá ao dono dela continua com o dono: o desconto nos feitiços e o que o Efeito dele permite fazer. A técnica dele entra no raio como técnica comum, rolando ataque e Teste de Resistência, e quem está preso no domínio continua preso.

### Pétala

> **Pétala** — a energia cobre o seu corpo e rebate o que encosta nela, energia contra energia. Quando o Acerto de uma Expansão toca você, o dano dele depende da sua Essência contra a do dono da Expansão: maior, ele não te fere; igual, você leva um quarto; menor, você leva metade. O que a Expansão traz por contato e não é dano, como agarrar, condição ou marca, ela anula de qualquer jeito.
>
> Ela levanta com uma Reação quando uma Expansão abre, ou com uma Ação Bônus no seu turno. Erguer custa a sua maior Classe em PE, toda vez que ela sobe, e de pé ela custa `1` PE por rodada.
>
> Ela cai pelos golpes em você. Cada golpe que te acerta, de qualquer um, pede o teste do `Carregar`: um Teste de Resistência de Espírito contra a CD de quem te feriu. Com metade da sua Essência em falhas (no mínimo 1), ela se desfaz. Esse teste não ocupa a sua Concentração, e a Mão Firme não protege dele.
>
> Quando ela cai, a Expansão não te alcança na hora: o próximo Acerto te pega inteiro se ela ainda estiver caída. Erguer de novo custa a Ação Bônus, com as falhas zeradas.
>
> Com uma arma corpo a corpo empunhada, ela contra-ataca. Quando um golpe corpo a corpo te acerta, você pode gastar a Reação num ataque de oportunidade com vantagem contra quem te acertou, se ele estiver ao seu alcance. Cada contra-ataque custa `3` PE. O soco não conta.
>
> Requisito: ser Descendente, ou ter aprendido com alguém de um clã; refino 4 e nível 10. Classe Passiva 2.

**Quanto a Pétala segura**
| a sua Essência, contra a do dono da Expansão | maior | igual | menor |
|---|---|---|---|
| o dano do Acerto que toca, que você leva | nada | `1/4` | metade |

A Pétala só responde ao que toca: corte, chama, enxame, criatura, a mão de alguém. O Acerto que não encosta, como informação ou uma regra, passa por ela, e o que não é Acerto de Expansão também, como um soco. Contra a Expansão incompleta ela não faz nada, e fora de uma Expansão ela só serve para o contra-ataque.

### Extensão de Domínio

> **Extensão de Domínio** — você se envolve numa camada fina de domínio sem técnica dentro. Enquanto ela estiver de pé, nada do que uma Expansão faz te alcança: nem o Acerto dela, nem o que ela faz com as pessoas ou com o lugar, seja ela completa, incompleta ou sem barreiras. A barreira continua te prendendo, e o que a Expansão dá ao dono dela continua com ele.
>
> Ela levanta com uma Reação quando uma Expansão abre, ou com uma Ação Bônus no seu turno. Erguer custa a sua maior Classe em PE, toda vez que ela sobe; de pé, ela custa `1,5 × a sua maior Classe` de PE por rodada, e dura `refino` rodadas. Ela não cai por golpe.
>
> A técnica que encostar nela é anulada até `1/3 do refino + 1`: uma Classe Passiva, uma Regra Própria ou um feitiço de Classe até esse número. Acima dele, ela reduz o dano em um quarto, e você leva `3/4`.
>
> Enquanto ela estiver de pé, você não usa feitiço nem `Manejo`. Se a sua Expansão já estava aberta, ela continua; abrir uma nova derruba a Extensão.
>
> Requisito: ter visto uma sendo usada, ou ter estudado, ou aprendido com alguém; refino 7 e nível 18. O Corpo Amaldiçoado não compra. Classe Passiva 3. O refino escala a duração e o teto.

## Aptidões de barreira

> **As duas levam um minuto para levantar**, e um minuto são dez rodadas. As duas são ferramenta de preparação, e se levantam antes da briga começar.

### Barreira Simples

> **Barreira Simples** — um domo de raio `6 m`, ancorado no lugar onde você o ergueu, que bloqueia passagem e linha de efeito nos dois sentidos. Ele tem `5 × refino` de pontos de vida, e cai quando você fica `Inconsciente`.
>
> Requisito: nenhum. O refino escala a vida do domo.

O domo fica onde foi erguido. Você não leva ele junto, e é por isso que ele serve para fechar um cômodo, uma porta, uma escada.

### Cortina

> **Cortina** — mesma preparação de um minuto da `Barreira Simples`, exceto que ela cobre um lugar inteiro: um prédio, uma escola, um quarteirão. Ela esconde o que está dentro de quem não é feiticeiro, e você pendura uma condição sobre quem atravessa. Ela tem `40 × refino` de pontos de vida, e cai quando você fica `Inconsciente`.
>
> Requisito: exige a `Barreira Simples`. O refino escala a vida dela.

**Cortina**
| a condição pode | a condição não pode |
|---|---|
| barrar uma pessoa específica | causar dano a quem entra |
| deixar entrar quem tem energia amaldiçoada, e mais ninguém | mover a cortina, ou fazer ela seguir você |
| impedir que quem está dentro saia | dar bônus a quem está dentro |
| deixar passar quem você nomeou na hora de levantar | esconder de quem é feiticeiro, porque o efeito base já é o contrário |

> **Tamanho.** A `Cortina` não se mede em metros: ela cobre um lugar — um prédio, uma escola, um quarteirão —, e nada do que ela faz depende de distância. Quem precisa fechar uma distância com energia usa a `Barreira Simples`, que tem raio.

## Escrever uma aptidão

### Aptidão Própria

A vaga em branco do catálogo. É o truque que o seu feiticeiro desenvolveu manejando a própria energia, pequeno o bastante para nunca ter virado regra escrita, e específico o bastante para ninguém mais na mesa fazer igual.

> **Aptidão Própria** — você escreve, com o mestre, uma aptidão que não está no catálogo. Antes da sessão, e nunca no meio dela. Ela é Classe Passiva 1 ou 2, nunca 3, e você só pode pegá-la uma vez na ficha inteira.
>
> A ficha registra duas coisas: a frase, e a resposta de *"em quantas cenas por arco isso vai importar?"*.
>
> Requisito: uma vez na ficha inteira. Classe Passiva 1 ou 2.

A resposta dessa pergunta é o que decide o degrau:

**Peso e degrau**
| em quantas cenas por arco | o peso | o degrau |
|---|---|---|
| uma | Leve | Classe Passiva 1 |
| metade | Média | Classe Passiva 2 |
| quase toda | Pesada | Classe Passiva 3 |

> **Na dúvida, Pesada.** Pesada é Classe Passiva 3, e a Classe Passiva 3 está fora do que a `Aptidão Própria` alcança. Então dúvida reprova a proposta.

As cinco travas:

1. **Uma frase.**
2. **Verificável**: a mesa aponta o momento em que ela disparou.
3. **Não é atalho**: ela não repete uma das treze outras entradas do catálogo com outro nome, e não entrega uma que o seu requisito ainda não alcança.
4. **Sem dado de dano.**
5. **Com limite por cena**, se ela for Classe Passiva 2.

Três propostas, e uma delas é recusada:

**Exemplos de Aptidão Própria**
| proposta | em quantas cenas | degrau | veredito |
|---|---|---|---|
| *"você sabe se um objeto foi tocado por energia amaldiçoada nas últimas 24 horas"* | uma por arco | Classe Passiva 1 | **passa** |
| *"uma vez por cena, quando um aliado a até 9 m falha um Teste de Resistência, ele rerrola"* | metade | Classe Passiva 2 | **passa** |
| *"o seu deslocamento é `+3 m`"* | quase toda | Classe Passiva 3 | **recusada** |

A trava é de forma e não de tamanho: `+3 m` é pouca coisa, e mesmo assim está fora. Uma coisa que fica sempre ligada é Classe Passiva 3, no tamanho que for.

> Quem quiser a mesma ficção com Classe Passiva 3 tem a `Passiva Própria`, do lado do Fundamento, pagando em espaço de feitiço.

## Expansão de Domínio

A regra da Expansão está no capítulo 9, *Fundamento*, e é lá que ela é montada. Ela gasta espaço de feitiço, como Passiva, e o Acerto dela é o que as três aptidões anti-domínio anulam — mais a `Extensão de Domínio`, que não é da categoria e anula o mesmo.

---


# Capítulo 13 · Ritual

*fonte: `manual/46-ritual.md`*

Todo feitiço tem partes que você aprendeu a pular. O sinal de mão inteiro, o encantamento dito até o fim, a palma parada no lugar certo — um feiticeiro treinado corta tudo isso e conjura mesmo assim, mais rápido e sem avisar ninguém do que vem.

Ritual é parar de cortar.

Você faz o sinal completo, recita o verso inteiro, aponta a palma e segura ela ali. O feitiço sai mais forte porque ele sai **inteiro**. E sai mais devagar, porque fazer tudo leva tempo, e porque quem está na sua frente vê você fazendo.

> **Ritual é ação de combate.** Ele não é uma preparação de meia hora antes da missão: é uma coisa que você decide no seu turno, com o inimigo na sua frente, sabendo que vai custar.

## Pontos de Ritual

Ritualizar te dá **Pontos de Ritual**, e eles compram Melhorias de uma lista que só existe aqui. Esses pontos não saem do orçamento do feitiço — o feitiço continua com todos os pontos dele.

Quanto tempo você gasta decide quantos pontos você recebe.

**Quanto o ritual rende**
| Tempo que você gasta | Pontos de Ritual |
|---|---|
| **Ação Padrão** — o tempo normal de um feitiço | **2** |
| **Ação Completa** — a rodada inteira: sem movimento, sem Ação Bônus, sem mais nada | **6** |
| **Recitação Prolongada** — dois turnos, e o feitiço sai no segundo | **10** |

A Recitação Prolongada é o nome do degrau mais longo. Você começa o ritual num turno e dispara no seguinte.

## Teste de Ocultismo

Fazer os sinais certos no meio de uma luta é difícil, e quanto maior o feitiço, mais difícil fica. Você rola **Ocultismo** para montar o ritual.

> **CD = 8 + a sua Inteligência + a sua maestria + a Classe do feitiço − a sua Destreza.**

A sua Inteligência e a sua maestria estão nos dois lados da conta, então elas se cancelam: na prática você rola `d20` contra `8 + Classe − Destreza`. Isso quer dizer que **subir Inteligência não te faz ritualizar melhor**. O que faz é a Destreza, que é a mão treinada, e o treino em Ocultismo.

**Chance de montar o ritual**
| Classe do feitiço | 1 | 2 | 3 | 4 | 5 | 6 | 7 |
|---|---|---|---|---|---|---|---|
| Destreza 6 | 80% | 75% | 70% | 65% | 60% | 55% | 50% |
| Destreza 3 | 65% | 60% | 55% | 50% | 45% | 40% | 35% |
| Destreza 0 | 50% | 45% | 40% | 35% | 30% | 25% | 20% |

Se você **não é treinado** em Ocultismo, você não soma a maestria na rolagem — mas a CD soma assim mesmo. São uns 14 pontos percentuais a menos, e a diferença cresce conforme a campanha anda. Ninguém proíbe ritualizar sem treino; só é pior, e fica cada vez pior.

### Falha no ritual

O feitiço **sai mesmo assim**, sem nenhum Ponto de Ritual, e custa a **Classe do feitiço** em pontos. Você perdeu o tempo e uma parte da força, mas não perdeu o turno inteiro.

A Recitação Prolongada é diferente: ela **não rola**. Em vez do teste, ela usa a Restrição **Carregar** — se você tomar dano enquanto segura o feitiço, faz um Teste de Resistência de Espírito contra a CD de quem te feriu. Falhou, perdeu o feitiço.

## Melhorias de Ritual

Os Pontos de Ritual compram daqui, e só daqui.

**Lista de Melhorias de Ritual**
| Melhoria | O que faz | Pontos |
|---|---|---|
| **Ritual de Acerto** | +1 na rolagem de acerto. Pode comprar duas vezes. | 1 |
| **Ritual de Dificuldade** | +1 na CD do Teste de Resistência. Pode comprar duas vezes. | 1 |
| **Ritual de Defesa** | +2 de Defesa até o seu próximo turno. | 1 |
| **Ritual de Rerrolagem** | Rerrola os dados de dano que caírem no mínimo, até Classe + 1 deles. | 1 |
| **Ritual de Energia** | O feitiço custa metade da Classe, mínimo 1, a menos de PE. | 2 |
| **Ritual de Tamanho** | Sobe um degrau na escada de área. | 2 |
| **Ritual de Alcance** | Sobe um degrau na escada de alcance. | 2 |
| **Ritual de Perseguição** | O feitiço não pode ser desviado. | 2 |
| **Ritual de Excedente** | A cura que passa do máximo vira vida temporária, até um quarto da cura. | 2 |
| **Ritual de Compartilhamento** | Um aliado a mais, e o efeito não se divide. | 2 |
| **Ritual de Duração** | O efeito de estado dura uma rodada a mais. | 2 |
| **Ritual de Cobertura** | Ignora Cobertura Parcial. | 2 |
| **Ritual de Transmutação** | Escolhe o tipo de dano entre os que a sua técnica faz. | 2 |
| **Ritual de Meio Acerto** | Se você errar, metade dos dados acerta mesmo assim. | 3 |
| **Ritual de Seleção** | A área não atinge aliados. | 3 |
| **Ritual de Tiros** | +1 alvo na Rajada, e os dados não se dividem de novo. | 4 |

### Restrição desfeita pelo ritual

Se uma Melhoria de Ritual apaga o que uma Restrição cobra, aquela Restrição não devolve ponto nenhum. É a mesma regra do Selo: vender a mesma dor duas vezes não vale ponto novo.

São dois casos:

- **Ritual de Meio Acerto** não entra com a Restrição **Sem Volta**. Aquela Restrição cobra "se o feitiço não acertar ninguém"; se metade sempre acerta, ela nunca cobraria nada.
- **Ritual de Alcance** não entra com a Restrição **Corpo a Corpo**. Aquela te obriga a chegar a 1,5 m; subir um degrau de alcance desfaz parte do que ela cobra.

## Melhorias por Forma

Uma Melhoria de dano não entra num feitiço de apoio, e uma de cura não entra num feitiço de ataque. A trava é a mesma das Famílias: a Melhoria precisa de uma coisa que a Forma tenha.

**Melhorias por Forma**
| Forma | Alcança |
|---|---|
| **Projétil** e **Toque** | Acerto, Dificuldade, Defesa, Rerrolagem, Energia, Alcance, Perseguição, Duração, Cobertura, Transmutação, Meio Acerto |
| **Explosão**, **Aura**, **Cone**, **Linha** | as mesmas, menos Meio Acerto, mais Tamanho, Seleção e Tiros |
| **Cura** e **Apoio** | Defesa, Rerrolagem, Energia, Alcance, Excedente, Compartilhamento, Duração |
| **Onda** | as de Cura e Apoio, mais Tamanho e Seleção |
| **Efeito** | não ritualiza — ele é fora de combate |

## Liberação Máxima e ritual

Dá para ritualizar uma Liberação Máxima, e essa é a única coisa no sistema que passa do **Teto** de dano.

A Recitação Prolongada entrega, além dos Pontos de Ritual, **metade do vão** entre um feitiço comum e o Teto — que é metade da Classe, com o mínimo de 1. Somando as duas coisas, você chega de 1 a 3 dados acima do Teto.

> É pouco em número e muito em cena: são os 10 a 14 por cento a mais que separam o feitiço que você lança sempre do feitiço que a mesa vai lembrar.

## Ritual em dupla

Um aliado que também saiba ritualizar pode gastar a **Ação Completa** dele para te ajudar. Ele te dá **4 Pontos de Ritual**, e esses pontos não entram na CD.

Se o ritual falhar, os dois pagam a correção.

Auxiliar não costuma ser um bom negócio dentro do combate: o aliado gasta o turno inteiro dele e você ganha menos do que ele perde. Fora de combate, onde o turno não vale nada, ele sai de graça.

## Acesso

Ritual é uma aptidão. Ela pede **Inteligência 5** e **nível 10**. Quem monta a técnica em `Manejo` ou em `Kata` não compra.

O nível 10 não é escolha arbitrária: no marco 6 você escolhe entre um ponto de atributo e uma aptidão, e não dá para ter os dois. Inteligência 5 e uma aptidão só se encontram no marco seguinte. Quem tem Inteligência como atributo secundário chega no 14.

## Exemplo

*Kaito é um conjurador de nível 13, Inteligência 6, Destreza 4, treinado em Ocultismo, e tem a aptidão de Ritual. Ele quer abrir a luta com o feitiço de Classe 4 dele — uma Explosão.*

*Ele decide gastar a Ação Completa: 6 Pontos de Ritual. A CD é 8 + 6 + 2 + 4 − 4 = 16, e ele rola d20 + 6 + 2. Precisa de 8 ou mais no dado: 65%.*

*Tira 14. Passou.*

*Com os 6 pontos ele compra Ritual de Tamanho (2), Ritual de Dificuldade duas vezes (2) e Ritual de Seleção (3)… e para, porque isso são 7. Troca o Seleção pelo Ritual de Energia (2): a Explosão sai com um degrau a mais de raio, +2 na CD, e custa 10 PE em vez de 12.*

*Se ele tivesse falhado, a Explosão sairia do mesmo jeito, sem nada disso, e ainda custaria 4 pontos a menos de dano.*

---


# Capítulo 14 · Bênçãos e Lapidação

*fonte: `manual/47-bencaos-e-lapidacao.md`*

Bênção e Lapidação valem para **uma** rota de criação: a Restrição Celestial pelo ramo **sem energia**, no capítulo 7, *Origens e Legados*. Uma ficha com energia amaldiçoada — inclusive o Corpo Amaldiçoado, que produz a própria — usa refino e aptidões, no capítulo 12, *Aptidões e Refino*.

> **Sem energia amaldiçoada não existe refino nem aptidão.** No lugar dos dois vêm a **Lapidação** e as **Bênçãos**, e a máquina é a mesma casa por casa. O que muda é o conteúdo do catálogo.

## Lapidação

A Lapidação mede quanto da folga do corpo o seu personagem já gastou treinando.

> **A Lapidação vai de `1` a `10`.** Toda ficha começa em 1, e ela sobe nos marcos: **`+1` de graça em cada um, e mais `+1` se você escolher Lapidação no marco**.
>
> **São os mesmos degraus do refino, casa por casa** — a tabela `Refino por marco` do capítulo 12 vale para ela, trocando o nome.

> **A Lapidação nunca entra num número disputado contra alguém que cresce mais devagar que ela.** Ela fica fora de acerto, CD, defesa e Teste de Resistência.

Onde ela entra é em custo, em quantas vezes por cena, em alcance e duração, e em magnitude fora de disputa — a proteção de `Defesa sem Armadura`, o piso do `Esteio` e o dano na arma do `Estímulo Muscular`, que só vale na rodada em que você ataca. **Kata nunca cresce com Lapidação:** ela tem orçamento próprio, no capítulo 10, *Técnica Marcial*.

> **Arredondamento.** Toda divisão de Lapidação arredonda para baixo: Lapidação 5 dividido por 2 dá 2.

## Marco

> **Passivo:** +1 ponto de atributo, +1 de Lapidação e +1 espaço de Kata.
>
> **Escolha, uma das três:**
>
> **Corpo** — mais um ponto de atributo.
>
> **Lapidação** — mais um de Lapidação, e uma Bênção. **Se a sua Lapidação já estiver no teto, você leva duas Bênçãos no lugar.**
>
> **Leque** — mais uma Kata, que só pode ser Kata, e uma Passiva.

> **Quem nunca escolhe Lapidação termina a campanha com zero Bênçãos pagas.** A rota existe e é legítima: ela troca dez Bênçãos por sete pontos de atributo a mais.
`Defesa sem Armadura` e `Estímulo Muscular` vêm de graça na Lapidação 1, então nenhuma ficha fica sem Bênção nenhuma. A primeira continua crescendo com a Lapidação passiva até 8.

## Bênçãos

> **Bênção não custa espaço de Kata.** Espaço de Kata é a moeda das Passivas. As duas economias são separadas: Bênção custa marco, e só marco.

### Classe Passiva

**A Classe Passiva é o tamanho da Bênção**, e diz o quanto aquela entrada pode entregar. As Bênçãos usam a mesma escada das Passivas e das aptidões: a escada e o que cabe em cada altura estão no capítulo 9, *Fundamento*, na seção `Passivas`.

A Classe Passiva não cobra nada aqui: o marco compra uma de qualquer altura. Quem separa as alturas é o requisito.

**E se você for escrever uma `Bênção Própria`, a escada do capítulo 9 é a base:** escolha a altura que a sua ideia alcança, e escreva dentro do que aquela linha permite.

### Requisito

> **Requisito de atributo:** você precisa daquele atributo em **4** ou mais para pegar a Bênção.
>
> **⚠ Uma Bênção com requisito de atributo não soma aquele atributo na rolagem dela.** Ou você paga para destravar, ou usa na conta — nunca os dois.

## Catálogo

### Como funciona uma Bênção

Cada entrada aparece duas vezes. Primeiro nesta tabela, com três campos: **nome**, **requisito** e **Classe Passiva**. Depois na seção dela, com uma caixa de regra.

Traço na coluna de requisito quer dizer que ela não tem requisito. Traço na de Classe Passiva quer dizer que a entrada não tem um cálculo baseado em Classe Passiva, e que ela não pode ser usada como base.

**Como ler uma Bênção**
| Bênção | Requisito | Classe Passiva |
|---|---|---|
| Defesa sem Armadura | grátis na Lapidação 1 | — |
| Estímulo Muscular | grátis na Lapidação 1 | — |
| Ímpeto | Destreza 4 | 2 |
| Casco | Constituição 4 | 3 |
| Presilha | Força 4 | 2 |
| Vigília | — | 2 |
| Esteio | — | 3 |
| Faro | — | 1 |
| Sem Pegada | — | 1 |
| Vulto | — | 2 |
| Antecipar | Inteligência 4 | 2 |
| Campo | — | 1 |
| Assombro | Essência 4 | 1 |
| Bênção Própria | uma vez na ficha inteira | 1 ou 2 |

## Bênçãos de graça

Estas duas chegam com a ficha, na Lapidação 1, sem custar marco nenhum.

### Defesa sem Armadura

> **Defesa sem Armadura** — sem Traje e sem Revestimento, a sua proteção é `1/3 da Lapidação + 1`. Escudo soma com ela.
>
> Como Reação: Redução de Dano de `1,5 × Lapidação` num golpe, por **2 PE**. Você fica sem proteção até o fim do seu próximo turno.
>
> **Barreira de energia não segura você.** `Barreira Simples` e `Cortina` não detectam nem impedem você.
>
> **Expansão de Domínio.** O Acerto garantido de uma Expansão completa não alcança você. O Efeito continua acontecendo em volta, e uma Expansão incompleta funciona normalmente, porque o Acerto dela precisa de uma rolagem: ela não busca alvos com base em energia.
>
> Requisito: grátis na Lapidação 1. A Lapidação escala a proteção e a Redução de Dano da Reação.

**Traje e Revestimento.** Vestir um dos dois desliga só a proteção. A barreira e o Acerto garantido continuam sendo negados: eles vêm de você não ter energia amaldiçoada, e uniforme sem grau não tem energia.

Quem não tem energia amaldiçoada nunca tem Expansão de Domínio — está no capítulo 10, *Técnica Marcial*.

> **Você atravessa, o equipamento não.** Ferramenta amaldiçoada e objeto amaldiçoado emanam energia, e é o que eles emanam que a barreira lê: você entra na `Cortina`, e o seu equipamento amaldiçoado é detectado, ou nem atravessa, se for uma barreira física de energia. Contra Expansão de Domínio é diferente — o Acerto garantido busca alvos, e item normalmente não é alvo legível.
A Passiva `Maldição do Inventário`, no capítulo 10, *Técnica Marcial*, guarda o item dentro do corpo, e lá dentro ele para de emanar energia — o que permite ao **Sem energia** voltar a atravessar as barreiras normalmente.

### Estímulo Muscular

> **Estímulo Muscular** — escolha **uma perícia** e **um Teste de Resistência** na criação.
>
> **Usos.** `1×` por cena, e `2×` se a sua Lapidação for `10`. Cada uso dá **vantagem** numa rolagem de um dos dois escolhidos.
>
> **Dano na arma.** Os seus ataques **com arma** causam `1d4` de dano a mais a cada `3` pontos de Lapidação — `1d4` na Lapidação `1`, `2d4` na `3`, `3d4` na `6`, `4d4` na `9`. **Na Lapidação `10` os dados viram `d6`: `4d6`.**
>
> **Só arma.** Ele não entra em Kata nenhuma. E se o mesmo ataque já estiver carregando uma Kata de dano de `Classe 0` ou mais, este dano **não** se soma por cima — **é o caso do `Ferrão`, o nível 27 da Estocada, em que o golpe leva uma junto.** *Nesta rota o degrau de Trilha entrega Kata e não feitiço, e o capítulo 8, *Caminhos e Trilhas*, diz isso na abertura.*
>
> Requisito: grátis na Lapidação 1. A Lapidação escala o dano na arma e o número de usos.

> **Exemplo.** Com Lapidação 6, o soco e a lâmina levam `3d4` de dano a mais.

A escolha não precisa ser física. `Ocultismo` mais `Intelecto` é uma opção tão usável quanto `Atletismo` mais `Físico`.

## Bênçãos de corpo

### Ímpeto

> **Ímpeto** — como Ação Bônus, você se move até o seu deslocamento sem provocar ataque de oportunidade.
>
> **Sem chão.** Você anda em parede, em água e no ar enquanto estiver se movendo. Se terminar o turno e o movimento sem apoio, você cai.
>
> Requisito: Destreza 4. Classe Passiva 2.

### Casco

> **Casco** — você ganha **`+1` de vida a cada dois níveis** e **`+1`** em todo Teste de Resistência de Vigor que fizer.
>
> Requisito: Constituição 4. Classe Passiva 3.

### Presilha

> **Presilha** — quando você **falha** numa rolagem para **agarrar, derrubar ou tirar alguém do lugar**, role de novo. Uma vez por rodada.
>
> Requisito: Força 4. Classe Passiva 2.

### Vigília

> **Vigília** — você conta **um degrau de exaustão a menos** do que tem, para todo efeito.
>
> O degrau continua marcado na ficha. O que muda é o que ele cobra de você.
>
> Requisito: nenhum. Classe Passiva 2.

Ela não vira imunidade: a escada de exaustão do capítulo 5 tem três degraus e não tem degrau zero, então o pior caso continua sendo dois. E o descanso longo continua limpando no mesmo ritmo.

### Esteio

> **Esteio** — escolha **um atributo** na hora de pegar esta Bênção. Num Teste de Resistência daquele atributo, se o `d20` sair abaixo da sua **Lapidação**, ele vale a sua Lapidação.
>
> **Teto.** Ele nunca passa do atributo escolhido mais `2`, então o máximo dele é `8`.
>
> Requisito: nenhum. Classe Passiva 3.

## Bênçãos de perseguição

### Faro

> **Faro** — você segue rastro de feiticeiro e de maldição pelo rastro que eles deixaram: cheiro, marca, o que ficou fora do lugar.
>
> **Vestígio de técnica.** Encostando no que uma técnica fez, você sabe o superficial do que ela fez ali: o tipo de coisa que aconteceu, e nunca o detalhe nem de quem é.
>
> Requisito: nenhum. Classe Passiva 1.

### Sem Pegada

> **Sem Pegada** — você não deixa rastro físico: pegada, cheiro, marca, som de passo. **Nem `Faro`, nem cão, nem técnica de rastreamento acham por onde você passou.**
>
> Requisito: nenhum. Classe Passiva 1.

Não é furtividade: `Furtividade` continua sendo a perícia, e esta Bênção não soma nada nela. Isto apaga o vestígio, não a testemunha ter te visto.

## Bênçãos de combate

### Vulto

> **Vulto** — você percebe tudo o que estiver a **`1,5 m × metade da Lapidação`** de você sem precisar estar com os olhos abertos, só por som e movimento. É **visão às cegas**.
>
> Requisito: nenhum. Classe Passiva 2.

### Antecipar

> **Antecipar** — quando você **falha** num Teste de Resistência contra um efeito, você passa a rolar **com vantagem** contra aquele mesmo efeito pelo resto da cena.
>
> Requisito: Inteligência 4. Classe Passiva 2.

### Campo

> **Campo** — a ação **`Estudar`** custa a sua Ação Bônus em vez da Ação Padrão, **uma vez por cena**.
>
> Requisito: nenhum. Classe Passiva 1.

### Assombro

> **Assombro** — uma vez por cena, ao entrar numa cena ou ao ser visto pela primeira vez, escolha uma quantidade de criaturas que enxergam você igual a metade da sua Lapidação, no mínimo `1`.
>
> **O que ela rola.** Um Teste de Resistência de Espírito contra a CD da sua técnica, ou ela fica `Amedrontado` até o fim do próximo turno dela.
>
> Requisito: Essência 4. Classe Passiva 1.

A CD é a da sua técnica, do capítulo 9: `8 + atributo da técnica + maestria`.

## Escrever uma Bênção

### Bênção Própria

A vaga em branco do catálogo: a coisa que o seu personagem descobriu que o corpo dele faz, pequena o bastante para nunca ter virado comum.

> **Bênção Própria** — você escreve, com o mestre, uma Bênção que não está no catálogo. Antes da sessão. Ela é Classe Passiva 1 ou 2, nunca 3, e você só pode pegá-la uma vez na ficha inteira.
>
> A ficha registra duas coisas: a frase, e a resposta de *"em quantas cenas por arco isso vai importar?"*.
>
> Requisito: uma vez na ficha inteira. Classe Passiva 1 ou 2.

A régua é a mesma da `Aptidão Própria`, no capítulo 12, e vale inteira: uma frase, verificável, sem dado de dano, com limite por cena se for Classe Passiva 2, e não pode repetir uma das doze do catálogo com outro nome nem entregar uma que o seu requisito não alcança.

> **Na dúvida, Pesada.** Pesada é Classe Passiva 3, e a Classe Passiva 3 está fora do que a `Bênção Própria` alcança. Então dúvida reprova a proposta.

E existe uma trava a mais:

> **Uma Bênção com requisito de Constituição ou de Força não pode ser bônus, vantagem ou rerrolagem numa perícia.** Ela tem de ser **feito**: sobrevivência, recuperação, ou uma coisa única que o corpo passa a poder fazer.

---


# Capítulo 15 · Equipamento

*fonte: `manual/50-equipamento.md`*

Equipamento mexe em três coisas: a sua Defesa, o dado que você rola quando bate, e o que dá para fazer com a coisa que está na sua mão.

## Proteção

> **Defesa = 10 + Destreza + proteção.**

Existem duas classes de uniforme, e você usa uma ou outra: **Traje**, que é a leve, e **Revestimento**, que é a pesada. Cada uma tem três degraus.

### Como ler as tabelas de proteção

Os três campos aparecem sempre na mesma ordem.

- **proteção** — o número que soma na sua Defesa.
- **teto de Destreza** — o máximo de Destreza que conta na Defesa enquanto você estiver com aquilo vestido. `—` quer dizer que não tem teto.
- **requer Força** — a Força mínima para vestir. `—` quer dizer que não pede nada.

Se você estiver usando duas coisas com teto de Destreza diferente, vale o menor dos dois.

### Traje

A classe leve. Nenhum degrau trava a sua Destreza, e só o último degrau pede Força.

**Traje**
| degrau | proteção | teto de Destreza | requer Força | `Volume` |
|---|---|---|---|---|
| 1 | 1 | — | — | leve |
| 2 | 2 | — | — | `1` |
| 3 | 3 | — | 3 | `2` |

Quem fabrica é o ofício **Alfaiate**. Quem não tem o ofício encomenda de quem tem.

#### Situação do Traje

> **Todo Traje carrega uma situação.** Escolha na criação, escreva na ficha como o seu traje é, e quando a cena estiver naquela condição você rola com **vantagem** todos os seus testes de perícia e Testes de Resistência, à escolha na criação: joga dois d20 e fica com o melhor. Vantagem não empilha, duas fontes valem uma.

A lista é fechada e vale igual em toda mesa:

**Situação do Traje**
| situação |
|---|
| vão apertado |
| altura e beirada |
| escuro |
| superfície ruim |
| água e chuva |
| multidão |
| terreno instável |
| calor e fogo |

E existe uma vaga aberta: você pode inventar a sua, desde que ela passe nos três itens abaixo. Quem confere é o mestre, e um segundo mestre tem que chegar na mesma resposta. Toda situação se resume em uma ou duas palavras, no máximo.

> 1. É **condição física que o mestre já descreveu na cena**.
> 2. **Não decide o que uma das quatro perícias de Destreza já decide.** Senão vira vantagem em Furtividade pela porta dos fundos.
> 3. **Não acontece toda cena.** O alvo é mais ou menos um disparo por missão.

> **Exemplo.** Você pega **escuro**. Numa perseguição por um prédio sem luz, você rola com vantagem. Numa sala iluminada, o traje não faz nada, e o mestre não precisa julgar se você "usou bem" a roupa, porque a condição já estava descrita na cena antes de você pedir.

### Revestimento

A classe pesada. Todo degrau trava a sua Destreza em 0 na Defesa, e todo degrau pede Força.

**Revestimento**
| degrau | proteção | teto de Destreza | requer Força | `Volume` |
|---|---|---|---|---|
| 1 | 4 | 0 | 3 | `2` |
| 2 | 5 | 0 | 4 | `3` |
| 3 | 6 | 0 | 6 | `4` |

#### Uniforme e energia amaldiçoada

> **Traje e Revestimento desligam a sua proteção passiva de energia amaldiçoada.** Vestido, a sua proteção é a do uniforme, e só ela. Escudo soma por cima, sempre.

A Reação de cobrir-se continua disponível de uniforme. Ela é a aptidão `Cobrir-se de energia`, e o preço dela está no capítulo 12, *Aptidões e Refino*.

## Escudo

Três degraus. O escudo ocupa uma mão, soma com a sua proteção venha ela de onde vier, e ainda permite somar Destreza — se você não estiver de `Revestimento` —, com um teto para o quanto ela pode entrar.

**Escudo**
| degrau | nome | proteção | teto de Destreza | requer Força | `Volume` |
|---|---|---|---|---|---|
| 1 | **Broquel** | 1 | 5 | — | leve |
| 2 | **Médio** | 2 | 3 | 3 | `1` |
| 3 | **Torre** | 3 | 1 | 5 | `2` |

> **Aviso para quem tem `Selo` = `Gesto`.** Pegar um escudo ocupa a mão e desliga a sua técnica inteira. É o Selo funcionando: se o gesto é obrigatório para conjurar, sem a mão você não conjura. Para essa gente, escudo nunca esteve no menu.
## Armas

São 52, divididas em treze categorias. A categoria diz o que a coisa é, de onde vem o dano dela e em qual lista de treino ela cai.

Nenhuma arma deste catálogo fere maldição sozinha. Contra maldição, o que a elimina é energia amaldiçoada no golpe ou uma ferramenta amaldiçoada na mão, que é o que o `Estigma` explica no capítulo 16, *Ferramenta Amaldiçoada*. O catálogo de armas continua valendo inteiro contra pessoas, contra animais e contra objetos.

### Como ler uma arma

O `Catálogo de armas` tem seis colunas, nesta ordem:

**arma** · **categoria** · **mão** · **dado** · **propriedades** · **requer Força**

- **arma** — o nome. Nome japonês vem com a tradução entre parênteses.
- **categoria** — a família dela, e é onde o treino mora: treinar uma categoria libera todas as armas dela.
- **mão** — `1` ou `2`. Arma de duas mãos não deixa espaço para escudo nem para outros itens.
- **dado** — o dado de dano que você rola quando acerta.
- **propriedades** — o que a arma faz de diferente das outras. As restrições aparecem nessa mesma lista.
- **requer Força** — a Força mínima para empunhar. Um `—` quer dizer que não pede nada.

### Propriedades

**Propriedades**
| propriedade | o que faz |
|---|---|
| `Alcance` | Estica o corpo a corpo. Ver *Alcance no corpo a corpo* |
| `Longo Alcance` | A arma alcança à distância, em metros. Ver *Faixa de projétil* |
| `Duas mãos` | Ocupa as duas mãos, então não sobra mão para escudo. No catálogo ela aparece como o `2` da coluna **mão** |
| `Fineza` | No corpo a corpo, troca Força por Destreza no acerto **e** no dano |
| `Par` | Role dois dados de dano e fique com o melhor |
| `Oculta` | **Você esconde a arma no corpo:** arma com esta propriedade se esconde nas vestes ou no corpo sem precisar de teste, diferente das outras |
| `Versátil` | Nas duas mãos, o dado sobe um passo: `d6`→`d8`, `d8`→`d10`, `d10`→`d12` |
| `Munição` | Recarregar custa Ação Bônus. Ver *Munição* |
| `Rompe` | Vantagem contra objeto e estrutura |
| `Emaranha` | Você pode `Agarrar` sem largar a arma |
| `Vestida` | Não ocupa a mão |
| `Talha` | A arma é ruim de aparar: **−1** no `Bloquear` de quem se defende dela |

### Restrições

Restrição é defeito de verdade. Ela aparece na mesma coluna das propriedades.

**Restrições de arma**
| restrição | o que é |
|---|---|
| `Volumosa` | Não dá para esconder, e atrapalha em espaço apertado |
| `Embainhada` | Não se saca sozinha: precisa de tempo, ou de outra pessoa |
| `Comprida` | Perde no corpo a corpo colado |

Obs.: a `Comprida` ainda está sendo testada em armas novas. Por enquanto nenhuma arma tem `Comprida`.

### Alcance no corpo a corpo

O padrão de qualquer arma de mão é **1,5 m**. As Armas Longas chegam a **3 m**.

### Faixa de projétil

> **Toda arma de projétil tem duas faixas.**
>
> **Faixa normal** — até o `Longo Alcance` da arma. Ataque normal.
> **Faixa longa** — até o segundo número da tabela. Você rola com **desvantagem**: joga dois d20 e fica com o pior.
> **Além da faixa longa, você não consegue atingir um alvo.**
>
> **`Colado`:** atacar com arma de projétil estando adjacente a um inimigo (qualquer inimigo, não só o seu alvo) também é desvantagem.

> **Exemplo.** Você está com a Pistola e o alvo está a 21 metros. A faixa normal dela é 9 m e a longa vai até 27 m: você alcança, e rola com desvantagem. Se um inimigo estiver colado em você na hora do tiro, a desvantagem vale do mesmo jeito, mesmo que o alvo esteja a 5 metros.

**Armas de tiro**
| arma | faixa normal | faixa longa |
|---|---|---|
| Hankyū | 24 m | 96 m |
| Daikyū | 45 m | 180 m |
| Besta de Uma Mão | 9 m | 36 m |
| Besta | 30 m | 120 m |
| Pistola | 9 m | 27 m |
| Revólver | 12 m | 36 m |
| Submetralhadora | 15 m | 45 m |
| Espingarda | 9 m | 27 m |
| Rifle | 24 m | 72 m |
| Rifle de Precisão | 24 m | 72 m |
| Metralhadora Pesada | 24 m | 72 m |

**Armas de arremesso**
| armas | faixa normal | faixa longa |
|---|---|---|
| Punhal · Machadinha · Lança · Kunai · Shuriken · Tessen · Chakram · Kusarigama | 6 m | 18 m |

### Munição

> **Recarregar é Ação Bônus.** Você recarrega quando tirar **1 ou 2 natural** no ataque, **ou** depois de **X** ataques, o que vier primeiro. O X é da arma.

**Munição**
| X | armas |
|---|---|
| 4 | Metralhadora Pesada |
| 3 | Rifle · Submetralhadora |
| 2 | Pistola · Revólver · Espingarda · Rifle de Precisão |
| 1 | Besta · Besta de Uma Mão |

O `Yumi` não carrega `Munição`. Uma flecha se encaixa como parte do disparo: não há ciclo de recarga para modelar. Uma besta se arma e um pente se troca, e é disso que a propriedade trata.

> **Exemplo.** Você está com o Rifle, que tem X = 3. Você atira duas vezes sem problema. No terceiro tiro sai um `2` natural no dado de ataque: recarga na sua Ação Bônus, e o tiro seguinte já está pronto.

## Treino de arma

> **Treino mora na categoria.** Treinar uma categoria libera todas as armas dela. São treze categorias em três listas.

**Treino de arma**
| lista | categorias | armas |
|---|---|---|
| **Simples** | Lâmina Curta · Porrete · Ceifa · Arremesso · Manopla · Massa · Balestra | 26 |
| **Marciais** | Lâmina Longa · Machado · Armas Longas · Flexível · Yumi | 19 |
| **Arma de Fogo** | Arma de Fogo | 7 |

> **Bastião, Vanguarda e Incursor treinam as treze categorias.** Qualquer arma deste catálogo é deles.
>
> **Guia, Emanador e Evocador treinam Arma de Fogo e Balestra**, as duas que se aponta e dispara sem precisar de anos de treinamento.

Um Caminho conjurador não pega espadão de graça: ele precisa da Trilha que concede a categoria, como a `Arma Condutora` do Condutor Armado. O quadro de cada Caminho está no capítulo 8, *Caminhos e Trilhas*.

> **Sem treino, você tem desvantagem na rolagem de ataque com aquela arma.**
>
> **Sem o requisito de Força dela, o seu deslocamento cai pela metade enquanto você a estiver empunhando, e você não soma a sua Destreza na Defesa.**

As duas se somam.

## Catálogo

### Armas por treino

**Catálogo de armas**
| arma | categoria | mão | dado | propriedades | requer Força | `Volume` |
|---|---|---|---|---|---|---|
| **Treino simples** | | | | | | |
| Bastão | Porrete | 1 | **d6** | `Versátil` · `Alcance` · `Rompe` | — | `1` |
| Besta | Balestra | 2 | **2d8** | `Longo Alcance` · `Munição` · `Rompe` | 3 | `2` |
| Besta de Uma Mão | Balestra | 1 | **1d10** | `Longo Alcance` · `Munição` · `Oculta` | — | leve |
| Bō | Porrete | 2 | **d10** | `Alcance` · `Emaranha` | 3 | `2` |
| Canivete | Lâmina Curta | 1 | **d4** | `Fineza` · `Oculta` · `Rompe` | — | leve |
| Cassetete | Porrete | 1 | **d6** | `Oculta` · `Vestida` | — | leve |
| Chakram | Arremesso | 1 | **d4** | `Longo Alcance` · `Fineza` · `Oculta` | — | leve |
| Faca | Lâmina Curta | 1 | **d6** | `Fineza` · `Rompe` | — | `1` |
| Foice | Ceifa | 2 | **d10** | `Emaranha` · `Talha` | 3 | `2` |
| Kama | Ceifa | 1 | **d6** | `Par` · `Rompe` | — | `1` |
| Kanabō | Massa | 2 | **d12** | `Talha` | 3 | `2` |
| Kunai | Arremesso | 1 | **d6** | `Longo Alcance` · `Oculta` | — | leve |
| Kusarigama | Ceifa | 2 | **d8** | `Alcance` · `Emaranha` · `Longo Alcance` | — | `2` |
| Maça | Massa | 1 | **d8** | `Talha` | — | `1` |
| Marreta | Massa | 2 | **d10** | `Rompe` · `Talha` | 3 | `2` |
| Maul | Massa | 2 | **d12** | `Rompe` | 3 | `2` |
| Nunchaku | Porrete | 1 | **d6** | `Par` · `Emaranha` | — | `1` |
| Punhal | Lâmina Curta | 1 | **d6** | `Fineza` · `Longo Alcance` | — | `1` |
| Sai | Lâmina Curta | 1 | **d6** | `Fineza` · `Par` | — | `1` |
| Shuriken | Arremesso | 1 | **d4** | `Longo Alcance` · `Oculta` · `Par` | — | leve |
| Soqueira | Manopla | 1 | **d4** | `Vestida` · `Oculta` · `Par` | — | leve |
| Taco | Massa | 1 | **d8** | `Versátil` · `Oculta` | — | leve |
| Tanto | Lâmina Curta | 1 | **d6** | `Fineza` · `Oculta` | — | leve |
| Tekko | Manopla | 1 | **d4** | `Vestida` · `Par` · `Oculta` | — | leve |
| Tessen | Arremesso | 1 | **d4** | `Longo Alcance` · `Oculta` · `Vestida` | — | leve |
| Tonfa | Porrete | 1 | **d6** | `Par` · `Vestida` | — | leve |
| **Treino marcial** | | | | | | |
| Chicote | Flexível | 1 | **d4** | `Alcance` · `Emaranha` · `Oculta` | — | leve |
| Corrente | Flexível | 2 | **d8** | `Alcance` · `Emaranha` · `Rompe` | — | `2` |
| Daikyū | Yumi | 2 | **1d10** | `Longo Alcance` | — | `2` |
| Espada Longa | Lâmina Longa | 1 | **d8** | `Versátil` · `Rompe` | — | `1` |
| Espadão | Lâmina Longa | 2 | **d12** | `Alcance` | 3 | `2` |
| Hankyū | Yumi | 2 | **1d8** | `Longo Alcance` · `Oculta` | — | `2` |
| Katana | Lâmina Longa | 1 | **d8** | `Versátil` · `Fineza` | — | `1` |
| Lança | Armas Longas | 1 | **d6** | `Alcance` · `Longo Alcance` | — | `1` |
| Machadinha | Machado | 1 | **d6** | `Longo Alcance` · `Rompe` | — | `1` |
| Machado | Machado | 1 | **d8** | `Rompe` | — | `1` |
| Machado de Guerra | Machado | 2 | **d12** | `Rompe` · `Talha` · `Volumosa` | 3 | `2` |
| Machete | Lâmina Longa | 1 | **d8** | `Rompe` | — | `1` |
| Manriki | Flexível | 1 | **d6** | `Emaranha` · `Oculta` | — | leve |
| Naginata | Armas Longas | 2 | **d10** | `Alcance` · `Rompe` | 3 | `2` |
| Nodachi | Lâmina Longa | 2 | **d12** | `Alcance` · `Rompe` · `Volumosa` | 3 | `2` |
| Odachi | Lâmina Longa | 2 | **d12** | `Alcance` · `Talha` · `Embainhada` | 3 | `2` |
| Rapieira | Lâmina Longa | 1 | **d6** | `Fineza` · `Talha` | — | `1` |
| Wakizashi | Lâmina Longa | 1 | **d8** | `Oculta` | — | leve |
| Yari | Armas Longas | 2 | **d10** | `Alcance` · `Talha` | 3 | `2` |
| **Treino de fogo** | | | | | | |
| Espingarda | Arma de Fogo | 2 | **2d8** | `Longo Alcance` · `Munição` · `Rompe` | 1 | `2` |
| Metralhadora Pesada | Arma de Fogo | 2 | **2d10** | `Longo Alcance` · `Munição` · `Rompe` · `Volumosa` | 3 | `2` |
| Pistola | Arma de Fogo | 1 | **1d10** | `Longo Alcance` · `Munição` · `Oculta` | — | leve |
| Revólver | Arma de Fogo | 1 | **1d10** | `Longo Alcance` · `Munição` · `Oculta` | — | leve |
| Rifle | Arma de Fogo | 2 | **2d8** | `Longo Alcance` · `Munição` · `Talha` | 1 | `2` |
| Rifle de Precisão | Arma de Fogo | 2 | **2d10** | `Longo Alcance` · `Munição` | 3 | `2` |
| Submetralhadora | Arma de Fogo | 2 | **2d6** | `Longo Alcance` · `Munição` · `Par` · `Oculta` | — | `2` |

### Lâmina Curta

Treino simples. Todas carregam `Fineza`, então o dano delas usa Destreza.

### Lâmina Longa

Treino marcial. O dano usa Força, ou Destreza nas duas que carregam `Fineza`.

Odachi e Nodachi são a mesma lâmina, com a mesma mão e o mesmo dado. A diferença está em como cada uma resolve o tamanho: o Odachi se carrega nas costas e precisa de tempo ou de ajuda para sacar, o Nodachi você saca sozinho e carrega à mostra.

### Massa

Treino simples. O dano sai de Força.

### Porrete

Treino simples. O dano sai de Força.

### Manopla

Treino simples. O dano sai de Força.

O Tekko e a Soqueira têm a mesma linha, o mesmo gasto e a mesma regra. O que muda é de onde cada uma veio.

### Machado

Treino marcial. O dano sai de Força.

O Machado tem a mesma linha do Machete, lá na Lâmina Longa: `d8`, uma mão, `Rompe`. A escolha entre os dois é narrativa, e as duas categorias caem no mesmo balde de treino.

### Ceifa

Treino simples. O dano sai de Força.

### Armas Longas

Treino marcial. O dano usa Força. É a única categoria em que o `Alcance` chega a 3 m.

### Flexível

Treino marcial. O dano sai de Força.

### Arremesso

Treino simples. O dano usa Força: o arremesso sai do corpo.

### Yumi

Treino marcial. O dano usa Destreza: o arco se puxa, e puxar é coisa do corpo. As duas rolam um dado só e nenhuma delas carrega `Munição`.

O daikyū passa de dois metros e se carrega nas costas. O hankyū fica entre 45 e 160 cm: é o arco de espaço apertado e de montaria, e é por isso que ele esconde e o outro não. O Daikyū tem o dado maior; o Hankyū tem a propriedade a mais.

### Balestra

Treino simples. **Não soma atributo nenhum**: a energia já está armazenada na corda, e você só precisa mirar. Em troca, o dado é maior.

### Arma de Fogo

Lista de treino própria, sozinha. **Não soma atributo nenhum**, pelo mesmo motivo da Balestra.

Pistola e Revólver têm a mesma linha de regra. A diferença entre os dois está na faixa: a Pistola vai a 9 m, o Revólver a 12 m.

## Soco

O punho vazio não é uma das armas. Ele não entra no catálogo, não tem categoria e não entra na divisão simples/marcial: todo mundo é treinado em dar soco.

> **O soco não tem propriedade nenhuma. O dado dele sobe com a maestria.**
>
> | maestria | níveis | dado |
> |---|---|---|
> | 1 | 2 a 9 | **d4** |
> | 2 | 10 a 17 | **d6** |
> | 3 | 18 a 25 | **d8** |
> | 4 | 26 a 30 | **d10** |

Ele soma Força, como todo corpo a corpo. E vale como arma para todo efeito de regra: crítico e ataque extra.

O soco não tem propriedade nenhuma, então ele abre mão de alcance, de `Par`, de `Oculta` e de todo o resto. Em troca, ninguém desarma um punho e ninguém confisca um punho na portaria: a condição `Desarmado` não existe para quem bate com a mão.

## Peso

Você carrega em `Volume`, que é espaço e não quilo. O seu limite é **`5 + Força`**: cinco de Força 0, onze de Força 6.

> **Passar do limite não é um degrau — é um muro.** Você não sai do lugar com mais do que cabe.

**Arrastar, empurrar ou levantar é o dobro disso**, e vale para aquele esforço, não para andar com a carga.

Quando alguma coisa não tem `Volume` escrito, o mestre pesa em quilo: **`12` kg por `Volume`**. O seu limite em quilo é de `60` a `132`.

### Peso item a item

Cada arma, cada uniforme e cada escudo traz o `Volume` dele na própria tabela, na última coluna. Você não precisa calcular nada — só somar o que está na mochila.

Se quiser conferir de cabeça, a régua é esta:

**`Volume` por arma**
| a arma | `Volume` |
|---|---|
| de duas mãos | `2` |
| de uma mão, com `Oculta` ou `Vestida` | leve |
| todo o resto | `1` |

**Cada coisa leve vale `0,1` de `Volume`**, e a soma não arredonda: nove leves são `0,9`, e dez são `1`. O que pesa quase nada não conta, e quem decide isso é o mestre.

Item comum — pé de cabra, lanterna, corda, o que estiver na mochila — é **leve**, salvo o que o mestre pesar de outro jeito.

> **O que o peso faz, e só isso:** ele diz quanto você leva. Ele não dá penalidade por item, não tem degrau, e não mexe no requisito de Força da arma nem do uniforme — esse requisito é outro número, e ele não olha o quanto você está carregando.

## Dinheiro e acesso

> **A moeda é o iene. Você recebe um salário mensal da instituição, e o valor sai da sua patente** — a tabela **Salário por patente** está no capítulo 19, *Experiência e Progressão*.
>
> **Dinheiro compra o que está à venda. O seu Grau libera o que não está.**

Duas famílias não têm prateleira. **`Arma de Fogo` exige Grau 2** ou **autorização prévia** — alguns membros recebem justificativa narrativa para isso, como uma Vanguarda com a rota de `Arma de Fogo` —, porque arma de fogo para civil é quase inalcançável no Japão e quem porta é quem a instituição autoriza. *É por não ter prateleira que ela é a única do capítulo com dois preços, e a tabela `Arma de fogo` traz os dois.* E o **`Revestimento` exige Grau 3 no degrau 2 e Grau 2 no degrau 3** — é blindagem de padrão militar, e ela não se compra numa loja.

O Grau também dá. Todo feiticeiro registrado **recebe o uniforme**: o `Traje` degrau 1 vem com a matrícula, e não precisa ser pago.

> **O seu Grau não decide que ferramenta amaldiçoada você pode usar.** Aquela escada é de nível, e está no capítulo 15. Patente adianta apenas quando uma ferramenta chega à sua mão.

### Preços

Todas as armas de uma mão gastam o mesmo orçamento, e todas as de duas mãos também. **Pagar mais nunca compra número — compra o que a arma é.** Uma Katana e um Machete acertam e ferem igual; a diferença entre as duas é forja, história e quem olha.

**Armas de uma mão**
| faixa | ¥ | armas |
|---|---|---|
| produzido em massa | 8.000 | Soqueira · Tekko · Cassetete · Canivete · Manriki · Shuriken · Tessen · Chakram · Kunai |
| utilitário | 16.000 | Faca · Machete · Machadinha · Bastão · Taco · Tonfa · Nunchaku · Kama · Lança · Chicote · Punhal · Sai |
| forjado | 32.000 | Tanto · Maça · Machado · Rapieira · Wakizashi |
| de assinatura | 48.000 | Katana · Espada Longa |

**Armas de duas mãos**
| faixa | ¥ | armas |
|---|---|---|
| haste e corrente | 20.000 | Bō · Corrente · Kusarigama |
| massa e agrícola | 36.000 | Marreta · Kanabō · Maul · Foice · Naginata · Yari |
| lâmina grande | 60.000 | Espadão · Machado de Guerra · Nodachi |
| de assinatura | 90.000 | Odachi |

**Arco e balestra**
| arma | ¥ |
|---|---|
| Hankyū | 40.000 |
| Daikyū | 60.000 |
| Besta de Uma Mão | 50.000 |
| Besta | 80.000 |

**Arma de fogo tem dois preços, e o que muda é quem está vendendo.** Na criação quem te arma é a instituição, e ela cobra o que pagou; depois dela você compra pelo mercado que ela alcança, e aí o preço é o cheio. **O da criação é sempre metade do de mercado**, e ele vale uma vez só, na montagem da ficha.

**Arma de fogo**
| arma | ¥ na criação | ¥ no mercado | |
|---|---|---|---|
| Pistola · Revólver | 125.000 | 250.000 | Grau 2 |
| Espingarda | 150.000 | 300.000 | Grau 2 |
| Rifle | 175.000 | 350.000 | Grau 2 |
| Submetralhadora | 200.000 | 400.000 | Grau 2 |
| Rifle de Precisão | 300.000 | 600.000 | Grau 2 |
| Metralhadora Pesada | 450.000 | 900.000 | Grau 2 |

Nos ¥150.000 da criação cabem a Pistola, o Revólver e a Espingarda, e nada além delas — então dá para começar com a arma que a sua rota pressupõe, e não dá para começar com um Rifle de Precisão. Duas armas de fogo não cabem juntas em combinação nenhuma. Com a Pistola ou o Revólver ainda sobram ¥25.000, que compram um escudo `Broquel` e uma arma de uma mão da faixa de baixo; com a Espingarda o dinheiro acaba ali.

Depois da criação a coluna da esquerda não existe mais. Se você perder a arma, quiser uma segunda ou quiser subir de calibre, é o preço de mercado que vale, e ele é o mesmo para todo mundo.

As linhas de baixo não são enfeite: o fundo da criação é uma mensalidade da patente em que você começa, então numa campanha que abre acima do nível 2 elas entram. O `Kit inicial`, no fim deste capítulo, diz em que patente cada uma abre.

**Proteção e apoio**
| item | ¥ | |
|---|---|---|
| Traje 1 | 30.000 | o seu vem de graça |
| Traje 2 | 90.000 | |
| Traje 3 | 270.000 | |
| Revestimento 1 | 150.000 | |
| Revestimento 2 | 450.000 | Grau 3 |
| Revestimento 3 | 1.350.000 | Grau 2 |
| Broquel | 12.000 | |
| Médio | 36.000 | |
| Torre | 108.000 | |
| corda, lanterna, algema, pé de cabra, gazua, kit de escalada | 3.000 | cada |

### Kit inicial

> **Você começa Grau 4, com o `Traje` degrau 1 da instituição e ¥150.000 para comprar o resto.** São uma mensalidade de um Grau 4, que é o que você é.

**O fundo é sempre uma mensalidade da patente em que o personagem começa**, e não um valor fixo. Quase toda ficha começa Grau 4 e por isso o número é ¥150.000, mas numa campanha que abre acima do nível 2, ou quando o mestre decide que o grupo já é gente da casa, a patente inicial sobe e o fundo sobe junto — é a tabela `Salário por patente`, no capítulo 19, que diz quanto.

É isso que mantém a coluna de criação da arma de fogo viva inteira. **No Grau 4 cabem três das sete — a Pistola, o Revólver e a Espingarda; no Grau 3 entram o Rifle, a Submetralhadora e o Rifle de Precisão; e no Grau 2 a tabela `Arma de fogo` fecha, com a Metralhadora Pesada.** Não por acaso: o Grau 2 é a patente em que a arma de fogo deixa de precisar de autorização.

---


# Capítulo 16 · Ferramenta Amaldiçoada

*fonte: `manual/55-ferramenta-amaldicoada.md`*

> **Uma ferramenta amaldiçoada é uma arma do catálogo de Equipamento (ou um objeto de apoio) mais um `Estigma`.**
>
>
> **Uma ferramenta que você não empunha nem veste é um objeto comum, e nada mais.**

**Objeto de apoio** é a ferramenta que você carrega sem empunhar: um anel, um cordão, uma peça costurada no forro do casaco.

## Na mão ou no corpo

> **A ferramenta funciona enquanto você a empunha ou veste.** Não há ritual, não há descanso, não há PE.
>
> **Guardada, ela não faz nada**: o `Estigma` não age da mochila.

Trocar de ferramenta custa o que custa sacar, e isso está no capítulo *O turno*.

Quantas agem ao mesmo tempo é o `Teto de Estigma` — as suas mãos, mais dois objetos de apoio. **Quantas você carrega para trocar é o peso:** cada ferramenta ocupa o `Volume` da arma que está por baixo dela, e o seu limite é `5 + Força`.

## Ferramenta forjada

A arma por baixo continua sendo a arma de sempre: mesmo dado, mesmas propriedades, mesmo requisito de Força. O `Estigma` entra como camada por cima disso, e não muda nada dela.

Uma ferramenta carrega no máximo **um** `Estigma`.

## Ferramenta, objeto, cadáver e maldição solta

**Coisas com energia amaldiçoada**
| O que é | Como se reconhece | Onde está a regra |
|---|---|---|
| ferramenta amaldiçoada | foi forjada para canalizar energia. Você empunha, e ela fere maldição | este capítulo |
| objeto amaldiçoado | é a maldição presa numa forma de objeto. Você carrega, e o que está dentro dele age | este capítulo, *Objeto amaldiçoado* |
| cadáver amaldiçoado | coisa sem vida que ganhou movimento próprio, com um núcleo no lugar do coração | capítulo 17, Invocações |
| maldição solta | a maldição sem forma de coisa nenhuma. É o que se exorciza | capítulo 4, *Dano, Condições e Cobertura* |

Ferramenta e objeto são ranqueados pela mesma escada, pela força da energia que carregam: grau 4 a grau 1, mais o especial.

## Objeto amaldiçoado

> **Um objeto amaldiçoado é a maldição presa numa forma de objeto.**
>
> **Todo objeto amaldiçoado tem história.** Ele foi alguém, ou saiu de dentro de alguém.

### Atração

> **Um objeto amaldiçoado sem selo puxa maldição para perto dele.**

Enquanto alguém do grupo carrega um objeto sem selo, maldições vão naturalmente ser atraídas para ele.

### Selo

O objeto selado empurra maldição em vez de puxar, e é por isso que ele serve de amuleto.

E selo gasta. Ele enfraquece com o tempo, e quando vence a atração volta — maior do que estava, porque nesse meio-tempo o objeto ficou juntando o que o selo empurrou.

Selo novo empurra, selo vencido puxa. Não existe objeto amaldiçoado que não faça nada.

Quanto tempo um selo dura é decisão do seu mestre.

### `Kiko`

**`Kiko`** — o depósito da escola onde os objetos de grau alto ficam trancados, selados um a um.

### Encarnação

Engolir um objeto amaldiçoado é o que faz o que está dentro dele ganhar corpo. Três Origens nascem daí.

**Resultados de encarnação**
| O que se engoliu | Quem pode engolir | O que sai | Origem |
|---|---|---|---|
| resto de feiticeiro antigo, em pedaço | quase ninguém. O objeto escolhe, e quem não serve morre | os dois ficam no mesmo corpo | Receptáculo |
| ventre feito de propósito | qualquer um, mesmo quem não tem talento nenhum | meio gente, meio maldição | Feto |
| resto de feiticeiro antigo, num corpo preparado de antemão | um corpo que alguém preparou para receber | alguém toma o corpo | Reencarnado |

## Grau

O que o grau escolhe é o **formato** do `Estigma`.

**Graus de ferramenta**
| Grau | `Estigma` | Nível mínimo | Exemplar do material |
|---|---|---|---|
| **4** | nenhum. Ela fere maldição, e para nisso | nenhum | a katana da Kasumi, a semi-ferramenta |
| **3** | Classe 1: efeito pequeno, condicional ou de informação | nenhum | o machado da Mei Mei |
| **2** | Classe 2: reativo, com limite por cena ou por descanso | 7 | a Katana de Alma Partida |
| **1** | Classe 3: permanente, muda como você joga | 13 | as forjadas de topo |
| **especial** | Classe 3, e ela é única no mundo | 13 | Nuvem Brincalhona · Lança Invertida do Céu · Corrente de Mil Milhas |

As Classes são as mesmas do capítulo 12, *Aptidões e Refino*, e o nível mínimo é o de lá: uma aptidão de Classe 2 pede nível 7, uma de Classe 3 pede nível 13, e Classe 1 não pede nada.

### Grau 4

Ele não dá `Estigma` nenhum. Ferir maldição é a única coisa que ela consegue fazer.

### Grau 1 e especial

Os dois dão um `Estigma` de Classe 3 e os dois pedem nível 13. A diferença é de ficção: uma de grau 1 se forja, e uma especial é única no mundo, com nome próprio.

As três especiais nomeadas na tabela `Graus de ferramenta` não têm ficha escrita: quem quiser pôr uma em jogo monta com o mestre, dentro do que a Classe 3 permite.

### Grau e patente

> **A sua patente não decide que ferramenta você pode portar. A ferramenta que você porta não mexe na sua patente.**

São duas escadas de cinco casas com o mesmo nome. Patente é reconhecimento; grau é a energia que a peça carrega.

## `Desgaste`

O `Desgaste` é um efeito que algumas ferramentas podem ter, em troca de não terem nível mínimo.

> **`Desgaste`: a ferramenta ignora o nível mínimo do `Estigma` dela.**
>
> **Em troca, ela tem um número fixo de missões.** Cada missão em que você usar o `Estigma` gasta uma. Quando elas acabam, ela vira arma comum ou se quebra, sem conserto.
>
> **Dentro da missão o uso é livre.** Usar dez vezes gasta o mesmo que usar uma.

**Missões de `Desgaste`**
| Grau | Missões |
|---|---|
| **3** | 1 |
| **2** | 2 |
| **1** e **especial** | 3 |

**Ela não desce de grau, e não troca de `Estigma`.** O que acaba é o número de missões.

> **Exemplo.** O Ryo é nível 4 e ganha uma corrente de grau 1 com `Desgaste`. O `Estigma` dela é `Anátema`, que pediria nível 13; com o `Desgaste`, ele usa sem o requisito de nível, e a corrente tem **três missões**.
>
> Na primeira ele encosta a corrente em quatro técnicas diferentes, no mesmo dia: **gastou uma missão**, e não quatro. Na segunda ele não saca a corrente uma vez sequer: **não gastou nada**. Na terceira e na quarta ele usa de novo, e acabaram as três — o que sobra na mão dele é uma corrente que fere maldição e nada mais.
>
> **A decisão é em que missão sacar, e não quantas vezes.**

## Catálogo de `Estigma`

Dez entradas, agrupadas por Classe. A Classe diz o grau da ferramenta que pode carregar aquele `Estigma`, e diz o nível mínimo junto.

### Entrada

Cada entrada abre com o nome e diz **quando o `Estigma` age**: sempre ligado, na hora de um gatilho, ou como Reação. Quando existe limite de uso, ele vem escrito na própria entrada.

### Classe 1 · grau 3 · sem nível mínimo

> **`Fiel`** — ela volta para a sua mão no seu turno. Não dá para te desarmar dela.
>
> **`Aferido`** — ao encostar numa maldição, você sabe o grau dela.
>
> **`Presságio`** — ela avisa que tem maldição perto, antes de você ver.
>
> **`Perene`** — ela não quebra e não enferruja.

### Classe 2 · grau 2 · nível 7

> **`Quebranto`** — Reação: garante um sucesso num teste de `Bloquear` ou num Teste de Resistência contra um feitiço. É um sucesso comum, não crítico, e tem de ser usado antes da rolagem. Uma vez por cena.
>
> **`Avulsa`** — Reação, quando um inimigo no seu alcance te ataca: a arma sai da sua mão e ataca ele. Duas vezes por cena.

### Classe 3 · grau 1 e especial · nível 13

> **`Anátema`** — o contato dela **ignora e anula energia amaldiçoada**. E como **Reação**, ela anula um feitiço que vem em você: role um **Teste de Resistência Físico contra a CD do conjurador**; num sucesso o feitiço é anulado, e se ele for de área, é anulado para todos os alvos. *(especial)*
>
> **`Cisão`** — o golpe dela atravessa o corpo: tira Integridade, e não tira vida. É *dano direto na alma*, do capítulo 4, *Dano, Condições e Cobertura*. Contra alvo de alma dura, você vai sentir falta do dano normal. *(grau 1)*
>
> **`Insondável`** — enquanto a ponta dela estiver escondida, o alcance dela é **na cena**: um quarteirão, na ordem de 100 metros. *(grau 1)*
>
> **`Contrapeso`** — ela ignora o requisito de Força da arma. *(grau 1)*

---


# Capítulo 17 · Invocações

*fonte: `manual/60-invocacoes.md`*

Invocar põe outra criatura ao seu lado. Ela tem ficha, anda por conta própria e cumpre a tarefa que recebeu. Você continua com as suas ações. Para ela usar uma habilidade especial, você precisa comandar.

Cada criatura é uma **entidade**. O tipo dela vem de duas coisas: a **origem**, que diz como você a conseguiu, e o **corpo**, que diz o que ela é.

- **Técnica:** shikigami ou corpo amaldiçoado, obtido por um espaço de feitiço ou por uma lista de ritual.
- **Criação:** shikigami guardado num talismã ou corpo amaldiçoado feito de peças.
- **Maldição domada:** uma maldição que você enfrentou e passou a comandar.

São cinco tipos. O que pertence à origem vale nos dois corpos; o que pertence ao corpo vale nas duas origens. O shikigami de técnica é a base, sem benefício próprio do tipo.

## Entrada rápida

**Você pode ter duas entidades ativas ao mesmo tempo.** Cada uma conserva a ficha inteira. Esse teto vale do nível 1 ao 30, dentro e fora de combate.

Você e as entidades usam a mesma **iniciativa**, o lugar de vocês na ordem da luta. Um **ciclo** vai do começo de um turno seu ao começo do próximo. Nesse começo, cada entidade em campo recupera seu Movimento e uma **atuação básica**: a oportunidade de atacar, ajudar ou fazer outra ação permitida pela ficha. Conhecer duas básicas dá duas opções, não duas atuações.

Todas as suas entidades dividem uma **Reação coletiva**: uma resposta a um acontecimento previsto numa habilidade. Ela também se renova no começo do seu turno. A sua Reação pessoal é separada.

> **Para a primeira luta:**
>
> **Antes de começar**, você pode manifestar as entidades pagando os pontos de energia, ou **PE**, da entrada. Elas começam a luta em campo, com as tarefas que já tinham.
>
> **No seu turno**, cada entidade segue a tarefa recebida com a básica e o Movimento dela. Termine uma ação antes de começar a seguinte.
>
> **Para mudar as tarefas**, gaste a sua Ação Bônus. Ela orienta até todas as entidades em campo, e cada uma pode receber uma tarefa diferente.
>
> **Para comandar uma especial**, gaste a sua Ação Padrão. A entidade usa a básica ainda disponível e paga o PE da especial. Ela não faz a básica e a especial no mesmo ciclo.
>
> **Para entrar, trocar ou recolher**, gaste a sua Ação Bônus, no seu turno e consciente. Cada entrada também custa PE. Recolher não custa PE.

**Entrar sem substituir não dá básica naquele ciclo.** A primeira tarefa custa outra Bônus. Na troca, a substituta recebe a primeira tarefa junto e pode receber uma básica ainda disponível de quem saiu. Ela só a recebe se ainda não tiver gasto uma básica naquele ciclo.

**Para acertar**, role `d20 + atributo de acerto da entidade + sua maestria`. A maestria é o bônus de treino da sua ficha. Compare com a Defesa do alvo, o número que precisa alcançar para acertá-lo. Num efeito de resistência, é o alvo que rola contra a **CD**, a dificuldade do efeito.

*Na mesa:* Kaito começa a luta com duas entidades de nível 5 manifestadas e orientadas. Cada entrada custou 2 PE. Uma usa sua básica de 2d6. Kaito gasta a Padrão para comandar a especial de Classe 2 da outra: ela ocupa a própria básica e custa 6 PE. A Bônus de Kaito continua disponível. Se o atributo de acerto da entidade é 3 e a maestria dele é 1, um 12 no d20 dá `12 + 3 + 1 = 16`: acerta Defesa 16.

**A manifestação dura até o fim da cena.** Se a cena virar combate, ela continua até o fim da luta. Quando o combate acaba, pague o PE da entrada de novo para mantê-la. Não há cobrança por rodada só para a entidade existir.

## Aquisição

Toda entidade exige uma troca para ser obtida. Pagar pela entrada não compra uma entidade nova.

**Espaço de feitiço.** Você ocupa um espaço da sua lista de feitiços conhecidos. Ele dá uma entidade no seu nível, que sobe de nível junto com você. A troca pode ser refeita quando você sobe de nível.

**Lista de ritual.** Um feitiço de ritual traz uma lista de entidades que você vai domando. Você enfrenta o ritual sozinho. As entidades da lista sobem de nível junto com você.

**Maldição domada.** Você busca e enfrenta a maldição; o grupo pode participar da luta. Ela conserva o nível e o conjunto de habilidades de quando foi domada. Não sobe com você nem recebe compensação por ficar para trás.

**Criação.** A entidade é feita com tempo, testes e os materiais que a criação exigir. As criadas não sobem de nível junto com você. O procedimento de criar pertence ao sistema de criação.

Não há limite de quantas entidades você pode ter. Isso não aumenta o teto de duas ativas. Os talismãs ocupam carga; os corpos amaldiçoados têm limite de inativos; as entidades de técnica ocupam espaço ou pertencem à lista de ritual. Sem técnica para recolhê-la, uma maldição domada fica no mundo.

*Exemplo:* Kaito tem uma entidade de espaço e uma maldição domada, ambas no nível 5. Quando ele chega ao nível 6, a de espaço sobe para 6. A domada continua no 5, com as habilidades que tinha.

### Domar

**Derrote a maldição sem destruí-la. Fora da luta, ela faz um Teste de Resistência de Espírito contra a sua CD.** Se falhar, está domada. Se resistir, é exorcizada.

Chegar a zero de vida não a destrói por si. A morte definitiva usa a vida máxima dela e os limites de *Queda e morte*, adiante. O nível da domada é o da maldição, até o seu nível.

**Durante a luta**, você só tenta se o mestre permitir, na quantidade de vida que ele permitir. A tentativa custa a sua Ação Padrão e usa o mesmo Teste de Resistência. Não existe uma marca fixa de metade da vida para essa permissão.

*Exemplo:* a maldição de nível 5 sobrevive à queda. Kaito, também no nível 5, tem CD 12. Fora da luta, o resultado total do TR de Espírito dela é 11: ela fica domada no nível 5. Um resultado 12 resistiria e a exorcizaria.

## Montagem da entidade

A entidade tem uma definição, atributos, básica, especiais e passivas. **Passiva** é uma característica que funciona sem você ordenar uma especial. **Classe** mede o tamanho de uma habilidade; **Classe Passiva** é a escala própria das passivas.

Tudo que depende de nível usa o nível da entidade, que nunca passa do seu. A maestria usada no acerto, no Teste de Resistência treinado e na CD continua sendo a sua.

### Definição

Escreva o que a entidade é em menos de duas linhas. Toda habilidade e característica precisa caber nessa definição. Ela não ganha a Regra Própria gratuita, a Passiva Livre nem um Selo.

A definição também precisa sustentar a anatomia, os sentidos e a comunicação que você quer usar. Não há mãos, fala, telepatia, visão compartilhada ou ataque implícitos. Uma entidade pode não ter ataque nenhum.

*Exemplo:* Kaito começa pelo corpo: “Um cão de sombra que fareja energia amaldiçoada e morde quem persegue.” A definição sustenta o faro e a mordida; não dá mãos, leitura de pensamentos ou visão compartilhada.

### Famílias

As **Famílias** agrupam as Melhorias, os efeitos que você compra na montagem de uma habilidade. Das nove Famílias, a entidade tem **seis Fechadas e três abertas**. Escolha as abertas conforme a definição.

Entre as três abertas, **uma é Livre**: a que a definição pede. Nela, a Melhoria custa metade da Classe a menos, com mínimo 1 tanto para o desconto quanto para o preço final. Arredonde o desconto para baixo. Nas outras duas, o preço é cheio. Uma Família Fechada não oferece suas opções.

**Famílias da montagem**
| Família | Do que trata |
|---|---|
| **Alcance** | Chegar longe, se mexer, mexer o inimigo de lugar |
| **Área** | Pegar mais de um alvo, aumentar tamanho, dividir o ataque |
| **Mira** | Acertar, não errar, atravessar defesa |
| **Controle** | Derrubar, prender, calar, barreira, terreno |
| **Auxiliares** | Somar e tirar número: vantagem, defesa, CD, deslocamento |
| **Castigo** | Fazer o dano render mais |
| **Tempo** | Ação bônus, reação, deixar armado, conjurar escondido |
| **Marca** | Preparar o próximo golpe, roubar vida, rastrear |
| **Amparo** | Curar, limpar condição, levantar aliado |

`Projétil`, `Toque` e `Efeito`, as Formas que dizem como a habilidade sai, ficam disponíveis para todas. O mesmo vale para as Melhorias fora de família. Disponibilidade não dispensa a definição nem dá uma execução adicional.

*Na mesa:* Kaito escolhe a Família Livre pelo que o shikigami faz. O faro e a mordida precisam justificar as Melhorias que ele comprar. Abrir uma Família não permite qualquer poder dentro dela sem relação com a criatura.

### Básica e especial

**A básica própria é de Classe 0, usa d6, não custa PE e não ocupa espaço de especial.** A entidade conhece uma até o nível 10 e duas do nível 11 em diante. Continua tendo uma atuação básica por ciclo.

Uma básica pode receber uma Melhoria `Leve` e uma Restrição `Leve`, tirando um dado para pagar. Restrição é uma exigência aceita na montagem. Do nível 1 ao 4, tirar o único dado deixa a básica sem dado de dano.

**A especial vai da Classe 1 até a Classe liberada pelo nível da entidade.** Ela tem os pontos da tabela e custa `3 × a Classe da especial` em PE. Os pontos montam a habilidade; o PE paga cada uso. São contas separadas.

**Números da entidade**
| Classe do nível | básica (Classe 0) | pontos da especial | o jogador |
|---|---|---|---|
| 1 (1–4) | 1d6 | 2 | 2d8 · 3 pontos |
| 2 (5–8) | 2d6 | 4 | 3d8 · 6 pontos |
| 3 (9–12) | 2d6 | 6 | 3d8 a 4d8 · 9 pontos |
| 4 (13–16) | 2d6 | 9 | 4d8 · 12 pontos |
| 5 (17–20) | 3d6 | 11 | 5d8 · 15 pontos |
| 6 (21–25) | 3d6 | 13 | 5d8 a 6d8 · 18 pontos |
| 7 (26–30) | 3d6 | 16 | 6d8 · 21 pontos |

A primeira coluna mostra a Classe que o nível libera. A básica acompanha o nível da entidade. A especial conserva a Classe em que foi montada: uma entidade de Classe 4 pode conhecer uma especial de Classe 2, com 4 pontos e custo de 6 PE.

O tamanho dos efeitos que crescem com a Classe usa **a Classe da especial menos 1, no mínimo 1**. Isso vale para `Rajada`, `Fura`, `Anteparo`, `Desarma o Feitiço`, `Sugar`, `Levanta`, `Remenda` e o tamanho das Formas de área. Essa redução não muda o acerto, o Teste de Resistência nem a CD da ficha.

*Exemplo:* uma especial de Classe 4 tem 9 pontos e custa 12 PE. Para um dos efeitos dessa lista, ela usa Classe 3. Uma especial de Classe 1 usa Classe 1, pelo mínimo.

### Espaços e passivas

Os **espaços** pagam as especiais conhecidas e, na domada com técnica, a Expansão de Domínio. A conta é `(2 + nível ÷ 2) ÷ 2`, arredondando para baixo, sem somar espaços por marco. Começa com 1 no nível 1 e ganha um no 4, 8, 12, 16, 20, 24 e 28. Chega a 8.

**A entidade ganha uma passiva no nível 1 e outra nos níveis 6, 10, 14, 18, 22, 26 e 30.** São oito no nível 30, fora dos espaços das especiais. Não há teto de cinco.

Cada passiva entra na Classe Passiva mais alta que o nível liberou quando ela foi ganha: Classe Passiva 1 até o nível 6; 2 do 7 ao 12; 3 do 13 em diante. Assim, as passivas dos níveis 1 e 6 são de Classe Passiva 1, a do 10 é de Classe Passiva 2 e as do 14 em diante são de Classe Passiva 3.

*Exemplo:* no nível 10, a entidade tem `(2 + 10 ÷ 2) ÷ 2 = 3,5`, arredondado para 3 espaços. Conhece uma básica e tem três passivas, recebidas nos níveis 1, 6 e 10. A segunda básica vem no 11; o próximo espaço, no 12.

### Progressão

Ao subir de nível, a entidade pode reescrever uma especial do zero. Confira também a vida, a Classe liberada, os dados da básica, os espaços e os marcos alcançados. Uma especial antiga não troca de Classe só porque a entidade subiu.

A básica usa os dados da tabela, esteja a entidade sozinha ou em dupla. A especial também usa os próprios pontos: substituir sua Padrão por um comando não dá uma básica extra à entidade.

### Montagem da habilidade

**Escolha Classe, Forma e Melhorias. O que sobra dos pontos da especial vira d8 de dano.** A básica segue a quantidade de d6 da entidade, com o limite de uma Melhoria e uma Restrição `Leve`.

1. **Classe.** Escolha até a liberada pelo nível da entidade. Separe os pontos da tabela *Números da entidade* e o custo de `3 × Classe` em PE.
2. **Forma.** Escolha como ela atinge. Pague o preço da Forma quando houver. Ela não ocupa uma Melhoria.
3. **Melhorias.** Compre efeitos das Famílias disponíveis. Na Livre, aplique o desconto. Uma peça própria conta como Melhoria.
4. **Restrições.** Se aceitar uma exigência real, use os pontos devolvidos para pagar Melhoria. Devolução que sobrar se perde; não aumenta dano.
5. **Resultado.** Cada ponto restante da especial vira 1d8. Anote alcance, alvo, resolução, duração, requisitos e custo. Escreva também como a entidade faz aquilo.

**Os preços continuam usando a Classe real da especial.** A Classe menor é usada só no tamanho dos efeitos que escalam com ela. Não diminua o preço junto.

Melhoria `Leve` custa metade da Classe; `Média`, a Classe; `Pesada`, Classe e meia. Arredonde o preço para cima. Restrições devolvem no máximo `2 × Classe` e nunca mais do que o gasto que podem pagar. Uma especial comum não passa dos próprios pontos em dados contra um alvo. Somando alvos e repetições, permanece o teto geral de `4 × Classe` em dados.

**Limites da montagem**
| Classe do feitiço | Melhorias | Restrições |
|---|---|---|
| **1 e 2** | 2 | 2 |
| **3 e 4** | 3 | 2 |
| **5 em diante** | 4 | 2 |

Duas Melhorias escritas como uma pagam e contam como as duas. O `Efeito Próprio` conta no limite. Nenhuma montagem dispensa o comando da especial ou permite básica e especial no mesmo corpo no ciclo.

*Exemplo:* a especial de Classe 2 tem 4 pontos. Uma Melhoria `Média` custa 2; na Família Livre, o desconto de 1 a deixa em 1. Sem Restrição, sobram `4 − 1 = 3d8`. Se a peça for `Fura`, ela ignora 2 de Redução de Dano: usa Classe 1 para o efeito, embora continue sendo uma especial de Classe 2 e custe 6 PE.

### Formas

Cada habilidade tem uma Forma. Nas tabelas de montagem, **você é quem executa a habilidade: a entidade**. Custos de comando continuam sendo do invocador. Redução de Dano é o desconto aplicado ao dano recebido; é diferente de proteção, que entra na Defesa.

**Formas da entidade**
| Forma | Custa | O que é | Como resolve |
|---|---|---|---|
| `Projétil` | — | 18 m, um alvo | Rolagem de acerto |
| `Toque` | — | 1,5 m, um alvo. `Projétil` com a Restrição `Corpo a Corpo` embutida (devolve `Média`). | Rolagem de acerto |
| `Explosão` | `Leve` | Esfera de raio 3 m, num ponto a até 18 m | Teste de Resistência, metade no sucesso |
| `Aura` | `Leve` | Esfera de raio 3 m centrada em você. `Explosão` com `Corpo a Corpo` embutida (devolve `Média`). | Teste de Resistência, metade no sucesso |
| `Cone` | `Leve` | 4,5 m saindo de você. A largura do cone em qualquer ponto é igual à distância daquele ponto até você. | Teste de Resistência, metade no sucesso |
| `Linha` | `Leve` | 18 m por 1,5 m. Quando o comprimento chega ao topo da escada, `Maior` passa a subir a largura: 1,5 m → 3 m → 4,5 m. | Teste de Resistência, metade no sucesso |
| `Cura` | `Média` | Um aliado a até 9 m. Os dados viram cura. Pode escolher alvo hostil. | Automático no aliado, acerto no hostil |
| `Apoio` | — | Um aliado a até 9 m. Sem dano. Cada ponto que sobra vira 3 de vida temporária. | Automático |
| `Onda` | `Pesada` | Esfera de raio 3 m centrada em você. A cura ou o apoio pega todos os aliados dentro, sem dividir. | Automático |
| `Efeito` | — | Fora de combate. Sem dano. Ver *Fora de combate*. | Automático |

`Explosão`, `Aura`, `Cone` e `Linha` exigem Área aberta. `Cura`, `Apoio` e `Onda` exigem Amparo aberto. `Projétil`, `Toque` e `Efeito` ficam para todas. Classe 0 não cura: não usa `Cura` nem `Onda`.

Trocar acerto por Teste de Resistência, ou o contrário, é gratuito na montagem. No TR, o alvo rola o atributo pertinente, com maestria se treinado, contra a CD da entidade. Igualar ou passar resiste. As áreas de dano entregam metade no sucesso, salvo regra em contrário.

**Base das Formas.** `Toque` alcança 1,5 m em qualquer Classe. `Projétil` alcança 9 m na Classe 0, 18 m nas Classes 1 a 5 e 36 m nas Classes 6 e 7. `Apoio` alcança 4,5 m, 9 m e 18 m nessas mesmas faixas; `Cura`, indisponível na Classe 0, alcança 9 m e 18 m.

O tamanho de área da especial lê uma Classe abaixo, mínimo 1. `Explosão` e `Aura` têm raio 3 m até a especial de Classe 6 e 4,5 m na 7. `Cone` tem 4,5 m até a especial de Classe 6 e 9 m na 7. `Linha` tem 18 × 1,5 m até a especial de Classe 6 e 30 × 1,5 m na 7. Na Classe 0, `Explosão` e `Aura` têm raio 3 m, `Cone` tem 3 m e `Linha`, 9 × 1,5 m.

O ponto da `Explosão` fica a até 9 m na Classe 0, 18 m nas Classes 1 a 5 e 36 m nas Classes 6 e 7; `Aura` é centrada na entidade. O raio básico de `Onda` é 3 m. Distância até o alvo e tamanho da área são medidas separadas.

**Escadas da montagem**
| Escada | Degraus |
|---|---|
| **Alcance** | 1,5 m → 9 m → 18 m → 36 m → 90 m → o que você enxergar |
| **Esfera (raio)** | 3 m → 4,5 m → 6 m → 9 m → 15 m |
| **Cone e Linha** | 4,5 m → 9 m → 18 m → 30 m → 60 m |

As Melhorias que aumentam alcance ou área sobem essas escadas. Ao chegar ao último degrau, param. “O que você enxergar” usa olho nu, sem câmera, luneta, espelho ou visão emprestada.

*Exemplo:* uma especial de Classe 6 usa o tamanho de área da Classe 5: o Cone básico tem 4,5 m. Se comprar um aumento de degrau de tamanho, chega a 9 m. Isso não muda o PE nem os pontos da especial.

**Ampliar.** Uma especial conhecida pode ser usada numa Classe maior, até a maior liberada, pagando o PE novo e refazendo pontos, preços e devoluções. A natureza da habilidade continua a mesma. Isso é diferente de reescrever a especial ao subir de nível.

**Cura.** Pague a Forma e transforme os dados restantes em cura. `Onda` aplica a cura ou o apoio aos aliados na área sem dividir; `Junto` acrescenta aliado dividindo. A Forma `Cura` pode mirar alvo hostil com acerto: contra uma maldição, energia positiva causa os dados como dano com 50% a mais; contra outro alvo hostil, não faz nada. Essa aplicação exige `Energia Reversa`, e a entidade não a recebe por escolher a Forma. Não há Liberação Máxima de cura.

**Controle.** Uma especial com Melhoria de Controle e dano final de até um quarto do teto geral — até a Classe em dados — ganha uma rodada nos efeitos de Controle. Sem dano, ganha também +2 na CD desses efeitos. O TR do dano não recebe esse bônus. O limite que reserva condições `Média` e `Pesada` à especial comandada continua valendo.

**Efeito fora de combate.** A Forma `Efeito` não causa dano nem rola dado. Os pontos compram Melhorias; sobras não viram dano. Custa o PE normal e ocupa espaço quando não é Classe 0.

**Escala da Forma Efeito**
| Classe | O que cabe | Quanto dura |
|---|---|---|
| **0** | Coisa de mão: acender uma vela, trancar uma porta, marcar um objeto. | até você desfazer |
| **1** | Uma pessoa, um objeto pequeno, um cômodo apertado. | um minuto |
| **2** | Um cômodo grande, uma parede, um carro, meia dúzia de pessoas. | dez minutos |
| **3** | Uma casa, um quarteirão, uma dúzia de pessoas. | uma hora |
| **4** | Um prédio, uma rua inteira, uma multidão. | um dia |
| **5** | Um bairro, uma noite inteira, o clima do lugar. Um prédio dormindo ao mesmo tempo, um rio parando de correr, uma ponte que não deixa ninguém passar. | uma semana |
| **Máxima** | Uma cidade, uma coisa que vira notícia. Todo mundo esquecendo um nome, um bairro de onde ninguém sai, uma noite que não amanhece. | até alguém desfazer |

*Na mesa:* um `Efeito` de Classe 1 trabalha na escala de uma pessoa, objeto pequeno ou cômodo apertado por um minuto. A definição da entidade ainda precisa comportar o que será feito; a Forma não lhe dá qualquer poder daquela escala.

### Catálogo de Melhorias

Compre só o que cabe na definição e nas Famílias abertas. As tabelas usam a Classe real para o preço. Nas sete peças que escalam abaixo, **Classe do efeito** significa `Classe da especial − 1`, no mínimo 1.

**Melhorias de Alcance**
| Melhoria | Custo | O que faz |
|---|---|---|
| `Longe` | `Leve` | Sobe um degrau na escada de alcance. Pode comprar duas vezes. |
| `Muito Longe` | `Média` | Sobe três degraus de uma vez. |
| `Sem Ver` | `Pesada` | Você conjura contra um alvo fora da sua linha de visão, desde que saiba onde ele está. Alcance normal do feitiço. |
| `Passo` | `Leve` | Você anda até 6 m antes ou depois do feitiço, sem provocar ataque de oportunidade. |
| `Empurrão` | `Leve` | Move o alvo até 6 m na direção que você quiser. |
| `Troca` | `Média` | Você e o alvo trocam de lugar. |
| `Perseguir` | `Média` | Se o alvo sair do alcance antes de o feitiço concluir, o feitiço vai atrás. |

**Melhorias de Área**
| Melhoria | Custo | O que faz |
|---|---|---|
| `Maior` | `Leve` | Sobe um degrau de tamanho de área. Pode comprar duas vezes. |
| `Muito Maior` | `Pesada` | Sobe três degraus de tamanho de uma vez. |
| `Escolher` | `Média` | Você decide quem, dentro da área, é atingido. |
| `Fica` | `Média` | A área continua ali por 1 minuto. Quem entrar ou começar o turno nela leva metade dos dados. Exige concentração. |
| `Mais Um` | `Leve` | Um alvo a mais. Os dados são divididos entre os alvos. Pode comprar duas vezes. |
| `Rajada` | `Leve` | Divide o feitiço em (Classe do efeito + 1) tiros, cada um com sua rolagem de acerto, distribuídos como você quiser. |
| `Salto` | `Média` | Depois do primeiro alvo, pula para o inimigo mais perto a até 9 m com metade dos dados. |
| `Contorno` | `Leve` | A área faz curva. Ignora cobertura e dobra esquinas. |

**Melhorias de Mira**
| Melhoria | Custo | O que faz |
|---|---|---|
| `Precisão` | `Leve` | +2 na rolagem de acerto, ou +2 na CD do Teste de Resistência. |
| `Certeiro` | `Média` | Sem rolagem de acerto. O alvo ainda faz o Teste de Resistência para metade. |
| `Inescapável` | `Média` | Sem acerto e sem Teste de Resistência: o dano é automático. Este feitiço não pode ter mais nenhuma peça, nem Melhoria nem Restrição, e não pode ser uma Liberação Máxima. |
| `Fura` | `Média` | Ignora até 2 × Classe do efeito de Redução de Dano. |
| `Corrói` | `Pesada` | Resistência ao seu tipo de dano deixa de valer neste feitiço. Só pode ser comprada se Mira for uma das suas Famílias Livres. |
| `Sem Cobertura` | `Leve` | Cobertura `Parcial` não atrapalha. A `Total` não se fura: ela não é bônus, é a ausência de alvo legal. |
| `De Novo` | `Média` | Se você errar, rola de novo. Uma vez por cena. |
| `Toca a Alma` | `Leve` | Só da Classe 3 em diante, e só quando a definição da entidade for direta sobre alma. Os dados de dano deste feitiço viram dano na alma, e você fica com metade deles, arredondando para baixo. Não entra numa Liberação Máxima. |

**Melhorias de Controle**
| Melhoria | Custo | O que faz |
|---|---|---|
| `Condição` | o nível dela | Aplica uma das treze condições. O preço é o nível dela (`Leve`, `Média` ou `Pesada`), e a seção *Condições* traz as três listas. Dura uma rodada, a não ser que o feitiço tenha a `Concentrada` ou a `Duradoura`. As de nível `Pesada` dão Teste de Resistência no fim de cada turno do alvo, e só pode ser colocada uma delas por feitiço. |
| `Terreno` | `Leve` | A área vira terreno difícil, ou fica obscurecida, por uma rodada. |
| `Anteparo` | `Média` | Deixa uma parede ou escudo com 10 × Classe do efeito de pontos de vida, por 1 minuto. Ocupa os mesmos quadrados que a `Linha` da Classe do efeito, arrumados como você quiser, cada um partilhando um lado com outro. Altura mínima 2 quadrados. Colocado num ponto a até o alcance do feitiço. |
| `Prende` | `Média` | O alvo não sai do lugar até o fim do próximo turno dele. Ele pode gastar uma ação — qualquer uma, menos livre — para tentar um Teste de Resistência e se soltar. O Teste é decidido na criação do feitiço. |
| `Cerca` | `Leve` | O alvo não consegue se aproximar de você até o fim do próximo turno dele. Acaba assim que você causar dano a ele — inclusive o dano do próprio feitiço que comprou esta Melhoria. |
| `Puxa` | `Média` | Todo mundo na área é puxado 6 m na direção do centro. |
| `Desarma o Feitiço` | `Média` | Cancela um efeito contínuo ou uma barreira de Classe igual ou menor que a Classe do efeito. |

**Melhorias de Auxiliares**
| Melhoria | Custo | O que faz |
|---|---|---|
| `Impulso` | `Leve` | O alvo tem vantagem no próximo teste dele, até o fim do próximo turno. |
| `Trava` | `Leve` | O alvo tem desvantagem no próximo ataque dele. |
| `Abre Ferida` | `Leve` | O alvo fica com −2 em um Teste de Resistência até o fim do próximo turno dele. |
| `Sobrecarga` | `Leve` | Até o fim do próximo turno do alvo, ele não usa Reação, e o feitiço dele sai com a CD 2 menor. |
| `Firmeza` | `Média` | O alvo tem vantagem no próximo Teste de Resistência dele. |
| `Guarda` | `Média` | Até o fim do próximo turno, o alvo tem +2 de defesa. |
| `Pressa` | `Média` | O alvo ganha +6 m de deslocamento e não provoca ataques de oportunidade até o fim do próximo turno. |
| `Enfraquece` | `Média` | O dano do alvo cai `Xd4` até o fim do próximo turno dele, com X sendo metade do seu atributo de técnica. |
| `Ecoa` | `Média` | O próximo ataque de um aliado contra o alvo tem vantagem. |

**Melhorias de Castigo**
| Melhoria | Custo | O que faz |
|---|---|---|
| `Queima` | `Média` | Metade dos dados de novo, no começo do próximo turno do alvo. |
| `Acúmulo` | `Média` | +1 dado por rodada seguida usando este feitiço no mesmo alvo. Para de somar em +3. |
| `Remate` | `Média` | +25% de dano contra alvo abaixo de metade da vida. Não entra num feitiço que tenha uma `Condicional` ligada à vida do alvo ou à duração, nem num feitiço com a Restrição `Aquecer`. |
| `Estilhaço` | `Leve` | Em crítico, ou quando o alvo falha o Teste de Resistência por 5 ou mais, metade dos dados respinga em quem estiver do lado. |
| `Quebra Coisa` | `Leve` | Dano dobrado contra barreiras, objetos e estruturas. |
| `Rasga Escudo` | `Média` | O dano ignora `vida temporária` e barreiras: bate direto na vida. Não ignora Redução de Dano. |
| `Sem Cura` | `Média` | O alvo não pode receber cura até o fim do próximo turno dele. |

**Melhorias de Tempo**
| Melhoria | Custo | O que faz |
|---|---|---|
| `Rápido` | `Pesada` | Custa Ação Bônus em vez de Ação Padrão. Não entra no mesmo feitiço que `Reação` nem com a Restrição `Atrasar`. |
| `Reação` | `Pesada` | Você conjura como Reação, a um gatilho que você declara quando monta o feitiço. Não entra no mesmo feitiço que `Rápido` nem que `Armado`, nem com as Restrições `Atrasar` e `Parado`. |
| `Armado` | `Leve` | Você gasta a ação e o PE do feitiço, e ele fica armado até o fim da cena. Na hora de armar, escolha um gatilho que a mesa consiga ver acontecer e que não seja um momento do seu próprio turno. Quando ele acontece, o feitiço sai sem gastar Reação, com alcance e alvo conferidos naquela hora. Um armado por vez. Se ele não sair, porque a cena acabou ou porque você armou outro, metade do PE volta. Não entra no mesmo feitiço que `Reação` nem com a Restrição `Carregar`. |
| `Silencioso` | `Leve` | Sem gesto, sem palavra. Usar não revela a sua posição e não exige nenhum sinal. Dispensa Selo de gesto ou de som; Selo de condição, como enxergar o alvo, continua valendo. |
| `Adianta` | `Média` | Se você conjurar antes de qualquer inimigo agir na rodada, +2 na CD. |
| `Segura` | `Leve` | Você pode adiar o efeito por até uma rodada e disparar no seu próximo turno, de graça. |
| `Concentrada` | `Leve` | Os efeitos de estado do feitiço, que hoje duram uma rodada ou até o fim do próximo turno, passam a durar o tempo da tabela `Quanto dura`. Exige concentração. Não vale para o dano, para a `Fica` nem para o `Anteparo`. |
| `Duradoura` | `Média` | A mesma coisa que a `Concentrada`, só que sem exigir concentração, e com o tempo da coluna `Duradoura` da tabela `Quanto dura`. |

**O comando continua obrigatório.** `Rápido` não torna uma especial autônoma nem dá Bônus à entidade. `Reação` e `Armado` também não substituem os procedimentos de ordem antecipada e `Preparar`. A relação dessas montagens com as ações de comando precisa estar resolvida no texto da capacidade; não deduza execução gratuita da tabela.

Quando a regra geral de conjuração permitir feitiço por Bônus ou Reação, o único outro feitiço naquele turno é Classe 0. Não use uma opção do catálogo para ignorar o limite de uma básica do corpo ou a coletiva.

**Duração dos efeitos**
| O que o efeito faz | Concentrada | Duradoura |
|---|---|---|
| Condição, buff ofensivo e debuff | 1 minuto | 1 minuto |
| Buff defensivo numérico: um bônus fixo na Defesa ou num Teste de Resistência (a `Guarda`) | 10 minutos | 1 minuto |
| Buff defensivo mecânico: resistência, imunidade, pontos de vida ou dividir dano (a `Divide`) | 10 minutos | Classe 1 e 2: 1 hora · Classe 3: 8 horas · Classe 4 em diante: 24 horas |

O feitiço inteiro usa a menor duração entre seus efeitos. Concentração mantém um efeito por vez; sofrer dano exige TR de Vigor contra a CD de quem causou o dano.

**Melhorias de Marca**
| Melhoria | Custo | O que faz |
|---|---|---|
| `Marca` | `Leve` | O alvo fica marcado até o fim do seu próximo turno. **Você** tem vantagem no seu próximo ataque contra ele. Só você. |
| `Alvo de Caça` | `Leve` | O alvo fica marcado até o fim do seu próximo turno. Daí em diante, cada ataque **seu** que acertar ele causa 1d4 a mais, e o feitiço que marcou não ganha o dado. Vale arma, desarmado e feitiço com rolagem de acerto, e cada tiro da `Rajada` conta. Se este feitiço tiver o `Rápido`, o dado é 1d8. Não entram feitiço de Teste de Resistência, dano que volta em rodada seguinte como o da `Queima`, respingo, nem ataque da sua invocação. Um alvo marcado por vez: marcar outro apaga a marca anterior. |
| `Rastro` | `Leve` | Você sabe onde o alvo está por 1 hora, desde que ele esteja no mesmo plano. |
| `Sugar` | `Média` | Você recupera um quarto do dano causado, até no máximo 5 × Classe do efeito. |
| `Isca` | `Leve` | Até o fim do próximo turno do alvo, ele tem desvantagem em qualquer ataque que não mire você. |
| `Cobrança` | `Média` | Se o alvo cair nesta cena, o seu próximo feitiço custa metade. |
| `Aviso` | `Leve` | Você sabe qual foi o último feitiço que o alvo usou e de que Classe ele era. |

**Melhorias de Amparo**
| Melhoria | Custo | O que faz |
|---|---|---|
| `Limpa` | `Média` | Remove de um aliado uma condição de nível `Leve` ou `Média`. |
| `Limpa Fundo` | `Pesada` | Remove de um aliado uma condição de qualquer nível. |
| `Levanta` | `Pesada` | Um aliado caído em 0 pontos de vida volta de pé com 5 × Classe do efeito, seja qual for a vida máxima dele. Uma vez por cena. |
| `Divide` | `Média` | Um aliado a até 9 m passa a receber metade do dano que você receberia, até o fim do próximo turno. Você escolhe na hora de conjurar. |
| `Junto` | `Leve` | A cura ou o apoio pega um aliado a mais. O efeito é dividido entre eles. Pode comprar duas vezes. |
| `Reserva` | `Média` | A cura fica guardada no aliado e é usada sozinha quando ele cair abaixo da metade da vida. Dura até o fim da cena. |
| `Remenda` | `Pesada` | Devolve 5 × Classe do efeito de Integridade a um aliado. Uma vez por cena, por alvo. |

**Melhoria fora de família**
| Melhoria | Custo | O que faz |
|---|---|---|
| `Efeito Próprio` | o mestre decide | Uma mecânica que não existe em lugar nenhum desta lista. Um deslocamento junto com o dano, um efeito que só funciona em superfície molhada, o que for. Um por feitiço, e ele conta como uma Melhoria no limite da Classe. Combinado antes da sessão e nunca no meio dela. Não pertence a nenhuma Família, então Família Fechada não bloqueia. |

Uma condição usa o nível que tem na regra geral. Só uma `Pesada` por habilidade, com TR no fim de cada turno do alvo. O texto abaixo adapta `Atordoado` à atuação da entidade.

**Condições de nível `Leve`**
| Nível `Leve` | O que faz |
|---|---|
| `Lento` | Deslocamento pela metade, e sem Ação Bônus. |
| `Incapacitado` | Você não pode Bloquear, e todo ataque corpo a corpo que acertar você é crítico. Só ele: conjuração e ataque à distância não, e o feitiço de Toque é conjuração mesmo encostado em você. |
| `Derrubado` | No chão. Só se move rastejando, desvantagem nos seus ataques, e quem ataca de até 1,5 m tem vantagem; de longe, desvantagem. |
| `Agarrado` | Deslocamento 0. Acaba se quem agarrou ficar `Incapacitado`, ou se algo te tirar do alcance dele. Ataque à distância contra quem está agarrando tem 50% de chance de errar o alvo: role `1d10`, e em 6 ou mais você acerta o alvo desejado; em 5 ou menos, acerta quem está agarrando. |
| `Desarmado` | A sua arma está no chão ou na mão de outro. Você bate desarmado até pegar de volta. |
| `Surdo` | Não ouve. Falha automática em teste que precise de audição, e −2 na iniciativa. |

**Condições de nível `Média`**
| Nível `Média` | O que faz |
|---|---|
| `Calado` | Você não conjura. Nada que precise de voz, gesto ou Selo que envolva voz sai. |
| `Enfeitiçado` | Você não ataca quem enfeitiçou nem mira efeito nocivo nele, e ele tem vantagem em teste social contra você. |

**Condições de nível `Pesada`**
| Nível `Pesada` | O que faz |
|---|---|
| `Impedido` | Deslocamento 0, desvantagem nos seus ataques e no Teste de Resistência Físico, e vantagem para quem te ataca. |
| `Cego` | Não enxerga. Falha automática em teste que precise de vista, desvantagem nos seus ataques, vantagem para quem te ataca. |
| `Amedrontado` | Desvantagem em ataque e teste enquanto enxergar a fonte do medo, e você não se aproxima dela de vontade própria. |
| `Envenenado` | Desvantagem nos seus ataques e em todo teste de perícia. |
| `Atordoado` | A entidade perde uma atuação básica e não usa a Reação coletiva enquanto estiver `Atordoado`. A condição não gasta a coletiva das outras entidades. |

*Exemplo:* comprar `Condição` para deixar o alvo `Lento` cabe numa básica, pagando a Melhoria `Leve` com um dado. Deixá-lo `Atordoado` exige especial comandada, mesmo se a definição sugerir uma aura que paralisa.

### Restrições

São exigências reais em troca de pontos para pagar Melhorias. Cabem no máximo duas, devolvendo até `2 × Classe`. Nunca devolvem `Pesada`, nunca viram dano e nunca pagam mais do que foi gasto em Melhorias.

**Restrições da montagem**
| Restrição | Devolve | O que muda |
|---|---|---|
| `Corpo a Corpo` | `Média` | `Projétil` vira `Toque` (1,5 m). `Explosão` vira `Aura`, centrada em você. `Cone` e `Linha` já saem de você, então não podem pegar esta. |
| `Atrasar` | `Média` | Custa a rodada inteira (Ação Completa): você não se move, não usa ação bônus e não faz mais nada naquele turno. |
| `Parado` | `Leve` | Você não se move no turno em que conjura. A ação bônus continua sua. |
| `Gesto` | `Leve` | Precisa das duas mãos livres e de falar em voz audível. |
| `Sangra` | `Média` | Você toma 2 × Classe de dano que não pode ser reduzido. |
| `Recuo` | `Leve` ou `Média` | Você fica com uma condição até o fim do seu próximo turno. Ela devolve o nível dela: uma condição `Leve` devolve `Leve`, uma `Média` devolve `Média`. Nível `Pesada` não entra, porque Restrição nunca devolve `Pesada`. |
| `Carregar` | `Média` | Você gasta um turno carregando o feitiço antes de disparar. Se tomar dano nesse meio-tempo, faz um Teste de Resistência de Espírito contra a CD de quem te feriu para manter. Se falhar, perde o feitiço. Carregar não é concentração: o feitiço ainda não saiu. |
| `Tudo ou Nada` | `Leve` | Quem passa no Teste de Resistência não toma nada, em vez de tomar metade. Só em feitiços de Teste de Resistência. |
| `Uma Vez` | `Leve` | Uma vez por cena. |
| `Condicional` | `Leve` ou `Média` | Só funciona quando uma condição de cena ou de alvo, escrita na ficha, é verdadeira: no escuro, marcado por você, abaixo de metade da vida, perto de água corrente. Falha em menos de uma cena a cada três: devolve `Leve`. Falha na maioria das cenas: devolve `Média`. |
| `Fraqueza` | `Leve` ou `Média` | Depois de usar, você fica com desvantagem num dos quatro Testes de Resistência, escolhido na montagem, até o fim da cena. Vigor ou Intelecto: `Leve`. Físico ou Espírito: `Média`. |
| `Frágil` | `Leve` | Se você tomar dano antes do seu próximo turno, o efeito do feitiço acaba na hora. Só serve em feitiço que deixa algo durando. |
| `Barulho` | `Leve` | Todo mundo num raio de 90 m ouve, e sabe de onde veio. |
| `Assinatura` | `Leve` | O feitiço deixa uma marca visível que dura 1 hora e aponta para você. |
| `Aquecer` | `Leve` | Não pode ser usado na primeira rodada do combate. |
| `Dívida` | `Média` | Depois de usar, o próximo feitiço que você conjurar nesta cena custa **`2 ×` a Classe deste feitiço** de energia a mais — **mesmo que ele seja de Classe 0**. |
| `Peso Morto` | `Leve` | Seu deslocamento cai pela metade até o fim do próximo turno, e você recebe `−1` no seu Teste de Resistência Físico. |
| `Sem Volta` | `Média` | Se o feitiço não acertar ninguém, você não conjura nada no seu próximo turno. |

**Restrição própria**
| Restrição | Devolve | O que muda |
|---|---|---|
| `Restrição Própria` | `Leve` ou `Média` | Uma desvantagem que não existe nesta lista. Escrita com o mestre antes da sessão, nunca no meio dela, e vale só para o feitiço onde nasceu. Conta no limite de duas Restrições e obedece as mesmas travas de todas as outras. |

Uma Restrição própria é escrita com o mestre antes da sessão. Se atrapalha em menos de uma cena a cada três, devolve `Leve`; se atrapalha na metade das cenas ou mais, `Média`. Se não há uma cena em que atrapalhe, não devolve ponto. Na dúvida de preço, uma Melhoria própria é `Pesada`; uma Restrição própria é `Leve` ou não serve.

**Escolha no máximo uma Restrição de frequência:** `Uma Vez`, `Condicional`, `Aquecer`, `Dívida` ou uma própria que limite quando a habilidade pode sair. Duas Restrições não podem cobrar a mesma coisa. Depois de três sessões, o mestre revê as que nunca atrapalharam e as troca, salvo se a habilidade nunca foi usada.

*Exemplo:* `Parado` devolve uma `Leve` se a entidade abrir mão de se mover no turno da execução. Ela não vende os metros do invocador. Já `Atrasar` cobra uma rodada inteira: a entidade não recebe suas ações de personagem para pagar isso. A montagem precisa deixar esse custo resolvido antes de ser usada.

### Escolha das passivas

A entidade recebe as passivas nos níveis escritos em *Espaços e passivas*. Elas não gastam os espaços de especial. Classe Passiva 1 comporta efeito pequeno, condicional ou de informação; Classe Passiva 2, efeito reativo com limite de uso; Classe Passiva 3, mudança permanente.

As entradas abaixo são opções da regra comum, sujeitas à definição. Elas não dão técnica, reserva, ações do invocador ou execução adicional à entidade. Uma característica de armazenamento também pode ocupar uma passiva, pelas regras de *Carga e equipamento*.

**Passivas de referência**
| Passiva | Classe Passiva | O que faz |
|---|---|---|
| `Leitura` | 1 | Você identifica a Classe e a Forma de qualquer feitiço conjurado a até 18 m. |
| `Instinto` | 1 | Você não é pego de surpresa enquanto estiver acordado. |
| `Raiz` | 1 | Você não é movido à força nem derrubado contra a sua vontade. |
| `Mão Firme` | 1 | Você não perde concentração nem carga por dano de 10 ou menos. |
| `Farejador` | 1 | Você sente se alguém conjurou num lugar nas últimas 24 horas, e de que Classe. |
| `Aviso` | 1 | Você sabe qual foi o último feitiço que um inimigo à vista usou. |
| `Fluxo` | 2 | Ao conjurar Classe 3 ou mais, você ganha 2 × Classe de vida temporária. |
| `Eco` | 2 | Quando você derruba um inimigo com feitiço, o próximo feitiço da cena custa metade. |
| `Costura` | 2 | Uma vez por cena, um aliado a até 9 m que cairia a 0 fica com 1. |
| `Contramedida` | 2 | Como Reação, quando alguém conjura a até 9 m, gasta PE e sobe em 2 a CD daquele feitiço. |
| `Escama` | 3 | Escolha um tipo de dano que a definição da entidade justifique. Você tem resistência a ele: todo dano daquele tipo cai pela metade. |
| `Afinidade` | 3 | Escolha um tema da definição da entidade. Feitiços daquele tema ignoram cobertura `Parcial` e resistência ao seu tipo de dano. |
| `Passiva Própria` | 1 a 3 | Qualquer outra coisa, montada com o mestre na escala das outras entradas desta tabela. |

O catálogo não autoriza condição `Média` ou `Pesada` por passiva. Uma passiva reativa paga a coletiva quando exigir Reação; não dá outra reserva. Cura continua sem alcançar entidade a zero. Corpo amaldiçoado exige uma técnica feita para curá-lo ou reparo.

*Exemplo:* `Farejador`, Classe Passiva 1, permite ao cão de sombra sentir se alguém conjurou ali nas últimas 24 horas e de que Classe. Isso não mostra ao invocador tudo que o cão percebe nem revela sozinho quem conjurou.

## Ficha da entidade

**Distribua 9 pontos entre Força, Destreza, Constituição, Inteligência e Essência, sem passar de 3 na criação.** A cada marco, some 1 ponto de atributo. O teto depois da criação é 6.

Escolha o atributo de acerto na montagem. A entidade tem um Teste de Resistência treinado; nos outros, a maestria não entra. Físico usa Força ou Destreza, escolhida na criação; Vigor usa Constituição; Intelecto usa Inteligência; Espírito usa Essência. O **Teste de Resistência**, ou **TR**, é a rolagem para resistir a algo que acontece com ela.

> **Acerto:** atributo dela + sua maestria. Role d20 e some esse bônus.
>
> **CD:** 8 + atributo dela + sua maestria.
>
> **TR treinado:** d20 + atributo dela + sua maestria.
>
> **Defesa sem uniforme:** 10 + Destreza dela + metade da sua Essência ou da sua Inteligência, arredondada para baixo.
>
> **Vida máxima:** `(5 + Constituição) + (3 + Constituição) × (nível − 1)`.

**Corpo amaldiçoado de criação** usa 4 no lugar do 3 por nível. No nível 1 continua com `5 + Constituição`. O corpo amaldiçoado de técnica usa a vida normal. A vida ganha por nível é inteira.

*Exemplo:* Kaito distribui Força 3, Destreza 2, Constituição 2, Inteligência 1 e Essência 1: `3 + 2 + 2 + 1 + 1 = 9`. Escolhe Força para o acerto. Com maestria 1 e Essência 2 de Kaito, o shikigami tem acerto `3 + 1 = +4`, CD `8 + 3 + 1 = 12` e Defesa `10 + 2 + 2 ÷ 2 = 13`. No nível 1, tem `5 + 2 = 7` de vida. No 5, tem `7 + 5 × 4 = 27`. Se fosse um corpo de criação, teria `7 + 6 × 4 = 31`.

**Perícias treinadas:** escolha um número igual a `4 + metade da Inteligência da entidade`, arredondada para baixo. Use a lista de perícias do sistema e escolhas compatíveis com a definição. Nos testes treinados, some o atributo da perícia e a sua maestria; nos demais, apenas o atributo. **Ofícios exigem permissão expressa na ficha ou na regra de aquisição da entidade**; esses treinos não concedem ofícios automaticamente.

O Movimento é próprio de cada corpo. Os metros disponíveis precisam estar definidos na ficha; a regra de invocações não fixa um valor único.

### Traje e Revestimento

**`Traje` e `Revestimento` são equipamentos normais.** Qualquer entidade pode vestir um que sua anatomia comporte. Eles não vêm das escolhas do construtor.

Com um deles, a Defesa fica `10 + Destreza dela + proteção do item`. A proteção **substitui** a metade do seu atributo; as duas não somam. Requisito de Força, teto de Destreza, penalidade por requisito não cumprido e situação sob medida do `Traje` usam as regras do item, com os atributos da entidade.

Vestir não é carregar. O escudo, por sua vez, precisa ser segurado. Pelas combinações de uniforme e escudo, a Defesa da entidade chega a 19: metade do seu atributo com `Broquel`, `Traje` 3 com `Broquel`, ou `Revestimento` 3 com `Torre`.

*Exemplo:* o shikigami de Kaito tem Destreza 2 e recebia 1 de proteção pela metade da Essência dele. Vestindo um item de proteção 3 e cumprindo seus requisitos, a Defesa passa de 13 para `10 + 2 + 3 = 15`.

## Exemplo de montagem

Kaito quer uma entidade que procure sinais de conjuração e ataque de perto. Está no nível 2, tem maestria 1 e Essência 2. Ele ocupa um espaço de feitiço com um shikigami de técnica. A entidade começa no nível 2 e vai subir junto com ele.

**Definição.** “Um cão de sombra que fareja energia amaldiçoada e morde quem persegue.” Kaito descreve um quadrúpede sem mãos, capaz de perceber e compreender suas ordens faladas. Isso não lhe dá fala ou telepatia.

**Atributos.** Força 3, Destreza 2, Constituição 2, Inteligência 1 e Essência 1. São 9 pontos, nenhum acima de 3. Kaito escolhe Força para o acerto e a CD, e treina o TR Físico pela Força.

**Famílias.** Mira é Livre, para a mordida precisa; Alcance e Controle ficam abertas, a preço normal. Área, Auxiliares, Castigo, Tempo, Marca e Amparo ficam Fechadas. São seis Fechadas e uma Livre entre as três abertas.

**Básica.** Mordida na Forma `Toque`, sem Melhoria: 1d6, alcance 1,5 m, acerto +4 e nenhum PE. Kaito prefere conservar o único dado em vez de trocá-lo por uma condição `Leve`.

**Especial.** Outra mordida, agora de Classe 1, na Forma `Toque`. Tem 2 pontos. Compra `Precisão`, `Leve` de Mira, por 1; o mínimo mantém o preço em 1 mesmo na Livre. O `Toque` traz `Corpo a Corpo`, que devolve 1 e paga a Melhoria. Conta: `2 − 1 + 1 = 2d8`. Custa 3 PE e tem acerto `3 + 1 + 2 = +6` com `Precisão`. Ela ocupa o único espaço da entidade: `(2 + 2 ÷ 2) ÷ 2 = 1,5`, para baixo, 1.

**Passiva.** `Farejador`, a passiva de Classe Passiva 1 que veio no nível 1. Fica fora do espaço da especial. O cão sente conjuração feita no lugar nas últimas 24 horas e a Classe dela.

**Ficha.** Vida `5 + 2 + (3 + 2) × (2 − 1) = 12`; Defesa `10 + 2 + 2 ÷ 2 = 13`; acerto +4; CD 12; TR Físico treinado `d20 + 3 + 1`. Entrada de 1 PE. Volta depois de cair de 2 PE, com 6 de vida. Ele não tem reserva própria nem equipamento. O Movimento ainda precisa receber o valor da ficha; esta regra não fixa os metros.

**Na primeira luta.** Kaito paga a entrada antes da iniciativa e dá a tarefa de proteger a porta. Com o alvo a 1,5 m, no turno de Kaito o cão pode morder pela básica enquanto Kaito usa a Padrão para outra coisa. Ou Kaito pode gastar a Padrão e 3 PE para comandar a mordida especial: o cão usa a mesma oportunidade de básica, sem atacar de novo depois.

**No nível 4**, o cão tem 22 de vida e 2 espaços, mas ainda uma básica conhecida e uma passiva. Kaito pode montar outra especial no espaço novo; ganhar espaço não executa nada de graça.

**No nível 5**, a vida chega a 27, a básica passa a 2d6 e a entrada custa 2 PE. Ao reescrever a especial em Classe 2, ele ganha 4 pontos. `Precisão` custa 1; `Toque` devolve 2, mas só 1 é aproveitado para pagar a Melhoria. Sobram `4 − 1 + 1 = 4d8`, por 6 PE. Sem reescrever nem Ampliar, a versão de Classe 1 continuaria com os números antigos.

**No nível 6**, Kaito põe o ponto de atributo do marco em Constituição, que vai a 3. A vida passa a `(5 + 3) + (3 + 3) × 5 = 38`. A segunda passiva ainda é de Classe Passiva 1: ele escolhe `Instinto`, ligado à atenção do cão durante a vigília. Os espaços continuam 2 e a básica, 2d6. A segunda básica conhecida só chega no nível 11.

## Entidade em campo

### Recursos e ciclo

Você conserva suas ações. Não usar uma delas não a entrega à entidade.

**Recursos do conjunto**
| Recurso | A quem pertence | O que não concede |
|---|---|---|
| Atuação básica | Cada entidade | Não dá outra execução por conhecer outra capacidade. |
| Movimento | Cada corpo | Não usa nem transfere os metros do invocador ou da criatura substituída. |
| Reação coletiva | Todas as entidades do mesmo invocador | Não há uma reserva por corpo; a Reação pessoal não a abastece. |
| Padrão/Bônus do invocador | Personagem | Não passam às criaturas quando ele deixa de usá-las. |

No começo do seu turno, renove os recursos das entidades em campo e resolva os efeitos de começo de turno de cada uma. Organize as ações na ordem que escolher, concluindo uma antes da seguinte. No fim do seu turno, resolva os efeitos de fim de turno e os TR de cada criatura, mesmo das que não conseguiram agir.

**O turno de cada corpo não começa quando ele se move.** Os momentos de começo e fim são os seus. Virar a rodada da luta, trocar, recolher, redirecionar ou comandar não renova recursos.

*Na mesa:* Kaito move uma entidade, resolve sua básica, usa a própria Padrão e depois move a segunda. Nenhuma dessas escolhas abre outra renovação. Se a segunda ainda tiver uma básica disponível, pode usá-la numa oportunidade legal.

### Entrada e recolhimento

**Entrar, trocar e recolher custam a sua Ação Bônus.** Só acontecem no seu turno, com você consciente. Fora da luta, entrar e recolher não custam ação, mas a entrada continua custando PE.

A sua Padrão pode virar Bônus, e a Bônus pode virar Movimento. A conversão nunca anda ao contrário. Se você usar a Padrão como uma segunda Bônus, já gastou a ação que comandaria a especial.

Cada entrada custa a **Classe do nível da entidade** em PE. A tabela *Números da entidade* traz as faixas. Isso vale para manifestação, troca e retorno; voltar depois de cair tem o preço dobrado, explicado em *Queda e morte*. Recolher não custa PE.

**Sem troca**, ela aparece num espaço livre a até 1,5 m de você. **Na troca**, a substituta direta aparece no lugar de quem sai. Se o lugar não comportar a entidade, use o espaço livre mais próximo.

*Exemplo:* Kaito, no nível 13, manifesta uma domada de nível 5. Ela custa 2 PE, pela Classe dela, e aparece junto dele. Não custa 4 PE só porque Kaito já alcançou a Classe 4.

Uma entrada sem substituição dá ao corpo novo seu Movimento, mas não cria básica nem renova a coletiva. Para dar a primeira tarefa, você gasta outra Bônus, que também pode orientar as demais entidades em campo. Sem tarefa executável, ela só preserva a si mesma pelas regras de *Intenção*.

Se houver uma resposta reativa escrita na ficha e a coletiva estiver disponível, a entidade recém-chegada pode usá-la. Isso não cria uma básica nem fornece um ataque que ela não tenha.

*Na mesa:* Kaito usa a Bônus para manifestar. Converte a Padrão em Bônus para orientar a recém-chegada e outra entidade. A nova pode se mover, mas espera a próxima renovação em campo para ter sua básica. Kaito não comanda uma especial com a Padrão que já converteu.

Uma vaga aberta no turno inimigo espera seu turno. A saída por queda ou por morte do invocador pode acontecer a qualquer momento; ela não é um recolhimento voluntário.

### Troca

Trocar tira uma entidade e põe outra no lugar. A que entra para substituir a que sai é a **substituta direta**, escolhida naquela troca.

1. Veja se quem sai tem uma básica ainda disponível e utilizável.
2. Confira se a substituta ainda não gastou uma básica neste ciclo. Uma especial que ocupou a básica também conta como gasto.
3. Transfira no máximo uma básica. Ela deixa de pertencer a quem saiu.
4. Dê a primeira tarefa à substituta sem outra Bônus. Ela precisa receber a orientação, mesmo se não houver básica para transferir.
5. A substituta usa o Movimento dela. A coletiva conserva o saldo do conjunto.

**Transferir não copia.** Se a entidade que saiu voltar, não traz outra cópia da básica que entregou. Recolher a substituta não estorna a transferência. Trocar de posição, sair e voltar ou passar a oportunidade por vários corpos não apaga o histórico de uso de cada um.

*Exemplo:* uma entidade de Kaito ainda não agiu. Ele a troca por outra que também não gastou básica no ciclo. A substituta recebe a básica e a tarefa “ataque quem está na porta”. Se a primeira já tivesse atacado, a troca ainda daria a tarefa, mas não daria básica.

**Várias entradas.** Se uma troca legal tiver uma saída e várias entradas, escolha uma substituta direta. Só ela recebe a básica transferível e a orientação incluída. As outras entram junto de você, sem básica nem primeira tarefa gratuita.

**Várias saídas.** Se várias saírem para uma entrar, ela recebe no máximo uma básica. Não some as oportunidades. Ela aparece no lugar de uma das que saíram, à sua escolha. Toda troca precisa respeitar o teto de duas ativas.

Uma tarefa não cumprida pode ter deixado a básica sem uso. Já `Preparar`, a ação explicada adiante, gasta a básica na preparação. Recolher quem preparou não devolve nem transfere essa básica.

### Retorno e reserva

Anote por corpo a básica, o Movimento restante, a intenção, a vida, as condições e os usos de habilidade. Anote a coletiva uma vez para o conjunto.

**Sair e voltar não recupera recurso nem cura.** A entidade ferida volta com a vida que tinha. Ordem especial antecipada e preparação acabam na saída e não voltam com ela.

No começo do ciclo seguinte, acaba a trava da básica usada no ciclo anterior, mesmo para quem está recolhida. Ela pode receber uma transferência legal no ciclo novo, mas não ganha uma básica própria na reserva. Oportunidades antigas não se acumulam.

**Movimento não renova enquanto recolhida**, mesmo que passem vários ciclos. Na volta, ela conserva só os metros que ainda tinha. Renova quando chegar ao começo de um turno seu estando em campo.

*Exemplo:* a entidade gastou todo o Movimento, foi recolhida e ficou fora por dois ciclos. Ao voltar, continua sem Movimento restaurado. Se entrar substituindo alguém com básica disponível, pode receber essa básica, desde que cumpra as travas. Movimento e básica são contas separadas.

## Intenção

**Intenção é a tarefa que a entidade continua cumprindo sem você repetir a ordem.** Dê um objetivo concreto, com uma pessoa, alvo, objeto, lugar ou grupo que ela consiga identificar.

“Proteja esta entrada” permite escolher uma ameaça à passagem, aproximar-se, atacar, ajudar ou esquivar, conforme a ficha. Não obriga o inimigo a atacar a entidade, não dá interceptação e não revela alvos escondidos.

“Vença a luta” e “faça o melhor” precisam ser delimitadas. Uma sequência de missões independentes exige novas orientações. Trocar de meio dentro da mesma tarefa não é trocar de tarefa.

### Redirecionamento

**Gaste uma Ação Bônus para dar novas intenções a até todas as suas entidades em campo.** Elas podem receber tarefas diferentes. A Bônus não renova básica, Movimento ou coletiva e não manda usar especial.

Um sinal combinado também custa redirecionamento se comunicar uma nova escolha tática. “Ataque quem eu apontar” não torna gratuitas suas próximas escolhas de alvo. Informar algo do cenário, por si, não cobra uma nova Bônus; a entidade também pode escolher entre ameaças que já pertenciam à tarefa.

*Exemplo:* Kaito muda o plano. Com uma Bônus, manda uma entidade guardar a porta e a outra atacar a maldição junto da escada. Cada uma escolhe um trajeto legal com seu próprio Movimento.

### Impedimento e tarefa concluída

**Impedimento temporário conserva a intenção.** A entidade procura uma rota ou oportunidade possível, com os sentidos e recursos que tem. Quando o impedimento acaba, retoma sem nova Bônus. Esperar não acumula básicas nem autoriza atacar fora do seu turno.

**Tarefa cumprida ou definitivamente sem objeto termina.** A entidade não escolhe outra missão por conta própria. Perder o alvo de vista por um momento não prova que a tarefa acabou.

*Na mesa:* quem recebeu “proteja esta entrada” continua no posto depois de derrubar uma ameaça. Quem recebeu uma tarefa pontual e a concluiu precisa de nova orientação para começar outra.

**Sem tarefa executável**, ela pode preservar a si: usar `Esquivar` se houver básica ou gastar Movimento para sair de um perigo imediato que percebeu. Não sai perseguindo, protegendo terceiros ou usando especiais por conta própria. Isso vale antes da primeira orientação e não apaga uma intenção só temporariamente impedida. Respostas reativas escritas e especiais já ordenadas seguem seus procedimentos.

### Comunicação

**Toda instrução nova precisa ser percebida e compreendida.** Vale para primeira tarefa, redirecionamento, especial, ajuste, cancelamento e orientação depois da especial. Uma orientação gratuita também precisa chegar.

Voz e gesto servem quando os sentidos e a compreensão da criatura permitem. Comunicação mental exige regra expressa. Não há idioma universal, telepatia, sentidos compartilhados nem conhecimento automático de alvos. O alcance próprio do vínculo ainda não está fixado; não use o alcance de uma habilidade como se fosse o vínculo inteiro.

Perder só a comunicação não apaga uma intenção ou ordem recebida. A entidade continua com o que sabe enquanto existir e puder atuar. Recuperar o contato não entrega mensagens que falharam.

**Falha percebida antes da tentativa.** Corrija a declaração sem gasto se um impedimento conhecido for identificado antes de emitir a ordem.

**Falha descoberta depois.** Se você realmente emitiu a ordem e só depois descobriu que ela não chegou, a Padrão ou Bônus fica gasta. A mensagem não fica aguardando recepção. Uma especial que nem começou não gasta básica, coletiva ou custo de ativação, salvo custo que seu texto cobre antecipadamente.

*Exemplo:* Kaito redireciona duas entidades por voz. Só uma ouve e entende: só ela muda de tarefa. A outra conserva o estado anterior. A Bônus foi uma, sem devolução parcial. Tentar de novo custa a ação normal.

A primeira intenção incluída numa troca e a orientação depois de uma especial pertencem àquele evento. Se a orientação não chegar até o evento terminar, ela não vira um crédito gratuito para depois. A troca ou a especial continua resolvida, sem devolver custos nem desfazer uma básica transferida.

## Básica e limite de ataques

**No seu turno, no máximo duas entidades suas atuam causando dano, fora as especiais comandadas.** O limite conta entidades que causam dano. A especial comandada fica de fora nas modalidades imediata, antecipada e preparada. Tudo que acontece fora do seu turno também fica de fora.

Condição sem dano e ações comuns sem dano não contam: `Agarrar`, `Derrubar`, `Provocar`, `Ajudar` e `Esquivar`, por exemplo. Uma básica com dano e condição `Leve` conta pelo dano. Com você inconsciente, o limite continua valendo no seu turno.

Com duas ativas, as duas podem atacar. A ficha delas não cresce nem encolhe com quantas estão em campo.

**Condição de nível `Média` ou `Pesada` só vem de especial ativa comandada.** Básica, ação de Bônus paga com básica, preparação de básica, capacidade reativa, passiva e aura não aplicam essas condições. A condição `Leve` pode vir delas, com os custos da habilidade; na básica própria, paga a Melhoria `Leve` da Classe 0.

*Exemplo:* uma entidade usa uma básica sem dano para impor uma condição `Leve`; isso não conta no limite. Se a montagem também causar dano, conta. Para impor `Atordoado`, precisa de uma especial comandada.

### Ações comuns

Uma ação comum compatível com o corpo não ocupa uma escolha personalizada de habilidade, mas gasta a atuação correspondente. `Atacar`, `Correr`, `Desengajar`, `Esquivar`, `Esconder`, `Ajudar`, `Vasculhar`, `Estudar` e `Usar objeto` exigem os meios e requisitos normais.

`Correr` ocupa a básica para ampliar o deslocamento; não vem de graça junto de um ataque. `Ajudar` exige contribuição real e vale para a tentativa pertinente. Vários ajudantes não acumulam vantagem no mesmo teste. Ajudar a especial de outra entidade gasta a básica da ajudante.

**A entidade pode pagar com sua básica uma ação de Bônus disponível a ela**, como `Provocar` ou `Ler o Ambiente`, quando cumprir os requisitos. Continuam os custos próprios, os limites e a intenção. Isso não lhe dá uma Bônus própria, suas capacidades de personagem ou outra básica.

Se um efeito impedir Ação Bônus, também impede essas opções pagas com básica. Uma entidade `Lento` não usa `Provocar` dessa maneira. Pode gastar a básica em outra opção permitida.

*Na mesa:* Kaito tem duas entidades ajudando o mesmo aliado. Isso não acumula duas vantagens. Se uma delas ajudar a especial da outra, ambas gastam suas básicas: uma para ajudar, outra para executar a especial comandada.

`Agarrar`, `Derrubar` e `Empurrar` ainda não têm resolução completa aqui. Não acrescente teste, CD ou custo por semelhança com outra ação. `Estudar` também conserva a lacuna de qual perícia usar. A lista de ações comuns não dá conjuração autônoma nem os ataques adicionais do seu Caminho.

## Especial

**Você paga a Padrão para comandar; a entidade ocupa a básica disponível para executar.** Ela precisa receber a ordem e cumprir os requisitos da habilidade. As outras entidades conservam suas básicas.

Se a destinatária já gastou a básica, o comando não dá outra naquele ciclo. Se ela executar a especial primeiro, não sobra uma básica depois. Movimento e coletiva são separados, salvo custo ou impedimento escrito.

A especial pode sair contra um alvo fora da intenção atual. **Depois de conhecer o resultado**, você pode manter a intenção anterior ou dar outra à destinatária, sem Bônus adicional. A nova tarefa pode mirar outro alvo, mas não dá execução imediata nem orienta as demais.

*Exemplo:* Nue enfrenta uma maldição junto à porta. Você comanda uma especial contra outra. Depois do resultado, decide que Nue deve proteger a escada. Ele recebeu a tarefa, mas já gastou a básica naquela especial.

### Energia

Sem reserva própria, o PE da especial sai todo de você. **Só a maldição domada pode ter técnica própria** e, se a ficha dela trouxer, a reserva de energia dessa técnica.

Com reserva, divida o custo da especial pela metade. O ímpar fica com você. Se a reserva não cobrir a parte dela, você paga a diferença. Quando ela acaba, você paga tudo.

> **Reserva máxima:** nível da entidade × `(1 + um terço da Essência dela, arredondado para baixo)`.
>
> **Recuperação:** cheia no descanso longo; um quarto no descanso curto. Sair e voltar não recarrega.

*Exemplo:* uma domada de nível 10 e Essência 3 tem `10 × (1 + 3 ÷ 3) = 20 PE`. Uma especial de Classe 3 custa 9: 5 seus e 4 da reserva. Se só houver 2 na reserva, você paga 7. No descanso curto, ela recupera um quarto de 20, ou 5 PE.

Ordenar uma execução não autoriza repetir a especial sozinha. Duração, manutenção, usos e custos antecipados seguem o texto dela.

### Ordem antecipada

**Se um impedimento real bloquear a especial agora, você pode pagar a Padrão e ordenar antes.** Diga qual entidade, capacidade e alvo. Ela precisa receber a ordem legalmente.

Básica já gasta ou alcance insuficiente são impedimentos possíveis. Se tudo já permitir executar, a especial sai imediatamente: a ordem não fica guardada só porque você prefere outro momento.

A antecipada aguarda a **primeira oportunidade válida**. Não expira só porque passou seu próximo turno. Emitir a ordem não gasta nem reserva a básica ou os custos da especial; custos expressamente antecipados são exceção.

Enquanto houver impedimento, a entidade pode usar outra básica. Se fizer isso, aquela básica fica indisponível para a especial até uma renovação legítima. A coletiva não substitui uma básica que falta.

**Execução da ordem antecipada**
| Momento | Recursos consumidos quando a especial começa |
|---|---|
| Dentro do turno do invocador | Básica disponível da destinatária e custos próprios de ativação. |
| Fora do turno do invocador | Básica disponível da destinatária, **Reação coletiva** e custos próprios de ativação. |

Na execução, não pague outra Padrão. Confira básica, aptidão, alvo, alcance, percepção, energia, usos e os demais requisitos. Se faltar algum, a especial não começa e não gasta recursos de ativação ainda não pagos.

**Fora do seu turno**, a janela abre depois de terminar a ação, o movimento ou o efeito que tornou a especial possível. Não interrompa nem desfaça aquela resolução. Confira o estado que ficou depois dela.

*Exemplo:* Kaito ordena uma especial contra um alvo fora do alcance. A ordem fica pendente. No turno inimigo, o alvo termina um movimento dentro do alcance. Se a entidade tiver básica, coletiva e os demais recursos, executa ali, pagando ambos e o PE. Se outra resposta já gastou a coletiva, continua esperando.

**Ajuste.** Você pode pagar uma Bônus para mudar o alvo ou a capacidade da mesma ordem antecipada. A mensagem precisa chegar antes de a execução começar. Isso não muda a destinatária, não cria segunda ordem e não redireciona as outras entidades.

**Desistência.** Antes de começar, você pode comunicar o cancelamento sem nova ação, inclusive na janela que acabou de abrir. A Padrão investida não volta. A ordem termina; não vira crédito para outra especial.

Você não pode deixar passar uma oportunidade válida só para guardar a antecipada. Execute ou desista legalmente. Se ela for executada e errar, a ordem também termina. O resultado ruim não dá repetição.

### Ordens pendentes

**Cada corpo mantém no máximo uma especial aguardando execução:** antecipada ou preparada. Entidades diferentes podem ter suas próprias ordens, cada uma com seu comando pago.

Uma antecipada ainda inviável pode coexistir com a preparação de uma básica. Essa preparação gasta a básica, que então falta para a especial até outra oportunidade legítima.

Se várias respostas possíveis disputarem a coletiva na mesma janela, sem prioridade expressa, você escolhe qual resolve. Reavalie as outras depois. Uma antecipada sem coletiva continua esperando; uma preparação que dependia dela se perde quando a coletiva é gasta em outra resposta.

*Na mesa:* duas entidades têm antecipadas e o mesmo acontecimento torna ambas possíveis fora do seu turno. Você escolhe uma para gastar a coletiva. A outra espera. Isso não dá duas Reações ao conjunto nem permite guardar todas as antecipadas executáveis sem cumprir ou encerrar nenhuma.

Essa escolha também pertence ao jogador enquanto o invocador está inconsciente, mas só entre respostas já autorizadas. Não permite comando, ajuste ou cancelamento novo. A regra não estabelece prioridade para todo efeito simultâneo do jogo.

## Preparar

**Preparar paga agora para responder a um acontecimento definido.** É diferente da ordem antecipada, que espera um impedimento acabar.

Para preparar uma básica, a entidade gasta a básica no seu turno e declara uma ação legal e um gatilho visível ou verificável, dentro da intenção que tem. No gatilho, ela paga a coletiva e os custos próprios; não paga segunda básica.

A preparação expira no começo do seu próximo turno. Recolher a entidade, ela cair a zero ou gastar a coletiva em outra resposta também encerra a preparação. A básica investida não volta nem passa para substituta.

*Exemplo:* a entidade prepara um ataque contra quem cruzar a porta. Ela já gastou a básica. Se usar a coletiva em outro acontecimento antes da passagem, perde a preparação, mesmo que ninguém tenha cruzado ainda.

Uma básica preparada com dano conta no limite de ataques se disparar no seu turno. Fora dele, não conta. Se o limite estiver cheio no seu turno, ela não dispara ali; a preparação continua dentro do prazo para um gatilho fora do turno.

### Especial preparada

**Você paga a Padrão e manda preparar desde o começo.** A entidade recebe a ordem, investe a básica disponível e define a especial e seu gatilho. Sem básica agora, não há preparação pronta para usar depois.

No gatilho, confira os requisitos e pague coletiva e ativação. **A coletiva é exigida mesmo dentro do seu turno.** Não há segunda Padrão nem segunda básica. O prazo e as perdas são os mesmos de `Preparar`.

Depois da execução, você pode dar a orientação posterior à destinatária. Perder a preparação sem executar não dá essa orientação. Errar depois de executar não conserva a especial para outra tentativa.

**Ajustar no turno de emissão.** No mesmo turno em que comandou a preparação, você pode mudar alvo, capacidade ou gatilho sem nova ação. A destinatária é a mesma, precisa receber o ajuste e a execução ainda não pode ter começado. O prazo não muda, os gastos não voltam e o novo gatilho não pode usar um acontecimento passado. Fora daquele turno, não há esse ajuste gratuito.

**Gatilho inviável.** Se o gatilho acontecer sem algum requisito, a ocorrência é descartada. Não gaste coletiva ou ativação ainda não paga. A preparação continua até o prazo original, mas exige outra ocorrência válida. Recuperar alcance ou energia depois não ressuscita o acontecimento perdido.

**Recusar a ocorrência.** Consciente, percebendo o acontecimento e conseguindo comunicar antes da execução, você pode deixá-lo passar sem nova ação. A mesma preparação continua até o prazo original. Isso não troca o gatilho nem guarda um disparo para qualquer hora. Essa permissão é da especial preparada; não vale para a antecipada nem se estende à básica por analogia.

*Exemplo:* o gatilho é “quando o alvo entrar em alcance”. Ele entra, e Kaito recusa a ocorrência. Ficar dentro do alcance não dispara de novo. Se o alvo sair e entrar outra vez antes do prazo, há uma nova ocorrência a conferir. Se já estava no alcance quando a preparação foi feita, aquela entrada passada não conta.

### Cruzamento e movimento

**Se o gatilho for cruzar uma porta, a especial preparada resolve no cruzamento**, antes do resto do deslocamento. Confira os requisitos ali. Não espere o alvo chegar à cobertura para usar a mesma ocorrência.

Depois da especial, o alvo pode continuar com o Movimento que sobrou, se os efeitos permitirem. Acertar ou causar dano não interrompe o deslocamento por si.

*Na mesa:* o alvo cruza a porta e ainda teria caminho até uma parede. A preparada resolve na porta. Se ela só causar dano, ele pode continuar. Se houver um efeito que o impeça de andar, aplique esse efeito. A antecipada conserva sua outra janela: depois de terminar a resolução que a tornou possível.

### Mudança de modalidade

Para trocar uma antecipada por preparada, ou o contrário, **encerre a anterior por comunicação válida e pague outra Padrão para o novo comando**, numa oportunidade legal. Não aproveite o comando antigo.

Encerrar não recupera básica, PE, usos, Padrão nem custo antecipado. Se a preparação já investiu a básica, cancelá-la não permite preparar outra sem básica. Uma nova antecipada pode esperar uma básica elegível, se o novo comando for legal.

*Exemplo:* Kaito cancela uma preparada e quer uma antecipada. Precisa de outra Padrão legitimamente disponível. A básica que a entidade investiu continua gasta. Se a nova mensagem falhar, a ordem encerrada não volta.

## Movimento e defesa

Cada corpo gasta seu próprio Movimento para cumprir a tarefa. Você não precisa ordenar cada passo. Os metros não vêm de você nem de quem foi substituído. Autonomia não dá movimento ilimitado nem acompanhamento fora do turno sem regra escrita.

### Reação coletiva

Uma entidade apta responde sozinha ao gatilho de uma capacidade reativa que conheça. Paga a coletiva e os custos escritos. Continua precisando perceber, alcançar e cumprir as condições da resposta.

Uma condição pode impedir uma entidade de reagir sem gastar a coletiva. Outra entidade apta ainda pode usar a reserva. Trocar de corpo não a recarrega. Ter Reação disponível também não fornece ataque ou interceptação a quem não os tem.

*Na mesa:* uma entidade de Kaito está impedida de reagir. A outra tem uma resposta escrita e percebe o gatilho. Ela pode gastar a coletiva, que não foi perdida só pela condição da primeira.

### Bloquear

**`Bloquear` é gratuito por ataque elegível e não gasta a coletiva.** Role `2d10 + Defesa − 11`, pelas regras gerais. Não serve contra Teste de Resistência.

O duplo 10 de `Aparar` impede o acerto comum, mas não um 20 natural. Revidar com o contra-ataque exige Reação e usa o bônus de dano da regra geral; para a entidade, paga a coletiva. O duplo 1 abre `Brecha`: o ataque adicional é pago com a Reação do agressor. Se ele for outra invocação, paga a coletiva do conjunto dele.

*Exemplo:* a entidade tem Defesa 13 e tira 6 e 8 nos d10: `6 + 8 + 13 − 11 = 16`. Esse é seu resultado de Bloquear. Se a coletiva já tiver sido gasta, ela ainda pode bloquear ataques elegíveis; só não pode pagar o contra-ataque que exige Reação.

### Esquivar e condições

**`Esquivar` gasta a básica.** Até o começo do seu próximo turno, os ataques contra aquela criatura têm a desvantagem prevista pela ação, e seus TR Físicos têm vantagem. Não protege outro alvo. Vantagem usa o melhor de dois dados; desvantagem usa o pior.

**`Atordoado` tira uma básica da entidade e impede aquela criatura de reagir.** Não gasta a coletiva das outras. Se a condição acabar no fim do turno, ela pode voltar a reagir quando surgir uma oportunidade legal, mas não recupera a básica retirada naquele ciclo. Uma ordem antecipada continua esperando.

**`Incapacitado` impede Bloquear** e torna críticos os acertos corpo a corpo previstos no texto da condição. Não apaga todas as ações por si. `Lento` reduz deslocamento e impede Bônus. `Agarrado` e `Impedido` seguem seus próprios impedimentos.

Suas condições não passam às entidades por associação. Se você perder a Padrão, não emite o comando especial comum. Isso não significa que todas as entidades perderam suas básicas.

*Exemplo:* Kaito fica `Atordoado` e perde sua Padrão. A entidade que já guardava a porta continua cumprindo a intenção, se estiver apta. Se quem ficar `Atordoado` for ela, perde a própria básica; a outra entidade ainda pode reagir pela coletiva.

### Respostas do Guia

`Abrir Caminho` fornece uma **Abertura**, a oportunidade escrita na habilidade, a um aliado voluntário que cumpra seus requisitos. Não fornece a ação para aproveitá-la. O alcance e o PE do Guia pertencem à habilidade dele, não ao vínculo entre você e a entidade.

Depois do uso da Abertura, `Resposta Coordenada` pode convidar um aliado elegível. **Na resposta normal, Guia e aliado pagam suas Reações.** A entidade usa a coletiva. Se você for o Guia, paga sua pessoal, e ela paga a coletiva: continuam duas reservas separadas.

O **Golpe** concedido é um ataque comum. Não é básica, especial, Ação Atacar nem etapa de Sequência. Não renova básica, não traz ataques adicionais e não dispara outra ação concedida. Pode acontecer depois de uma básica ou especial, com gatilho, elegibilidade e coletiva disponíveis.

`Feitiço breve`, a outra opção do Guia, usa um Classe 0 conhecido e conserva requisitos, custos e limite geral de conjurações. Não vira Golpe nem fornece uma habilidade desconhecida à entidade.

**`Avançar`.** Seu turno conta como turno da entidade beneficiária. Nele, ela consome a Abertura e faz o trecho concedido antes ou depois de uma ação, sem básica nem coletiva. Fora dele, consome a Abertura e paga a coletiva depois de terminar uma ação ou deslocamento, salvo dispensa expressa da habilidade. O trecho não renova o Movimento próprio. Posição, trajeto, terreno, prazo, percepção e demais requisitos continuam valendo.

**`Todos no Mesmo Plano`.** No nível 30 do Guia, a segunda resposta dispensa só a Reação do Guia. Os aliados ainda pagam as suas, e precisam ser criaturas diferentes. A cadeia conserva seus tipos de Abertura distintos, prazos e limites.

*Exemplo:* um Guia aliado abre uma cadeia. A primeira entidade de Kaito responde antes do começo do turno dele e gasta a coletiva. O turno de Kaito começa e a coletiva renova. Uma segunda entidade pode pagar a segunda resposta, se a cadeia do Guia ainda for válida. Sem essa renovação entre os gatilhos, não poderia. Se Kaito for o próprio Guia, os dois ciclos começam juntos; não há aquela fronteira separada para aproveitar.

*Fora de combate:* tarefas continuam dependendo dos meios e das informações da entidade. Sob pressão de tempo, buscas e tentativas consomem a atuação correspondente. Ter mais corpos não dá tentativas infinitas nem dispensa as regras de ajuda e de testes de grupo.

## Talismã

O talismã é o **shikigami de criação**. Você manifesta a criatura que está guardada nele; o talismã continua com você.

**No descanso longo, escolha quais talismãs carregar.** Pague com o PE que ainda tem antes de o descanso devolver energia. Cada talismã guarda uma carga até ela ser usada.

**A entrada carregada custa metade da entrada normal, arredondada para cima, no mínimo 1 PE.** A carga custa a diferença: 0 PE na Classe 1; 1 nas Classes 2 e 3; 2 nas Classes 4 e 5; 3 nas Classes 6 e 7.

*Exemplo:* um talismã de nível 13 normalmente custa 4 PE para entrar. Kaito paga 2 PE que sobraram antes do descanso longo para carregá-lo. Quando usar a carga, paga os outros 2 PE pela entrada. A carga fica guardada se ele não a usar no dia seguinte.

**Cada talismã ocupa `0,5` de `Volume`, guardado ou com a entidade em campo.** `Volume` é a medida da carga; dois talismãs ocupam 1. Seu limite de carga é `5 + Força`.

*Na mesa:* quatro talismãs ocupam 2 de `Volume`. Manifestar dois shikigami não reduz essa carga: os quatro talismãs continuam com você.

## Corpo amaldiçoado

O corpo amaldiçoado não é recolhido. Isso vale para o de técnica e o de criação. Os dois podem ficar ativos ou **inativos**; a zero de vida, ficam `Desligada`, outro estado, explicado em *Queda e morte*.

### Modo inativo

**Você pode ter tantos corpos inativos quanto sua Essência ou Inteligência**, usando o mesmo atributo escolhido para a Defesa das entidades. Eles ficam além do teto de ativos.

O inativo anda e conserva Defesa, vida e a ficha inteira. Continua sendo alvo. **Falha em toda rolagem, não age e não recebe tarefa**, fora interpretação ou trabalho extremamente simples, sem rolagem. Não conta no teto de duas ativas.

*Na mesa:* um corpo inativo serve de apoio para alcançar uma prateleira. Isso não autoriza mandá-lo fazer um teste de escalada, lutar ou executar uma tarefa difícil. Com o atributo 3, Kaito pode manter três corpos inativos.

**Ativar substitui invocar.** Acontece onde o corpo está e custa a Bônus e o PE da entrada, respeitando o teto. Na troca, desative um e ative outro. O desativado pode andar o Movimento dele até um lugar seguro; isso não renova metros gastos.

No fim do combate, o ativo volta a inativo. O fim da manifestação não recupera vida nem religa um corpo caído. O inativo pode acompanhar você andando, sem precisar ser levado como carga. Se chegar a zero, fica `Desligada`; inativo não é outro nome para um corpo caído.

### Imunidades e cura

Todo corpo amaldiçoado é imune a `Envenenado`. O que não é autônomo não tem alma: é imune ao dano de `Alma` e às consequências que esse dano arrasta. O autônomo, como o Panda, tem alma.

**Corpo amaldiçoado só se cura por técnica feita para isso ou por reparo.** `Energia Reversa` e curas montadas sobre ela não o curam. O descanso longo recupera a vida; uma queda sem destruição também permite a volta paga com metade da vida.

*Exemplo:* uma cura comum alcançaria o shikigami ferido de Kaito, mas não conserta o corpo feito de peças. Se ele ainda estiver acima de zero, pode ser reparado no descanso curto.

### Reparo

**No descanso curto, quem tem `Entalhador` ou `Forja` pode reparar um corpo amaldiçoado.** Faça o teste de ofício na escada de dificuldade que acompanha o nível. Se passar, recupere metade da vida máxima do corpo, arredondando para baixo.

A dificuldade é difícil para corpo do nível de quem repara, média uma Classe abaixo e fácil duas ou mais Classes abaixo. O reparo pode ser feito pelo dono ou por outra pessoa. Há uma tentativa por corpo em cada descanso curto; se falhar, ele não recupera vida naquele descanso.

**Reparo não funciona a zero nem em `Desligada`.** A caída volta pela entrada. Para os outros tipos, o descanso curto não devolve vida.

*Exemplo:* o corpo de criação de nível 5 e Constituição 2 tem 31 de vida máxima. Está com 8. Um reparo bem-sucedido recupera metade de 31, arredondada para 15: ele fica com 23. Se estivesse a zero, o teste de reparo não o religaria.

## Trunfos da domada

**Só a maldição domada com técnica pode ter Liberação Máxima, Técnica Máxima e Expansão de Domínio.** Os outros tipos têm habilidades, mas não esses trunfos.

A domada conserva os trunfos do nível em que foi domada. A Liberação Máxima é montada com os pontos da especial e soma a Classe em d8. A Técnica Máxima usa o dano fixo da faixa.

**Trunfos da domada**
| | a domada | o jogador |
|---|---|---|
| Liberação Máxima (uma no nível 10, duas no 20, três no 30) | os pontos da especial + a Classe em d8 | 3 pontos por Classe + a Classe em d8 |
| Técnica Máxima, 17 a 20 | 19d8 | 24d8 |
| Técnica Máxima, 21 a 25 | 22d8 | 28d8 |
| Técnica Máxima, 26 a 30 | 26d8 | 32d8 |

A **Liberação Máxima** é o feitiço que rompe o limite comum de dano num alvo. A **Técnica Máxima** tem dano fixo e montagem própria. Os custos e requisitos comuns continuam valendo, com os valores da domada acima.

Na **Expansão de Domínio**, que estende a técnica sobre o ambiente, você gasta os espaços da domada. Os requisitos de nível usam o nível dela. Tudo que lê refino usa **seu refino inteiro**: o eixo de controle da energia da sua ficha. A especialização em `Ocultismo` exigida para a Expansão sem Barreiras é sua.

Quando o trunfo cobra a rodada inteira, quem paga é você, que comanda. O PE se divide entre você e a reserva como na especial. Isso não torna gratuita a atuação da entidade.

*Exemplo:* uma domada de nível 17 tem acesso à faixa de 19d8 da Técnica Máxima. Ela não passa para 22d8 quando você chega ao nível 21: continua no nível em que foi domada. Já o refino lido pelo domínio é o seu, inteiro, mesmo que tenha aumentado depois.

### Liberação Máxima

A Liberação é escrita antes da sessão, de Classe 3 ou maior, e não ocupa espaço da lista. Monte com os pontos da especial e some a Classe em d8. Não serve para cura. Aceita Melhorias e Restrições nos limites normais.

**Custa sua rodada inteira e 50% a mais de PE que a especial da Classe**, arredondado para cima. Rodada inteira gasta Movimento, Padrão e Bônus; a Reação pessoal continua separada. Ao disparar, escolha o preço do trunfo para quem o executa:

- **Vazio:** a domada não conjura no próximo turno.
- **Sangue:** ela recebe `4 × Classe` de dano irredutível.
- **Peso:** ela fica `Lento` e com desvantagem nos TR até o fim do próximo turno.

*Exemplo:* uma Liberação de Classe 3, só de dano, usa os 6 pontos da especial e soma 3d8: 9d8. O PE é `9 + 50% = 13,5`, arredondado para 14. Você paga a rodada inteira; com reserva suficiente, são 7 PE seus e 7 da domada.

### Técnica Máxima

O dano da Técnica Máxima é fixo. Nas faixas 17 a 20 e 21 a 25, há 8 pontos para Forma e Melhorias; na faixa 26 a 30, 12. Use os preços da maior Classe da entidade. Ponto que sobrar se perde, sem comprar dano. Não aceita Restrição.

**Custa sua rodada inteira e `5 × a maior Classe da domada` em PE:** 25, 30 ou 35. Depois do uso, só fica disponível de novo depois do fim do terceiro turno seguinte. Quem passa no TR reduz o dano em um quarto, não pela metade. Numa Forma sem dano, os dados viram cura ou a escala `Máxima` de `Efeito`. Uma mesa pode adotar o uso uma vez por cena no lugar da recuperação por turnos.

*Exemplo:* uma domada de nível 17 monta a Técnica Máxima com 8 pontos, mas causa os 19d8 fixos da faixa. Os pontos compram a Forma e as Melhorias, não mais dados. O custo é 25 PE, dividido em 13 seus e 12 da reserva quando houver energia suficiente.

### Expansão de Domínio

Escreva com o mestre duas frases dentro da definição da domada: o **Acerto**, o que o domínio garante que acontece, e o **Efeito**, o que ele permite fazer ali dentro. Dano garantido tem a régua de `Inescapável`: ocupa o feitiço inteiro, sem peças extras. Uma regra de ambiente precisa ser verificável e valer para todos, inclusive a entidade.

**Incompleta.** Custa 2 espaços da domada; exige nível 10 dela e seu refino 4. Não fecha barreira. O Acerto ainda resolve por rolagem.

**Completa.** Exige a incompleta, nível 14 da domada e seu refino 5. Custa mais 1 espaço, total 3. Fecha barreira e entrega o Acerto sem rolagem nem TR.

**Sem Barreiras.** Exige a completa, seu refino 10 e sua especialização em `Ocultismo`. Custa mais 2 espaços, total 5. Em cada abertura, escolha fechar a barreira, seguindo a completa, ou abrir sem ela.

Abrir custa sua rodada inteira. Com barreira ou incompleta, pague `6 × a maior Classe da domada` em PE. O Acerto acontece na abertura e no começo de cada turno da entidade, que coincide com o seu.

**Duração e tamanho.** Dura metade do seu refino em rodadas, mínimo uma. O raio é `1,5 m × seu refino`; a incompleta para em 7,5 m. Na completa, a entidade pode gastar seu deslocamento, com os pés no chão, para mover a expansão junto.

**Desconto.** Dentro da incompleta, tire um terço do seu refino do PE de cada feitiço; na completa, metade. Arredonde o benefício para baixo. O custo nunca fica menor que 1 PE.

**Barreira.** Por fora, tem `50 × metade do seu refino` de vida. Por dentro, não se quebra normalmente: se o mestre permitir alcançar a borda, ela tem o dobro da vida exterior e resistência a todos os danos. O mestre pode declarar outra quebra pela ficção.

**Sem barreira aberta.** Custa `7 × a maior Classe da domada` em PE, tem raio 200 m e centro fixo. Não prende ninguém; quem sair do raio deixa de receber o Acerto. Lá dentro, o desconto por feitiço é `maestria × 2`, com mínimo de 1 PE. Quem não tem energia só é atingido se o Acerto alcançar esse tipo de alvo. Sem casca para quebrar, ela pode acabar por tempo, corrida entre domínios, concentração ou pela entidade chegar a zero.

**Rescaldo.** Quando o domínio termina, a técnica da domada queima pelo resto da cena. Ela fica com Classe 0, corpo e o que não depender da técnica. O preço vale se a duração acabar, se ela desfizer ou se a barreira cair. `Regravação`, quando disponível pelas regras próprias, encerra o Rescaldo.

*Exemplo:* uma domada de nível 14 tem 4 espaços. Comprar a completa ocupa 3 e deixa 1 para especial. Com seu refino 6, o raio é 9 m e a duração, 3 rodadas. A Classe máxima dela é 4: abrir custa 24 PE, dividido em 12 seus e 12 da reserva se houver energia.

**Sobreposição.** Dois domínios completos sobrepostos suspendem seus Acertos garantidos enquanto disputam. O maior refino conquista e derruba o outro. Se empatar, um Acerto sem dano vence um com dano. Se continuar igual, cada lado rola 1d12: diferença de 4 ou mais dá a vitória ao maior. Sem essa diferença, começa a corrida; não se repete o desempate a cada rodada.

Na corrida, quem perder o domínio ou chegar a zero recebe o Acerto do outro imediatamente. Dano em quem sustenta exige TR de Vigor contra a CD de quem feriu. O domínio cai quando as falhas chegam a metade da Essência, arredondada para baixo, mínimo uma. Esse teste não ocupa a concentração comum e `Mão Firme` não o protege.

Contra domínio inimigo, há no máximo um desses testes por jogador que o acertou na rodada, pela maior CD entre os golpes dele. **Golpe de invocação não provoca esse teste**, embora tire vida. Quem é personagem de jogador testa a cada dano, sem esse limite.

Uma incompleta entra na disputa, mas não conquista. Ela desliga o Acerto garantido do completo e permite sair da barreira dele enquanto dura; o próprio Acerto da incompleta continua rolando. Contra expansão aberta sem barreira, a anulação só vale dentro do raio sobreposto. Fora dele, o Acerto sem barreira continua e, se causar dano, pode atingir por fora a outra barreira.

Com três ou mais domínios com barreira, todas essas barreiras caem, sem vencedor nem Acerto de conquista. Rescaldo vale para todos. Uma expansão aberta sem barreira não entra nessa contagem e continua de pé. Com duas barreiras e uma sem barreira, as duas disputam e a sem barreira pode atingir ambas por fora.

## Queda e morte

**A zero de vida, a entidade para de atuar.** Se puder recolher, sai de campo. Se não puder, fica no lugar, `Desligada`. Antes disso, confira se o dano a destruiu.

### Morte definitiva

**A entidade morre de vez se um único golpe causar sua vida máxima inteira, ou se o dano que passar do zero for maior que metade da vida máxima.** Dano em área derruba, mas nunca destrói.

O **excedente** é o dano que sobrou depois de zerar a vida atual. A metade é da vida máxima, não da vida que restava. Igualar a metade não basta para destruir por excedente: precisa passar dela.

*Exemplo:* uma entidade tem 52 de vida máxima e está com 8. Recebe um golpe de 30: chega a zero, com `30 − 8 = 22` de excedente. Como 30 não alcança 52 e 22 não passa de 26, ela só cai. Se o golpe fosse 35, o excedente seria 27: maior que 26, e ela morreria de vez. Se fosse dano em área, não seria destruída.

**A destruída não volta.** Na lista de ritual, ela sai da lista e aquela vaga se perde. Na entidade de espaço de feitiço, você pode refazer a troca na próxima subida de nível; isso não ressuscita a entidade perdida.

A morte definitiva vem antes de `Desligada`. Um corpo que não pode recolher também é destruído se o golpe cruzar o limite.

### Queda sem destruição

**Cair não é trocar.** A básica ainda não gasta não passa para outra entidade. Ninguém entra automaticamente e não há primeira intenção gratuita.

A queda encerra ordem antecipada e preparação, sem devolver Padrão, básica ou custo já pago. Ela não gasta a coletiva por si; outra entidade apta ainda pode usá-la. Uma especial que não começou não paga ativação ainda não cobrada.

Isso também vale se um dano persistente levar uma entidade recolhida a zero. Ela continua fora de campo, agora caída. Recolher não a protege desse dano.

*Na mesa:* a entidade de Kaito cai enquanto tem uma especial preparada. A preparação se perde, com Padrão e básica já gastas. A outra entidade não recebe aquela básica, mas conserva acesso à coletiva se ela ainda estiver disponível.

### Volta

**Para trazer de volta quem só caiu, pague o dobro do PE da entrada e a Bônus, no seu turno.** Ela volta com metade da vida máxima. A entrada continua respeitando o teto, a posição e as regras de recursos; voltar não cria básica.

A vida cheia volta no descanso longo. Cura não alcança entidade a zero, esteja recolhida ou no chão. Uma entidade de pé pode receber cura que alcance outra pessoa, com a exceção do corpo amaldiçoado.

*Exemplo:* a entidade de nível 10 e vida máxima 52 caiu sem ser destruída. A entrada normal custaria 3 PE; a volta custa 6 PE e a Bônus. Ela retorna com 26 de vida. Se Kaito apenas a tivesse recolhido com 8 de vida, a entrada normal de 3 PE a traria com os mesmos 8.

### Desligada

**`Desligada`** — a entidade caída que não pode ser recolhida vira um objeto no campo. Isso acontece com corpos amaldiçoados e com maldições domadas sem técnica do invocador que permita recolhê-las.

Ela ocupa o lugar e atrapalha a passagem como um corpo caído. Pode ser carregada. Não age, não recebe ordens, não usa a coletiva e não projeta aura ou passivas. **Não conta no teto de entidades ativas.**

O dano que receber soma ao excedente da queda. Se o total passar de metade da vida máxima, ela é destruída. Dano em área continua sem destruir. Efeitos já aplicados continuam: dano periódico soma, duração passa, e áreas que exigem presença a alcançam porque ela continua ali. Cura periódica não funciona a zero.

**Religar é a volta da caída:** dobro do PE da entrada e Bônus, no seu turno, com metade da vida, no lugar onde o corpo está e respeitando o teto. A cura não religa.

*Exemplo:* um corpo de vida máxima 52 caiu com excedente 22. Outro dano direto de 5 eleva a soma a 27, maior que 26, e o destrói. Se for religado antes disso, a volta põe metade da vida. Com duas entidades já ativas, você precisa respeitar o teto para ativá-lo.

## Efeitos fora de campo

**Recolher não limpa condição nem reinicia duração.** Benefícios e penalidades com prazo continuam contando. Uma condição sem prazo espera seu critério de término.

Efeitos já aplicados que não dependam de presença continuam suas ocorrências: dano, benefícios e testes de recuperação. Use o começo e o fim do seu turno, sem criar ocorrências extras por sair ou voltar. Resolver esses efeitos não exige básica, Movimento ou coletiva só por resolvê-los; custos expressos continuam valendo.

Condições `Pesada` mantêm seus TR pertinentes no fim do turno. `Envenenado` não causa dano periódico só por ter esse nome.

**Uma entidade recolhida não ocupa posição no campo, nem a sua posição.** Não recebe efeito que exija estar numa área ou junto de uma fonte. Não projeta aura que dependa de presença. Um efeito já aplicado com duração independente continua, e uma área independente de quem a criou não desaparece só por recolhê-la.

Na volta, confira os requisitos no lugar onde ela entrou. A duração não recomeça, os usos não renovam e não há ativação gratuita. Gatilhos de entrada e saída só existem quando a capacidade os escrever.

*Exemplo:* a entidade tem um efeito de dano que continua por turnos, sem depender de estar perto do inimigo. Kaito a recolhe, mas resolve o dano nos momentos devidos. A aura que ela projetava no campo para de alcançar os outros. Uma área independente que já criou pode continuar, conforme seu texto.

## Invocador inconsciente

**Você apagar não derruba a sustentação das entidades.** As que estão em campo e funcionais continuam a básica, o Movimento e as respostas autorizadas, com a intenção recebida. Suas ações não usadas não passam para elas.

Zero de vida não significa automaticamente que você apagou: confira `Insistir` e `Aguentar` nas regras de queda. Enquanto você estiver de pé em `Insistir`, age conforme aquelas regras. Em `Aguentar`, ou depois que `Insistir` desaba, as entidades continuam. Quando você levanta, não precisa refazer as ordens que continuaram válidas.

**Inconsciente, você não entra com entidades, recolhe, comanda, ajusta, cancela ou dá orientação nova.** Uma especial ordenada antes continua podendo ser executada se houver requisitos e sustentação. Ela pode gastar seu PE para cumprir aquela ordem, com a divisão normal se houver reserva. Isso não dá acesso livre à sua energia para escolher novas especiais.

Depois da especial, a entidade conserva a intenção anterior, porque você não pode dar outra. Se faltar energia ou outro requisito, a antecipada continua esperando.

*Na mesa:* Kaito apaga depois de antecipar uma especial. Quando o alvo fica ao alcance, a entidade pode executar com a básica, a coletiva se estiver fora do turno e o PE devido. Kaito não pode cancelar ali nem aproveitar o resultado para trocar a tarefa dela.

### Manutenção

**Um efeito com manutenção que possa ser desligado acaba quando você apaga.** A entidade continua atuando.

Uma passiva que não possa ser desligada continua, e paga a manutenção primeiro da reserva da entidade. Sem reserva, ou depois que ela acabar, paga do seu PE. Diferente da especial, essa manutenção não divide o custo pela metade.

O texto da passiva diz se ela pode ser desligada. O caso em que ela não pode e as duas fontes de energia acabam ainda não tem desfecho definido.

*Exemplo:* uma domada mantém uma passiva que não pode desligar. Enquanto tiver reserva, paga dela. Quando a reserva acaba, passa a pagar do PE de Kaito, mesmo que ele continue inconsciente.

## Morte do invocador

**Quando você morre, as entidades saem de campo imediatamente.** Quem não pode recolher fica no lugar, `Desligada`. Preparações e antecipadas acabam sem execução nem devolução. A morte não transfere básica nem coloca outra entidade no lugar.

O gatilho é a morte, pelo estágio 4 de dano de alma ou pela narrativa. Enquanto a janela de `Aguentar` continua aberta, vale a regra do invocador inconsciente.

Depois da saída, cada origem tem seu destino:

- **Técnica:** a entidade desaparece com o dono. O corpo amaldiçoado de técnica autônomo, que tem alma, fica sob controle do mestre.
- **Criação:** fica no mundo como objeto. O talismã conserva a carga que tinha; o corpo fica parado.
- **Maldição domada:** fica livre, volta a ser maldição e passa ao mestre. Outro invocador pode domá-la.

É o mestre da mesa em que a morte aconteceu. O invocador morto não traz ninguém de volta. Herdar talismã ou corpo criado pertence às regras de criação.

*Na mesa:* Kaito morre com um talismã carregado e uma maldição domada. O talismã fica com a carga. A maldição fica livre. Nenhum dos dois continua recebendo ordens do personagem morto.

## Carga e equipamento

**A entidade só carrega o que cabe nas mãos que a definição dá.** Sem mãos, não carrega nada por essa regra. Vestir um equipamento compatível com o corpo é outra coisa.

Para carregar mais, precisa de uma característica própria que caiba na definição: armazenamento como o de um personagem ou capacidade de carregar personagens, como o Nue. Essa característica ocupa uma das passivas da entidade.

O armazenamento usa `5 + Força` de `Volume`, com a Força dela. Quantas pessoas uma característica transporta e o que isso custa de Movimento precisam estar escritos na montagem; a regra não dá uma quantidade automática.

*Exemplo:* uma entidade de Força 3 com a passiva de armazenamento tem `5 + 3 = 8` de `Volume`. Sem essa característica, a Força 3 não lhe dá uma mochila inteira de carga: ela fica no que as mãos comportam.

### Saída com equipamento

**O que a entidade veste vai junto quando ela sai de campo; ela volta vestida.** Do que segura, vai junto o equipamento dela: a arma com que luta, seu foco ou ferramenta. O que segura para outra pessoa ou pegou pelo caminho cai onde ela estava.

Isso vale para recolhimento, queda e fim da manifestação dos tipos que recolhem. O corpo amaldiçoado e a `Desligada` ficam no campo com tudo. Uma entidade que deixa de existir, por morte definitiva ou porque a técnica acabou com a morte do dono, larga tudo no lugar.

*Exemplo:* a entidade veste `Revestimento`, segura a arma dela e leva um objeto que pegou para Kaito. Ao recolher, o `Revestimento` e a arma vão junto. O objeto de Kaito cai onde ela estava. Para usar um equipamento que viajou com ela, ele precisa tirá-lo da entidade em campo.

---


# Capítulo 18 · Pactos

*fonte: `manual/65-pactos.md`*

Pacto é uma troca. Você abre mão de alguma coisa e ganha outra, e quem cobra é a sua própria energia amaldiçoada — não existe juiz, não existe rolagem, e não existe desfazer.

> **Pacto é opcional.** A ficha nasce sem nenhum.

## Formas de pacto

**Formas de pacto**
| Forma | Quando se fecha | Teto |
|---|---|---|
| **permanente** | fora de cena, com o mestre lendo | metade da Essência |
| **temporário** | Ação Bônus, no seu turno | não tem |
| **`Promessa`** | entre duas partes, as duas aceitando | não tem |
| **de restrição** | na criação, junto da Origem ou da técnica | não se aplica |

> **Nenhuma forma de pacto se fecha sob ameaça.** Todo mundo envolvido aceita por vontade própria, ou não houve pacto — nem a metade que cobra, nem a que paga.

### Câmbio

O câmbio resolve o tamanho de qualquer pacto, e vale para as quatro formas:

> **Promessa pequena, ganho pequeno. Promessa que arrisca a vida, ganho enorme.**

É por ele que o mestre aprova ou recusa: um pacto que pede muito e oferece pouco não fecha.

## Pacto permanente

O efeito de um pacto permanente fica ligado enquanto o personagem existir.

> **Você fecha, na campanha inteira, um número de pactos permanentes igual a metade da sua Essência, arredondando para baixo.**
>
> **Sem piso.** Essência 0 e Essência 1 não fecham nenhum.

**Pactos permanentes por Essência**
| Essência | 0 | 1 | 2 | 3 | 4 | 5 | 6 |
|---|---|---|---|---|---|---|---|
| **Pactos** | 0 | 0 | 1 | 1 | 2 | 2 | 3 |

Esta é a única linha de Pactos que entra na ficha.

> **Esta é a exceção à regra de arredondamento.** Em todo o resto do sistema, o que você ganha nunca fica abaixo de 1. Aqui fica: quem não investiu em Essência não tem pacto permanente nenhum.
### Características de um pacto permanente

Você escreve duas coisas, e o mestre lê as duas antes de aprovar: **o que você entrega** e **o que você recebe**.

O que você entrega é da ficção, e o mestre cobra pelo câmbio. O que você recebe sai da tabela `O que um pacto permanente concede`.

**O que um pacto permanente concede**
| Concede | Quem alcança |
|---|---|
| pontos de energia | qualquer ficha |
| uma aptidão | quem tem aptidão — capítulo 12, *Aptidões e Refino* |
| um espaço de feitiço | quem escreve Fundamento — capítulo 9, *Fundamento* |
| um estilo | só a sub-origem Sem Técnica, no capítulo 7, *Origens e Legados* |

### Limites

> **Pacto não mexe em número de rolagem.** Nem no seu acerto, nem na sua Defesa, nem em perícia nenhuma. Um pacto que promete qualquer um dos três está fora.

E se você pedir dano, o mestre te dá pouco. Pacto compra acesso, permissão, e coisa que o resto da ficha não consegue fazer.

## Pacto temporário

> **Como Ação Bônus ou Reação, no seu turno, você fecha um pacto na hora.** Diga o que perde e o que ganha; o mestre aprova ou recusa na mesma frase.
>
> **A perda é física ou energética, e ela tem de ter valor para você.**

O ganho morre na cena. A perda, não. Um braço que você entregou no meio da luta não volta porque a luta acabou.

## Promessa

`Promessa` é o pacto entre duas partes. As duas precisam saber o que está sendo combinado e aceitar.

As duas partes não precisam ser dois personagens de jogador, nem dois feiticeiros. Uma delas pode ser a Guilda.

> **Invocação não fecha `Promessa`** — ela não é uma segunda vontade, e a ficha dela sai da sua. *As regras de invocação estão no capítulo 17, Invocações.* **Uma invocação senciente fecha**, e aí ela é uma das duas partes como qualquer outra.

### Termos de uma Promessa

**Termos de uma Promessa**
| Termo | O que é |
|---|---|
| o que eu dou | a sua metade |
| o que eu recebo | a metade do outro |
| a cláusula | o que você acrescenta para proteger o que não quer perder |

### Quebrar uma Promessa

> **Quebrar custa a sua energia amaldiçoada, e pode custar a sua vida.** Quanto exatamente é o mestre, ou o contrato, quem diz.

Isso vale para quem quebra — ninguém precisa descobrir, ninguém precisa cobrar.

## Pacto de restrição

Ele escreve o preço de uma coisa que a sua ficha já tem: a Origem que já custou, o corpo que já veio limitado, o Legado que você já escolheu.

Ninguém é obrigado a ter um. Quem escreve um está dando forma de regra a uma limitação que até então era só narrativa.

> **Um pacto de restrição não compra poder.** A limitação que devolve pontos é a `Restrição` de feitiço, no capítulo 9, *Fundamento*.

A tabela `Ideias de restrição` mostra o que um preço pesado parece, e serve também para quem vai propor um pacto temporário ou uma `Promessa`.

## Catálogo

### Pactos da obra

**Pactos da obra**
| Pacto | Forma | O que foi trocado |
|---|---|---|
| Overtime | permanente | energia reduzida no horário de trabalho, em troca de energia acima do normal na hora extra |
| Mostrar a mão | temporário | explicar a própria técnica ao adversário, em troca de a técnica ficar mais forte |
| O braço | temporário | a energia que protegia um braço jogada para o resto do corpo — e o braço se perdeu |
| O domínio | permanente | uma promessa que arrisca tudo, em troca de alguns minutos sem poder morrer |
| Cura por informação | `Promessa` | um cura o corpo do outro; o outro entrega informação — com a cláusula de não encostar em ninguém de uma escola inteira |
| Volta à vida | `Promessa` | trazer alguém de volta, em troca de um minuto de uso pleno do corpo, cobrado quando o outro lado quiser |
| O carrasco | `Promessa` | jurar executar alguém, em troca do posto — e a segunda parte é a instituição, não uma pessoa |
| Existência garantida | `Promessa` | parar de viver e não ferir ninguém, em troca de a própria existência ficar garantida — e ela atravessa mil anos |

### Ideias de restrição

**Ideias de restrição**
| Ideia | O que ela faz |
|---|---|
| `Fragmentação` | a sua Integridade deixa de ser uma barra só e vira **cinco**, cada uma com um quinto do total. Todo dano na alma cai numa delas, e **quem está causando escolhe qual**. As penalidades continuam funcionando para cada barra individualmente |
| `Liberação irregular` | a sua energia não sai no ritmo que você manda. **No começo de cada turno seu, role o teto de PE daquele turno** — é só isso que você gasta nele, com o poço cheio ou não |
| `50/50` | a sua energia pisca. **Ela alterna: ligada num turno, desligada no seguinte**, e você sabe em qual está. No turno desligado você não consegue usá-la, **e todo dano que te acerta vem dobrado** |
| `Pacifismo impraticável` | o seu corpo exige que você mate um ser vivo a cada X dias, mas você tem um voto que proíbe você de fazer isso. Você tem de procurar sempre um jeito de gerar mortes de forma acidental ou indireta; senão, você morre |
| `Direcional` | você só anda em linha reta, e só para no fim. **Escolha uma direção no começo da Ação de Movimento e vá até gastar todo o seu movimento ou bater em alguma coisa** — sem diagonal, sem curva, sem parar no meio |
| `Magnetismo energético` | energia amaldiçoada em movimento é puxada para você. **Ataque que viaja em linha até outro alvo muda de rota e vem em você** — projétil, feixe, o que atravessa o espaço. Área e toque não, porque não viajam |
| `Aquecendo` | o seu corpo demora a acordar. **Você entra em toda luta com a vida máxima em `1`, e ela sobe a cada turno seu até a sua vida máxima de sempre — e para ali.** Ela nunca passa dela |
| `Catatau` *(Boo.zip names)* | a sua vida e a sua energia são a mesma coisa, e a conversão é `1` para `1`: **cada `1` de dano que você leva tira `1` de PE, e cada `1` de PE que você gasta tira `1` de vida.** Conjurar te machuca, e apanhar te desarma |

Essas penalidades foram escritas com base nas ideias do canada.zip, um amigo meu. Usem como ideia para as suas restrições de nascença, envolvendo tanto o corpo quanto a técnica. A ideia dos pactos nunca é trazer valor numérico, e sim mecânica única para a sua ficha ou para a situação, sempre decidida com o mestre. Todos os casos de pacto acima podem conceder um benefício à parte, tão único quanto a penalidade — mas a fala do mestre é final sobre o quanto esses pactos concedem, contanto que nunca seja numérico.

## Pactos na criação

Pacto permanente, temporário e `Promessa` nascem em jogo, e nenhum dos três entra na criação de personagem, no capítulo 6, *Criação de Personagem*.

O pacto de restrição é o único que a criação alcança, e ele se escreve junto da Origem ou da técnica. Com permissão do mestre, você pode ter um pacto de restrição sem ter a Essência mínima para o primeiro pacto — mas essa decisão é inteira do mestre, e é recomendada só nos casos em que o narrativo do pacto agrega mais que o mecânico.

Quem quiser começar com uma troca já feita tem duas portas que não são Pactos: a `Regra Própria` da sua técnica, no capítulo 9, *Fundamento*, e o Legado da sua Origem, no capítulo 7, *Origens e Legados*.

---


# Capítulo 19 · Experiência e Progressão

*fonte: `manual/80-experiencia-e-progressao.md`*

Você sobe de nível gastando XP, e o XP vem de missões e mesas.

> **Cada nível custa um número inteiro de missões: duas no nível 2, três nos dois seguintes, e daí duas a mais a cada três níveis, até parar em dezessete.**
>
> **Uma missão padrão paga 100 XP, e paga o mesmo para todo mundo na mesa.**
>
> **Nenhuma missão faz você subir mais de um nível. O que sobra fica acumulado.**
>
> **Na sua semana, as duas primeiras missões pagam cheio. Da terceira em diante o valor cai pela metade a cada uma.**
>
> **Do nível 20 para o 21, além do XP é preciso um feito.** *Normalmente isso também sobe o seu Grau.*

O XP não muda com o seu nível nem com o Grau de quem está na mesa. Um nível 8 e um nível 14 na mesma missão levam os mesmos 100, e quem está atrás sobe mais rápido sozinho, porque cada nível custa mais que o anterior.

Grau é reconhecimento; nível é poder. O Grau abre porta, dá acesso e pesa em conversa, e não paga XP.

> **Uma ficha nova começa no nível 2.** O nível 1 é opção de campanha, para a mesa que quiser jogar o personagem antes de ele ser feiticeiro.

## Curva de XP

**Curva de XP**
| você está no nível | o próximo nível custa | em XP |
|---|---|---|
| **2** | 2 missões | 200 |
| **3 a 4** | 3 missões | 300 |
| **5 a 7** | 5 | 500 |
| **8 a 10** | 7 | 700 |
| **11 a 13** | 9 | 900 |
| **14 a 16** | 11 | 1.100 |
| **17 a 19** | 13 | 1.300 |
| **20 a 22** | 15 | 1.500 |
| **23 a 29** | 17 | 1.700 |

Chegar ao nível 20 custa **14.300 XP** no total, que são 143 missões padrão. Do 20 ao 30 são **16.400**, ou mais 164 missões.

O nível 2 é a única linha que foge da conta: ele custa duas missões e não três, para a sua primeira ficha mudar de forma na segunda mesa em vez da terceira.

## Tamanho da missão

**Tamanho da missão**
| tamanho | paga | o que é |
|---|---|---|
| **curta** | 50 | uma cena, um interrogatório, roleplay puro, uma escolta sem incidente |
| **padrão** | 100 | a missão de uma sessão: sai, resolve, volta |
| **longa** | 200 | duas ou mais sessões, ou uma sessão que virou noite |
| **final de arco** | 300 | o fecho de uma linha de missões, ou o que a mesa vai lembrar por meses |

> **Quem declara o tamanho é quem posta a missão, e declara antes de ela acontecer.**

Missão de roleplay que qualquer Grau pode entrar é missão curta, e ela paga — mas toda missão pode variar por mais do que o tempo: importância e periculosidade também mexem nesses valores. Um final de arco pode ser uma mesa só de roleplay, por exemplo.

## Ritmo de subida

> **Você sobe no máximo um nível por missão. O XP que sobrar fica acumulado e sai na próxima.**

**Ritmo de subida**
| no nível | curta | padrão | longa | final de arco |
|---|---|---|---|---|
| **2** | +50 | +100 | **1 nível** | 1 nível, +100 |
| **3 e 4** | +50 | +100 | +200 | **1 nível** |
| **5 e acima** | +50 | +100 | +200 | +300 |

Quem levou um final de arco no nível 2 sobe um nível na hora e entra na missão seguinte com 100 XP no bolso, que é um terço do nível seguinte. O acumulado nunca some: ele sai na próxima missão.

Com os valores desta tabela nenhuma missão chega a dar dois níveis, então o teto não morde em lugar nenhum. Ele existe para o servidor que decidir pagar mais do que 300 numa mesa de fecho de temporada.

## Desconto da semana

**Desconto da semana**
| missão da semana | paga |
|---|---|
| **1ª e 2ª** | 100% |
| **3ª** | 50% |
| **4ª** | 25% |
| **5ª** | 12% |
| **6ª** | 6% |

A contagem zera na virada da semana, e ninguém sai com zero: a sexta missão ainda paga.

**O desconto é individual.** Numa missão com quatro pessoas, uma pode estar na primeira missão da semana dela e outra na quarta. Cada um aplica o seu.

## Tempo de campanha

A duas mesas por semana o nível 20 chega perto de um ano e três meses, e o 30 perto dos dois anos.

**Tempo de campanha**
| você joga | chega ao nível 20 em | e ao 30 em |
|---|---|---|
| 1 mesa a cada 15 dias | 62 meses | 94 |
| 1 por semana | 31 | 47 |
| **2 por semana** | **15,5** | **23,4** |
| 3 por semana | 12,4 | 18,7 |
| 4 por semana | 11,3 | 17,0 |

A tabela `Tempo de campanha` supõe que do nível 20 em diante a mesa roda missão longa e final de arco. **É por isso que a faixa lendária custa mais missões que a mundana e mesmo assim leva metade do tempo** — se o seu servidor continuar rodando missão padrão lá em cima, o topo demora mais que a base inteira.

Jogar quatro vezes por semana em vez de duas não corta o tempo pela metade: corta em 4,2 meses. O desconto da semana é o que faz isso.

## Acelerar o ritmo do seu servidor

A tabela `Tempo de campanha` é o piso. **Se o seu servidor quiser um ritmo mais rápido, acelere com evento em vez de mexer na curva** — nível não desce, então dar a mais é fácil e tirar depois não é.

O mecanismo mais direto é a **mesa de dobro**: uma missão declarada antes como valendo o dobro do tamanho dela.

**Mesa de dobro por mês**
| mesas de dobro por mês | nível 20 a 2/sem | nível 30 |
|---|---|---|
| nenhuma | 15,5 meses | 23,4 |
| **uma** | **13,9** | **21,0** |
| duas | 12,6 | 19,0 |
| três | 11,5 | 17,4 |

**O recomendado é uma por mês.** Ela acrescenta 12% de XP e tira um mês e meio do caminho até o nível 20.

Outros dois mecanismos que valem a pena, e nenhum deles é regra:

> **Quem ficou fora recebe o dobro até alcançar.** Vale para quem está três níveis ou mais atrás do resto. Isso não acelera ninguém que esteja em dia — ele fecha a distância, e a tabela `Alcance` mede quanto.
>
> **Agir na motivação do personagem paga 10% a mais na missão**, com aprovação da mesa. Aplicado em metade das missões, rende 5% de XP no mês.

**A mesa de dobro não alcança quem joga pouco.** Ela paga na proporção do que a pessoa já joga, e não dá para dobrar uma mesa que não foi jogada: quem joga a cada quinze dias só joga duas mesas por mês, então o terceiro dobro não muda quase nada para ele. Para essa pessoa o mecanismo que funciona é o segundo.

## Distância entre quem joga muito e quem joga pouco

Duas pessoas no mesmo servidor, uma jogando uma vez por semana e a outra duas, se separam. **A distância entre elas chega a treze níveis por volta do vigésimo terceiro mês**, e ela abre principalmente porque quem passou do nível 20 começa a rodar missão grande enquanto o outro ainda roda missão padrão.

> **Não existe regra de compensação, e a ausência dela é decisão.** Quanto se paga a quem joga menos é economia de cada servidor, e dois servidores podem responder isso diferente e os dois estarem certos.

O que dá para dizer é o tamanho da coisa, e quanto custa cada remédio. **Se o seu servidor quiser fechar essa distância, o desenho usual é pagar `X` vezes o XP para quem estiver `Y` níveis atrás do resto** — e o que decide o resultado é o `X`, não o `Y`.

**Alcance — exemplos, e não regra**
| quem está 3 níveis atrás recebe | a distância para de crescer em |
|---|---|
| nada | 13 níveis |
| 1,5 vez o XP | 9 |
| **2 vezes** | **6** |
| 2,5 vezes | 4 |
| 3 vezes | 4 |

**Dobrar o XP não zera a distância, e passar de 2,5 vezes não compra mais nada** — daí para cima o que limita deixa de ser o XP e passa a ser o teto do nível 30. É a faixa lendária acelerando quem já chegou nela: para alcançar alguém que ganha 240 por missão, quem ganha 106 precisa de mais que o dobro.

O recomendado é `2 vezes`, que corta a distância de treze para seis sem transformar a regra em elevador. Um servidor que prefira não mexer no XP de ninguém tem outras saídas, e nenhuma delas é mecânica: mesa por faixa de nível, personagem secundário para quem já está no topo, e missão curta de roleplay, que qualquer Grau pode jogar.

## Falhar

> **Missão falhada paga metade ou nada, e quem decide é o mestre.**

Uma missão perdida por azar de dado pesa diferente de uma abandonada na metade, e é essa diferença que o mestre está lendo quando escolhe entre as duas.

## XP de quem mestra

> **Mestrar paga numa moeda diferente, com base no servidor onde ele foi estabelecido.** Algumas guildas concedem XP por missão mestrada, mas não aconselhamos isso. O recomendado é uma "moeda" recebida no fim da missão mestrada, trocável por vários recursos dentro do próprio servidor.

Um mestre ativo constrói patente e rede, e as duas podem abrir portas que nível nenhum abre.

> **Exemplo: a cada `X` mesas mestradas você recebe uma mensalidade extra do seu Grau.** A marca fecha sozinha no `X` e paga na patente que você tinha naquele dia.

Não daria para segurar mesa e fechar a marca depois de subir de patente: o `X` fecha sozinho. Quem mestra `Y` vezes por mês chega a uma marca a cada `X` meses, e quem mestra uma vez por mês leva o tempo maior. É um bônus em cima da folha, e nunca um segundo salário.

## Salário

> **Feiticeiro recebe salário mensal da instituição, e o valor sai da patente.** Ele depende da sua patente e das missões de que você participou.

**Salário por patente**
| patente | por mês | por ano |
|---|---|---|
| Grau 4 | ¥150.000 | ¥1,8 milhão |
| Grau 3 | ¥300.000 | ¥3,6 milhões |
| Grau 2 | ¥600.000 | ¥7,2 milhões |
| Grau 1 | ¥1.200.000 | ¥14,4 milhões |
| Especial | ¥2.400.000 | ¥28,8 milhões |

Um Grau 4 ganha pouco menos que um recém-formado de empresa, e mora onde a escola manda. Um Grau 1 ganha o que ganha um executivo. Um especial ganha o que ganha um ministro.

O dinheiro compra equipamento, e os `Preços` estão no capítulo 15, *Equipamento*. Ele não compra nível, não compra marco e não compra aptidão.

> **Salário mínimo.** Se um feiticeiro não participar de missões, o salário que ele recebe é `1/4` do padrão do Grau dele. Cada missão jogada preenche esse requisito: para receber o salário completo, é preciso participar de pelo menos `X` missões ou mesas no mês, e cada uma completa uma fatia do salário depois do mínimo. Missão longa vale por **2**, e final de arco vale por **3**. Missão pode conceder dinheiro extra, mas isso é decisão de cada servidor.

Quanto vale o `X`, e se o salário existe, é decisão de cada servidor — um deles pode escolher não pagar em dinheiro nenhum, e trocar a folha por acesso, ferramenta ou favor. O recomendado é `3` missões: com ele, quem joga uma vez por semana recebe cheio e quem some por um mês inteiro ainda recebe o mínimo.

## Limiar do nível 20

> **Você chega ao nível 20 por XP. Você passa dele por feito.**

Aos 12.500 de XP acumulado o personagem para no nível 20 até a mesa reconhecer alguma coisa que ele fez. O XP continua acumulando e nada se perde: quando o feito acontece, o que estava guardado destrava de uma vez, concedendo nível após nível pela métrica de sempre.

**A lista é fechada.** O mestre ou o servidor da mesa tem a palavra final sobre se um feito aconteceu — e não sobre quais são.

**Feitos do limiar — exemplos**
| | o feito |
|---|---|
| **1** | derrubar um chefe de nível acima do seu |
| **2** | sair de pé de uma Expansão de Domínio completa |
| **3** | fechar uma missão de final de arco |
| **4** | pôr de pé alguém que estava a 0 de vida |
| **5** | voltar do estágio 4 de dano de alma |
| **6** | cumprir uma `Promessa` até o fim, pagando a sua metade |
| **7** | trazer para a Guilda uma ferramenta de grau 1 ou especial |
| **8** | terminar a missão depois de outro personagem jogador chegar ao estágio 4 |

Um feito basta, e ele destranca uma vez só. Toda entrada da tabela `Feitos do limiar` cita uma coisa que fica escrita na ficha ou no registro da missão depois que a mesa acabou — é isso que faz sete mestres diferentes lerem a lista do mesmo jeito. Esses feitos podem acontecer antes do limiar, contanto que tenha sido entre os níveis **15 e 20**.

A tabela `Feitos do limiar` traz exemplos, e não regra.

## Operação na mesa

1. **O mestre posta a missão e declara o tamanho:** curta, padrão, longa ou final de arco.
2. **A mesa acontece.**
3. **No fim, o mestre paga o valor declarado:** cheio no sucesso, metade ou nada na falha.
4. **O jogador anota na ficha** e aplica o desconto da semana, se já for a terceira missão dele.
5. **Chegou ao XP do próximo nível, sobe.** No máximo um nível, e o resto fica acumulado.

Não precisa de aprovação de ninguém, exceto no limiar do 20. E uma linha de missões paga a cada missão: quem entra no meio de uma linha recebe pelo que jogou.

## Progressão por nível

Ache a sua linha e leia ela inteira.

**Progressão por nível**
| nível | XP | maestria | espaços de feitiço | refino | Classe | Passiva | Classe 0 | o que este nível entrega |
|---|---|---|---|---|---|---|---|---|
| **1** | — | 1 | **2** | 1 | 1 | 1 | 2 | **Fundamento**, Passiva Livre, dois feitiços de Classe 0 |
| **2** | 200 | 1 | **3** | 1 | 1 | 1 | 2 | degrau de **Caminho** · entrega de **Trilha** · +1 espaço de feitiço |
| 3 | 300 | 1 | **3** | 1 | 1 | 1 | 2 | — |
| 4 | 300 | 1 | **4** | 1 | 1 | 1 | 2 | +1 espaço de feitiço |
| **5** | 500 | 1 | **4** | 1 | 2 | 1 | 3 | Classe 2 · mais um Classe 0 |
| **6** | 500 | 1 | **6** | 2 | 2 | 1 | 3 | **marco** · +2 espaços de feitiço |
| **7** | 500 | 1 | **6** | 2 | 2 | 2 | 3 | degrau de **Caminho** · libera Passiva de Classe 2 |
| 8 | 700 | 1 | **7** | 2 | 2 | 2 | 3 | +1 espaço de feitiço |
| **9** | 700 | 1 | **7** | 2 | 3 | 2 | 3 | Classe 3 |
| **10** | 700 | 2 | **9** | 3 | 3 | 2 | 3 | **marco** · **1ª Liberação Máxima** · +2 espaços de feitiço |
| **11** | 900 | 2 | **9** | 3 | 3 | 2 | 4 | entrega de **Trilha** · mais um Classe 0 |
| 12 | 900 | 2 | **10** | 3 | 3 | 2 | 4 | +1 espaço de feitiço |
| **13** | 900 | 2 | **10** | 3 | 4 | 3 | 4 | Classe 4 · libera Passiva de Classe 3 |
| **14** | 1.100 | 2 | **12** | 4 | 4 | 3 | 4 | **marco** · +2 espaços de feitiço |
| **15** | 1.100 | 2 | **12** | 4 | 4 | 3 | 4 | degrau de **Caminho** |
| 16 | 1.100 | 2 | **13** | 4 | 4 | 3 | 4 | +1 espaço de feitiço |
| **17** | 1.300 | 2 | **13** | 4 | 5 | 3 | 5 | Classe 5 · **Técnica Máxima** · mais um Classe 0 |
| **18** | 1.300 | 3 | **15** | 5 | 5 | 3 | 5 | **marco** · +2 espaços de feitiço |
| **19** | 1.300 | 3 | **15** | 5 | 5 | 3 | 5 | entrega de **Trilha** |
| **20** | 1.500 | 3 | **16** | 5 | 5 | 3 | 5 | **2ª Liberação Máxima** · +1 espaço de feitiço |
| **21** | 1.500 | 3 | **16** | 5 | 6 | 3 | 5 | Classe 6 |
| **22** | 1.500 | 3 | **18** | 6 | 6 | 3 | 5 | **marco** · +2 espaços de feitiço |
| **23** | 1.700 | 3 | **18** | 6 | 6 | 3 | 5 | degrau de **Caminho** |
| 24 | 1.700 | 3 | **19** | 6 | 6 | 3 | 5 | +1 espaço de feitiço |
| 25 | 1.700 | 3 | **19** | 6 | 6 | 3 | 5 | — |
| **26** | 1.700 | 4 | **21** | 7 | 7 | 3 | 5 | **marco** · Classe 7 · +2 espaços de feitiço |
| **27** | 1.700 | 4 | **21** | 7 | 7 | 3 | 5 | entrega de **Trilha** |
| 28 | 1.700 | 4 | **22** | 7 | 7 | 3 | 5 | +1 espaço de feitiço |
| 29 | 1.700 | 4 | **22** | 7 | 7 | 3 | 5 | — |
| **30** | — | 4 | **24** | 8 | 7 | 3 | 5 | **marco** · degrau de **Caminho** · **3ª Liberação Máxima** · +2 espaços de feitiço |

Nível em negrito é nível que entrega decisão nova: uma Classe, um marco, um degrau de Caminho, uma entrega de Trilha. Os espaços de feitiço correm no ritmo próprio deles e por isso aparecem também em linha sem negrito. Nos níveis que ficaram de fora, o personagem cresce só em número.

### Colunas de progressão

- **XP** é o que custa **sair** daquele nível, e ele é o mesmo dentro de cada faixa de dois níveis. Uma missão padrão paga 100. O nível 30 é o topo e não tem custo.
- **maestria** é o bônus que entra no seu ataque de conjuração, na CD dos seus feitiços e nas perícias em que você é treinado.
- **espaços de feitiço** é o tamanho da sua lista de feitiços conhecidos, e é a coluna que responde "quantos feitiços eu tenho agora?". Passiva é paga com espaço, e a Expansão de Domínio também. Liberação Máxima não ocupa.
- **refino** aqui é só a linha de graça, o que todo mundo tem sem escolher nada. Quem escolhe Refino no marco tem mais que isso, e o teto é 10.
- **Classe** é a maior Classe de feitiço que você consegue montar.
- **Passiva** é a maior Classe de Passiva que já abriu para você.
- **Classe 0** é quantos feitiços grátis você carrega, e eles ficam fora da conta de espaços.

### Feitiços por nível

> **Espaços de feitiço conhecido = `2 + (nível ÷ 2)`, arredondando para baixo. Mais um por marco já alcançado.**

A parte de baixo da conta dá um feitiço novo **a cada nível par**. A parte de cima é o espaço que cada **marco** solta de graça, então nos níveis 6, 10, 14, 18, 22, 26 e 30 entram dois de uma vez.

Passiva custa espaço de feitiço conhecido, e a Expansão de Domínio também: as três saem desta mesma coluna.

### Vida e PE

As duas dependem do seu Caminho, e cabem em duas linhas:

> **Vida:** no nível 1, a vida inicial do seu Caminho mais a sua Constituição. Em cada nível depois, a vida por nível do seu Caminho mais a Constituição de novo.
>
> **PE:** o PE por nível do seu Caminho vezes o seu nível.

## Marcos

A cada quatro níveis o personagem chega a um **marco**: os níveis **6, 10, 14, 18, 22, 26 e 30**. São sete na campanha inteira, e o último cai exatamente no nível 30.

Marco é o nível em que a ficha muda de forma. Nos outros níveis a subida acontece sozinha e você só anota; no marco você para, olha a ficha e decide uma coisa. Você volta da missão diferente de como saiu: mais forte no corpo, mais fino no controle da própria energia, ou com um jeito novo de usar a técnica que já tinha.

> **De graça, em todo marco:** +1 ponto de atributo, +1 de refino e +1 espaço de feitiço.
>
> **E escolha uma destas três:**
>
> **Corpo** — mais um ponto de atributo, **e mais uma perícia ou um ofício treinado**.
> *Do nível 10 em diante, no lugar da perícia ou do ofício novo, você pode **especializar** um que já treina: some **metade da maestria** de novo naquela rolagem, arredondando para baixo.*
>
> **Refino** — mais um de refino, e uma aptidão. **Se o seu refino já estiver no teto, você leva duas aptidões no lugar, ao escolher a rota.**
>
> **Leque** — mais um feitiço, que só pode ser feitiço, e uma Passiva.

**Teto de atributo: 6. Teto de refino: 10.**

A escolha é do momento: você decide no marco, e nada obriga você a repetir a escolha anterior.

### Maestria

**Maestria por marco**
| marco | nv 6 | nv 10 | nv 14 | nv 18 | nv 22 | nv 26 | nv 30 |
|---|---|---|---|---|---|---|---|
| atributo, refino, espaço e escolha | sim | sim | sim | sim | sim | sim | sim |
| maestria sobe | — | **sim** | — | **sim** | — | **sim** | — |

Um marco sim, um não, começando pelo segundo.


### Teto de Passivas

Você paga por **cinco** Passivas ao longo da campanha, e esse número não muda. Cada escolha de **Leque** abre uma vaga a mais no teto, e a Passiva que a própria escolha concede ocupa essa vaga nova. Uma rota pura de Leque termina com doze Passivas na ficha, e cinco delas continuam sendo as cinco pagas de sempre.

---

<!-- fonte: da71e05d32c96bbaf1312784fa9cad92f3d9566d -->
