# Planejamento editorial do Manual da Guilda

Proposta 3, de 02/10/2026, sobre a v0.331. Esta etapa detalha a execução do piloto, prepara seus exemplos e abre uma primeira rodada de nomes; a edição jogável continua preservada.

Para continuar agora, comece por [PILOTO-EDITORIAL.md](PILOTO-EDITORIAL.md). Ele define a primeira entrega de redação e prova visual: abertura do mundo, funcionamento da mesa, cena de Kaori, começo da criação e uma amostra de proteção do Bastião. As demais amostras técnicas entram no segundo lote.

O [PLANO-EDITORIAL.md](PLANO-EDITORIAL.md) reúne a arquitetura do livro inteiro, os critérios de revisão e a execução por lotes. As cores atuais serão mantidas.

Para avaliar o fundamento do plano:

- [DIAGNOSTICO-DO-LEITOR.md](DIAGNOSTICO-DO-LEITOR.md): comentários da Caramelo confrontados com o livro atual, lacunas e achados concretos.
- [METODO-E-TESTES-COM-LEITORES.md](METODO-E-TESTES-COM-LEITORES.md): métodos editoriais, pesquisa externa e protocolo de teste humano. Nenhum teste novo com jogadores foi realizado nesta etapa.
- [ESTUDO-DOS-LIVROS.md](ESTUDO-DOS-LIVROS.md): leitura dirigida dos nove PDFs enviados, páginas e limites. Não é leitura integral.
- [AUDITORIA-DO-PDF.md](AUDITORIA-DO-PDF.md): navegação, páginas examinadas, causas de produção e paleta.
- [REFERENCIAS-E-DIAGNOSTICO.md](REFERENCIAS-E-DIAGNOSTICO.md): levantamento inicial de quatro livros, incluindo Pathfinder 2e, e método das contagens.

Para executar:

- [PILOTO-EDITORIAL.md](PILOTO-EDITORIAL.md): percurso do leitor, conteúdo a preparar, prova visual, amostras e critérios de avaliação.
- [NOMES-PRIMEIRA-RODADA.md](NOMES-PRIMEIRA-RODADA.md): Fundamento, Classe/Classe Passiva e Refino; significados, alternativas e riscos, sem renomes aplicados.
- [Preparação de Kaori](evidencias/preparacao-kaori.md): fontes, contas, omissões do tutorial e sincronizações necessárias.
- [MAPA-DE-MIGRACAO.md](MAPA-DE-MIGRACAO.md): destino das 22 fontes e divisão dos capítulos maiores.
- [PAUTA-DE-DECISOES.md](PAUTA-DE-DECISOES.md): propostas, exigências confirmadas, nomes e pendências mecânicas.
- [ROTEIRO-DE-EXECUCAO.md](ROTEIRO-DE-EXECUCAO.md): piloto, lotes, entregas e conferência de preservação.
- [INVENTARIO-BASE.json](INVENTARIO-BASE.json): retrato das fontes e artefatos da v0.331.
- [CONFERENCIA.json](CONFERENCIA.json): checagens desta entrega; [saída do verificador de voz](evidencias/voz-v0.331.txt) e [conferência documental](evidencias/repositorio-r3.txt). A consulta de histórico Git não foi executada nessa conferência final; os arquivos publicados foram comparados pelos hashes do inventário.

A próxima unidade concreta é redigir e diagramar a primeira versão do piloto. Ele pode usar os nomes atuais bem explicados enquanto as alternativas são discutidas. O sumário de vinte capítulos ainda é uma proposta. Nenhum renome novo ou mudança de regra foi aprovado por constar neste pacote. Não é necessário produzir outro plano geral antes de começar essa amostra.

Use o plano com o pacote integrado v0.331 ou com acesso à pasta atual. Este pacote não contém o livro inteiro nem os PDFs de referência. Links para arquivos fora do pacote exigem o repositório original. Se Origens, fichas ou regras tiverem avançado em outro ambiente, concilie a nova entrega antes de aplicar este retrato.
