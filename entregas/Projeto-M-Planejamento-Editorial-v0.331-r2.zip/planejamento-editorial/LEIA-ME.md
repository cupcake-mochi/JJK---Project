# Planejamento editorial do Manual da Guilda

Proposta 2, de 02/10/2026, sobre a v0.331. Esta etapa atualiza o diagnóstico e o método; a edição jogável continua preservada.

Comece por [PLANO-EDITORIAL.md](PLANO-EDITORIAL.md). Ele reúne a arquitetura proposta, o percurso de entrada no mundo, a revisão dos nomes, o piloto integrado de texto e visual e a execução por lotes. As cores atuais serão mantidas.

Para avaliar o fundamento do plano:

- [DIAGNOSTICO-DO-LEITOR.md](DIAGNOSTICO-DO-LEITOR.md): comentários da Caramelo confrontados com o livro atual, lacunas e achados concretos.
- [METODO-E-TESTES-COM-LEITORES.md](METODO-E-TESTES-COM-LEITORES.md): métodos editoriais, pesquisa externa e protocolo de teste humano. Nenhum teste novo com jogadores foi realizado nesta etapa.
- [ESTUDO-DOS-LIVROS.md](ESTUDO-DOS-LIVROS.md): leitura dirigida dos nove PDFs enviados, páginas e limites. Não é leitura integral.
- [AUDITORIA-DO-PDF.md](AUDITORIA-DO-PDF.md): navegação, páginas examinadas, causas de produção e paleta.
- [REFERENCIAS-E-DIAGNOSTICO.md](REFERENCIAS-E-DIAGNOSTICO.md): levantamento inicial de quatro livros, incluindo Pathfinder 2e, e método das contagens.

Para executar:

- [MAPA-DE-MIGRACAO.md](MAPA-DE-MIGRACAO.md): destino das 22 fontes e divisão dos capítulos maiores.
- [PAUTA-DE-DECISOES.md](PAUTA-DE-DECISOES.md): propostas, exigências confirmadas, nomes e pendências mecânicas.
- [ROTEIRO-DE-EXECUCAO.md](ROTEIRO-DE-EXECUCAO.md): piloto, lotes, entregas e conferência de preservação.
- [INVENTARIO-BASE.json](INVENTARIO-BASE.json): retrato das fontes e artefatos da v0.331.
- [CONFERENCIA.json](CONFERENCIA.json): checagens desta entrega; [saída do verificador de voz](evidencias/voz-v0.331.txt).

A próxima unidade concreta é o piloto da abertura e primeira experiência de jogo. Os termos centrais necessários a ele entram na discussão; o sumário de vinte capítulos ainda é uma proposta. Nenhum renome novo ou mudança de regra foi aprovado por constar neste pacote.

Use o plano com o pacote integrado v0.331 ou com acesso à pasta atual. Este pacote não contém o livro inteiro nem os PDFs de referência. Links para arquivos fora do pacote exigem o repositório original. Se Origens, fichas ou regras tiverem avançado em outro ambiente, concilie a nova entrega antes de aplicar este retrato.
