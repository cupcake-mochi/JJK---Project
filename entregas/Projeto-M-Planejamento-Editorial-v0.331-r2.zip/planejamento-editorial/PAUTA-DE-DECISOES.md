# Decisões da revisão editorial

Base: v0.331, 02/10/2026. Este é o registro inicial de temas para discussão. Nenhum nome sugerido ou ajuste de regra foi aplicado nesta etapa.

## Decisões de arquitetura

| Identidade | Tema | Recomendação do planejamento | Estado |
|---|---|---|---|
| E01 | Estrutura principal | Vinte capítulos em cinco partes, com referências no fim, conforme PLANO-EDITORIAL | Proposta |
| E02 | Glossário | Quadro breve na abertura e glossário completo no fim, com a mesma fonte de definições | Proposta |
| E03 | Caminhos | Um capítulo com seis unidades próprias e suas Trilhas; acesso direto no PDF | Proposta |
| E04 | Fundamento | Procedimento, catálogo e poderes avançados em três capítulos ligados | Proposta |
| E05 | Invocações | Uso em campo antes da montagem; catálogo reduzido continua junto da entidade | Proposta |
| E06 | Equipamento | Reunir equipamento e ferramentas num capítulo, preservando distinções internas | Proposta |
| E07 | Nomes antigos | Remissão no índice e tabela de correspondência durante a transição | Proposta |
| E08 | Visual | Piloto integrado de abertura e jogo; combate e provas de catálogo, habilidade longa e ficha | Proposta atualizada |
| E09 | Cores | Preservar a paleta atual do tema; composição e tipografia podem mudar | Exigência expressa do Mizuki |
| E10 | Mundo e leitura | Fortalecer a apresentação do universo, personagens e situações; avaliar a função de cada trecho | Objetivo confirmado; texto por desenvolver |
| E11 | Navegação digital | Selecionar destinos úteis, organizar hierarquia e iniciar ramos recolhidos; testar consulta | Proposta técnica |
| E12 | Método | Usar feedback como diagnóstico, pesquisa e provas de uso; evitar receitas literais e certificados de qualidade por contagem | Orientação expressa do Mizuki |

“Proposta” quer dizer pronta para discutir; não quer dizer mudança publicada ou aprovação presumida.

## Primeira leva de nomenclatura

A lista abaixo prioriza impacto na compreensão e alcance das referências. Não é uma lista de termos condenados.

| Identidade | Termos atuais ou família | O que verificar | Alcance da decisão |
|---|---|---|---|
| N01 | Fundamento, técnica, Regra, feitiço | Se o leitor identifica a diferença entre conceito, limite ficcional e aplicação construída | Criação, todo o construtor, Origens e Trilhas |
| N02 | Classe, Classe Passiva, grau, patente, nível | Se cada escala é reconhecida sem a definição ao lado | Tabelas, ficha, progressão, ferramentas e invocações |
| N03 | Refino, Lapidação, marco, Corpo, Leque | Se os nomes indicam o que progride e o que se escolhe | Desenvolvimento de todas as rotas |
| N04 | Passiva, aptidão, Bênção, Legado | Se o leitor distingue origem, aquisição e função de cada benefício | Criação, evolução e catálogos |
| N05 | Destranca, Ajusta, Desliga | Clareza dos formatos de Legado e compatibilidade com a nova proposta de Origens | Aguardar conciliação de Origens |
| N06 | Canalizar energia, Dano na arma, Canalizar em Golpe | Uma mesma função aparece sob nomes diferentes; escolher como publicar sua relação | Caminhos, aptidões, crítico e rota sem energia |
| N07 | Ação Atacar, ataque, golpe simples; ação e deslocamento | A palavra deve indicar se é um recurso gasto, uma rolagem ou parte de uma ação | Combate, ataques adicionais e Fluidez |
| N08 | Reação pessoal, Reação coletiva, Bloquear | Tornar distinguíveis recurso e resposta defensiva; Bloquear não gasta Reação pela regra atual | Combate, Bastião, Guia e invocações |
| N09 | Invocação, entidade, básica, especial, intenção, comando, reserva | Se os termos distinguem corpo, habilidade, ação e energia | Invocações e Evocador |
| N10 | Restrição, Restrição Celestial, Selo | Separar construção de efeito, rota de personagem e exigência de uso | Origens, montagem e ritual |
| N11 | Reflexo | Colisão já registrada na fila; levantar todos os usos e seus sentidos antes de propor alternativa | Incursor e referências encontradas na triagem |
| N12 | Sentença Final | Colisão já registrada na fila; verificar o que o nome precisa comunicar em cada uso | Assassino e demais ocorrências |
| N13 | Outros nomes de habilidades e efeitos | Verificar promessa do nome, interesse de jogo e associação com a ação concreta | Trabalhar por Caminho e Trilha |
| N14 | Ferramenta, objeto, corpo e cadáver amaldiçoado | Distinguir coisas que hoje têm regras diferentes e nomes próximos | Equipamento, Origens e entidades |

**Já aprovados:** Incursor, Pugilista e Malabarista. Eles não entram numa nova troca automática só porque o livro está sendo revisado.

Para cada renome, registrar: conceito estável; fonte da regra; contexto do problema; candidatos; escolha do Mizuki; nome antigo; abreviação permitida; arquivos e artefatos afetados; aplicação concluída ou pendente. Conferir também usos sem acento, plural, títulos, tabelas, campos da ficha e procura pelo nome antigo.

O teste de nome tem duas partes. Primeiro, sem mostrar a descrição, pedir a um leitor que diga o que imagina. Depois, mostrar a habilidade e perguntar se a associação se mantém. Uma surpresa pode ser sabor; uma associação recorrente com outra regra é um problema a discutir. Registrar respostas, sem transformar uma amostra pequena em estatística geral de qualidade.

## Pendências de regras que atravessam a revisão

A fila vigente está em ../../../ESTADO-ATUAL.md. Os itens abaixo são interfaces desta revisão; não substituem aquela fila.

| Tema preservado | Onde pesa | Tratamento editorial |
|---|---|---|
| Quantidade do kit inicial ampliado | Criação e equipamento | Identificar a opção exata; não criar kit fixo por Caminho nem substituir o orçamento livre aprovado |
| Troca de Trilha e aquisições em duplas | Regras comuns dos Caminhos e opções do Evocador | Preservar a regra geral publicada; isolar os casos específicos ainda sem decisão |
| Repertório quando o atributo cai | Poderes e entidades | Mostrar ao responsável a lacuna concreta; não inventar perda ou retenção |
| Corpos excedentes ao fim do combate | Invocações e Trilhas | Confrontar teto geral com exceções da Trilha e duração do benefício |
| Comandos, preparo e estados | Turnos, Guia, Evocador e invocações | Conferir as sequências e os recursos de cada participante |
| Agarrar, Derrubar, Empurrar e Estudar gerais | Combate e perícias | Não universalizar automaticamente a regra específica do Pugilista ou Assassino |
| Origens em outro ambiente | Criação, Legados, rotas de poder e ficha | Aguardar o resultado dessa frente para fechar os capítulos afetados |
| Fichas no Claude | Roteiro de criação, campos e exemplos | Conciliar a versão e os nomes antes da publicação final |
| Calibração para seis Caminhos | Bestiário e playtest | Mantida como trabalho de equilíbrio; não recalibrar inimigos durante a revisão de texto |

Os ajustes do Bastião da v0.331 estão concluídos e entram como base. Alterações adicionais nas classes só entram com a decisão correspondente.

## Achados documentais a tratar na execução

- A introdução descreve cinco a sete jogadores e dois a três mestres; a caracterização do projeto usa cinco a sete mestres ativos. Esclarecer o público descrito sem inventar tamanho obrigatório de mesa.
- O README do livro conta vinte fontes; o inventário desta tarefa encontra 22.
- A documentação histórica ainda contém regras e impedimentos superados. O cabeçalho vigente da v0.331 prevalece; revisar ponteiros ativos, preservando o registro histórico.
- As atuais proteções de fidelidade textual e contagens de catálogo dependem da estrutura antiga. Adaptá-las conscientemente quando a estrutura mudar, preservando o que elas precisam garantir.
- A cena inicial deve distinguir escolhas compatíveis no mesmo turno de alternativas que disputam um recurso. Isso exige revisar a apresentação da cena, não conceder ações novas. Ela também omite a baixa de PE ao demonstrar Peso nas Mãos.
- Glossário e capítulo Como Jogar divergem na descrição da escala de CD; conferir com a fonte mecânica responsável, sem inventar nova escala.
- Há 827 marcadores nos dois PDFs, com 199 grupos inicialmente abertos. Separar títulos semânticos e atalhos selecionados.
- A capa artística imprime v0.1; decidir como identificá-la junto da edição corrente para não confundir versão de arte e versão das regras.
- O verificador de voz estrito acusa 34 itens editoriais pendentes. Triar por função antes de aplicar regras de estilo automaticamente.

## Estados de uma decisão

Levantado → proposta → aprovado → aplicado → conferido.

Só “conferido” encerra a linha. Uma decisão aprovada pode continuar ausente de uma ficha ou tabela; por isso aplicação e conferência são etapas separadas.
