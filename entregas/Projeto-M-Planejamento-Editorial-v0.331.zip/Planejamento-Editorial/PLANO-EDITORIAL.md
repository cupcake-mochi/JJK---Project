# Planejamento da organização do Manual da Guilda

Proposta editorial 1, de 02/10/2026. Base examinada: Projeto - M v0.331.

Este plano organiza a revisão do livro inteiro: sequência de leitura, localização das regras, nomes, redação, exemplos, imagens e publicação. O objetivo é que uma pessoa nova consiga começar e que uma pessoa em sessão encontre a regra sem depender de quem escreveu o sistema.

**Recomendação:** um livro principal de jogador com vinte capítulos, divididos em cinco partes, e referências no fim. Manter o material de preparação e arbitragem do mestre em seu destino próprio. Fazer a revisão de nomes estruturais antes da reescrita em escala; aprovar um piloto de texto e um de diagramação antes de aplicar os padrões ao livro inteiro.

O planejamento está pronto para discussão e execução por etapas. Os capítulos, as regras e os arquivos publicados da v0.331 não foram reorganizados nesta tarefa. Os títulos abaixo são títulos editoriais propostos; os nomes atuais das mecânicas continuam valendo.

## Diagnóstico do material atual

O livro tem dezenove capítulos e três peças de abertura, distribuídos em 22 fontes Markdown. A contagem lexical dessas fontes dá aproximadamente 109 mil palavras. Ela inclui títulos, tabelas e números; serve para comparar o peso dos blocos, e não deve ser confundida com a contagem do Word ou do arquivo de texto exportado.

| Bloco atual | Palavras pela mesma contagem | Parcela do conjunto |
|---|---:|---:|
| Caminhos e Trilhas | 32.234 | 29,5% |
| Fundamento | 13.948 | 12,8% |
| Invocações | 16.371 | 15,0% |

Os três somam 57,2% do texto, antes de arredondar as parcelas. Essa concentração pede navegação interna, procedimentos curtos e catálogos bem localizados. O tamanho, sozinho, não prova redundância.

O inventário completo, com arquivos, títulos e hashes, acompanha este plano. São seis Caminhos e dezoito Trilhas na edição integrada. O estado das Origens ainda depende do trabalho em outro ambiente; não se deve transformar a enumeração atual em requisito imutável da próxima edição.

Os problemas estruturais observados foram:

- O glossário completo aparece antes da cena inicial. Ele ajuda na consulta, mas também põe um catálogo extenso na frente de quem quer começar.
- A criação só chega no capítulo 6, depois de regras detalhadas de dano, condições e descanso. É possível antecipar a escolha do personagem com uma explicação básica menor.
- Como Jogar concentra resolução geral, ataque, defesa, Bloquear, recursos, vida a zero e condições. Parte disso precisa continuar como apresentação; a regra completa pode ter destinos mais previsíveis.
- Fundamento reúne definição da técnica, procedimento de montagem, catálogo, poderes avançados, progressão e exemplos prontos. São tarefas diferentes dentro de um mesmo capítulo.
- Invocações apresenta grande parte da montagem e dos catálogos antes de explicar o ciclo completo da entidade em campo. Quem já tem uma entidade precisa atravessar material de construção para chegar ao uso.
- Os Caminhos têm apresentações de épocas diferentes. Há habilidades em caixas compartilhadas e outras em seções próprias, com critérios distintos para exemplos e exceções.
- Há termos que precisam ser confrontados por sentido, além de procurar palavras iguais: Classe, Classe Passiva, grau, patente, Refino, Lapidação e marcos, por exemplo.
- A documentação editorial também envelheceu: o README do livro ainda descreve vinte fontes, enquanto a pasta contém 22. Documentação de produção entra na revisão de consistência.
- A abertura mistura a quantidade de jogadores com a de mestres, enquanto a descrição do projeto fala em cinco a sete mestres ativos. É uma questão de apresentação a esclarecer, não um novo limite de grupo.

A revisão não começa eliminando toda repetição. Um lembrete local pode poupar várias consultas. O que precisa de controle é a repetição que reescreve uma regra inteira e acaba criando outra versão dela.

## Arquitetura recomendada

A ordem de publicação e a ordem de trabalho serão diferentes. O leitor recebe um caminho de entrada simples. A equipe revisa primeiro as regras das quais os demais capítulos dependem.

### Abertura

Capa, créditos, sumário e apresentação breve da proposta do jogo. A orientação de leitura fica aqui, uma vez: começar, criar personagem ou consultar durante a sessão.

Um quadro curto apresenta os termos indispensáveis para atravessar o começo: atributo, maestria, teste, CD, vida, PE, Origem, Caminho, Trilha e técnica. É uma seleção do glossário, mantida a partir das mesmas definições. O glossário completo vai para o fim.

O tutorial já existente continua dentro do livro. A decisão anterior de não produzir um quick-start separado é preservada.

### Parte I — Começar a jogar

| Capítulo proposto | Conteúdo e função |
|---|---|
| **1. Como jogar** | Conversa de mesa, primeira rolagem, atributos e maestria, vantagem, diferença entre ataque e TR, recursos em uma visão breve. A cena da Kaori entra como demonstração guiada. |
| **2. Criação de personagem** | Roteiro completo com a ficha à vista, decisões em ordem, caminhos de leitura para cada rota de poder e exemplo preenchido. Cada escolha termina dizendo o que anotar e onde buscar as opções. |

O capítulo 1 ensina o suficiente para entender uma cena. Ataques completos, Bloquear, queda e recuperação têm capítulos de consulta próprios mais adiante. O resumo inicial aponta para eles e não estabelece exceções próprias.

Na criação, a ordem efetiva de escolhas continua condicionada às regras: Origem, técnica, Caminho, atributos e demais etapas não serão trocados apenas para caber numa sequência visual bonita. O trabalho editorial pode apresentar decisões provisórias e retornos ao roteiro sem mudar quando elas se tornam válidas.

### Parte II — Construir e desenvolver o personagem

| Capítulo proposto | Conteúdo e função |
|---|---|
| **3. Origens e Legados** | Formas de origem, efeitos na ficha e Legados. Recebe a versão conciliada do trabalho externo. O formato final depende dessa entrega. |
| **4. Caminhos e Trilhas** | Comparação inicial dos seis Caminhos, regras comuns e seis seções independentes, cada uma com suas três Trilhas. |
| **5. Perícias e Ofícios** | Treino, atributo usado, testes, catálogo e aplicações já existentes em exploração e interação. |
| **6. Equipamento e ferramentas amaldiçoadas** | Compra e acesso, uso, treino, armas, proteção, carga e, em seção própria, ferramentas, objetos e Estigmas. |
| **7. Experiência e progressão** | Subir de nível, entregas, marcos, escolhas e registro entre mesas. Regras de personagem distinguem-se das recomendações administrativas para a guilda. |

O capítulo 4 continua sendo um capítulo lógico, mas cada Caminho deve abrir como uma unidade reconhecível, com marcador próprio no PDF e acesso pelo sumário. Internamente, pode ser montado a partir das seis fontes integradas. Não há razão para obrigar o leitor a percorrer as outras cinco classes.

A fusão de Equipamento e Ferramenta Amaldiçoada aproxima assuntos que se consultam juntos. Preserva uma fronteira visível entre equipamento comum, ferramenta e objeto amaldiçoado; não unifica conceitos nem torna os três intercambiáveis.

A progressão se aproxima da criação para permitir planejar e atualizar a ficha. As tabelas são as mesmas da edição vigente até existir decisão mecânica diferente.

### Parte III — Resolver as cenas

| Capítulo proposto | Conteúdo e função |
|---|---|
| **8. Turnos e combate** | Iniciativa, ações, deslocamento, ataques, Defesa, Bloquear, oportunidade, concentração e preparo, em ordem de resolução. |
| **9. Dano, condições e recuperação** | Aplicar dano, proteção e reduções conforme as regras, condições, cobertura, alma, vida a zero, morte, descanso e reparo. |

Os capítulos 8 e 9 são destinos de consulta. O capítulo 1 faz a apresentação e o 5 explica as perícias. Não é necessário inventar um sistema novo de exploração ou de cena social para preencher um capítulo.

Cobertura permanece definida uma vez, com um diagrama e referência no ponto em que modifica o ataque. Inconsciente, Incapacitado, Derrubado e os demais estados precisam de entradas que permitam reconhecer tanto seus efeitos quanto a duração e o término já previstos.

A fronteira entre os dois capítulos é o resultado: o 8 chega ao ataque ou teste resolvido; o 9 aplica suas consequências e mostra como recuperar. Exceções continuam junto da habilidade que as concede.

### Parte IV — Técnicas e poderes

| Capítulo proposto | Conteúdo e função |
|---|---|
| **10. Aptidões e Refino** | Recursos e poderes comuns de quem tem energia: obter, escolher, usar e consultar aptidões. |
| **11. Fundamento e criação de feitiços** | Descrição, Regra, Família, Selo, Passivas, orçamento e procedimento completo de montar e usar um feitiço. |
| **12. Formas, Melhorias e Restrições** | Catálogo da construção, com índices por nome e função e indicação dos requisitos relevantes. |
| **13. Liberação Máxima, Técnica Máxima e Domínio** | As três extensões avançadas, seus procedimentos e as interações entre Domínios. |
| **14. Técnica Marcial** | Acesso, transformações do procedimento comum, Kata, Ruptura, Ōgi, rotas de arma e ferramenta e exemplos. |
| **15. Sem Técnica** | Acesso, Semente, Manejo, Auge, limites e aplicação da construção comum. |
| **16. Bênçãos e Lapidação** | Desenvolvimento e catálogo da rota sem energia, com a ponte necessária para os conceitos compartilhados. |
| **17. Ritual** | Procedimento, testes, ganhos, falhas, acesso e ritual em dupla. |
| **18. Pactos** | Formas de pacto, custos, limites, criação e aplicação das trocas já aprovadas. |

Separar o Fundamento em três capítulos não cria três sistemas. O capítulo 11 ensina a construir; o 12 fornece as peças; o 13 trata dos recursos avançados. A ficha de feitiço e a conferência final devem continuar próximas do procedimento de montagem.

As rotas Marcial, Sem Técnica e sem energia precisam de um mapa curto: o que herdam, o que substituem e o que não acessam. Esse mapa deve ser extraído das regras atuais. Não transformar a organização por capítulos em novos pré-requisitos.

Aptidões precedem o construtor na ordem proposta por incluírem recursos comuns já usados pelos Caminhos. A definição breve de Classe Passiva aparece no ponto de uso e remete à escala completa. Se o piloto mostrar excesso de idas e voltas, a posição desse capítulo é o primeiro ajuste a testar; não será necessário redesenhar todo o sumário.

Exemplos prontos permanecem ao lado da máquina que demonstram: técnica e feitiço comuns no 11; Liberações e Técnicas Máximas no 13; exemplos de Kata no 14.

### Parte V — Invocações

| Capítulo proposto | Conteúdo e função |
|---|---|
| **19. Invocações em campo** | O que é uma entidade, aquisição em resumo, manifestação, ciclo, intenção, comando, ações, reação coletiva, movimento, energia, queda e saída. Um exemplo acompanha a sequência. |
| **20. Montagem de entidades** | Aquisição completa, domar, ficha, famílias, básicas, especiais, espaços, passivas, progressão, formas, melhorias, restrições e exemplo completo de montagem. |

A regra geral de Invocações pertence a estes capítulos. Evocador e suas Trilhas descrevem as mudanças específicas que concedem e apontam para o procedimento afetado.

O catálogo reduzido das entidades continua disponível junto de sua montagem. A semelhança com o Fundamento não autoriza apagar regras locais: os custos, limites e escalas diferem. Onde a semântica realmente for comum, a fonte de produção pode ser compartilhada; o resultado publicado deve continuar utilizável sem uma sequência excessiva de consultas.

### Referências finais

- **Glossário completo:** definição breve, categoria quando necessária e destino da regra completa.
- **Referência de mesa:** sequência de ataque, recursos do turno, condições, recuperação e ciclo de invocações.
- **Fichas e modelos:** personagem, feitiço e entidade, conciliados com o trabalho das fichas.
- **Índice remissivo:** destinos principais, referências úteis e nomes antigos que apontem para os novos durante a transição.

Os nomes antigos funcionam como entradas de busca, não como dois nomes oficiais concorrentes no corpo do livro. As referências rápidas são geradas ou conferidas contra suas fontes para não virar uma nova versão da regra.

## Caminhos de leitura

A estrutura não exige ler todos os catálogos em sequência. A abertura aponta três percursos: aprender a jogar, pelo capítulo 1 e depois 8 e 9; criar personagem, pelo 1 e pelo roteiro do 2, abrindo apenas os catálogos necessários; construir poderes, pelo procedimento do 11, pelas opções do 12 e pela rota correspondente.

O custo desta escolha é afastar o combate detalhado da abertura. A cena inicial precisa ser suficiente para começar, e o acesso aos capítulos 8 e 9 deve ser direto no sumário e nos marcadores. Essa é uma das coisas a testar no piloto.

## Fronteira do livro principal

O manual precisa conter tudo que um jogador necessita para construir e usar as opções publicadas. Pré-requisitos, preços, limites, falhas e exceções não podem desaparecer por serem difíceis de explicar.

A preparação de encontros, a calibração de inimigos, o processo de aprovação de conteúdo próprio, a fabricação detalhada de itens e a administração da guilda têm destinos de mestre já previstos no projeto. O bestiário permanece um material próprio. As regras de PvP seguem o destino de mestre decidido anteriormente.

Não abrir agora uma frente de escrita do livro do mestre para conseguir concluir a revisão do jogador. Registrar interfaces e reaproveitar o material já existente quando for executada aquela frente. As pendências do arquivo REMOCOES-material-de-mestre continuam rastreáveis.

Regras que afetam escolhas do jogador permanecem acessíveis a ele. A explicação de como os autores chegaram ao preço de uma arma pode ficar na documentação de design; o preço que ele paga e o efeito da arma precisam estar no manual.

## Revisão de nomes

A revisão ocorrerá em duas passagens.

**Primeiro, termos estruturais.** Conceitos repetidos por todo o sistema: categorias de poder, progressão, recursos, ações e condições. Mudá-los tarde multiplica o retrabalho. A ficha participa desta revisão porque é onde o jogador mais vê esses termos.

**Depois, nomes locais.** Habilidades, efeitos, Trilhas e entradas de catálogo, trabalhados junto de cada lote de texto. Incursor, Pugilista e Malabarista já estão aprovados. Reflexo e Sentença Final continuam na pauta; nenhum substituto foi escolhido neste plano.

Cada proposta deve apresentar o significado atual, o problema concreto, duas ou três alternativas e o custo da troca. Um nome evocativo pode continuar acompanhado por uma linha operacional clara. A meta não é dar nome técnico a todas as habilidades.

Os critérios são: permitir uma associação razoável com o efeito; diferenciar conceitos vizinhos; caber na ficha e na fala; combinar com a ficção do sistema; não colidir com outro nome ou com um uso muito estabelecido no hobby.

O registro de renomes terá identidade estável, nome antigo, nome proposto, decisão do Mizuki, origem da regra e superfícies afetadas. Trocas globais por busca e substituição só entram depois de separar usos homônimos. O termo Projeto - M, por exemplo, não muda por conveniência editorial.

A pauta inicial está em PAUTA-DE-DECISOES.md. Ela identifica o que investigar; não declara todos esses termos defeituosos.

## Revisão textual e formato das entradas

A regra de voz atual é o ponto de partida. As quatro camadas aprovadas para catálogo continuam: identificação, situação de uso, efeitos reconhecíveis e regra. A forma visual pode variar por família, desde que a localização das informações seja previsível.

| Família | O que o leitor precisa localizar |
|---|---|
| Regra de procedimento | Quando se aplica, sequência de resolução, resultado e exceções relevantes |
| Habilidade de Caminho ou Trilha | Nível, gatilho ou ativação, custo, alvo e alcance, efeito, duração, frequência e término, quando houver |
| Entrada de catálogo de montagem | Função, custo ou degrau, requisitos, escala e restrições de combinação |
| Condição | Efeitos separados, duração ou fonte da duração, meios previstos de terminar e interações indispensáveis |
| Equipamento | Categoria, treino, mãos, alcance, dano, propriedades, requisito, preço e carga, conforme o item |
| Exemplo | Situação, escolha, recursos disponíveis, resolução e estado final |

Não preencher campos ausentes com regras inventadas. Uma habilidade passiva não precisa de uma linha ornamental de custo. Uma condição cuja duração vem do efeito que a aplicou deve dizer isso, sem receber duração nova.

O padrão evita dois extremos: um parágrafo único que esconde custos e uma ficha repetitiva com dez rótulos para uma habilidade de duas linhas. Listas ficam para alternativas, etapas e efeitos independentes. Prosa explica a relação entre eles.

A revisão registra três espécies de alteração:

1. **Editorial:** muda clareza ou posição, mantendo a mesma resolução.
2. **Nomenclatura:** altera o termo, com correspondência aprovada.
3. **Mecânica:** muda possibilidade, preço, alvo, momento, duração, frequência, alcance, resultado ou exceção.

A terceira espécie segue em pauta própria até receber decisão. Trocar “pode” por “deve”, retirar “hostil” ou mudar “após o ataque” para “ao acertar” é alteração mecânica mesmo que nenhum algarismo mude.

Exemplos e ilustrações explicativas podem esclarecer a regra. Não serão usados como a única fonte de uma exceção. Quando uma frase aparentemente dispensável for dona de um fato, o fato é preservado na regra antes de cortar a frase.

Não estabelecer uma meta geral de eliminar 20% do livro, nem igualar o tamanho dos seis Caminhos. Cortes serão avaliados por perda de informação, facilidade de encontrar e compreensão.

## Exemplos e elementos visuais

O livro precisa de imagens que mostrem o jogo e de ilustrações que convidem a jogá-lo. As duas funções entram no orçamento editorial.

| Elemento prioritário | O que precisa comunicar |
|---|---|
| Ficha anotada | Onde cada decisão de criação é registrada e onde o jogador encontra o número durante a sessão |
| Sequência de ataque | Declaração, respostas anteriores à rolagem, acerto, defesa escolhida e aplicação das consequências |
| Movimento e cobertura | Espaços, distâncias, ponto de apoio, linha de ataque e posições possíveis |
| Construção de feitiço | Orçamento, escolhas, gasto e resultado, com todas as contas do exemplo |
| Ciclo de invocação | O que pertence ao invocador, a cada entidade e à reação coletiva |
| Progressão | O que vem do nível, do marco, do Caminho e da Trilha |
| Ilustrações dos Caminhos | A fantasia de jogo de cada um, distinguindo postura, função e relação com a técnica |
| Aberturas de parte | O clima de ação e ocultismo contemporâneo do projeto |

Direção inicial proposta: traço e contraste que combinem com ação e horror urbano, áreas claras para leitura, uma cor de destaque consistente e silhuetas fáceis de distinguir. Escolher a identidade com amostras. A paleta atual pode ser aproveitada ou revista nessa etapa.

Não usar arte de preenchimento para cumprir uma proporção fixa de imagem por página. O catálogo pode ser denso; uma abertura pode respirar. Uma cena que demonstre alcance ou parkour precisa corresponder às possibilidades escritas.

Os diagramas técnicos devem ter texto legível, legendas e identificação que funcionem sem depender apenas da cor. Ilustrações, fontes e créditos terão um inventário de produção. As figuras dos livros de referência servem para análise; os novos elementos do Projeto - M devem ter seus próprios arquivos e créditos.

### Piloto de diagramação

Começar pelo capítulo proposto **Turnos e combate**, por reunir prosa, tabela, exceção e espaço para diagramas. Testar um trecho suficiente para representar esses elementos, sem forçar o capítulo a um número de páginas.

Antes de estender o padrão ao resto, acrescentar provas de três situações que esse capítulo não cobre bem: habilidade longa, catálogo com tabela larga e ficha de entidade. Bastião, Malabarista e a montagem de Invocações fornecem os casos.

Comparar a leitura em página inteira, em ampliação normal de tela e em impressão comum. Duas colunas são uma hipótese de partida para a prosa. Tabelas e diagramas podem ocupar largura inteira. Tamanho de fonte e largura de coluna são decididos pela prova, não pela meta de reduzir páginas.

O Word permanece apropriado para comentar e revisar texto. A diagramação final sai da fonte editorial e dos estilos do livro; não se mantém uma edição independente dentro do Word.

## Etapas de execução

| Etapa | Trabalho | Saída que permite avançar |
|---|---|---|
| **0. Inventário** | Identificar fontes, capítulos, dependências e decisões vigentes | Concluído nesta tarefa; mapa e retrato da v0.331 disponíveis |
| **1. Arquitetura e termos centrais** | Discutir este sumário e a primeira pauta de nomes; mapear chegada de Origens e fichas | Estrutura escolhida e correspondência dos termos centrais aprovada |
| **2. Piloto editorial** | Reescrever amostras representativas com exemplos e conferir preservação de regras | Padrão de redação aceito e diferenças mecânicas separadas |
| **3. Migração e revisão por lotes** | Aplicar a arquitetura e revisar blocos completos na ordem de dependência | Cada lote com fonte, texto, decisões e validação; glossário atualizado |
| **4. Piloto visual** | Diagramar combate e as provas complementares | Sistema visual escolhido e problemas de tabela, habilidade e ficha resolvidos |
| **5. Produção visual e leitura transversal** | Diagramar o conjunto, produzir arte, conferir consistência entre capítulos | Livro completo navegável, com figuras e referências corretas |
| **6. Leitura de prova e entrega** | Ensaios de consulta, inspeção final, exportações e pacote | Arquivos finais e registro das mudanças, com pendências remanescentes declaradas |

O piloto visual pode começar quando o primeiro lote de regras e termos estiver estável. A arte pode avançar em paralelo ao texto dos lotes aprovados. A paginação definitiva e os números de página vêm depois da estabilização do conteúdo.

Não há estimativa honesta de dias antes do piloto: a quantidade de mudanças de nomes e a extensão da nova entrega de Origens ainda não estão fechadas. O avanço será medido por lotes aceitos, não por páginas redigidas.

## Trabalho com o Claude

O plano é utilizável em qualquer ambiente que consiga ler as fontes. O trabalho externo das fichas continua tendo sua própria frente. Na conciliação, comparar a versão das regras, os termos e as fórmulas, e registrar o que cada alteração afeta.

Para a revisão do livro, trabalhar com um responsável por lote e uma segunda leitura independente. O segundo revisor recebe a fonte vigente e a proposta; devolve achados localizados e alternativas, evitando reescrever simultaneamente o mesmo capítulo.

A escolha do responsável pode usar o piloto já recomendado: mesmas cinco amostras, mesmas instruções, resultados avaliados sem identificar o modelo. Isso é uma avaliação do projeto, não prova geral de superioridade entre modelos. Não há motivo para repetir esse comparativo a cada capítulo depois de o fluxo funcionar.

Cada remessa deve dizer: base usada; unidade em revisão; alterações autorizadas; decisões pendentes; fontes; produto esperado; critérios de conferência. O roteiro operacional está em ROTEIRO-DE-EXECUCAO.md e aponta para as fontes, sem copiar todas as regras do projeto.

## Critérios para considerar a revisão concluída

- Todo conteúdo vigente tem destino conhecido; nenhuma regra desapareceu ao mover ou resumir uma seção.
- Nenhuma diferença mecânica entrou disfarçada de edição.
- Nomes aprovados aparecem de forma consistente no livro, ficha, gerador, fontes e índices; os antigos continuam encontráveis na transição.
- O caminho de uma primeira ficha e de uma primeira cena funciona sem explicação oral do autor.
- Uma consulta encontra a regra completa e suas exceções relevantes sem depender de lembrança da conversa de design.
- Duas pessoas que mestram resolvem os casos de leitura de prova da mesma maneira ou registram exatamente onde divergem.
- Referências internas, sumário e marcadores digitais apontam para os destinos corretos.
- As tabelas, exemplos e fichas batem com as fontes; os validadores aplicáveis passam sem checagens puladas.
- A exportação foi inspecionada visualmente. Títulos, tabelas e caixas não têm corte, sobreposição ou separações que escondam informação necessária.
- O pacote identifica a edição, o histórico de nomes e qualquer pendência que permaneça.

A leitura de prova verifica clareza, consulta e fidelidade. O equilíbrio dos seis Caminhos continua sendo uma frente de matemática e mesa.

## Próxima unidade recomendada

Discutir primeiro **o sumário proposto e o destino do glossário**. Em seguida, revisar a primeira leva de termos estruturais. Depois disso, fazer o piloto editorial antes de encaminhar a reescrita em volume.

A opção recomendada já está descrita neste documento. Se houver mudança no sumário, ajustar o mapa antes de mover arquivos, sem refazer o diagnóstico ou começar a escrever todos os capítulos.

## Referências do planejamento

A comparação foi feita com amostras dos PDFs locais de D&D 2024, GURPS, Pathfinder 2e e 3D&T Alpha. As observações, páginas consultadas, limites da amostragem e medidas do livro estão em [REFERENCIAS-E-DIAGNOSTICO.md](REFERENCIAS-E-DIAGNOSTICO.md).
