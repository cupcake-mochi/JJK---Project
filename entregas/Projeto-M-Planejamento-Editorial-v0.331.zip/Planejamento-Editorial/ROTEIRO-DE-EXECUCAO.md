# Roteiro de execução da revisão do livro

Este roteiro acompanha o PLANO-EDITORIAL. Serve para continuar o trabalho no ambiente escolhido pelo Mizuki, sobre a versão vigente do projeto.

## Antes de cada lote

Confirmar a pasta, ler a retomada atual e verificar se houve entrega nova de Origens, fichas ou regras. Este pacote é um retrato da v0.331. Se a versão tiver avançado, atualizar o confronto antes de usar o inventário.

Escolher uma unidade que possa ser revisada inteira. Declarar a fonte, a proposta de destino, os nomes já aprovados e as decisões mecânicas permitidas. As referências originais preservadas na integração não devem ser reescritas para fazer a comparação passar.

Trabalhar em uma proposta identificada, com um responsável pelo lote. O segundo revisor entrega achados sobre ela. Coordenar quem integra para evitar duas versões correntes do mesmo capítulo.

## Piloto editorial

Usar cinco amostras com dificuldades diferentes, retiradas das fontes atuais:

1. Criação de personagem: uma decisão e o preenchimento dos números correspondentes.
2. Combate: declaração de ataque, Assumir um golpe, Defesa/Bloquear e consequências.
3. Malabarista: um uso de Fluidez e sua interação com ataques, alcance e retorno.
4. Fundamento: construir um feitiço completo, com o catálogo necessário.
5. Invocações: um ciclo com manifestação ou comando, básica, especial e reação coletiva.

O piloto precisa produzir texto utilizável, exemplos conferidos, lista de nomes e comparação com a regra fonte. Aprovar a forma de cada família; uma habilidade e um catálogo não precisam da mesma apresentação.

Caso sejam comparados modelos, entregar exatamente as mesmas fontes e instruções. Avaliar sem o nome do modelo. Contar achados válidos, falsos positivos, omissões, alterações de regra não autorizadas, trechos aceitos e retrabalho. Registrar tempo e consumo quando estiverem disponíveis. Não concluir superioridade geral com cinco amostras.

## Ordem de revisão por dependência

A numeração dos capítulos abaixo é a proposta, não a da v0.331.

| Lote | Unidade | Dependência principal |
|---|---|---|
| R01 | Termos e resolução básica do capítulo 1 | Sumário e primeira leva de nomes |
| R02 | Turnos e combate, capítulo 8 | R01 e estado das ações gerais |
| R03 | Dano, condições e recuperação, capítulo 9 | R02 |
| R04 | Perícias e Ofícios, capítulo 5 | R01 e interfaces com ações |
| R05 | Equipamento e ferramentas, capítulo 6 | R02; confrontar os treinos vigentes dos Caminhos |
| R06 | Fundamento, capítulo 11 | Termos de técnica e procedimentos comuns |
| R07 | Catálogo, capítulo 12 | R06; dividir por famílias quando necessário |
| R08 | Poderes avançados, capítulo 13 | R06 e R07 |
| R09 | Aptidões e Refino, capítulo 10 | Escalas comuns e regras de energia |
| R10 | Técnica Marcial, Sem Técnica e Bênçãos, capítulos 14 a 16 | R06 a R09; revisar cada rota como unidade |
| R11 | Invocações em campo, capítulo 19 | R02, R03 e confronto das interfaces vigentes de Guia/Evocador |
| R12 | Montagem de entidades, capítulo 20 | R06, R07 e R11 |
| R13 | Bastião, incluindo as três Trilhas | R02 e R03; mudanças da v0.331 são a base |
| R14 | Vanguarda, incluindo as três Trilhas | R02 e R05 |
| R15 | Guia, incluindo as três Trilhas | R02, R03 e R11 |
| R16 | Emanador, incluindo as três Trilhas | R06 a R09 |
| R17 | Evocador, incluindo as três Trilhas | R11 e R12 |
| R18 | Incursor, incluindo Assassino, Pugilista e Malabarista | R02, R05, R09 e ações gerais |
| R19 | Ritual e Pactos, capítulos 17 e 18 | Fontes comuns e limites de acesso por rota |
| R20 | Origens e Legados, capítulo 3 | Entrega externa conciliada |
| R21 | Progressão, capítulo 7 | Todas as entregas e nomes envolvidos |
| R22 | Criação, tutorial e abertura definitivos | R13 a R21 e ficha conciliada |
| R23 | Glossário, referências rápidas, modelos e índice | Destinos e termos estabilizados |

Esses lotes representam cobertura, não uma fila rígida que obrigue esperar tudo. Origens pode entrar assim que chegar. O confronto de uma interface usa a versão vigente da outra ponta, e é repetido quando essa ponta for revisada. Quando houver dependência circular, confrontar os dois textos no mesmo lote sem inventar uma regra de ligação.

Evocador e Incursor são blocos grandes. Se não couber uma leitura cuidadosa com todas as fontes, separar base do Caminho e uma Trilha por remessa, mantendo uma conferência final do conjunto. Não mandar o livro inteiro para ser reescrito numa única resposta.

## Produto de cada lote

Entregar:

- Texto proposto completo da unidade, no formato editorial escolhido.
- Correspondência entre seções antigas e novas, incluindo o destino do que foi movido.
- Lista curta de mudanças relevantes e o problema que cada uma resolve.
- Renomes aprovados aplicados e nomes ainda em discussão.
- Diferenças mecânicas identificadas, com fonte e decisão quando houver.
- Exemplos e tabelas conferidos.
- Pendências que impedem fechar aquele lote.

Não repetir toda a história da conversa no texto de mesa. O histórico de decisões permanece na documentação de trabalho.

## Fonte das regras e geração dos livros

A edição integrada de Caminhos está em caminhos/05-Edicao-Integrada; Invocações, em invocacoes/05-Edicao-Integrada. A fonte do livro está em sistema/05-material/livro/manual. O manual do Fundamento tem sua própria fonte no gerador de manual; as peças de sistema/03-mecanica e os registros atuais indicam quem responde por cada regra.

Quando a revisão atingir uma regra copiada, atualizar a fonte responsável e a representação do livro no mesmo lote. Se a melhoria for só de redação, conferir o conteúdo mecânico antes de atualizar a proteção de fidelidade. Os textos aprovados originais continuam preservados como histórico.

Recomendação de produção: declarar a ordem dos capítulos e suas identidades num único mapa utilizado pelos três exportadores. Hoje PDF, Word e texto têm listas próprias. A migração precisa alcançar os três, as tabelas da introdução, glossário, âncoras, índice, fichas e verificações que dependem dos nomes ou arquivos antigos.

Cada conceito deve ter uma identidade interna estável, independente do nome que aparece na página. Um renome não precisa quebrar a busca nem perder o destino de uma referência. Números de capítulo e página devem ser resolvidos na montagem do livro.

Essa melhoria de produção é uma tarefa de implementação futura. Nenhum exportador foi alterado pelo planejamento.

## Conferência de preservação

O guardião de números é útil, mas insuficiente. Comparar também:

| Campo | Exemplos de alterações que mudam a regra |
|---|---|
| Momento | Antes da rolagem; depois do ataque; depois de acertar |
| Ação e recurso | Reação, Ação Bônus, gasto de Fluidez, PE e reserva da entidade |
| Alvo e elegibilidade | Hostil, aliado, você, entidade, arma Leve/Finez, alvo oculto |
| Alcance e posição | Origem da distância, ponto de ricochete, apoio, adjacência |
| Frequência e renovação | Por turno, entre seus turnos, rodada, cena e combate |
| Duração e término | Até quando; perda por condição, movimento, saída de campo |
| Resolução | TR, Defesa, Bloquear, dano, crítico, empurrão e agarrão |
| Combinações | Ataque adicional, Canalizar em Golpe, condições e ordens |
| Autoridade | Escolha do jogador, exigência da habilidade ou decisão do mestre |

Antes de remover uma repetição, verificar se ela contém a única ocorrência de uma exceção. Depois de mover, confirmar se as referências ainda chegam à seção certa.

Executar as verificações aplicáveis ao lote. Na migração estrutural e na entrega final, rodar a bateria completa, incluindo os validadores do Fundamento e a conferência do repositório; verificar as checagens puladas. Mudanças numéricas aprovadas continuam exigindo as verificações e perturbações previstas no procedimento do projeto.

Não desativar uma proteção só porque a nova divisão de capítulos a fez falhar. Identificar se ela verifica conteúdo, localização, título ou uma contagem antiga; adaptar a localização preservando a garantia. Comparação de números não substitui leitura da resolução.

## Provas de consulta e compreensão

Aplicar primeiro na versão atual e repetir na candidata. Usar tarefas iguais, cronometrar quando possível e registrar ajuda pedida e destino consultado.

- Montar a primeira ficha pela rota escolhida e localizar onde anotar cada escolha.
- Resolver um ataque contra um aliado com a resposta do Bastião.
- Explicar quando recupera a Reação e quando pode ganhar Fluidez novamente.
- Distinguir Ação Atacar, ataque adicional e ataque fora do turno.
- Encontrar custo, alvo, alcance e término de uma habilidade do Malabarista.
- Montar um feitiço e conferir todos os seus pontos e custos.
- Encontrar o que a rota sem energia herda e o que substitui.
- Resolver um turno com invocador e entidades sem gastar duas vezes o mesmo recurso.
- Determinar a consequência de uma condição e como ela termina.
- Subir de nível e separar entregas do Caminho, da Trilha e do marco.
- Encontrar uma habilidade procurando pelo nome antigo.
- Consultar a mesma informação no PDF, no texto e na ficha.

A amostra deve incluir pessoas novas e pessoas que já jogam. Comparar acerto, tempo de consulta e necessidade de explicação. Metas de tempo só são fixadas depois da linha de base. Se dois mestres divergem, registrar o trecho que permitiu as duas leituras.

Essas provas não medem equilíbrio de combate. Esse trabalho permanece com a frente de simulação e playtest.

## Fechamento

Depois de estabilizar nomes e texto, produzir a diagramação completa e suas imagens. Conferir visualmente todas as páginas da edição candidata, com inspeção individual dos trechos densos e do que mudou após a última exportação.

A entrega final inclui fonte editorial, PDF, Word de revisão, texto pesquisável, fichas conciliadas, glossário, índice e registro das alterações. O pacote deve dizer o que ainda depende de teste ou decisão.

O commit continua sendo do Mizuki. Preparar a mensagem para o fluxo do repositório e registrar o ponto de retomada.
