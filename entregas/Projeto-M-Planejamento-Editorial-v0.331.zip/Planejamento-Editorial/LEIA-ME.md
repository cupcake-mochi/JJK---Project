# Planejamento editorial do Manual da Guilda

Proposta de 02/10/2026, preparada sobre a v0.331. O planejamento não altera a edição jogável.

Comece por [PLANO-EDITORIAL.md](PLANO-EDITORIAL.md). Ele apresenta o diagnóstico, os vinte capítulos propostos, a revisão de nomes e texto, o plano visual e as etapas.

Os documentos de apoio são:

- [MAPA-DE-MIGRACAO.md](MAPA-DE-MIGRACAO.md): destino das 22 fontes e divisão dos capítulos maiores.
- [PAUTA-DE-DECISOES.md](PAUTA-DE-DECISOES.md): escolhas editoriais, primeira leva de termos e pendências de regras.
- [ROTEIRO-DE-EXECUCAO.md](ROTEIRO-DE-EXECUCAO.md): piloto, lotes, entregas e conferência de preservação.
- [REFERENCIAS-E-DIAGNOSTICO.md](REFERENCIAS-E-DIAGNOSTICO.md): comparação com quatro livros locais e método das medidas.
- [INVENTARIO-BASE.json](INVENTARIO-BASE.json): retrato das fontes e dos artefatos da v0.331.

A próxima etapa recomendada é discutir o sumário e o destino do glossário, depois a primeira leva de nomes estruturais. A reescrita em escala começa após o piloto editorial.

Para trabalhar em outro chat, use o plano com o pacote integrado v0.331 ou com acesso à pasta atual do projeto. Este pacote de planejamento não contém o livro inteiro nem os PDFs de referência. Os links externos à pasta só funcionam no repositório original; nomes, caminhos e localizadores ficam registrados para identificar as fontes.

Se houver versão posterior ou nova entrega de Origens e fichas, concilie-a antes de aplicar este retrato. As propostas de arquitetura e os nomes em discussão não se tornam regras aprovadas por estarem neste documento.
