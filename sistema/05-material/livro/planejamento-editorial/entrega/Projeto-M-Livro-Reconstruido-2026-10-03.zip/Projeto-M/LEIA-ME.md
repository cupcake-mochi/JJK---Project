# Projeto - M — entrega da reconstrução

Comece por Projeto-M-Livro-Completo.pdf e REVISAO-FINAL.md. O PDF reúne o livro inteiro; o Markdown único serve para leitura e transferência para outro editor/chat.

## Conteúdo

- Livro completo em PDF e Markdown.
- Capítulos editáveis em editorial, nos caminhos de ORDEM.json.
- Registros ALTERACOES.json por capítulo, com decisões e motivos.
- Mapa de nomes, validações, evidências e resumo da revisão.
- Gerador e conferidor do livro, com as fontes tipográficas usadas.

A fonte principal são os capítulos. O Markdown reunido é derivado: não o altere esperando que o gerador preserve edições manuais nele. Para recompor o livro, use Python3 com reportlab, pypdf e pdfplumber e execute gerar_livro.py --strict dentro de editorial/consolidacao/lote-01. Depois execute conferir_livro.py. A composição foi reproduzida a partir deste pacote antes da entrega.

Relatórios históricos mantêm o estado da época; a referência vigente é VALIDADORES.json da consolidação, acompanhada de FECHAMENTO-INTEGRACAO.json por capítulo. Os testes históricos podem depender de cópias locais de versões anteriores ou referências que não estão neste pacote. O gerador do livro reunido é autocontido quanto a textos, mapas e fontes; requer apenas as bibliotecas Python indicadas.

Não foram incluídos os PDFs de sistemas de terceiros nem as centenas de imagens de inspeção, que podem ser recriadas a partir do PDF. Nenhuma imagem de IA foi usada. A publicação v0.331 foi preservada, e esta candidata ainda deve passar pela leitura do autor e por testes de mesa.

Confira SHA256SUMS.json para a integridade dos arquivos deste pacote.
