# Projeto - M — entrega da candidata revisada

Comece por Projeto-M-Livro-Completo.pdf e REVISAO-FINAL.md. O PDF reúne o livro inteiro, com 382 páginas; o Markdown único serve para leitura e transferência para outro editor ou chat.

Esta entrega substitui a de 03/10/2026. Depois dela, a revisão pós-reconstrução corrigiu divergências entre capítulos, aplicou decisões do autor e tirou do livro do jogador as contas de projetista, como tempo de campanha, total de XP e médias de dano. Tudo isso está em editorial/revisao-interfaces/CORRECOES-APLICADAS.md, com antes, depois, motivo e efeito na mesa. Os achados que ainda dependem do autor estão em editorial/revisao-interfaces/ACHADOS.md.

## Conteúdo

- Livro completo em PDF e Markdown.
- Capítulos editáveis em editorial, nos caminhos de ORDEM.json.
- Registros ALTERACOES.json por capítulo, com decisões e motivos.
- Registro da revisão de 04/10 em editorial/revisao-interfaces.
- Mapa de nomes, validações, evidências e resumo da revisão.
- Gerador e conferidor do livro, com as fontes tipográficas usadas.

A fonte principal são os capítulos. O Markdown reunido é derivado: não o altere esperando que o gerador preserve edições manuais nele. Para recompor o livro, use Python3 com reportlab, pypdf e pdfplumber e execute gerar_livro.py --strict dentro de editorial/consolidacao/lote-01. Depois execute conferir_livro.py. A composição foi reproduzida a partir deste pacote antes da entrega.

A referência vigente é VALIDADORES.json da consolidação. A inspeção visual do livro atual está em editorial/consolidacao/lote-01/evidencias/FINAL-V14.json, encadeada até a prova completa de 03/10. Relatórios históricos mantêm o estado da época. Os testes históricos podem depender de cópias locais de versões anteriores ou de referências que não estão neste pacote; o gerador do livro reunido é autocontido quanto a textos, mapas e fontes.

Não foram incluídos os PDFs de sistemas de terceiros, os PDFs individuais dos capítulos nem as imagens de inspeção, que podem ser recriados. Nenhuma imagem de IA foi usada. A publicação v0.331 foi preservada, e esta candidata ainda deve passar pela leitura do autor e por testes de mesa.

Confira SHA256SUMS.json para a integridade dos arquivos deste pacote.
