from pathlib import Path
import json,re,unicodedata,hashlib
R=Path('/media/mizuki/HD Externo II/Claude/Claude 2');P=R/'sistema/05-material/livro/planejamento-editorial';B=P/'consulta/lote-01';E=B/'evidencias'
# The reference target is the title plus a file/anchor pair. Final physical pages are not authored here.
files={
 'testes':'regras-gerais/lote-final/REGRAS-GERAIS.md','ataques':'regras-gerais/lote-final/REGRAS-GERAIS.md','dano':'dano-e-recuperacao/lote-final/DANO-E-RECUPERACAO.md','recuperacao':'dano-e-recuperacao/lote-final/DANO-E-RECUPERACAO.md','comuns':'regras-gerais/lote-final/REGRAS-GERAIS.md','movimento':'regras-gerais/lote-final/REGRAS-GERAIS.md','pericias':'pericias-e-oficios/lote-01/PERICIAS-E-OFICIOS.md',
 'fundamento':'fundamento/lote-01/FUNDAMENTO.md','catalogo':'catalogo/lote-01/CATALOGO.md','poderes':'poderes-avancados/lote-01/PODERES-AVANCADOS.md','aptidoes':'aptidoes/lote-01/APTIDOES-E-REFINO.md','rotas':'rotas/lote-01/ROTAS.md','ritual':'ritual-e-pactos/lote-01/RITUAL-E-PACTOS.md',
 'campo':'invocacoes/lote-01/INVOCACOES-EM-CAMPO.md','entidades':'invocacoes/lote-02/CONSTRUIR-INVOCACOES.md','fabricacao':'invocacoes/fabricacao/lote-01/FABRICACAO-DE-ENTIDADES.md','origens':'origens/lote-01/ORIGENS-E-LEGADOS.md','progressao':'progressao/lote-01/PROGRESSAO.md','criacao':'abertura/lote-01/ABERTURA-E-CRIACAO.md',
 'equipamento':'equipamento/lote-01-r5/EQUIPAMENTO-EM-JOGO.md','protecao':'equipamento/lote-02-r3/PROTECAO.md','municao':'equipamento/lote-03-r5/MUNICAO.md','armas':'equipamento/lote-04-r4/ARMAS.md','itens':'equipamento/lote-05-r1/ITENS-E-OBJETOS.md','compras':'equipamento/lote-06-r1/COMPRAS-E-EQUIPAMENTO-INICIAL.md','ferramentas':'equipamento/lote-08/EQUIPAMENTO-AMALDICOADO.md',
 'bastiao':'caminhos/bastiao/lote-01/BASTIAO.md','vanguarda':'caminhos/vanguarda/lote-01/VANGUARDA.md','guia':'caminhos/guia/lote-01/GUIA.md','emanador':'caminhos/emanador/lote-01/EMANADOR.md','evocador':'caminhos/evocador/lote-01/EVOCADOR.md','incursor':'caminhos/incursor/lote-01/INCURSOR.md'}
# Equipamento foi consolidado; preserve o segmento e traduza âncoras antigas pelo mapa do dono.
equipment_legacy=files.copy()
equipment_map=json.loads((P/'equipamento/lote-final/FONTES.json').read_text())['mapeamento_ancoras']
for key,file in list(files.items()):
 if file.startswith('equipamento/'):
  files[key]='equipamento/lote-final/EQUIPAMENTO.md'
sections={}
for key,file in files.items():
 text=(P/file).read_text();parts=re.split(r'<!-- page:([^|]+)\|([^>]+) -->\s*',text)
 sections[key]=[{'arquivo':file,'ancora':parts[i],'titulo':parts[i+1],'texto':parts[i+2]} for i in range(1,len(parts),3)]
 if equipment_legacy[key].startswith('equipamento/'):
  allowed=set(equipment_map[equipment_legacy[key].removeprefix('equipamento/')].values());sections[key]=[x for x in sections[key] if x['ancora'] in allowed]
def target(key,anchor=None,term=None):
 candidates=sections[key]
 if anchor and equipment_legacy[key].startswith('equipamento/'):
  anchor=equipment_map[equipment_legacy[key].removeprefix('equipamento/')].get(anchor,anchor)
 if anchor: result=next(x for x in candidates if x['ancora']==anchor)
 elif term: result=next(x for x in candidates if term.casefold() in x['texto'].casefold())
 else: result=candidates[0]
 return {k:v for k,v in result.items() if k!='texto'}
G=[]
def g(term,definition,key,anchor=None,search=None):G.append({'termo':term,'definicao':definition,'destino':target(key,anchor,search)})
g('Ação','Recurso usado para executar uma tarefa. Padrão, Bônus e Movimento têm usos distintos; a Reação responde a um gatilho.','testes','turnos')
g('Ação Bônus','Recurso gasto em uma opção que declare esse custo. Não torna uma tarefa gratuita nem fornece uma habilidade por si.','testes','turnos')
g('Ação Completa','Custo que compromete Padrão, Bônus e Movimento do turno. Também aparece em textos anteriores como Rodada inteira.','testes','turnos')
g('Ação de Movimento','Recurso que permite percorrer o deslocamento ou pagar uma tarefa com esse custo. Não é uma medida em metros.','testes','turnos')
g('Ação Padrão','Recurso usado por ações como Atacar, Conjurar e Ajudar, salvo custo próprio indicado na capacidade.','testes','acoes')
g('Alcance','Distância permitida até um alvo ou ponto de origem. A ficha informa de onde medir.','fundamento','alcance')
g('Ampliar','Usar uma aplicação conhecida numa Classe maior pelo procedimento de sua rota.','fundamento',search='# Ampliar')
g('Área','Espaço ocupado por um efeito, como uma esfera ou um cone. Alcance e tamanho de área são medidas diferentes.','fundamento','alcance')
g('Aptidão','Capacidade do catálogo de Aptidões e Refino, adquirida quando a ficha cumpre seus requisitos.','aptidoes')
g('Atributo','Valor da ficha usado por testes e capacidades. O próprio número anotado serve de modificador quando a regra o pede.','testes','atributos')
g('Ataque','Tentativa de atingir um alvo com rolagem de acerto. Um ataque concedido não equivale necessariamente à Ação Atacar completa.','ataques','ataques')
g('Atuação básica','Recurso da entidade usado para uma ação ou capacidade básica, ou comprometido pelo comando de uma especial.','campo','inv-basica')
g('Bênção','Capacidade da rota sem energia amaldiçoada. Seu acesso segue Lapidação e os requisitos de sua entrada.','rotas','rota-bencaos')
g('Caminho','Conjunto das capacidades principais de combate do personagem. A Trilha desenvolve uma especialidade dentro dele.','criacao','ab-caminho')
g('Carga','Conjunto de objetos transportados e sua ocupação, medida em Volume.','movimento','carga')
g('CD','Classe de Dificuldade: valor que uma rolagem precisa igualar ou superar. O procedimento define a CD ou explica como determiná-la.','testes','testes')
g('Cena','Trecho de jogo organizado em torno de uma situação. Sua passagem depende do que ocorre na ficção, não de uma quantidade fixa de turnos.','recuperacao','usos')
g('Classe','Escala de uma aplicação, como feitiço, Manejo ou Kata. Determina seu orçamento e seus limites. Não é o Caminho do personagem.','fundamento','pontos')
g('Classe 0','Aplicação de escala própria, registrada separadamente dos espaços conhecidos comuns.','fundamento','classezero')
g('Categoria de Efeito','Escala usada por Talentos, Aptidões e Bênçãos, abreviada CE. Cada entrada informa seus requisitos e sua aquisição. Não é a Classe de um feitiço.','fundamento','selo')
g('Concentração','Manutenção de um efeito que exige essa atenção. Seu procedimento define interrupção e testes; preparações como Carregar têm regras próprias.','testes','concentracao')
g('Condição','Estado nomeado que altera capacidades ou ações. Sua entrada e a fonte que o aplicou definem consequências e término.','dano','condicoes')
g('Crítico','Acerto que recebe o tratamento especial de dados previsto em Combate. Nem todo dado adicional acompanha a duplicação.','ataques','critico')
g('Defesa','Valor comparado à rolagem de ataque. Não é um Teste de Resistência nem redução de dano.','ataques','defesa')
g('Derrotado','Estado que encerra a participação ativa na cena. Recuperar reservas não devolve essa participação; consulte o procedimento de saída.','recuperacao','derrota')
g('Deslocamento','Distância que o personagem pode percorrer com uma Ação de Movimento, antes dos custos do terreno e demais alterações.','comuns','movimento')
g('Desvantagem','Rolagem de dois d20 que usa o menor. Seu encontro com vantagem segue Testes.','testes','pericias')
g('Duração','Prazo de um efeito. Registre a quem o turno se refere e qual evento termina o efeito.','fundamento','conjurar')
g('Entidade','Criatura com ficha própria obtida por uma das formas de aquisição de Invocações.','entidades','entidades-criar')
g('Especial de invocação','Capacidade executada pela entidade mediante comando, com requisitos, ação e pagamento próprios.','campo','inv-especial')
g('Estabilizar','Socorro que interrompe a perda de tempo da janela de queda enquanto suas condições forem mantidas. Não recupera vida nem acorda o alvo.','recuperacao','socorro')
g('Espaço conhecido','Vaga usada por uma aplicação ou outra opção que expressamente a ocupe. Não é uma carga que se gasta a cada conjuração.','fundamento','repertorio')
g('Exaustão','Consequência ligada a esforço e recuperação, com procedimento próprio. Não é uma Condição comprável do catálogo.','recuperacao','exaustao')
g('Expressão da técnica','Manifestação de aparência ou expressão ligada ao conceito da técnica, dentro dos limites de sua entrada.','fundamento','selo')
g('Família','Grupo de Melhorias. As escolhas de acesso e desconto dependem da rota e da ficha que está sendo montada.','fundamento','familias')
g('Feitiço','Aplicação preparada de uma técnica, com efeito, custo e requisitos registrados.','fundamento','primeiro')
g('Ferramenta amaldiçoada','Equipamento que carrega energia própria. Seu grau e sua ficha definem se possui um efeito especial.','ferramentas','equipamento')
g('Forma','Peça que define a aplicação inicial: alvos, origem, alcance e resolução, conforme sua entrada.','fundamento','formas')
g('Fundamento','Conceito e funcionamento que sustentam as aplicações de uma técnica. O capítulo também apresenta o processo de montagem.','fundamento','fundamento')
g('Gatilho','Evento necessário para uma resposta ou efeito. Possuir um recurso disponível não dispensa esse evento.','testes','oportunidade')
g('Grau','Termo usado na patente e na classificação de ferramentas. A ficha informa qual escala está sendo usada; uma não concede a outra.','ferramentas','graus')
g('Inconsciente','Estado de quem perdeu a consciência. A regra que o causou determina como sair dele.','dano','inconsciente')
g('Integridade','Recurso usado pelas regras de alma. Seus efeitos e recuperação têm procedimento próprio.','dano','integridade')
g('Intenção','Tarefa compreensível que orienta a entidade. Não é, por si, um comando para executar uma especial.','campo','inv-intencao')
g('Invocador','Personagem responsável pelas entidades que adquiriu. Os custos distinguem seus recursos dos recursos de cada corpo.','campo','inv-campo')
g('Invocação','Aquisição e atuação de uma entidade. Manifestar uma entidade conhecida não cria outra ficha.','entidades','entidades-aquisicao')
g('Kata','Aplicação montada pela rota de Técnica Marcial.','rotas','rota-marcial')
g('Lapidação','Progressão de controle corporal da rota sem energia amaldiçoada. Não concede Refino pessoal.','rotas','rota-lapidacao')
g('Legado','Escolha da Origem que registra uma capacidade ou vínculo. Cada entrada informa seu tipo e suas consequências.','origens')
g('Leve, Média e Pesada','Nomes de faixas de preço e também de categorias de Condição. Consulte a tabela correspondente; pontos de montagem e PE não são a mesma conta.','fundamento','pontos')
g('Maestria','Bônus ligado ao nível. Só entra nas rolagens e valores que indiquem seu uso.','testes','atributos')
g('Manejo','Aplicação criada a partir da semente de quem segue Sem Técnica.','rotas','rota-sem-tecnica')
g('Marco','Nível que entrega escolhas adicionais de progressão. As opções e suas condições ficam em Progressão.','progressao','prog-marcos')
g('Melhoria','Peça comprada na montagem para alterar a aplicação ou acrescentar um efeito permitido.','fundamento','pontos')
g('Movimento imposto','Deslocamento provocado por outra criatura ou efeito. O procedimento de movimento o distingue do percurso voluntário.','comuns','quedas')
g('Morrendo','Situação tratada pelas regras de queda e recuperação. Consulte seu procedimento antes de aplicar custos, prazos ou saídas.','recuperacao','zero')
g('Nível','Medida de progressão da ficha. É distinto da patente, da Classe da aplicação e do grau de um item.','progressao')
g('Ofício','Prática aprendida com atributo definido pela tarefa. Seu procedimento informa treino, ferramentas e tentativas permitidas.','pericias','oficios')
g('Origem','Escolha de criação que reúne traço, Legados, treinos e opções de rota do personagem.','origens')
g('Pacto','Acordo ou compromisso com benefício e preço definidos pelo procedimento de Pactos.','ritual',search='# Pactos')
g('Talento','Capacidade adquirida cujo funcionamento e investimento seguem sua Categoria de Efeito. Uma entrada reativa ainda pode exigir ação ou gatilho.','fundamento','selo')
g('Patente','Reconhecimento do personagem no meio jujutsu, expresso por Grau. Não substitui nível nem requisito de uma capacidade.','progressao','prog-patentes')
g('PE','Pontos de energia. Na rota sem energia amaldiçoada, a sigla representa Pontos de Esforço, conforme aquela rota.','rotas','rotas')
g('Perícia','Capacidade de realizar um tipo de tarefa, associada ao atributo indicado em sua entrada.','pericias')
g('Pontos de montagem','Orçamento usado para preparar uma aplicação. Não são os PE cobrados quando ela é usada.','fundamento','pontos')
g('Proteção','Parcela da Defesa fornecida por equipamento ou capacidade, com regras próprias de combinação.','protecao')
g('PV','Pontos de vida. Registre o valor atual separado do máximo. Vida temporária é anotada à parte.','dano')
g('Reação','Recurso gasto em uma resposta permitida por um gatilho. Sua recuperação ocorre no começo do próprio turno.','testes','oportunidade')
g('Reação coletiva','Recurso compartilhado pelas entidades, separado da Reação pessoal do invocador.','campo','inv-ciclo')
g('Redução de Dano','Valor descontado durante a resolução do dano quando sua fonte permitir. Não aumenta a Defesa. Abreviação: RD.','dano','reducao')
g('Refino','Progressão de controle de energia amaldiçoada, usada pelas aptidões e pelos requisitos que o indicam.','aptidoes')
g('Regra da técnica','Frase que delimita o funcionamento do poder e orienta quais aplicações cabem no conceito.','fundamento','tecnica')
g('Restrição','Exigência adicional da montagem que pode devolver pontos quando impõe uma limitação válida.','fundamento','restricoes')
g('Ritual','Procedimento que reforça uma conjuração com preparação e requisitos próprios. Não é um nome geral para qualquer uso de energia.','ritual','ritual')
g('Rodada','Passagem da ordem de iniciativa do combate. Turno é o momento de atuação de um participante dentro dela.','testes','turnos')
g('Selo','Ato ou requisito que acompanha a conjuração de uma técnica. A rota pode usar equipamento como seu Selo.','fundamento','selo')
g('Sem Técnica','Rota que cria Manejos a partir de uma semente. Ausência de Técnica Inata não significa ausência de energia amaldiçoada.','rotas','rota-sem-tecnica')
g('Técnica amaldiçoada','Poder com funcionamento próprio que sustenta suas aplicações. As opções do sistema distinguem suas rotas de criação.','criacao','ab-mundo')
g('Técnica Marcial','Rota de criação de Katas sustentadas por um estilo e seu equipamento.','rotas','rota-marcial')
g('Técnica Máxima','Aplicação avançada com montagem e uso próprios. Pode ter finalidade ofensiva, de cura ou utilidade conforme suas regras.','fundamento',search='# Técnica Máxima')
g('Teste de Resistência','Rolagem de quem tenta evitar ou encerrar um efeito. A regra indica o atributo, a CD e o resultado de sucesso ou falha. Abreviação: TR.','testes','resistencia')
g('Traço','Característica narrativa concedida pela Origem, com o alcance descrito em sua entrada.','origens')
g('Treino','Qualificação registrada para perícia, ofício, TR ou equipamento. Cada tipo explica o que o treino permite.','testes','pericias')
g('Trilha','Especialidade escolhida dentro de um Caminho.','criacao','ab-caminho')
g('Turno','Momento de atuação de um participante. Prazos como começo do seu próximo turno se referem ao participante indicado.','testes','turnos')
g('Uso limitado','Capacidade com quantidade e recuperação próprias. Registre o que foi gasto e qual evento devolve o uso.','criacao','ab-conferencia')
g('Vantagem','Rolagem de dois d20 que usa o maior. Várias fontes não acrescentam novos dados por si.','testes','pericias')
g('Vida temporária','Reserva separada dos PV atuais e máximos, sujeita aos limites e ao prazo de Dano e Recuperação.','recuperacao','temporarios')
g('Volume','Medida de carga usada pelo inventário. É distinta de uma propriedade de manejo da arma.','movimento','carga')
# Early manuscript: all principal sections before the alphabetical index.
norm=lambda s: ''.join(c for c in unicodedata.normalize('NFD',s.casefold()) if not unicodedata.combining(c))
G.sort(key=lambda x:norm(x['termo']))
parts=[]
def page(id,title,body):parts.append(f'<!-- page:{id}|{title} -->\n# {title}\n\n'+body.strip()+'\n')
start=0
for gi,size in enumerate([15,15,15,15,15,14]):
 i=start;chunk=G[start:start+size];start+=size;title='Glossário: '+chunk[0]['termo'].split()[0]+' a '+chunk[-1]['termo'].split()[0]
 body='\n\n'.join('**'+x['termo']+'.** '+x['definicao']+' **Consulta:** '+x['destino']['titulo']+'.' for x in chunk)
 page('consulta-glossario-'+str(gi+1),title,body)
page('consulta-testes','Testes na mesa','''
| Situação | Procedimento |
|---|---|
| Tentativa com resultado incerto | Identifique a tarefa, o atributo e o treino aplicável. Role d20 + bônus e compare com a CD. Igualar é sucesso. |
| Ataque | Quem ataca rola contra a Defesa. Confira alcance, requisitos e respostas antes de aplicar o resultado. |
| Teste de Resistência | Quem sofre o efeito rola o TR indicado contra a CD. A ficha do efeito informa o resultado. |
| Bônus já calculado | Some o valor completo uma vez. Não acrescente o atributo ou a Maestria novamente. |

**Vantagem:** dois d20, use o maior. **Desvantagem:** dois d20, use o menor. Havendo ambas, elas se cancelam, mesmo com várias fontes de um lado. Acrescente o bônus depois de escolher o dado.

## Recursos do turno

| Recurso | Conferência |
|---|---|
| Ação Padrão | Qual tarefa você vai executar e quais requisitos ela tem? |
| Ação Bônus | Existe uma opção que permite esse uso? |
| Ação de Movimento | Quantos metros ou qual tarefa inteira ela vai pagar? |
| Reação | O gatilho aconteceu e o recurso ainda está disponível? |

A Reação volta no começo do seu turno. A mudança de rodada não a recupera. Ação Completa compromete Padrão, Bônus e Movimento; conserva a Reação.

**Conversões:** Padrão → Bônus → Movimento. Cada conversão gasta o recurso anterior. Ela não devolve usos nem altera requisitos de uma habilidade.

Antes de passar a vez, confira efeitos com prazo no fim do turno e anote recursos gastos. **Consulta:** Testes; Turnos; Reações e ataques de oportunidade; Concentração.
''')
page('consulta-ataques','Ataques e efeitos','''
## Ataque com rolagem

1. Declare a capacidade e o alvo. Confira alcance, posição, equipamento e custos.
2. Resolva as respostas que precisam ocorrer antes da rolagem.
3. Role o ataque. Resolva a Defesa ou a escolha de Bloquear, quando permitida.
4. Confira acerto, crítico e os resultados especiais de Bloquear.
5. Aplique o dano e os demais efeitos que cabem naquele resultado. Depois, resolva as respostas posteriores.

Cada ataque recebe sua própria resolução. Um ataque adicional não concede automaticamente uma nova Ação Atacar. **Consulta:** Ataques; Bloquear; Aparar e Brecha; Dano e crítico.

## Efeito com TR

Quem recebe o efeito faz o teste indicado. Compare com a CD da capacidade e use sua consequência de sucesso ou falha. Bloquear não substitui esse teste. Sucesso no TR não significa metade de todo dano: depende da regra aplicada.

## Registro de duração

| Anote | Exemplo de registro |
|---|---|
| Origem e alvo | Qual ficha aplicou o efeito e quem o recebeu. |
| Término | Começo do próximo turno de quem conjurou; ou outro prazo da capacidade. |
| Saída antecipada | Teste, interrupção, distância ou outro evento que encerra o efeito. |
| Recurso comprometido | Concentração, uso limitado ou preparação em andamento. |

Use um marcador junto do participante a cujo turno o prazo se refere. Um efeito que termina no começo do turno não dura até o fim dele.

Ao sofrer dano, siga Dano e Recuperação para os recursos atingidos, a queda e suas consequências. Efeitos sobre Integridade seguem o procedimento de alma. A ficha da capacidade continua sendo a referência para exceções.
''')
page('consulta-entidades','Entidades na mesa','''
Mantenha uma linha para cada corpo, inclusive quando estiver guardado. A ficha da entidade registra suas capacidades; esta folha acompanha o que já ocorreu na cena.

| Corpo | Básica e Movimento | Tarefa e pendências |
|---|---|---|
| __________________ | __________________ | __________________ |
| __________________ | __________________ | __________________ |
| __________________ | __________________ | __________________ |
| __________________ | __________________ | __________________ |

Registre **Reação pessoal do invocador** e **Reação coletiva das entidades** em campos separados. As linhas extras servem para reserva ou permissões específicas; não aumentam a quantidade de entidades ativas.

## Começo do ciclo

Confira os recursos renovados pelas regras de Turnos das entidades, os efeitos de começo de turno e as ordens pendentes. Um ciclo vai do começo de seu turno até o começo do próximo.

## Antes de uma execução

Identifique o corpo, a atuação disponível e a instrução recebida. Para uma especial, confira o comando, a comunicação, a básica comprometida e quem paga cada parcela de PE. Anote a preparação no momento em que a ordem for paga; a resolução posterior conserva esse registro.

## Entrada, troca e saída

Anote posição, custo e tarefa. Na troca, confira se existe uma básica que possa ser transferida. Entrar e sair não limpa usos gastos nem cria outro ciclo. Preserve o histórico do corpo recolhido.

Ao encerrar a cena ou o combate, confira manutenção, corpos que permanecem, equipamentos e efeitos pendentes antes de apagar marcadores. **Consulta:** Invocações em campo; Turnos das entidades; Trocar de entidade; Comandar uma especial; Energia das entidades; Manutenção.
''')
page('consulta-ficha-personagem','Ficha de personagem','''
**Nome:** ____________________ **Jogador:** ____________________

**Campanha ou guilda:** ____________________ **Versão das regras:** ____________________

| Identidade | Registro |
|---|---|
| Origem, traço e Legados | ________________________________________ |
| Caminho, Trilha e nível | ________________________________________ |
| Patente | ________________________________________ |
| Rota de capacidades | ________________________________________ |
| Vínculos e motivo para acompanhar o grupo | ________________________________________ |

**Atributos:** Força ______ · Destreza ______ · Constituição ______

Inteligência ______ · Essência ______

| Teste de Resistência | Atributo usado, treino e bônus completo |
|---|---|
| Físico | ________________________________________ |
| Vigor | ________________________________________ |
| Intelecto | ________________________________________ |
| Espírito | ________________________________________ |

| Recursos e valores | Atual | Máximo ou cálculo |
|---|---|---|
| PV | ______ | __________________ |
| Vida temporária | ______ | Origem e término: __________________ |
| PE, energia ou esforço | ______ | __________________ |
| Energia temporária | ______ | Origem e término: __________________ |
| Integridade | ______ | __________________ |
| Defesa | ______ | Base, proteção, Destreza e outros: __________________ |
| Bloquear | ______ | __________________ |
| Iniciativa | ______ | __________________ |
| Deslocamento e modos | ______ | __________________ |

**Maestria:** ______ **Refino ou Lapidação, conforme a rota:** ______

**XP disponível:** ______ **Custo do próximo nível:** ______

**Posição da próxima missão na semana:** ______ **Feito de limiar, se necessário:** __________________

Use Criar um personagem e os capítulos de sua Origem e Caminho para preencher os valores. Um campo disponível não concede o recurso a uma rota que não o possua.
''')
page('consulta-ficha-repertorio','Repertório e inventário','''
**Personagem:** ____________________ **Data da atualização:** ____________________

## Treinos e capacidades

| Registro | Nome, bônus completo e referência |
|---|---|
| Perícias e especializações | ________________________________________ |
| Ofícios e especializações | ________________________________________ |
| Treino com armas | ________________________________________ |
| Aptidões ou Bênçãos | ________________________________________ |
| Habilidades de Caminho, Trilha e Origem | ________________________________________ |

| Repertório | Espaços ocupados | Referência da ficha |
|---|---|---|
| Feitiços, Manejos ou Katas | ______ | __________________________ |
| Talentos pagos | ______ | __________________________ |
| Entidades por espaço e outras ocupações | ______ | __________________________ |
| Total ocupado / disponível | ______ / ______ | __________________________ |

**Classe 0 e capacidades fora da conta:** ________________________________________

## Ataques registrados

| Arma ou ataque | Acerto | Dano, alcance e requisitos |
|---|---|---|
| __________________ | ______ | __________________________ |
| __________________ | ______ | __________________________ |

## Equipamento

| Item e quantidade | Volume total | Situação e recursos |
|---|---|---|
| __________________ | ______ | Vestido, empunhado ou guardado: __________________ |
| __________________ | ______ | Munição, cargas ou usos: __________________ |
| __________________ | ______ | Empréstimo e devolução: __________________ |

**Volume carregado / limite:** ______ / ______ **Dinheiro:** __________________

Anote munição carregada e reserva separadamente. Ferramentas precisam de grau, efeito, requisitos e usos próprios. Um efeito guardado não deve aparecer como benefício ativo sem permissão.

## Recursos de sessão

**Padrão:** ______ **Bônus:** ______ **Movimento restante:** ______ **Reação:** ______

**Condições, efeitos e términos:** ________________________________________

**Usos limitados, Pactos e obrigações:** ________________________________________

Anote o nome da capacidade e seu destino no livro. Acrescente folhas para o repertório completo, sem substituir requisitos por uma abreviação que você não consiga consultar.
''')
page('consulta-ficha-feitico','Ficha de aplicação','''
Use este modelo para um feitiço, Manejo ou Kata. Invocações possuem orçamento e escalas próprios, registrados em Ficha de capacidades da entidade.

**Nome:** ____________________ **Técnica, semente ou estilo:** ____________________

**Regra do poder:** ___________________________________________________________

**Rota e atributo:** ____________________ **Selo ou equipamento:** ____________________

**Famílias Livres e Fechadas:** ________________________________________________

| Montagem | Registro |
|---|---|
| Classe e tipo de aplicação | ________________________________________ |
| Forma e preço | ________________________________________ |
| Melhorias e preços, após descontos | ________________________________________ |
| Restrições e devoluções válidas | ________________________________________ |
| Orçamento, gasto, devolução aproveitada e saldo | ________________________________________ |
| Limite de dados e repetições conferido | ________________________________________ |
| Espaço ocupado ou forma de aquisição | ________________________________________ |

| Uso | Registro |
|---|---|
| Ação, PE e demais custos | ________________________________________ |
| Momento e frequência | ________________________________________ |
| Origem, alcance, área e alvos | ________________________________________ |
| Ataque, TR ou outra resolução | ________________________________________ |
| Dados, tipo de dano, cura ou outro resultado | ________________________________________ |
| Efeito no sucesso e na falha | ________________________________________ |
| Duração, concentração e saída | ________________________________________ |

**Texto completo do efeito:** __________________________________________________

____________________________________________________________________________

**Opções ao Ampliar, quando permitidas:** ________________________________________

**Conferência e data:** ________________________________________________________

Registre aplicações avançadas em fichas próprias, com seus limites e recargas. Os valores de Fundamento, da rota e da capacidade usada determinam quais campos se aplicam. O espaço para escrever uma opção não dispensa adquirir essa opção.
''')
page('consulta-ficha-entidade','Ficha de entidade','''
**Nome:** ____________________ **Invocador:** ____________________

| Aquisição e corpo | Registro |
|---|---|
| Aquisição, data e responsável | ________________________________________ |
| Espaço ocupado, vínculo ou registro da conquista | ________________________________________ |
| Origem, tipo e nível | ________________________________________ |
| Evolução permitida pela aquisição | ________________________________________ |
| Definição e função | ________________________________________ |
| Tamanho, anatomia e manipulação de objetos | ________________________________________ |
| Sentidos e comunicação | ________________________________________ |
| Deslocamento e modos especiais adquiridos | ________________________________________ |
| Talismã, corpo ou local de reserva | ________________________________________ |

| Atributos e testes | Registro |
|---|---|
| Força / Destreza / Constituição | ______ / ______ / ______ |
| Inteligência / Essência | ______ / ______ |
| Atributo de ataque, bônus e CD | ________________________________________ |
| TR Físico: atributo fixo e bônus | ________________________________________ |
| Vigor / Intelecto / Espírito | ______ / ______ / ______ |
| TR treinado e perícias | ________________________________________ |
| Defesa e origem de cada parcela | ________________________________________ |
| PV atuais / máximos | ______ / ______ |
| Integridade atual / máxima, quando aplicável | ______ / ______ |
| Reserva própria, se houver, atual / máxima | ______ / ______ |

**Famílias abertas e Família Livre:** ____________________________________________

**Equipamento e Volume carregado:** ____________________________________________

A capacidade de perceber, mover ou comunicar algo extraordinário precisa estar sustentada pela ficha. A aparência não concede outro modo de movimento. **Consulta:** Criar uma invocação; Definição e corpo; Atributos e testes; Vida e Defesa.
''')
page('consulta-ficha-entidade-capacidades','Ficha de capacidades da entidade','''
**Entidade:** ____________________ **Nível:** ______ **Revisão:** ____________________

| Repertório | Nome e referência |
|---|---|
| Básicas conhecidas | ________________________________________ |
| Espaços de especiais ocupados / disponíveis | ______ / ______ |
| Especiais conhecidas | ________________________________________ |
| Talentos e Categoria de Efeito | ________________________________________ |
| Trunfos adquiridos, quando permitidos | ________________________________________ |

## Capacidade

**Nome e tipo:** ____________________ **Classe ou CE:** ______

| Montagem | Registro |
|---|---|
| Forma, Melhorias e Restrições | ________________________________________ |
| Preços, desconto Livre e devoluções aproveitadas | ________________________________________ |
| Saldo, conversão e limites da entidade | ________________________________________ |
| Origem, alcance, área e alvos | ________________________________________ |
| Resolução e efeito completo | ________________________________________ |
| Duração, concentração e saída | ________________________________________ |

| Execução | Registro |
|---|---|
| Ação do invocador e atuação da entidade | ________________________________________ |
| PE: total e parcela de cada pagador | ________________________________________ |
| Comunicação e outros requisitos | ________________________________________ |
| Gatilho, preparação ou ordem pendente | ________________________________________ |
| Frequência, recarga e término fora de campo | ________________________________________ |

**Conferência e data:** ________________________________________________________

Use uma cópia para cada capacidade. Conhecer mais de uma básica amplia as escolhas; o registro não fornece outra atuação. Uma reserva de PE própria só existe quando a regra da entidade a concede.

**Consulta:** Habilidades básicas; Habilidades especiais; Formas da entidade; Saldo e limites; Comandar uma especial; Energia das entidades.
''')
page('consulta-ficha-recuperacao','Ficha de recuperação','''
**Personagem:** ____________________ **Cena e data:** ____________________

| Reservas | Atual | Máximo |
|---|---|---|
| Vida | ______ | ______ |
| Integridade, quando aplicável | ______ | ______ |

**Estágio de Integridade:** ______ **Sequelas atuais:** ______

**Condições e outras causas de inconsciência:** __________________________________

## Queda em andamento

| Registro | Valor ou descrição |
|---|---|
| Causa e momento da queda | ________________________________________ |
| Máximo de referência da queda | ________________________________________ |
| Sequelas antes desta queda | ________________________________________ |
| Escolha: Aguentar ou Insistir | ________________________________________ |
| Janela inicial / restante | ______ / ______ |
| Ponto da iniciativa para a contagem | ________________________________________ |
| Tratamento necessário / acumulado | ______ / ______ |
| Estável? Momento e origem do socorro | ________________________________________ |
| Máximo perdido por Insistir | ________________________________________ |
| Custos já pagos / próximo pagamento | ________________________________________ |

## Atendimento e desfecho

| Momento e fonte | Cura válida ou outro atendimento | Consequência registrada |
|---|---|---|
| __________________ | __________________ | __________________ |
| __________________ | __________________ | __________________ |
| __________________ | __________________ | __________________ |

**Queda encerrada? Sequela registrada?** ________________________________________

**Derrotado? Causa e condição para sair desse estado:** ___________________________

**Descanso concluído e recursos recuperados:** __________________________________

Use uma folha para cada queda ou risque o registro anterior de forma identificável. Anote o tratamento separadamente da vida até cumprir o procedimento de Socorro. Uma reserva recuperada não significa, por si, que a pessoa acordou ou voltou à cena.

**Consulta:** Vida a zero; Insistir; Socorro; Sequelas e Cicatrizes; Derrota e morte; Inconsciente; Estágios de Integridade; Descansos.
''')
page('consulta-registro-missao','Registro de missão','''
**Missão:** ____________________ **Data:** ____________________

**Mestre e participantes:** ____________________________________________________

**Versão das regras e ajustes da campanha:** ____________________________________

**Objetivo recebido:** _________________________________________________________

**Resultado e consequências:** __________________________________________________

| Personagem | Recursos ao chegar | Recursos ao sair |
|---|---|---|
| __________________ | __________________ | __________________ |
| __________________ | __________________ | __________________ |
| __________________ | __________________ | __________________ |
| __________________ | __________________ | __________________ |

Registre PV, PE, Integridade e efeitos persistentes relevantes, sem presumir recuperação por terminar a sessão.

| Alteração | Registro e responsável |
|---|---|
| Dinheiro e recompensa de XP antes dos ajustes | ________________________________________ |
| Posição semanal, ajustes e XP recebido | ________________________________________ |
| XP gasto no avanço, saldo e feito de limiar | ________________________________________ |
| Itens obtidos, consumidos, perdidos ou emprestados | ________________________________________ |
| Munição e recursos de ferramentas | ________________________________________ |
| Entidades obtidas, caídas, destruídas ou transferidas | ________________________________________ |
| Pactos, favores, obrigações e alterações permanentes | ________________________________________ |
| Descanso realizado e recuperação efetivamente aplicada | ________________________________________ |

**Decisão de regra tomada durante a mesa:** _____________________________________

**Fonte consultada e situação em que valeu:** ____________________________________

**Pendência para a organização ou próxima sessão:** ______________________________

**Conferência com os jogadores:** _______________________________________________

Registre o destino de itens compartilhados para que duas fichas não recebam a mesma peça por engano. Uma pendência de interpretação deve acompanhar o registro, sem virar alteração permanente silenciosa. **Consulta:** Progressão; Dano e Recuperação.
''')
page('consulta-missao','Preparar uma missão','''
Comece por uma situação que peça ação dos personagens. Defina o que aconteceu, quem precisa de ajuda e o que pode piorar se ninguém agir. O objetivo apresentado aos jogadores deve ser reconhecível: encontrar uma pessoa, retirar sobreviventes, recuperar um objeto ou interromper uma ameaça.

## Material de preparação

| Anote | Para usar na mesa |
|---|---|
| Lugar | Acessos, saídas, obstáculos e o que os personagens conseguem perceber ao chegar. |
| Pessoas envolvidas | O que querem, o que sabem e como podem reagir às escolhas do grupo. |
| Pistas | O que cada descoberta revela e onde essa informação pode ser encontrada. |
| Perigos | Fichas completas, regras envolvidas e sinais que o grupo pode reconhecer. |
| Consequências | O que muda com sucesso, demora, recuo ou abandono. |

Prepare as fichas dos perigos antes da sessão. A descrição de uma maldição não substitui seus números. Use as referências de combate para resolver o encontro, sem conceder uma nova capacidade ao inimigo apenas para anular uma boa escolha dos jogadores.

## Escolhas do grupo

Conheça o objetivo e os obstáculos. Deixe o grupo propor os meios. Para alcançar uma sala, eles podem negociar a entrada, procurar outra passagem ou enfrentar quem a guarda. Uma nova abordagem pede que você avalie o que mudou na situação, os recursos usados e a regra pertinente.

Se uma informação for necessária para encontrar o próximo lugar, prepare maneiras diferentes de descobri-la. Uma falha pode mudar o tempo disponível ou chamar atenção, quando o procedimento permitir, sem tornar toda a missão impossível por uma única pista perdida.

**Exemplo:** o grupo precisa retirar dois funcionários de uma estação. O porteiro conhece a escada de serviço; uma planta na sala de manutenção mostra o mesmo acesso. A ameaça vigia o corredor principal. A equipe decide como chegar e como conduzir a retirada.

As capacidades dos personagens e a situação podem tornar uma solução inviável. Explique o impedimento que eles conseguem perceber e peça a próxima decisão. Não é necessário acrescentar uma rolagem a toda ação.
''')
page('consulta-conduzir','Mestrar uma sessão','''
Descreva primeiro o que os personagens podem perceber e o que exige atenção imediata. Inclua posições, acessos e riscos visíveis quando ajudarem a escolher uma ação. Dê detalhes adicionais conforme o grupo examina o lugar ou faz perguntas.

Depois que alguém propuser uma ação, identifique sua intenção. Escolha o procedimento que resolve a tentativa: descrição, teste, ataque, capacidade da ficha ou outra regra pertinente. Informe custos e consequências que o personagem já teria condições de prever. Resolva o resultado e descreva o que mudou.

## Informação e ritmo

Alterne o foco entre os participantes. Fora de combate, pergunte o que os demais fazem enquanto uma pessoa investiga ou conversa. Em combate, mantenha visíveis a iniciativa, as posições e os efeitos com duração. Terminar uma rolagem antes de começar outra reduz dúvidas sobre quando uma resposta pode ser usada.

Uma maldição pode ter intenções que os jogadores desconhecem. Os personagens só agem sobre o que perceberam ou descobriram. O mesmo cuidado vale para capacidades de investigação: elas entregam a informação descrita em sua regra, sem revelar toda a ficha de uma criatura.

## Dúvidas de regra

Procure a capacidade usada e o procedimento geral que ela modifica. Confira ação, alvo, alcance, resolução e prazo. Se a dúvida persistir, combine uma decisão para aquela sessão e registre o trecho que permitiu interpretações diferentes. A correção posterior deve ser comunicada a quem foi afetado.

## Continuidade da guilda

Antes da missão, confira a versão da ficha, os recursos de entrada e as opções que a organização autoriza. Quando vários mestres compartilham personagens, usem o mesmo registro para recompensas, empréstimos, Pactos e consequências.

Ao terminar, confiram as alterações com os jogadores. Separar o que foi observado na aventura do que foi decidido sobre uma regra ajuda o próximo mestre a continuar. As regras de progressão e recuperação permanecem nos capítulos correspondentes; trocar de mesa não renova recursos por si.
''')
page('consulta-referencias','Referências e adaptação','''
Projeto - M é um sistema de fã ambientado no universo de **Jujutsu Kaisen**, de Gege Akutami. A obra apresenta personagens, acontecimentos e poderes que inspiram o jogo. Os números e procedimentos desta edição foram escritos para a mesa.

## Obra e jogo

Nível, Classe, pontos de montagem, PE, economia de ações e opções de criação organizam o uso das capacidades no sistema. Uma tabela do livro não estabelece uma regra oficial do mangá. Personagens como Kaori e as missões dos exemplos foram criados para mostrar o funcionamento do jogo.

Quando uma campanha incluir personagens ou acontecimentos da obra, combinem a época e o quanto pretendem seguir essa história. O mestre pode usar uma situação original sem exigir que todos conheçam revelações do mangá.

## Fontes consultadas

A ambientação da abertura foi conferida em trechos do volume 1 de Jujutsu Kaisen, disponíveis na prévia oficial da Shueisha, e nos perfis oficiais do anime. Esses recortes sustentam a apresentação geral de maldições, escolas e feiticeiros. Não determinam custos ou alcance das capacidades do Projeto - M.

O **Player’s Handbook de Dungeons & Dragons, edição 2024**, foi usado como referência de organização: apresentação do jogo, roteiro de criação, fichas e consulta. O **Dungeon Master’s Guide, edição 2024**, serviu de referência para a função dos registros de campanha e das orientações de preparação de sessão. Foram consultados os exemplares locais fornecidos para o trabalho editorial.

As regras e os exemplos deste livro conservam seus próprios procedimentos. Uma semelhança de nome com outro RPG não substitui a leitura da entrada correspondente no Projeto - M.


''')
(B/'CONSULTA.md').write_text('\n'.join(parts))
(E/'GLOSSARIO.json').write_text(json.dumps(G,ensure_ascii=False,indent=2)+'\n')
(E/'ARQUIVOS-DONOS.json').write_text(json.dumps(files,ensure_ascii=False,indent=2)+'\n')
print(len(G),'termos;',len(parts),'páginas principais salvas')
