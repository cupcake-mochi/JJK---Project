# Projeto M — ações básicas, autonomia e comandos de invocações

**Análise de continuidade · 24/09/2026 · rascunho para discussão**

Este documento não aprova um subsistema, não substitui o manual e não cria Evocador ou Trilhas. O recorte continua sendo o funcionamento em campo. A comparação principal usa uma única invocação; duas e três aparecem somente para identificar riscos de escala.

## 1. Conclusão de trabalho

**Recomendo a ideia de Mizuki como fundamento: uma oportunidade de atuação autônoma, escolhida entre várias ações básicas elegíveis, e não uma criatura presa a repetir o ataque de sua ficha.** A eficiência de comandos especiais é outro eixo: pode existir depois como investimento específico, sem substituir essa base nem virar desconto universal.

A correção da leitura anterior é importante: variedade de ações disponíveis não significa várias ações executadas no mesmo turno. Também não significa conceder acesso irrestrito a todas as capacidades da ficha do usuário ou da entidade.

Para o próximo ensaio, recomendo não cobrar a Bônus do usuário apenas porque a criatura escolheu Esquivar em vez de atacar. Uma troca desse tipo, coerente com o objetivo e com a informação que ela percebe, cabe em seu discernimento. Comandar uma capacidade especial permanece uma decisão mecanicamente diferente.

## 2. Status: escolhas do autor e hipóteses do ensaio

### Escolhas e preferências explicitadas por Mizuki

| Direção | Alcance preservado |
|---|---|
| Autonomia mínima integrada ao investimento na invocação/vínculo | Não exige taxa periódica específica apenas para habilitar a rotina. Não elimina custos de manifestação ou sustentação particulares. |
| A entidade já em campo continua agindo se o usuário perder a consciência | Depende de permanecer existente e funcional. Não decide o que acontece na morte, com reservas recolhidas ou com PE do usuário. |
| Movimento próprio e sem microcomandos | A criatura pode se mover por discernimento ou para cumprir uma intenção. Não significa deslocamento ilimitado ou fora do turno. |
| Reação separada da do personagem | Escolha feita no recorte de uma invocação. Não aprova uma Reação por corpo quando houver várias. |
| Autonomia restrita à atuação básica | Habilidades especiais ativas exigem comando. Reações especiais e passivas ainda precisam de classificação própria. |
| Padrão como referência para comandar especiais | Mizuki propôs esse custo geral; execução, substituição da básica e eventuais eficiências ainda dependem de desenho. |
| Várias opções de ações básicas, além do ataque | Preferência atual do autor. O número de execuções não foi aprovado como progressão ou limite definitivo. |

### Recomendações deste relatório — não atribuir ao autor

- Usar uma atuação básica por turno do conjunto como parâmetro inicial.
- Permitir escolher sua ação básica sem pagar a Bônus do usuário, dentro dos meios da criatura e da intenção vigente.
- Tratar essa atuação como equivalente à Padrão da entidade para as condições que retiram ações, sem entregar uma Bônus adicional por corpo.
- Permitir básicas que originalmente custam Bônus pelo gasto/conversão da atuação única, com as proibições correspondentes.
- No ensaio, o comando especial de Padrão substitui a atuação básica da entidade; não a acrescenta.
- Adiar a eficiência por Bônus como regra geral. Uma variante específica pode ser testada, ainda substituindo a básica.
- Não reativar básica, Movimento ou Reação por receber nova intenção, ser comandada, cair/levantar o usuário ou trocar de modo.

A proposta de custo da mudança para um objetivo realmente novo continua aberta. Este relatório não usa essa lacuna para cobrar por cada decisão básica ou cada deslocamento.

## 3. O que a conferência da obra sustenta

Foram consultadas páginas oficiais do anime, material editorial da Shueisha e o catálogo oficial da VIZ. **Não houve leitura integral dos capítulos do mangá no leitor oficial.** A página da VIZ não expôs os quadros; a do MANGA Plus depende de JavaScript. Por isso, a contagem detalhada de golpes e ordens mencionada anteriormente não foi tratada como evidência verificada nesta análise.

A sinopse oficial do episódio 18 descreve Megumi enfrentando Kamo com shikigami e combate corporal. Isso sustenta a combinação geral, não uma regra sobre custos simultâneos de habilidades especiais. [E1]

O cadastro editorial da Shueisha identifica Garuda como shikigami de Yuki e destaca seu uso como uma bola; descreve também diferenças funcionais entre entidades, incluindo a língua de Sapo e o consumo elevado de energia de Max Elephant. Esses detalhes não quantificam uma economia de ações. [E2]

A página oficial de personagens descreve os dois tipos de shikigami autônomos de Dhruv e a relação de seus trajetos com o domínio. Ela também apresenta Kogane como interface de cada participante com o Culling Game. Existem funções que não se resumem a um ataque rotineiro. [E3]

O cadastro editorial de Tsukamoto descreve uma resposta à interrupção do fornecimento de energia: ele passa a golpear. Isso é útil para distinguir uma resposta prevista do funcionamento de uma entidade de uma ativação especial deliberadamente comandada. Não prova autonomia energética geral. [E2]

**Interpretação de design:** a obra apoia diversidade de funções, vínculos e modos de operação. Nossa fronteira entre básica autônoma e especial comandada é uma adaptação autoral; não foi demonstrada uma lei universal de que toda capacidade única de toda entidade exige uma nova ordem consciente. Tampouco foi demonstrada uma regra universal de dissipação ou persistência após inconsciência.

A sinopse do episódio 41 confirma o contexto de Megumi gravemente ferido antes de invocar um shikigami, mas não explica integralmente o ritual. A sinopse do episódio 58 e a cronologia oficial confirmam o confronto com Reggie e seu contexto, não cada gasto de ação. Não foram usadas para afirmar detalhes que não apresentam. [E4–E6]

### Pontos para futura leitura direta, sem fingir que já foram conferidos

As referências de capítulos levantadas ao longo da conversa — 73; 117–119; 172; 205–207; 232–234; 249; 269 — permanecem pontos de releitura para distinguir comando, manifestação, ação do usuário, efeito persistente, ritual e perda de controle. A existência dos capítulos é consultável no catálogo oficial, mas isso não verifica os acontecimentos quadro a quadro. [E7]

Essa lacuna não impede a comparação das propostas: as escolhas do autor sobre a experiência do jogo já fornecem a direção; a matemática não deve ser deduzida de quantos quadros uma cena ocupa.

## 4. Quais ações básicas podem entrar

**Base efetivamente consultada:** `11-o-turno.md`, linhas 57–118. A tabela contém doze ações de Padrão e há duas ações gerais de Bônus. Uma ação estar nessa tabela não significa que seja automaticamente elegível para uma invocação autônoma.

| Ação ou grupo | Tratamento recomendado para o ensaio |
|---|---|
| Atacar | Um ataque básico que a ficha da criatura realmente possua. Não recebe Ataque Extra, Sequência ou outras habilidades do invocador. O limite de um golpe é instrumental neste ensaio. |
| Correr | Consome a atuação básica e acrescenta deslocamento igual ao próprio. Com Movimento de 9 m, pode chegar a 18 m, não a 18 m mais um ataque básico. |
| Desengajar | Consome a atuação básica; o movimento permitido pela ação deixa de provocar oportunidade conforme a regra geral. Não transfere essa proteção ao usuário. |
| Esquivar | Consome a atuação básica; aplica a defesa prevista à própria entidade. Não cria interceptação ou proteção ao usuário. |
| Esconder | Usa Furtividade da entidade, com os requisitos da cena. Não concede invisibilidade. |
| Ajudar | Consome a atuação básica; exige contribuição real à tentativa de outro. Um ajudante por teste; não torna a rodada inteira do aliado favorecida. |
| Vasculhar e Estudar | Exigem sentidos, informações e aptidão compatíveis. Não concedem conhecimento automático nem compartilham percepção com o invocador. |
| Usar objeto | Objetos não mágicos e manipulação compatível com o corpo da entidade. Não concede mãos, ferramentas ou ofícios. |
| Influenciar | Somente quando a criatura consegue se comunicar/interferir de forma pertinente e a tentativa é possível. Não recebe automaticamente o repertório social do usuário. |
| Preparar | Gasta a atuação agora e a Reação no gatilho. Apenas uma ação básica elegível nesta hipótese. Não autoriza preparar uma especial sem comando. |
| Agarrar e Derrubar | São opções de Atacar no manual. Não devem virar especiais só porque a criatura as executa. Dependem de anatomia/alcance e de esclarecer a resolução comum no material fornecido. |
| Conjurar | Não entra automaticamente como básica. Ter sido listado entre ações de Padrão não torna um feitiço uma rotina sem comando. |
| Provocar e Ler o Ambiente | No manual são Bônus. Proponho realizá-las pela conversão/gasto da atuação única, sem uma Bônus adicional da entidade. Mantêm requisitos, limite por cena quando houver e impedimentos como Lento. |

**Distinção decisiva:** o que é ordinário depende dos meios já escritos na ficha, não só da aparência. Um golpe de tipo Elétrico pode ser o golpe básico comprado para a criatura; isso não autoriza acrescentar área, condição, cura ou outros efeitos e chamá-los de “básicos”. Esses componentes precisam ser descritos e avaliados separadamente.

### Inconsistências e lacunas encontradas no recorte

1. **Agarrar/Derrubar:** o capítulo 11, linhas 80–82, afirma que são opções de Atacar, mas os capítulos gerais consultados não especificam integralmente teste inicial, oposição/CD e todos os requisitos. O capítulo 15 descreve condições e encerramento. Não completei a lacuna com regras de D&D nem concluí que a regra inexiste no repositório inteiro.
2. **Esquivar:** a tabela fala em “TR de Destreza”. O capítulo 10 organiza TR em Físico, Vigor, Intelecto e Espírito, com Físico escolhido entre Força/Destreza. É necessário esclarecer a compatibilidade; o exemplo deste relatório usa somente a desvantagem em ataques, não a parte ambígua.
3. **Estudar/Vasculhar:** a tabela de Estudar enumera Sentir Energia, Ocultismo, Medicina e História; o parágrafo de explicação posterior menciona Percepção. Não escolhi silenciosamente uma redação definitiva.
4. **Inconsciente e zero PV:** o capítulo 10 permite Insistir e agir a zero, embora mais adiante resuma Inconsciente como ter chegado a zero. Nesta proposta, o gatilho é perder efetivamente a consciência, não simplesmente o marcador de PV chegar a zero.
5. **Controlador da bancada antiga:** sua Padrão + 1 PE aplica Derrubado a alvo adjacente mediante TR. Com Derrubar entre as básicas, pode haver redundância. Só será possível comparar depois de conhecer a resolução comum. Não proibir Derrubar para proteger um cartão experimental; revisar a distinção do cartão quando necessário.

## 5. Validação das duas ideias

### 5.1. Várias básicas elegíveis — recomendada como base

O benefício é flexibilidade: uma entidade capaz de atacar também pode gastar sua atuação para defender-se, ajudar, vasculhar ou interagir. Uma entidade sem ataque pode ser funcional sem precisar de uma exceção para cada turno. O número de execuções não aumenta por haver mais escolhas.

Isso não é custo zero. Escolher a melhor entre várias ações pode aumentar o valor médio da participação e habilitar cooperações que um ataque fixo não entrega. A avaliação precisa considerar a melhor contribuição razoavelmente disponível, não apenas o dano do ataque impresso.

**Não recomendo cobrar Bônus do usuário só para escolher uma básica diferente.** Isso cobraria justamente pela capacidade de discernimento que se quis estabelecer e favoreceria ordens muito abrangentes para contornar a taxa. Mudar de atacar para se proteger diante de um perigo não precisa virar um comando especial.

Se Mizuki quiser diferenciar uma mudança deliberada de objetivo do usuário, a regra deverá dizer o que essa coordenação adicional oferece. Ela não pode significar comprar outra atuação ou autorizar meios que a criatura não possui. Esse ponto fica em aberto, sem travar o repertório básico.

### 5.2. Eficiência de comando — coerente, mas adiada como acesso geral

A eficiência responde a outra pergunta: quanto da atuação do usuário é comprometida ao autorizar uma especial? Ela pode representar uma técnica/vínculo mais bem integrado sem exigir que toda entidade ganhe autonomia total sobre suas especiais.

Uma eventual eficiência precisa especificar a capacidade beneficiada, seu custo, quando se aplica, limites de uso e se substitui a básica. Não recomendo um texto genérico que transforme toda especial presente ou futura em Bônus. Também não tornaria essa eficiência exclusiva do Evocador por definição; a fonte de acesso e o investimento ainda serão desenhados.

### 5.3. Substituir ou acrescentar a especial

Defina, apenas como ferramenta de comparação:

- **P:** valor da melhor Padrão alternativa do personagem naquela situação.
- **B:** valor da melhor Bônus alternativa do personagem.
- **A:** valor da melhor básica elegível da invocação — pode ser Ajudar, não necessariamente atacar.
- **S:** valor da habilidade especial, considerando seus demais custos e efeitos.

Não são moedas, fatias ou números fixos. Uma situação pode valorizar informação, controle ou salvar alguém mais que dano.

| Opção | Participação, com a Bônus alternativa disponível quando não gasta | Quando a troca supera a rotina, numa comparação de valor aditiva simplificada |
|---|---|---|
| Rotina sem especial | P + B + A | Referência |
| Comando de Padrão substitui básica | B + S | S > P + A |
| Comando de Padrão acrescenta especial | B + A + S | S > P |
| Comando eficiente de Bônus substitui básica | P + S | S > B + A |

As comparações não capturam sinergias e duração, mas expõem o custo de oportunidade. A primeira forma de comando cobra a Padrão do personagem e a básica da criatura. Não é automaticamente equilibrada por parecer conservadora: pode tornar toda especial desinteressante.

**Minha escolha para o ensaio é substituição, não ação adicional.** Mantém uma atuação principal da entidade e evita transformar o comando num gerador de um segundo ataque/efeito. Essa escolha exige testar especiais úteis o bastante para justificar a troca, sem declarar nenhum novo valor de dano ou preço.

A eficiência por Bônus permanece hipótese de comparação, não requisito para a criatura funcionar. O valor da economia depende do usuário. Nas versões v0.4 consultadas, a Bônus aparece, entre outros usos, em Abrir Caminho do Guia, Compasso da Estocada e nas cadências do Condutor Armado. Não existe motivo para pressupor que ela valha sempre metade de uma Padrão. Nenhuma dessas habilidades foi alterada.

## 6. Contas reproduzíveis: Ajudar pode ser a melhor básica

### Premissas

Ataque +4 contra Defesa 15; um 20 natural dobra apenas os dados de dano; sem Bloquear, dano fixo, resistências, vantagens prévias, efeitos por acerto ou Caminhos. A invocação possui ataque instrumental de 1d6. O aliado faz uma única rolagem de ataque. A ajuda é efetivamente possível na cena e substitui o ataque da invocação.

O ataque normal tem 45% de acerto comum e 5% de crítico. Com vantagem, tem 65,25% de acerto comum e 9,75% de crítico. Para dano médio dos dados D:

`E(normal) = 0,55 × D`

`E(vantagem) = 0,8475 × D`

`Ganho marginal de Ajudar = 0,2975 × D`

| Dados do ataque do aliado | Dano esperado normal | Dano esperado com vantagem | Contribuição marginal de Ajudar | Ataque próprio 1d6 da invocação |
|---|---:|---:|---:|---:|
| 1d6 | 1,92500 | 2,96625 | 1,04125 | 1,92500 |
| 2d6 | 3,85000 | 5,93250 | 2,08250 | 1,92500 |
| 4d6 | 7,70000 | 11,86500 | 4,16500 | 1,92500 |
| 6d6 | 11,55000 | 17,79750 | 6,24750 | 1,92500 |

Os 6d6 são um parâmetro de sensibilidade, não a ficha de um Caminho ou o dano aprovado de uma especial. Contra um aliado com esse ataque, a ajuda contribui cerca de 3,25 vezes o ataque próprio da criatura. Com 2d6, a diferença é pequena: o conjunto passa de 5,775 para 5,9325 de dano esperado. Isso não demonstra que Ajudar seja sempre melhor.

### Sensibilidade à chance de acerto

Mantendo ataque do aliado 2d6, da invocação 1d6 e a mesma chance normal para ambos:

| Chance normal de acerto | Ganho de Ajudar | Ataque próprio da criatura | Maior contribuição em dano neste recorte |
|---|---:|---:|---|
| 30% | 1,8025 | 1,2250 | Ajudar |
| 50% | 2,0825 | 1,9250 | Ajudar |
| 70% | 1,8025 | 2,6250 | Atacar |
| 90% | 0,9625 | 3,3250 | Atacar |

Se o aliado já possui vantagem que não se acumula, o ganho adicional de Ajudar nessa rolagem é zero. A ajuda favorece a próxima tentativa elegível, não todos os ataques de uma Sequência ou todos os efeitos do turno. Um feitiço resolvido pelo TR do inimigo não se converte, por esta conta, numa rolagem de ataque favorecida.

**Consequência:** reduzir o ataque da criatura para controlar seu orçamento pode fazer Ajudar virar a opção dominante, sem reduzir sua contribuição real. É necessário avaliar o repertório inteiro, inclusive efeitos sobre outros aliados.

### Defesa também não é neutra

Na mesma bancada, um ataque inimigo de 2d6 tem expectativa 3,85 normalmente e 1,7675 com desvantagem. Uma criatura que usa Esquivar abre mão de sua básica ofensiva, mas pode conservar presença e vida por mais tempo. Não simulei Bloquear, transferências de dano ou resistências nesse cálculo.

A desvantagem contra a própria criatura não deve ser reaplicada retroativamente a um golpe já acertado contra o usuário e depois interceptado pelo Guardião experimental. Esse cartão transfere um acerto confirmado sem novo ataque/Bloquear; a ordem de resolução precisa ser preservada.

## 7. Rodada ilustrativa: uma básica diferente de atacar

**Não é teste com jogadores.** Os resultados abaixo foram escolhidos para explicar o procedimento, não sorteados.

A criatura já está manifestada. O usuário está junto de um mecanismo que pode ser acionado com Usar objeto. O Guardião está a 4,5 m do inimigo, com caminho livre, e recebeu antes a intenção “mantenha essa entrada segura enquanto eu abro a passagem”. Pode percorrer 3 m e terminar a 1,5 m do inimigo. Ficha instrumental: Defesa 15, deslocamento 9 m e 36 PV. Inimigo: ataque +4 e dano 2d6. Ninguém tem condições iniciais. O conjunto age antes do inimigo.

| Etapa | Resolução | Recurso |
|---|---|---|
| O usuário aciona o mecanismo | Usar objeto; nesta situação não há teste | Padrão do usuário |
| O Guardião se aproxima | Percorre 3 m, chegando ao alcance corpo a corpo | Movimento próprio; restam 6 m não usados |
| O Guardião se protege | Escolhe Esquivar em vez de atacar | Sua atuação básica |
| O inimigo ataca o Guardião | Com desvantagem, resultados 16 e 7; usa 7 + 4 = 11 | Padrão inimiga |
| Defesa | Defesa fixa 15: o ataque erra | Sem Bloquear ou Reação |

Saldo: mecanismo acionado; um ataque inimigo, 2d20; nenhum dano rolado, TR ou PE gasto durante o recorte. Guardião conserva 36 PV. Padrão do usuário gasta; sua Bônus, Movimento e Reação não foram gastos. Atuação básica da criatura gasta; 3 m usados e sua Reação disponível. O inimigo gastou apenas a Padrão.

Não houve comando especial nem necessidade de dizer “ande três metros e agora esquive”. A criatura produziu participação útil sem dano. Esquivar não obrigou o inimigo a atacá-la e não lhe concedeu uma interceptação automática; o alvo inimigo foi uma escolha deste exemplo.

## 8. Interações e limites que precisam acompanhar a proposta

### Condições e consciência

| Situação | Tratamento da hipótese |
|---|---|
| Usuário inconsciente; criatura funcional | Básica, Movimento e Reação próprios permanecem. Não recebe novo comando, PE automático ou ações que o usuário deixou de usar. |
| Usuário Atordoado | Perde a Padrão e sua Reação; isso não transfere a condição à criatura. Se uma eficiência de Bônus vier a existir, poderá ser utilizável pelo usuário ainda consciente, salvo outros impedimentos. |
| Criatura Atordoada | Perde a sua atuação equivalente à única Padrão e não usa Reação; o Movimento não é removido por essa condição. Comando substitutivo não recupera a atuação perdida. |
| Criatura Incapacitada | Não pode Bloquear; ataques corpo a corpo que a acertem são críticos. Não perde automaticamente básica, Movimento e Reação. |
| Criatura Lenta | Deslocamento pela metade; não usa opções de Bônus, inclusive por conversão. Básicas de Padrão continuam possíveis. |
| Criatura Impedida | Movimento zero e demais efeitos da condição. Autonomia não ignora impedimentos físicos. |
| Usuário em zero PV, mas usando Insistir e ainda consciente | Não tratar automaticamente como desmaio; os gatilhos devem seguir o estado efetivo. |

O ensaio não transforma toda proibição de ações em “Atordoado”. Se no futuro uma entidade receber mais de uma Padrão, será necessário respeitar a regra geral que Atordoado remove uma delas, não todas. A presente hipótese dispõe de uma única atuação básica.

### Reações

Reação própria é uma reserva, não uma capacidade. Bloquear não a gasta; Aparar e oportunidade podem gastá-la conforme as regras. Um corpo sem ataque não recebe um ataque por ter Reação. Uma capacidade de proteção precisa declarar seu próprio gatilho e custo.

Minha recomendação para a futura classificação é separar especiais ativas comandadas das capacidades reativas descritas como autônomas. Isso permite ao Guardião reagir para proteger sem exigir uma Padrão anterior toda rodada, mas não libera silenciosamente toda técnica especial como Reação. A aprovação dessa distinção permanece pendente.

### Preparar

A atuação básica é consumida ao preparar. A ação escolhida acontece depois, mediante a Reação, se houver gatilho válido antes do prazo. Não se prepara uma especial para fugir do comando. Se a Reação for gasta para interceptar, a ação preparada deixa de estar disponível; não há duas respostas pelo mesmo recurso.

### Guia v0.4

A invocação pode ser tratada como aliada elegível na bancada, desde que perceba a orientação e satisfaça as condições. Resposta Coordenada exige a Reação do Guia e a do destinatário; a existência da atividade básica não apaga nenhum desses custos. Um ataque concedido não é uma Ação Atacar ou etapa de Sequência e não desencadeia outra ação concedida. Não empresta conhecimento de feitiços à criatura. [I5]

Essa é uma permissão explícita de atuação adicional, diferente de renovar a própria básica por receber uma ordem. Ela deve continuar sendo registrada como ação concedida de fonte externa.

### Comunicação, distância e exploração

A criatura decide pelo que percebe. Não recebe a visão do usuário e não lhe transmite automaticamente a sua. Uma ordem antiga pode continuar fora do alcance de novas instruções, mas não cria informação. Alterar um objetivo à distância exige um meio de comunicação que o vínculo efetivamente permita; o alcance final não foi escolhido.

Sob pressão de tempo, Vasculhar uma gaveta ou Estudar um objeto consome a atuação correspondente. A criatura não faz testes infinitos porque a cena recebeu o nome “exploração”. A mesma tentativa não deve ser multiplicada automaticamente por vários corpos sem atender às regras de contribuição, repetição ou teste de grupo.

### Manifestação e substituição

Os custos e procedimentos da versão B não foram aprovados nem adaptados integralmente. Não supor que uma nova entidade entra com ataque e Reação prontos depois que a anterior já gastou tudo. Também não supor o contrário como regra fechada: isso precisa ser escrito na próxima etapa pertinente.

Recolher uma entidade ferida e chamar outra não cura a primeira, mas amplia a vida acessível. Nada neste relatório resolve a questão de reservas saudáveis ou autoriza materializar invocações recolhidas quando o usuário desmaia.

## 9. Duas e três entidades: alerta de escala, não regra pronta

Se a mesma atuação independente for dada a cada novo corpo, o conjunto passa a resolver duas ou três básicas autônomas além da Padrão do personagem. Isso já é outra carga de ação, mesmo com ataques pequenos.

Ajudar não empilha no mesmo teste, mas duas criaturas podem favorecer tentativas distintas. Uma pode ajudar um aliado e outra atacar; uma pode vasculhar enquanto outra mantém presença. Sem um critério de capacidade e sem avaliar o conjunto, não há como transportar o resultado de uma entidade diretamente para três.

Como ilustração matemática de uma possibilidade, se forem legítimas duas ou três tentativas independentes de 50% de sucesso, a probabilidade de ao menos um sucesso passa de 50% para 75% e 87,5%. Isso não autoriza repetição automática da mesma tentativa nem substitui a regra de teste de grupo.

As reservas de Reação individuais ou coletivas com várias entidades permanecem abertas. Também ficam abertos o teto de especiais, a conversão da Padrão do usuário em outra Bônus em um modelo eficiente e o ritmo de tentativas de controle. Não é necessário decidir horda, vida compartilhada ou novas Trilhas para reconhecer esses riscos.

## 10. Verificações realmente realizadas

- Leitura integral de `LEIA-ME.md` e `PROMPT-PARA-COLAR.md` diretamente do ZIP; contexto, arquiteturas e protótipo já disponíveis por leitura integral na conversa.
- Leitura do capítulo 10 pela ferramenta de arquivos. Busca dos demais capítulos na superfície da conversa não retornou texto indexado; extração e leitura direta das cópias do ZIP para capítulos 11 e 15 e consultas do Guia v0.4. Consultas pontuais a cabeçalhos/usos de Bônus nos demais Caminhos; não auditoria completa deles.
- Comparação byte a byte das 32 entradas do ZIP com as cópias extraídas: nenhuma diferença encontrada. Nenhum arquivo de referência foi editado.
- Conferência das fontes oficiais indicadas no apêndice. Nenhuma afirmação de leitura integral de mangá ou episódio.
- Enumeração exata de ataques normais, com vantagem e com desvantagem: 20 ou 400 resultados de d20, usando médias analíticas dos dados de dano.
- Execução de `verificar_acoes.py`: **22 verificações locais aprovadas**. Cobrem somente os comportamentos codificados; não demonstram equilíbrio, duração de turno, diversão ou funcionamento completo do sistema. O programa não simula anatomia, alcance/comunicação, todos os efeitos das condições, PE, cada Caminho, sustentação ou múltiplas invocações.
- Não houve sessão de mesa, simulação de combate completo, alteração de manual/Caminhos ou commit/push. Os 243 testes da versão B antiga não foram reexecutados nem apresentados como validação desta hipótese.

### Como reproduzir

Com Python 3.10 ou posterior, sem dependências externas:

```bash
python verificar_acoes.py --output resultados.json
```

O JSON contém premissas, resultados exatos convertidos em decimais, sensibilidade e nomes das verificações. A execução escreve apenas no destino informado. Os testes não substituem as decisões de regra ainda pendentes.

## 11. Duas perguntas úteis para a próxima conversa

1. O custo de Bônus aventado para redirecionamento deve existir somente quando o usuário troca a intenção por um objetivo diferente — abandonar uma luta para procurar uma chave, por exemplo — ou comunicar uma nova intenção pode não ter custo de ação, mantendo a única atuação da entidade? A recomendação inicial é não cobrar por decisões básicas coerentes com a intenção vigente; uma taxa de mudança de objetivo ainda não foi escolhida.
2. Uma proteção especial de Reação, como a interceptação do Guardião, deve poder ser usada autonomamente quando o gatilho ocorrer, ou precisa de autorização anterior? A recomendação é permitir autonomia apenas às respostas que a ficha descreva expressamente como reativas, com seus custos, sem estender essa permissão às especiais ativas de turno.

O próximo passo recomendado é testar uma única entidade com três básicas elegíveis, uma especial comandada e uma reação escrita, em uma situação na qual atacar não seja sempre a melhor escolha. Isso é uma proposta de ensaio delimitado, não a criação do subsistema inteiro.

## Apêndice — fontes e rastreabilidade

### Fontes internas do pacote `RPG-JJK-Acoes-e-Autonomia-v1.zip`

Os caminhos abaixo são relativos à raiz do pacote original. As linhas são as dos arquivos Markdown originais, não as linhas acrescidas por ferramentas de citação.

| ID | Arquivo e seção |
|---|---|
| I1 | `referencia-repositorio/sistema/05-material/livro/manual/10-como-jogar.md`: Ajudar, linhas 46–52; crítico, 129–137; Bloquear/Aparar/Brecha, 153–187; TR, 189–207; zero PV/consciência, 292–341. |
| I2 | `referencia-repositorio/sistema/05-material/livro/manual/11-o-turno.md`: recursos/conversões, 17–49; ações de Padrão, 57–106; Bônus, 108–118; oportunidade, 120–128; concentração, 130–158. A referência a Torrente antiga ao final não substitui Emanador v0.4. |
| I3 | `referencia-repositorio/sistema/05-material/livro/manual/15-dano-e-condicoes.md`: Lento/Incapacitado/Derrubado/Agarrado, 126–162; Impedido, 202–212; Atordoado, 242–249. |
| I4 | `propostas/02-RASCUNHO-prototipo.md`: proposta antiga, cartões instrumentais, fronteiras e limites. Todo o status de rascunho é preservado. |
| I5 | `caminhos-v0.4/04-Guia-Caminho-e-Trilhas.md`: Abrir Caminho, 19–51; Resposta Coordenada, 55–72; cadeias, 90–120. |
| I6 | `01-CONTEXTO-E-STATUS.md`, `LEIA-ME.md`, `PROMPT-PARA-COLAR.md`: escopo, precedência, preservação da v0.4 e não aprovação da arquitetura B. |

### Fontes externas efetivamente consultadas

| ID | Fonte primária/editorial oficial | O que foi acessível |
|---|---|---|
| E1 | https://jujutsukaisen.jp/episodes/18.php | Sinopse oficial de Megumi contra Kamo; não o episódio completo. |
| E2 | https://www.shonenjump.com/j/vote_jujutsu_kaisen/ | Descrições editoriais dos personagens/entidades, especialmente Sapo, Max Elephant, Garuda e Tsukamoto; não regras universais de autonomia. |
| E3 | https://jujutsukaisen.jp/character/ | Descrições de Dhruv e Kogane. |
| E4 | https://jujutsukaisen.jp/episodes/41.php | Sinopse da invocação em Shibuya, sem explicação integral do ritual. |
| E5 | https://jujutsukaisen.jp/episodes/58.php | Sinopse do confronto de Megumi com Reggie. |
| E6 | https://jujutsukaisen.jp/shimetsukaiyu/ | Cronologia oficial, sem sequência completa dos golpes/comandos. |
| E7 | https://www.viz.com/shonenjump/chapters/jujutsu-kaisen | Catálogo oficial dos capítulos; não os quadros integrais dos capítulos pagos. |
| E8 | https://www.viz.com/shonenjump/jujutsu-kaisen-chapter-205/chapter/25824 | Página do capítulo 205; o texto acessível não expôs os quadros. |
| E9 | https://mangaplus.shueisha.co.jp/titles/100034 | Página oficial da obra, com exigência de JavaScript; sem capítulo lido integralmente. |

Também foram abertas sinopses oficiais dos episódios 29, 35 e 59 e a página de personagens da primeira temporada. Nenhum detalhe não exposto nelas foi usado como prova de uma economia de ações. A página do guia de shikigami da Crunchyroll foi tentada, mas não retornou texto legível na abertura; não foi usada para validar detalhes novos.
