#!/usr/bin/env python3
"""Verificações locais de uma HIPÓTESE, não de regras aprovadas ou de equilíbrio.

Somente uma invocação. Política ensaiada: uma atividade básica escolhida entre
opções elegíveis, Movimento e Reação próprios; comando especial substitui a
atividade e custa a Padrão do usuário. Bônus é uma variante habilitada por
investimento hipotético. Não simula combate completo, alcance/comunicação,
PE, todas as condições, qualquer Caminho, manifestação, morte ou múltiplas.
Usa enumeração exata de d20 para as contas; não há amostragem aleatória.
Executar: python verificar_acoes.py --output resultados.json
"""
from __future__ import annotations
import argparse
from dataclasses import dataclass
from fractions import Fraction
from itertools import product
from pathlib import Path
import json
from typing import Callable


def attack_expectation(dice: int, sides: int, bonus: int, defense: int,
                       mode: str = 'normal', fixed: int = 0) -> Fraction:
    if dice < 1 or sides < 2 or mode not in {'normal', 'advantage', 'disadvantage'}:
        raise ValueError('Parâmetro de ataque inválido')
    # Nesta bancada todos os alvos podem ser acertados com 20 e errados com 1.
    if not 2 <= defense - bonus <= 20:
        raise ValueError('Limiar fora da faixa coberta pela bancada')
    avg = Fraction(dice * (sides + 1), 2)
    rolls = [(r,) for r in range(1, 21)] if mode == 'normal' else list(product(range(1,21), repeat=2))
    total = Fraction(0)
    for sample in rolls:
        r = sample[0] if mode == 'normal' else (max(sample) if mode == 'advantage' else min(sample))
        if r + bonus >= defense:
            total += avg * (2 if r == 20 else 1) + fixed
    return total / len(rolls)


BASICS = frozenset({'atacar', 'ajudar', 'esquivar', 'desengajar', 'correr',
                    'esconder', 'vasculhar', 'estudar', 'influenciar', 'usar_objeto', 'preparar', 'provocar', 'ler_ambiente'})
# Pertencer a esta lista não concede anatomia, proficiências ou objetos.
# Agarrar/Derrubar são deixados fora desta implementação por falta de resolução
# completa nos capítulos gerais consultados; não são declarados proibidos.

@dataclass
class Turn:
    user_unconscious: bool = False
    user_stunned: bool = False
    entity_stunned: bool = False
    entity_incapacitated: bool = False
    entity_slow: bool = False
    entity_restrained: bool = False
    efficient_command: bool = False
    standard: int = 1
    bonus_action: int = 1
    user_reaction: int = 1
    activity: int = 1
    entity_reaction: int = 1
    meters: Fraction = Fraction(9)
    prepared: bool = False
    entity_actions: int = 0

    def __post_init__(self) -> None:
        if self.user_unconscious:
            self.standard = self.bonus_action = self.user_reaction = 0
        elif self.user_stunned:
            self.standard = self.user_reaction = 0
        if self.entity_stunned:
            self.activity = self.entity_reaction = 0
        if self.entity_slow:
            self.meters /= 2
        if self.entity_restrained:
            self.meters = Fraction(0)

    def basic(self, name: str) -> None:
        # Básicas de Bônus usam a atuação única por conversão, sem Bônus extra.
        if self.entity_slow and name in {'provocar','ler_ambiente'}:
            raise ValueError('Lento impede uso de Ação Bônus, inclusive por conversão')
        if name not in BASICS or not self.activity:
            raise ValueError('Básica não elegível ou atuação já gasta')
        self.activity = 0
        if name == 'preparar':
            self.prepared = True
        elif name == 'correr':
            self.meters += Fraction(0) if self.entity_restrained else (Fraction(9,2) if self.entity_slow else Fraction(9))
        self.entity_actions += 1

    def command(self, cost: str = 'standard') -> None:
        if not self.activity:
            raise ValueError('Comando não recupera atuação consumida ou impedida')
        if self.user_unconscious:
            raise ValueError('Usuário inconsciente não dá novo comando')
        if cost == 'standard':
            if not self.standard: raise ValueError('Sem Padrão')
            self.standard -= 1
        elif cost == 'bonus':
            if not self.efficient_command or not self.bonus_action:
                raise ValueError('Sem eficiência expressa ou sem Bônus')
            self.bonus_action -= 1
        else:
            raise ValueError('Custo desconhecido')
        self.activity = 0
        self.entity_actions += 1

    def move(self, meters: Fraction) -> None:
        if meters < 0 or meters > self.meters:
            raise ValueError('Movimento excedido')
        self.meters -= meters

    def react(self, prepared: bool = False) -> None:
        if not self.entity_reaction or (prepared and not self.prepared):
            raise ValueError('Reação ou preparação indisponível')
        self.entity_reaction = 0
        self.prepared = False

    def user_reacts(self) -> None:
        if not self.user_reaction:
            raise ValueError('Sem Reação pessoal')
        self.user_reaction = 0

    def block(self) -> None:
        if self.entity_incapacitated:
            raise ValueError('Incapacitado não pode Bloquear')
        # Não consome Reação. Rolagem/resultados de Bloquear não são simulados.


def must_reject(f: Callable[[], None]) -> None:
    try:
        f()
    except ValueError:
        return
    raise AssertionError('Era esperada uma rejeição')


def run_checks() -> list[dict]:
    results: list[dict] = []
    def check(name: str, f: Callable[[], None]) -> None:
        f()
        results.append({'name': name, 'result': 'pass'})

    def c1():
        t=Turn(); t.basic('ajudar'); assert t.standard==1 and t.bonus_action==1; must_reject(lambda:t.basic('atacar'))
    def c2():
        t=Turn(); t.move(Fraction(3)); t.basic('vasculhar'); t.move(Fraction(6)); must_reject(lambda:t.move(Fraction(1)))
    def c3():
        t=Turn(); t.basic('correr'); assert t.meters==18; t.move(Fraction(18)); must_reject(lambda:t.basic('atacar'))
    def c4():
        t=Turn(); t.user_reacts(); t.react(); assert t.user_reaction==t.entity_reaction==0
    def c5():
        t=Turn(user_unconscious=True); t.basic('esquivar'); t.move(Fraction(3)); t.react(); assert t.standard==t.bonus_action==0
    def c6():
        t=Turn(user_unconscious=True); must_reject(lambda:t.command()); assert t.activity==1
    def c7():
        t=Turn(); t.command(); assert t.standard==0 and t.bonus_action==1 and t.activity==0; must_reject(lambda:t.basic('atacar'))
    def c8():
        t=Turn(); t.basic('atacar'); must_reject(lambda:t.command()); assert t.standard==1
    def c9():
        t=Turn(); must_reject(lambda:t.command('bonus')); assert t.activity==1 and t.bonus_action==1
    def c10():
        t=Turn(efficient_command=True); t.command('bonus'); assert t.standard==1 and t.bonus_action==0 and t.activity==0; must_reject(lambda:t.command())
    def c11():
        t=Turn(user_stunned=True); must_reject(lambda:t.command()); assert t.activity==1; t.basic('atacar')
    def c12():
        t=Turn(user_stunned=True,efficient_command=True); t.command('bonus'); assert t.activity==0
    def c13():
        t=Turn(entity_stunned=True); must_reject(lambda:t.basic('ajudar')); must_reject(lambda:t.command()); must_reject(lambda:t.react()); t.move(Fraction(9))
    def c14():
        t=Turn(entity_incapacitated=True); must_reject(lambda:t.block()); t.basic('atacar'); t.react()
    def c15():
        t=Turn(entity_slow=True); assert t.meters==Fraction(9,2); t.basic('ajudar'); t.react()
    def c16():
        t=Turn(entity_restrained=True); must_reject(lambda:t.move(Fraction(1))); t.basic('ajudar')
    def c17():
        t=Turn(); t.basic('preparar'); t.react(prepared=True); must_reject(lambda:t.react(prepared=True)); assert t.entity_actions==1
    def c18():
        t=Turn(); t.basic('preparar'); t.react(); must_reject(lambda:t.react(prepared=True))
    def c19():
        t=Turn(); t.block(); t.block(); assert t.entity_reaction==1; t.react(); t.block()
    def c20():
        t=Turn(); must_reject(lambda:t.basic('conjurar')); assert t.activity==1

    def c21():
        t=Turn(); t.basic('provocar'); assert t.bonus_action==1; must_reject(lambda:t.basic('atacar'))
    def c22():
        t=Turn(entity_slow=True); must_reject(lambda:t.basic('provocar')); assert t.activity==1; t.basic('ajudar')

    for name,func in [
        ('Escolher Ajudar não gasta ações do usuário nem permite segunda básica',c1),
        ('Movimento próprio pode ser fracionado sem ultrapassar o total',c2),
        ('Correr substitui a básica e compra metros, não ataque adicional',c3),
        ('Reações pessoal e da criatura são independentes',c4),
        ('Usuário inconsciente não cancela básica/movimento/reação sustentados',c5),
        ('Usuário inconsciente não comanda especial',c6),
        ('Comando Padrão substitui a básica no modelo escolhido',c7),
        ('Comandar depois da básica não cria uma segunda atuação',c8),
        ('Bônus não comanda especial sem eficiência expressa',c9),
        ('Eficiência por Bônus ainda substitui a básica',c10),
        ('Atordoado no usuário não atordoa a criatura',c11),
        ('Usuário Atordoado pode usar Bônus por hipótese se consciente e habilitado',c12),
        ('Atordoado na criatura impede sua atuação única e Reação, não Movimento',c13),
        ('Incapacitado impede Bloquear, não a ação ou Reação por si',c14),
        ('Lento reduz metros, não elimina atividade básica',c15),
        ('Impedido zera metros; teste não simula seus outros efeitos',c16),
        ('Preparar custa atividade agora e Reação no gatilho, uma única vez',c17),
        ('Gastar Reação com outro uso inviabiliza a ação preparada',c18),
        ('Bloquear não consome nem exige Reação',c19),
        ('Conjurar não entra automaticamente como opção básica',c20),
        ('Básica de Bônus consome a atuação única por conversão, sem Bônus adicional',c21),
        ('Lento impede básica de Bônus, mas não básica de Padrão',c22),
    ]: check(name,func)
    return results


def main() -> None:
    parser=argparse.ArgumentParser(description=__doc__)
    parser.add_argument('--output',type=Path,default=Path(__file__).with_name('resultados.json'))
    args=parser.parse_args()
    base=attack_expectation(1,6,4,15)
    help_rows=[]
    for dice in (1,2,4,6):
        normal=attack_expectation(dice,6,4,15)
        advantage=attack_expectation(dice,6,4,15,'advantage')
        help_rows.append({'ally_d6':dice,'normal':float(normal),'advantage':float(advantage),
                          'marginal_help':float(advantage-normal),'entity_attack':float(base),
                          'two_attacks_total':float(normal+base),'help_total':float(advantage)})
    assert base==Fraction(77,40)
    assert attack_expectation(2,6,4,15)==Fraction(77,20)
    assert attack_expectation(2,6,4,15,'advantage')==Fraction(2373,400)
    checks=run_checks()
    data={'status':'HIPÓTESES NÃO APROVADAS; NÃO CERTIFICAÇÃO DE EQUILÍBRIO',
          'date':'2026-09-24','checks_count':len(checks),'checks':checks,
          'math_method':'Enumeração exata de 20 ou 400 resultados; média analítica dos dados de dano',
          'math_assumptions':['ataque +4 contra Defesa 15','20 natural dobra só dados',
                              'sem Bloquear, dano fixo, resistências, efeitos por acerto ou Caminhos',
                              'Ajudar é elegível na situação e favorece somente uma rolagem',
                              'invocação abre mão de seu ataque 1d6 para Ajudar'],
          'help_comparison':help_rows,
          'accuracy_sensitivity':[{'normal_hit_chance':p,
              'ally_normal_2d6':float(attack_expectation(2,6,4,defense)),
              'ally_advantage_2d6':float(attack_expectation(2,6,4,defense,'advantage')),
              'marginal_help':float(attack_expectation(2,6,4,defense,'advantage')-attack_expectation(2,6,4,defense)),
              'entity_normal_1d6':float(attack_expectation(1,6,4,defense))}
              for p,defense in [(0.3,19),(0.5,15),(0.7,11),(0.9,7)]],
          'defense_example_2d6':{
              'normal':float(attack_expectation(2,6,4,15)),
              'disadvantage':float(attack_expectation(2,6,4,15,'disadvantage'))},
          'independent_attempts':[{'attempts':n,'at_least_one_success':float(1-Fraction(1,2)**n)} for n in (1,2,3)],
          'limits':['Os 22 checks verificam apenas os casos e gates escritos no programa.',
                    'A existência de opções não concede anatomia, habilidade, PE ou alcance.',
                    'Não há simulação de duelo, métricas de tempo ou jogadores humanos.',
                    'Os 243 testes da versão B antiga não foram reexecutados nem reutilizados como validação.']}
    args.output.parent.mkdir(parents=True,exist_ok=True)
    args.output.write_text(json.dumps(data,ensure_ascii=False,indent=2)+'\n',encoding='utf-8')
    print(json.dumps({'checks_count':len(checks),'help_comparison':help_rows,
          'accuracy_sensitivity':[{'normal_hit_chance':p,
              'ally_normal_2d6':float(attack_expectation(2,6,4,defense)),
              'ally_advantage_2d6':float(attack_expectation(2,6,4,defense,'advantage')),
              'marginal_help':float(attack_expectation(2,6,4,defense,'advantage')-attack_expectation(2,6,4,defense)),
              'entity_normal_1d6':float(attack_expectation(1,6,4,defense))}
              for p,defense in [(0.3,19),(0.5,15),(0.7,11),(0.9,7)]],'output':str(args.output)},ensure_ascii=False,indent=2))

if __name__=='__main__': main()
