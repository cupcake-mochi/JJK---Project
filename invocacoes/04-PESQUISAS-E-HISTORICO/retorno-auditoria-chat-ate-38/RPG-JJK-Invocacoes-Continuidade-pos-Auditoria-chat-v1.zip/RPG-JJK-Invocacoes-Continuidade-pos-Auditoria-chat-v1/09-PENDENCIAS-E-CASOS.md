# Pendências e casos — estado após a auditoria da conversa atual

## Próxima pendência real: conversão entre modalidades

**Por que as regras existentes não resolvem:** antecipada e preparada têm economia, compromisso e prazo próprios; as regras permitem ajustes internos de cada modalidade, mas não definem se uma ordem pode mudar de procedimento nem o destino da Padrão já paga, da básica, dos custos antecipados e do prazo ao fazer isso.

### Direções ainda não decididas

1. **Antecipada → preparada**
   - antecipada inviável com básica disponível;
   - antecipada inviável com básica já gasta;
   - tentativa de converter depois que surgiu oportunidade válida, sem usar a conversão para contornar o compromisso aprovado.

2. **Preparada → antecipada**
   - preparação com Padrão e básica já investidas;
   - impedir que a mudança crie persistência gratuita além do prazo original sem decisão expressa;
   - tratar custos antecipados sem inventar estorno ou cobrança automática.

### Regras já fechadas que limitam qualquer proposta

- uma especial pendente por corpo, somando antecipada e preparada;
- antecipada deve cumprir a primeira oportunidade válida ou ser encerrada por desistência legal;
- preparada já gastou a básica ao ser preparada;
- preparada expira no próximo início do turno do invocador e pode ser perdida por recolhimento ou gasto da coletiva em outra resposta;
- ajuste livre da preparada vale somente no turno de emissão e não autoriza mudança de modalidade;
- recusa de ocorrência válida conserva a preparação, não guarda o evento passado e não amplia o prazo;
- ajuste da antecipada segue seu procedimento próprio e não deve ser confundido com conversão;
- comunicação continua necessária onde já exigida.

## Outras pendências preservadas, sem reabertura automática

- existência e consequência completa a zero PV onde faltar regra válida; morte do invocador; perda de sustentação/vínculo;
- quantidade/progressão final de básicas;
- X definitivo;
- alcance e canais específicos de comunicação;
- custos/fontes das capacidades;
- custo, oportunidade, posição e legalidade de manifestação/recolhimento/troca;
- conversão de básica em opções originalmente de Bônus;
- precedência de efeitos simultâneos fora da disputa da coletiva;
- intenções prévias ao combate e prioridade entre tarefas quando um caso concreto exigir.

## Casos auditados nesta conversa

| Caso | Resultado |
|---|---|
| Especial contra alvo diferente da intenção atual | Já resolvido: pode contrariar pontualmente; após o resultado, manter ou atribuir nova intenção à destinatária sem Bônus, com comunicação válida. |
| Renovação do conjunto | Já resolvido: início do turno do invocador → próximo início; rodada global não renova. |
| Guia 30 atravessando a fronteira da coletiva | Já resolvido: renovação real entre gatilhos pode permitir duas respostas distintas de criaturas diferentes; não cria duas coletivas. |
| Substituição 1→1 | Já resolvido: até uma básica não gasta transferível, respeitando trava do corpo; corpo novo usa Movimento próprio. |
| Entrada adicional | Já resolvido: não cria básica nem primeira intenção gratuita; corpo novo tem Movimento próprio. |
| Primeira intenção da substituta direta | Já resolvido: incluída na substituição, sujeita à recepção. |
| Mesmo corpo retornando | Já resolvido: conserva identidade, gastos, estados e intenção anterior válida quando aplicável; saída não renova recursos. |
| Conversão antecipada ↔ preparada | **Indeterminado / pendente. Não discutido nesta conversa.** |

Nenhum código ou ensaio foi executado nesta etapa; esta entrega é uma auditoria textual de continuidade.
