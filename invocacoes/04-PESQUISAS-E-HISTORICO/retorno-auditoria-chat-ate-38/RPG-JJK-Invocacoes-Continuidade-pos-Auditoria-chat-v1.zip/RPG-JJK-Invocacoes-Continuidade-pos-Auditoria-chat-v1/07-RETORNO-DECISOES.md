# RETORNO — decisões e auditoria da conversa atual

**Projeto:** RPG-JJK / Projeto M — Procedimentos de Campo / Invocações  
**Autor:** Mizuki  
**Base recebida:** v0.3 CANDIDATA — revisão 3 de leitura, decisões autorais até §38  
**Status desta etapa:** auditoria de continuidade; nenhuma nova decisão de design alterou a r3.

## 1. Escopo efetivamente conferido

Foram confrontados:

- `00-LEIA-ME.md`;
- `01-PROCEDIMENTOS-v0.3-CANDIDATA-r3-LEITURA.md`;
- `02-ALTERACOES-E-AUTORIDADE.md`;
- `03-PENDENCIAS-E-PROXIMA-PAUTA.md`;
- `04-AUDITORIA-E-LIMITES.md`;
- `06-MODELO-DE-RETORNO.md`;
- `fontes/DECISOES-POSTERIORES.md`, registro autoral integral até §38;
- decisões e esclarecimentos expressos por Mizuki na conversa atual.

Não foi executado novo ensaio, código ou playtest humano. Os resultados históricos do pacote continuam pertencendo à revisão a que foram atribuídos e não validam decisões posteriores por extensão.

## 2. Perguntas feitas nesta conversa e classificação correta

| Pergunta levantada pelo assistente | Classificação após auditoria | Sustentação |
|---|---|---|
| Se a especial pode contrariar pontualmente a intenção persistente ou se seria necessário redirecionar antes com Bônus | **Já resolvida na base; pergunta repetida.** A especial pode atuar fora da intenção sem Bônus. Depois do resultado, o invocador pode manter a intenção anterior ou atribuir nova intenção à destinatária sem Bônus adicional, com comunicação válida. | Procedimentos §5 e §4.2; registro autoral sobre orientação incluída e comunicação. |
| Se o ciclo deve ser ancorado do início de um turno do invocador ao próximo, aceitando a interação com Guia 30 | **Já resolvida na base; pergunta repetida.** A resposta de Mizuki nesta conversa foi confirmação, não alteração. | Procedimentos §3 e §8.3; registro autoral §17 e decisões anteriores incorporadas. |
| Se, numa substituição, a básica fica limitada pelo saldo da entidade substituída enquanto o corpo novo usa seu próprio Movimento | **Já resolvida na base; pergunta repetida.** A resposta de Mizuki foi confirmação. | Procedimentos §9.2–§9.5; registro autoral §§9–12 e §18 conforme o caso de corpo novo/retorno. |
| Se somente a substituta direta recebe a primeira intenção incluída e entradas adicionais não recebem essa gratuidade | **Já resolvida na base; pergunta repetida.** Não exigia nova aprovação. | Procedimentos §9.2–§9.4 e §4.2; registro autoral §§11, 15 e 30. |

## 3. Correção obrigatória da formulação do assistente

Durante a conversa, o assistente resumiu incorretamente a especial imediata como se, após a execução, a intenção anterior permanecesse salvo redirecionamento separado por Bônus. Essa formulação era **mais restritiva do que a base** e não foi aprovada por Mizuki como alteração.

A regra preservada é:

1. o invocador paga sua **Ação Padrão** para comandar a especial imediata;
2. a especial ocupa uma básica disponível da destinatária e paga os custos próprios aplicáveis;
3. a especial pode contrariar pontualmente a intenção vigente sem Bônus adicional;
4. **depois de conhecer o resultado**, e com comunicação válida, o invocador pode escolher:
   - conservar a intenção anterior; ou
   - atribuir **uma nova intenção à própria destinatária sem Bônus adicional**;
5. a orientação gratuita pertence ao evento; se não for recebida naquela ocasião, não vira crédito posterior;
6. essa orientação não se espalha às demais entidades e não concede nova execução.

Mizuki confirmou nesta conversa que essa correção corresponde à base. Isso é **preservação/correção de leitura**, não nova decisão de design.

## 4. O que Mizuki realmente alterou nesta conversa

**Nenhuma regra de design da r3 foi alterada.**

As respostas “sim” dadas às perguntas sobre intervenção pontual, relógio e substituição confirmaram regras que já estavam incorporadas. A correção sobre orientação posterior à especial restaurou a redação correta da base; não criou regra nova.

Portanto, **não numerar nenhuma dessas confirmações como §39**.

## 5. Conversão entre modalidades

A conversão **antecipada ↔ preparada não foi discutida nem decidida nesta conversa**. Ela foi apenas identificada, após auditoria, como a próxima pendência real.

O registro anterior já delimita que:

- preparar uma especial é permitido, mas isso não autoriza converter silenciosamente uma ordem de execução em preparação (§33);
- existe no máximo uma especial pendente por corpo entre as duas modalidades (§35);
- ajuste da preparada dentro do turno de emissão não equivale a conversão (§37);
- recusar um gatilho válido preservando a preparação não converte a modalidade (§38);
- Padrão já paga, básica, custos antecipados, prazo e destino dos recursos numa conversão continuam sem regra aprovada.

**Último ponto autoral efetivamente encerrado:** §38.  
**Próximo ponto autoral real:** conversão entre modalidades, ainda sem solução aprovada.

## 6. Declaração de escopo e preservação

- Preservados Bastião, Vanguarda, Emanador e Guia v0.4.
- Preservada Estocada.
- Preservados os PE do Emanador sem acréscimo de atributo.
- Nenhuma regra de Evocador, Trilha, construtor, catálogo, orçamento em fatias ou preço de aquisição foi criada nesta etapa.
- Nenhum X, alcance, PE, PV, dado, custo de manifestação/recolhimento/troca ou recuperação definitiva foi fixado.
- Não houve edição do repositório/manual/Caminhos, commit ou push.
