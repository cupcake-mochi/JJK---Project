Vamos continuar o RPG-JJK / Projeto M. Sou Mizuki.

Anexei o ZIP `RPG-JJK-Invocacoes-Continuidade-pos-Auditoria-chat-v1.zip`. Esta conversa deve continuar a discussão de design dos Procedimentos de Campo das Invocações, sem reiniciar a arquitetura e sem avançar para Evocador, Trilhas ou construtor.

## Leitura obrigatória inicial

Leia primeiro:

1. `00-LEIA-ME.md`;
2. `01-PROCEDIMENTOS-v0.3-CANDIDATA-r3-LEITURA.md`;
3. `02-ALTERACOES-E-AUTORIDADE.md`;
4. `03-PENDENCIAS-E-PROXIMA-PAUTA.md`;
5. `04-AUDITORIA-E-LIMITES.md`;
6. `07-RETORNO-DECISOES.md`;
7. `09-PENDENCIAS-E-CASOS.md`;
8. `10-AUDITORIA-DA-CONVERSA-ATUAL.md`;
9. `fontes/DECISOES-POSTERIORES.md`, principalmente §§33–38 para a próxima pauta.

`08-PROPOSTA-OPERACIONAL-INTEGRAL-ATUALIZADA.md` reproduz integralmente o estado operacional corrente e pode ser usado como leitura autocontida. Consulte regras gerais e Caminhos apenas quando uma interação concreta depender deles.

## Autoridade e estado atual

A base corrente continua sendo **v0.3 CANDIDATA — revisão 3 de leitura, decisões autorais até §38**. A conversa imediatamente anterior não aprovou nenhuma alteração de design sobre essa base; ela apenas auditou repetições e corrigiu uma formulação equivocada do assistente.

Não numerar confirmações daquela conversa como novas decisões (§39+).

Preserve especialmente:

- a especial imediata pode contrariar pontualmente a intenção vigente sem Bônus;
- após conhecer o resultado da especial, com comunicação válida, o invocador pode manter a intenção anterior **ou atribuir uma nova intenção à própria destinatária sem Bônus adicional**;
- essa orientação gratuita pertence ao evento e não vira crédito futuro se não for recebida;
- ciclo ancorado do início de um turno do invocador ao próximo; virada da rodada global não renova;
- Guia 30 pode atravessar uma renovação real da coletiva sem que isso seja um problema a corrigir;
- na substituição, a básica fica limitada pelo saldo transferível da entidade que sai e pela trava de uso do corpo que entra;
- corpo novo entra com Movimento próprio; corpo que retorna conserva seu saldo próprio e não renova por sair/voltar;
- somente a substituta direta recebe a primeira intenção incluída; entradas adicionais não recebem essa gratuidade;
- a Reação coletiva não renova por manifestação, recolhimento ou troca.

## Próxima pendência real

Retome **somente a conversão entre modalidades de especial pendente: antecipada ↔ preparada**.

Essa conversão ainda não foi discutida nem decidida na conversa anterior. As regras existentes distinguem as duas modalidades, mas não dizem como mudar de uma para a outra nem o destino da Padrão já paga, da básica, dos custos antecipados e do prazo.

Antes de fazer uma pergunta, explique em uma frase por que a regra existente não resolve o caso. Compare no máximo duas ou três soluções concretas. Pode tratar as duas direções de forma assimétrica se isso fizer sentido.

Casos mínimos a considerar:

1. antecipada inviável, básica ainda disponível → jogador quer torná-la preparada para um gatilho específico;
2. antecipada inviável, básica já gasta → não criar preparação gratuita sem básica elegível;
3. preparada com Padrão e básica já investidas → jogador quer torná-la antecipada/persistente;
4. antecipada já encontrou oportunidade válida → não usar conversão para contornar o compromisso de executar ou desistir.

Preserve o que já está fechado: uma especial pendente por corpo; compromisso da antecipada com a primeira oportunidade válida; prazo/perdas da preparada; ajuste gratuito da preparada apenas no turno de emissão; recusa de gatilho da preparada não armazena o evento nem amplia prazo; comunicação e requisitos continuam valendo.

Não abra custo de substituição, energia própria, X, alcance, catálogo, preços ou Evocador para resolver essa decisão. Se uma dependência realmente bloquear a conversão, marque-a como pendente em vez de inventar regra.

## Forma de trabalho

Trabalhe um ponto por vez. Separe:

- decisão autoral existente;
- regra de referência;
- recomendação nova;
- hipótese de exemplo;
- pendência.

Não peça nova aprovação de algo já fechado. Quando eu aprovar uma decisão realmente nova, registre-a a partir do **§39**, indicando exatamente o que mudou na proposta operacional e o que permaneceu intacto.

Ao encerrar a etapa ou quando eu pedir consolidação, atualize `RETORNO-DECISOES.md`, `PROPOSTA-OPERACIONAL-INTEGRAL-ATUALIZADA.md` e `PENDENCIAS-E-CASOS.md`. Não edite repositório, manual ou Caminhos; sem commit ou push.

Escreva em português do Brasil, com linguagem operacional de RPG: benefício, custo, momento e condições.
