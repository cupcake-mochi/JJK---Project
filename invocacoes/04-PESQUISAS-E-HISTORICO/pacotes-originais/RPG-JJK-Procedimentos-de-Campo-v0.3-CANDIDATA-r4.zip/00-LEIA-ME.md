# Projeto M — Procedimentos de Campo

**v0.3 CANDIDATA — revisão 4 · Mizuki · 24/09/2026 · decisões até §40**

Esta revisão incorpora o encerramento seguido de novo comando ao mudar modalidade (§39) e o critério de ocorrência identificável (§40). Preserva as decisões anteriores, incluindo orientação gratuita depois de conhecer o resultado da especial. Nenhuma confirmação do chat externo foi transformada em decisão nova.

## Leitura corrente

1. [Procedimentos consolidados](01-PROCEDIMENTOS-DE-CAMPO-v0.3-CANDIDATA-r4.md): texto autocontido, com decisões, referências, hipóteses e pendências identificadas.
2. [Alterações](02-ALTERACOES-DA-REVISAO.md): decisões incorporadas, esclarecimentos e preservação do histórico.
3. [Pendências e conflitos](03-PENDENCIAS-E-CONFLITOS.md): questões realmente abertas, sem reabrir §§39–40.
4. [Relatório e auditoria](04-RELATORIO-E-AUDITORIA.md): evidência e limites.
5. [Ficha do ensaio](ensaio/FICHA.md) e [casos textuais de intenção](ensaio/CASOS-DE-INTENCAO.md): premissas e aplicações.

## O que foi verificado

**178 verificações executáveis passaram, nenhuma falhou:** 107 de regressão r1/r2 sobre o modelo ampliado e 71 novas. Há 80 verificações de rejeição/consulta com exigência de ausência de mutação. Não são 178 combates, nem provas independentes de equilíbrio.

Os §§31–32 foram examinados em dez casos textuais, sem interpretação automatizada de linguagem. Um caso com referência insuficiente permanece indeterminado até ser delimitado. Esses exemplos não entram na contagem de testes. Não houve playtest humano novo.

## Autoridade e preservação

O registro integral até §40 está em `fontes/DECISOES-POSTERIORES.md`. É cronológico: pendências antigas podem ter sido resolvidas por decisões posteriores. A lista corrente é a desta revisão. A consolidação continua candidata, sem aprovação automática do texto inteiro ou das hipóteses herdadas.

O pacote histórico r3 foi preservado integralmente em `historico/`; contém a r2 e o histórico anterior. Esta r4 substitui a leitura procedimental anterior até §40, sem apagar arquivos, substituir os Caminhos ou modificar o manual principal. As 12 referências protegidas continuam idênticas às usadas anteriormente.

Nenhuma regra de Evocador, Trilha, construtor, orçamento, custo de troca ou energia própria foi criada. Preservados os quatro Caminhos v0.4, Estocada e PE do Emanador sem atributo adicional. Sem alterações no principal, manual ou Caminhos; sem commit/push.

**Pronto para continuar a integração delimitada e aplicar ensaio de mesa aos ramos definidos.** Não há decisão autoral bloqueante para esse recorte. Onde a aplicação depender das pendências restantes, registrar resultado indeterminado. Não declarar o subsistema completo fechado ou equilibrado.
