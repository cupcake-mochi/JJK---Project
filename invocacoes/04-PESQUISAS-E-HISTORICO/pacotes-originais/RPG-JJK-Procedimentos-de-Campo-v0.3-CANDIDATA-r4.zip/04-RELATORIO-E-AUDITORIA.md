# Relatório e auditoria — revisão 4

## Resultado executado

**178 verificações passaram; zero falhas na execução final.**

- 107 regressões: os 49 casos da r1 e os 58 da r2, executados usando as classes ampliadas da r4.
- 71 verificações novas, identificadas como R4-01 a R4-71 em `ensaio/resultados.json`.
- 80 verificações exigem que rejeições/consultas não alterem o estado da cena.
- Dez casos textuais de intenção conferidos separadamente. Não são verificações executáveis ou playtests.

O arquivo `ensaio/execucao.json` contém contagens e hashes dos três arquivos de modelo. `ensaio/resultados.json` registra resultado esperado, obtido e estados antes/depois. A ficha especifica premissas e limites. Não foram fixados números de PE, PV, alcance, X, dano, custos de troca ou progressão.

## Contradições procuradas e evidência delimitada

| Relação | Resultado da conferência |
|---|---|
| Básica × especial | Preparada gasta básica na preparação e não na execução; imediata/antecipada usam básica na execução. R4-01–07 e regressões. |
| Preparada × antecipada | Modalidades exclusivas como especiais pendentes por corpo; antecipada inviável + Preparar básica continua possível. R4-36–43. |
| Substituição × entrada adicional | Mantidas as regressões de entrada, saldo doador, intenção incluída e Movimento próprio. R4-14 acrescenta perda da preparação especial sem transferência de básica investida. |
| Mesmo corpo × novo | Retorno não renova básica, Movimento ou preparação. R4-15 e regressões de identidade, reserva e fronteiras. |
| Movimento × básica transferível | Regressões preservam saldos separados. Preparar não transfere o Movimento nem devolve básica investida; R4-14 preserva Movimento da substituta nova. |
| Coletiva e Guia 30 | Usar a coletiva na preparação especial encerra outras preparações; Guia também pode causar a perda. R4-11–13, 40–43 e 68; regressões preservam a renovação real e corpos distintos do Guia 30. |
| Gatilho inviável | Ocorrência descartada, sem ativação/coletiva. Recurso recuperado não reativa o evento; outra ocorrência é necessária. R4-18–20 e 64. |
| Recusa de ocorrência válida | Conserva preparação até prazo original, sem mudar conteúdo ou guardar disparo. Exige invocador apto, percepção e recepção. R4-21–29 e 65. |
| Ajuste no turno da emissão | Gratuito mesmo sem Bônus disponível, conserva investimentos e não reaproveita evento anterior. Fora desse turno é recusado. R4-30–35. |
| Mudança de modalidade | Encerra ordem antes de novo comando; Padrão anterior não é aproveitada; básica gasta não retorna. R4-44–58 e 71. |
| Nova ocorrência × estado contínuo | Entrada anterior à preparação ou permanência dentro do alcance não disparam; sair e entrar novamente pode disparar dentro do prazo. R4-59–66. |
| Intenção persistente | Objetivo delimitado e autonomia de meios preservados. Dez casos textuais; o programa não julga a semântica de uma frase. |
| Primeira intenção e orientação posterior | Regressões mantêm intenção incluída só na substituta direta e falha sem crédito. R4-02, 26, 28 e 67–70 verificam orientação depois da especial preparada, inclusive destinatária antes sem tarefa. |

Nenhuma contradição adicional foi identificada nas relações e sequências exercitadas. Isso não demonstra exaustividade ou equilíbrio; as lacunas continuam explícitas.

## Ajustes durante a auditoria

A primeira execução passou 174 verificações (107 anteriores e 67 novas). A conferência de cobertura identificou quatro cruzamentos a acrescentar: duas especiais preparadas concorrentes; orientação após especial para corpo antes sem intenção; recuperação de comunicação sem crédito tardio; e novo comando falho depois de encerramento efetivo da ordem anterior. A execução final passou as 178 verificações.

O registro de execução passou a identificar capacidade e alvo da especial preparada executada. A verificação do ajuste agora confere esses dados, além do consumo de recursos. Não foi necessário alterar regra autoral para fazer a bancada passar.

Foi atualizado o texto corrente que ainda marcava mudança de modalidade como pendente. O §40 foi integrado sem transformar a permanência de um estado em sucessivos gatilhos. A regra da orientação após especial foi preservada, inclusive sua gratuidade e momento posterior ao resultado.

## Limites e preservação

As 12 referências protegidas foram conferidas por hash: continuam idênticas às da r2 e não foram editadas nesta etapa. Os dois arquivos de modelo herdados foram copiados sem modificação. Pacotes anteriores e registro histórico até §38 permanecem preservados; o registro atual até §40 foi copiado como fonte.

O principal já estava no commit `26333c2016df5363045c711a25da80f20aa986c1` no início desta etapa; esse estado é posterior às fotografias históricas da r2/r3. Esta tarefa não escreve nele nem desfaz alterações externas. Estado observado e hashes estão no manifesto. Não houve commit/push.

Não foram criadas regras de Evocador, Trilha, construtor, catálogo, orçamento ou custos de substituição. Energia própria continua futura. A possibilidade de reescrever o livro foi registrada como etapa futura, sem execução aqui.

## Estado para continuidade

O bloco procedimental até §40 está consolidado e possui ensaio simbólico ampliado. Pode voltar ao trabalho de integração delimitada e à aplicação em mesa, mantendo os conflitos documentados. Nenhuma decisão autoral nova foi necessária para terminar esta revisão.

Faltam playtest humano e definição das pendências quando necessárias para completar fichas, vínculo ou casos específicos. A revisão não autoriza migração automática ao principal nem declaração de equilíbrio. Recomenda-se usar os casos de intenção para observar dúvidas reais de leitura, antes de criar restrições adicionais.
