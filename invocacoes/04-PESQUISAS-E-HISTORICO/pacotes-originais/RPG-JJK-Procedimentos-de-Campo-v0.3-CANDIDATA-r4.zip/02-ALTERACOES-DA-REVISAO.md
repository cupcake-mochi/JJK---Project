# Alterações — v0.3 CANDIDATA r4

## Decisões autorais incorporadas

O registro cronológico até §40 está em `fontes/DECISOES-POSTERIORES.md`. As confirmações feitas no chat externo não se tornaram decisões novas. Sua correção restabeleceu a orientação gratuita posterior à especial, já aprovada e preservada.

| Decisões | Conteúdo | Integração atual |
|---|---|---|
| §§31–32 | Intenção com objetivo coerente, tarefa concreta e referência delimitada. | Preservada da r3; casos textuais em `ensaio/CASOS-DE-INTENCAO.md`. Não há interpretação automatizada de frases. |
| §§33–34 | Comandar Preparar especial, Padrão+básica na preparação, coletiva+custos próprios no gatilho; prazo e perdas. | Texto da r3 preservado; modelo ampliado e ensaiado. |
| §35 | Uma especial pendente por corpo, antecipada ou preparada; distinta da combinação antecipada inviável + Preparar básica. | Preservado; testadas concorrência e exclusão no modelo ampliado. |
| §§36–38 | Gatilho inviável sem disparo guardado; ajuste gratuito no turno de emissão; recusa comunicada conservando preparação. | Preservados; casos novos de requisitos, recepção, prazos e concorrência. |
| §39 | Mudar modalidade exige encerrar e comandar novamente, pagando outra Padrão, sem aproveitar/devolver gastos. | Seção 8.1.5 e referências cruzadas; casos das duas direções. |
| §40 | Gatilho indica acontecimento identificável; permanência de um estado não repete ocorrência; entrada passada não dispara retroativamente. | Seção 8.1.6; transições booleanas e casos de ocorrência descartada. |

## Esclarecimentos editoriais

- A lista atual de pendências não inclui mais mudança de modalidade nem o critério de repetição de um estado contínuo; §§39–40 os resolveram no recorte aprovado.
- “Outra Padrão” não fornece uma ação adicional. Ela precisa estar legalmente disponível; a espera pela fronteira não congela prazos ou compromissos anteriores.
- Encerrar uma ordem e emitir outra são passos distintos. Comunicação falha do novo comando não ressuscita a ordem que já foi legalmente encerrada.
- Mantida a distinção entre conferir gastos por programa e interpretar uma intenção por leitura. Não somar exemplos textuais aos testes executados.
- Mantidas hipóteses: Avançar do Guia no turno conjunto, quantidade final de básicas e campos numéricos continuam sem nova aprovação.

## O que a r4 substitui para leitura

A r4 substitui a r3 de leitura e as consolidações procedimentais anteriores para ler o estado atual até §40. O registro cronológico continua fonte de autoria. A r3 está preservada no ZIP histórico deste pacote, incluindo r2 e o histórico anterior. Os arquivos e ZIPs anteriores na pasta do usuário não foram alterados.

Não substitui Caminhos v0.4, regras gerais ou manual principal. Nenhuma regra de Evocador, Trilha, construtor, preço, custo de substituição ou orçamento foi criada. Energia própria permanece pauta futura.
