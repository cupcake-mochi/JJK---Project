# Pendências e conflitos atuais — até §40

Mudança de modalidade está decidida: encerrar e comandar novamente, sem aproveitamento. Gatilho de especial preparada usa acontecimento identificável; estado contínuo não renova ocorrência. Não reabrir esses pontos.

## Lacunas que exigem decisão somente quando um caso depender delas

1. **Existência e queda:** regra completa a zero PV onde ausente, retorno, morte do invocador e perda de sustentação/vínculo. A equivalência campo/reserva não escolhe uma consequência de queda que ainda não existe.
2. **Parâmetros e construção futura:** quantidade/progressão de básicas, X, alcance e canais, fontes/custos próprios e posição/legalidade/custos de entrada ou troca. Não preencher com fixtures do ensaio. Energia própria e custo de substituição continuam reservados para depois.
3. **Composição ainda não autorizada:** converter básica em opções originalmente de Bônus e compatibilizar futuras múltiplas básicas com os limites do subsistema.
4. **Janelas concretas fora do recorte:** precedências simultâneas além da disputa da coletiva e situações de intenção prévia ao combate ou prioridade entre tarefas que não sejam resolvidas pelo objetivo delimitado. Não inventar perguntas sem apresentar um caso que dependa delas.
5. **Referências gerais:** resolução de Agarrar/Derrubar/Empurrar; TR de Destreza em Esquivar; divergência de perícia em Estudar; adaptação de Avançar do Guia ao turno conjunto.

## Conflitos preservados

- Manual 60 conserva comando recorrente e inércia sem comando/inconsciência, incompatíveis com as decisões atuais de autonomia. Mecânica 15 e Manual 60 também contêm custos, Matilha e retorno da arquitetura anterior.
- Manual 11 menciona Torrente do Emanador, divergindo da coleção v0.4. Preservados Condutor Armado, Ressonante e Catalisador; nenhuma importação de exceções antigas.
- O TR de Esquivar não foi convertido silenciosamente para Físico. As manobras não ganharam teste ou CD por suposição. Estudar mantém o conflito de perícia identificado.
- Avançar continua adaptação candidata. Guia 30 mantém a exigência de reação dos aliados, corpos distintos e renovação real da coletiva; Golpe continua ataque comum.

## Próxima etapa útil

Aplicar um ensaio de mesa curto aos procedimentos consolidados, usando fichas e requisitos explicitamente fornecidos, sem inventar números finais. A folha de casos semânticos e os cenários de recursos servem de roteiro. Medir dúvidas de leitura e decisões difíceis, além de gastos e resultados. Onde faltar regra necessária, marcar o caso indeterminado.

Não existe decisão autoral bloqueante para essa leitura/aplicação dos ramos definidos. Ainda não é possível declarar todo o subsistema de Invocações fechado ou equilibrado, nem migrar para o principal sem pedido. Reescrita do livro permanece etapa futura; nenhuma reescrita foi iniciada nesta integração.
