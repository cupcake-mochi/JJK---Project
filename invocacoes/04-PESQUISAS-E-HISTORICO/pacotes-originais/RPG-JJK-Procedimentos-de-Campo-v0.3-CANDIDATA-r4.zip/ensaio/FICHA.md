# Ficha do ensaio r4

Ensaio simbólico de estados, sem motor completo, geometria, preços ou equilíbrio. `base_r1.py` e `bancada_r2.py` foram copiados sem edição. `bancada_r4.py` amplia as classes, e as regressões r1 e r2 executam sobre essas classes ampliadas; não se somam execuções independentes de modelos antigos como se validassem o modelo novo.

## Entradas assumidas

- Uma básica por corpo/ciclo é fixture para acompanhar conservação, não quantidade final aprovada.
- Requisitos, sentidos, comunicação e legalidade da emissão são fatos fornecidos pelo roteiro. Não há intérprete de linguagem ou confirmação sobrenatural de recepção.
- Capacidades e gatilhos são identificadores simbólicos já legais; alvo válido e custos disponíveis são predicados. Nenhum PE, PV, dado, preço ou alcance foi fixado.
- A ocorrência é fornecida na janela legal; a resolução é atômica. Não há escalonador universal nem decisão sobre a ordem de todas as interrupções, percepção durante movimento ou efeitos simultâneos. A janela da antecipada não é importada para Preparar.
- Uma observação booleana fora→dentro representa entrada em alcance. Dentro→dentro não representa novo acontecimento. Isso não calcula distância, trajetória ou visibilidade.
- Pagamentos antecipados já ocorridos são marcadores de estado da cena. A bancada verifica que não são apagados pelo encerramento; não implementa o momento, fonte ou preço de toda capacidade com custo antecipado, nem dispensas específicas.
- Dois cenários fornecem explicitamente outra Padrão legal: preparada→antecipada no mesmo ciclo e duas especiais preparadas em corpos diferentes. É premissa externa da cena, não concessão de uma segunda Padrão por este subsistema. Os demais casos usam recursos ordinários e renovação real.
- Troca/recolhimento/entrada são eventos legais fornecidos, com custo fora do modelo. Não significam gratuidade ou permissão de usar esses eventos a qualquer momento.

## Interpretação da execução

Cada verificação confere resultado e invariantes; rejeições e consultas marcadas devem preservar todo o estado. Ocorrência inviável/recusada atualiza somente o registro da ocorrência e o log, conservando os recursos que não foram gastos. Isso impede reaproveitar o mesmo evento após recuperar requisitos.

Um pedido impossível de recusa não é uma recusa bem-sucedida: o roteiro pode prosseguir com a execução da ordem prévia. Não conceder novos comandos na inconsciência. A continuidade de uma ordem já recebida depende da existência/sustentação, que são premissas nos casos exercitados.

A nova orientação é aplicada somente depois do resultado e se for recebida pelo invocador consciente/destinatária apta ao canal. Falha de recepção não guarda crédito. Não se calcula número de usos de capacidades além dos eventos simbólicos de ativação; efeitos próprios completos continuam fora do escopo.

## Limitações mantidas

Casos de intenção §§31–32 estão em `CASOS-DE-INTENCAO.md` e não entram na contagem automatizada. Não se verifica equilíbrio, preços, morte/retorno definitivos, fontes de energia, toda a ficha do Guia, todas as condições, múltiplas básicas ou todos os efeitos simultâneos. Um resultado de queda indeterminado continua intencionalmente indeterminado quando não há regra válida.

Não se modela interrupção depois de iniciar execução atômica. Isso não autoriza desfazer execução iniciada nem fixa restituições para capacidades interrompidas: seguem sua regra própria ou permanecem pendentes.

## Reprodução

Execute `python3 bancada_r4.py` nesta pasta. O programa escreve `resultados.json` (estados antes/depois) e `execucao.json` (resumo). A execução dos scripts históricos como programas separados regravaria esses mesmos nomes; use a bancada r4 para reproduzir este relatório.
