# Alterações r2 → r3 de leitura e autoridade documental

Status: v0.3 CANDIDATA. A r3 deste pacote é uma consolidação textual para continuidade até o §38. Não é uma nova bancada nem aprovação automática do documento inteiro.

## Decisões aprovadas incorporadas

| Registro autoral | Decisão | Local na consolidação |
|---|---|---|
| §§31–32 | Um objetivo coerente, tarefa concreta e referência delimitada; meios autônomos pertinentes são permitidos; sinais não disfarçam redirecionamento gratuito. | Seção 4 |
| §§33–34 | Preparar especial mediante Padrão + básica agora; coletiva e custos próprios na execução, inclusive dentro do turno; prazo e perdas de Preparar; orientação após resolução efetiva. | 8.1.1 |
| §35 | Uma especial pendente por corpo, antecipada ou preparada. Preservada a combinação distinta de antecipada inviável com Preparar básica. | 6.8 e 8.1.5 |
| §36 | Gatilho inviável não inicia execução; preparação permanece até o prazo original e requer nova ocorrência válida. | 8.1.2 |
| §37 | Ajuste de alvo/capacidade/gatilho da mesma preparação livre no turno em que foi emitida, com recepção e prazo preservados. | 8.1.3 |
| §38 | Recusa comunicada de ocorrência válida conservando preparação; exige nova ocorrência e preserva prazo, gastos e perdas. | 8.1.4 |

## Esclarecimentos editoriais

- Atualizados os limites de ordens e a tabela que diferencia Preparar básica, preparar especial por comando e antecipar uma especial.
- Especificado que a ordem que conserva a espera após outra resposta gastar a coletiva é a antecipada; preparações se perdem. Isso evita ambiguidade após ampliar o limite conjunto para incluir especiais preparadas.
- Removidas da pauta atual as perguntas já respondidas sobre limites da intenção e permissão/custos da preparação especial.
- Explicitado na seção de reentrada que preparação também se perde na saída, assim como já consta nos procedimentos específicos.
- Mantida a distinção entre básica não gasta em uma intenção impedida e básica efetivamente investida em Preparar.
- Preservados marcadores de hipótese/pendência: por exemplo, Avançar do Guia e as lacunas de manobras/TR não viraram aprovação.
- Retiradas do texto corrente as sugestões rejeitadas de proibir preparação especial ou cobrar Bônus por seu ajuste no turno de emissão. Elas só constam no histórico para explicar a decisão.

## Pendências e prioridade

Conversão entre modalidades continua em aberto. Consulte `03-PENDENCIAS-E-PROXIMA-PAUTA.md`; não recuperar a lista desatualizada da r2 como pauta atual. Não há regra nova de custo de troca ou energia própria.

Mensagens atuais explícitas de Mizuki prevalecem. Para o material deste pacote, a fonte autoral é `fontes/DECISOES-POSTERIORES.md`, até o §38, lida cronologicamente. Os blocos detalham essas decisões; a consolidação organiza a leitura sem inventar aprovação. Se aparecer divergência real, registrar com trecho e seção e pedir decisão apenas onde necessário. Pendências antigas do registro podem ter sido resolvidas por seções posteriores.

## O que esta leitura substitui

A r3 de leitura substitui, para ler os Procedimentos de Campo atuais, a r2 e os blocos parciais 02 e 04–22, além das propostas procedimentais históricas já substituídas pela r2. Não substitui o registro de autoria, não altera o manual principal e não revoga os Caminhos v0.4.

O ZIP r2 foi mantido integralmente em `historico/`, com o histórico anterior que ele já contém. O registro e todos os blocos atuais foram copiados sem edição em `fontes/`. Não é necessário abrir os ZIPs históricos para começar a próxima discussão.
