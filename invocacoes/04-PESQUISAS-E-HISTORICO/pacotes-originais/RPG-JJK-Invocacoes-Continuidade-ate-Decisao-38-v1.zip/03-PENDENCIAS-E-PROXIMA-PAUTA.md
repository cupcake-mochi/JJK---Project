# Pendências reais e próxima pauta

## Próximo ponto autoral recomendado: conversão entre modalidades

Ainda não foi decidido se uma especial antecipada pode virar preparada ou vice-versa, nem como tratar a Padrão já paga, a básica, os custos antecipados e o prazo. Ajustar conteúdo de uma ordem não autoriza mudar seu procedimento.

Na próxima conversa, apresente a distinção e uma recomendação concreta para discussão com Mizuki, com exemplos curtos e sem números. Não adote uma solução antes da resposta. Pode separar as duas direções se os efeitos forem diferentes, sem exigir a mesma solução por simetria.

Respeite o que já está fechado: uma especial pendente por corpo; antecipada deve cumprir a primeira oportunidade válida ou ser encerrada por desistência legal; preparada já gastou básica e expira no próximo início do turno; ajuste gratuito da preparada só no turno da emissão; recusar seu gatilho preserva a preparação, mas não guarda o evento passado. Conversão não pode ser considerada aprovada apenas porque esses outros ajustes existem.

Casos para fundamentar a proposta, ainda sem resultado aprovado:

1. Antecipada inviável, básica disponível: o invocador quer passar a preparar para um gatilho específico.
2. Antecipada inviável, básica já gasta: verificar que a proposta não cria uma preparação gratuita sem básica elegível.
3. Preparada com Padrão e básica gastas: o invocador quer uma ordem que persista depois da expiração original.
4. Tentativa de converter quando a antecipada já encontrou oportunidade válida: não presumir exceção ao compromisso para contornar a execução.

Não abrir agora custos de substituição, reserva de PE ou construtor para resolver essa pergunta.

## Outras pendências, somente quando o recorte exigir

- **Existência e queda:** consequência completa a zero PV onde faltar regra válida; retorno, morte do invocador e perda de sustentação/vínculo. Campo e reserva já têm equivalência aprovada; isso não escolhe uma consequência ausente.
- **Parâmetros futuros:** quantidade/progressão de básicas, X, alcance/canais específicos, custos/fontes das capacidades e posição/legalidade/custos de manifestação, recolhimento e troca. Não fixar números.
- **Composição futura:** conversão de básica em opções originalmente de Bônus e compatibilização de múltiplas básicas. A existência de diversas capacidades não concede ações adicionais.
- **Janelas e interpretação:** precedência de efeitos simultâneos fora da disputa da coletiva; gatilhos vagos ou contínuos; intenções prévias ao combate e prioridade entre tarefas. Só levar um caso concreto que realmente dependa disso; não gerar novas restrições por risco abstrato.
- **Preparação e inconsciência:** aplicar as instruções prévias e limites já aprovados, sem conceder novos comandos, cancelamentos ou recusa voluntária consciente. Se um caso exigir autonomia adicional de recusa ou prioridade não definida, sinalizar a lacuna em vez de aprová-la por analogia.

## Conflitos com o principal e referências

1. Manual 60 exige comando recorrente e prevê inércia sem comando/inconsciência, contrariando a autonomia e as ordens persistentes da candidata.
2. Manual 60 e mecânica 15 usam a arquitetura anterior de Invocações, custos, Matilha e retorno. Não importar seus números ou queda automaticamente.
3. Manual 11 menciona Torrente do Emanador; preservar a coleção v0.4 com Condutor Armado, Ressonante e Catalisador.
4. Agarrar/Derrubar não têm resolução suficiente; Empurrar também permanece sem procedimento. Esquivar menciona TR de Destreza em um projeto com TR Físico, Vigor, Intelecto e Espírito. Estudar tem divergência de perícia. Não resolver por suposição.
5. Avançar do Guia no turno conjunto continua adaptação marcada, sem alteração da v0.4. A resposta Golpe continua ataque comum: não básica, especial, Sequência ou Ação Atacar.

As referências copiadas estão idênticas às usadas na r2. Nenhum desses conflitos foi corrigido no projeto principal neste pacote.

## O que não está pendente novamente

Não reabrir como perguntas gerais: relógio do invocador; coletiva única; movimento por corpo e sua conservação fora de campo; primeira intenção da substituta; estados próprios; comunicação; desistência da antecipada; compromisso com oportunidade válida; Preparar básica; permissão de preparar especial; recursos, prazo, limite de ordens, gatilho inviável, ajuste no turno de emissão e recusa de gatilho da preparada. Consulte a consolidação e as decisões cronológicas.

## Pauta reservada

Energia própria de invocações e custo da substituição foram expressamente reservados para discussão posterior. Evocador e Trilhas vêm depois do subsistema de Invocações. Não criar agora construtor, catálogo, preços ou orçamento em fatias.

Não há decisão bloqueante para ler, discutir e auditar os procedimentos já fechados. A conversão fica indeterminada até decisão específica. O conjunto não está pronto para ser declarado subsistema definitivo ou equilibrado.
