# Modelo de retorno — preencher ao encerrar a próxima etapa

Este arquivo é um modelo de entrega, não uma regra nem uma decisão nova. Não preencher campos com aprovações presumidas. O pacote recebido termina no §38; numere novos registros a partir de §39 sem renumerar os anteriores.

## Entrega 1: RETORNO-DECISOES.md

- Base recebida: v0.3 CANDIDATA — revisão 3 de leitura, decisões até §38.
- Escopo efetivamente discutido e material lido.
- Para cada decisão nova: pergunta/proposta apresentada; resposta autoral exata ou trecho fiel suficiente; procedimento aprovado; limites; recomendações rejeitadas ou alteradas; seção afetada na consolidação.
- Separar esclarecimento editorial, nova decisão autoral, hipótese de ensaio e proposta ainda não aprovada.
- Identificar o último ponto encerrado e o próximo realmente pendente.

## Entrega 2: PROPOSTA-OPERACIONAL-INTEGRAL-ATUALIZADA.md

Texto autocontido dos procedimentos, conservando o rótulo CANDIDATA. Incorporar somente decisões explícitas; manter hipóteses e pendências marcadas. Preservar os trechos não alterados pelo novo recorte. Não entregar apenas um resumo que obrigue a reconstruir a regra pelo histórico.

## Entrega 3: PENDENCIAS-E-CASOS.md

- Lista curta de decisões realmente ausentes, sem reabrir as já respondidas.
- Para cada caso analisado: estado inicial, sequência, resultado esperado e regra de apoio.
- Distinguir análise textual, teste executado e playtest humano. Se faltar uma regra, marcar resultado indeterminado.
- Declarar se algum arquivo/teste foi realmente executado; não atribuir os 107 casos da r2 às decisões posteriores.
- Conferir: básica × especial; preparada × antecipada; substituição × entrada adicional; mesmo corpo × novo; Movimento × básica transferível; coletiva; intenção persistente; primeira intenção; comunicação; inconsciência; custos; expiração; gatilho não armazenado.

## Declaração de escopo

Informar se foram preservados os quatro Caminhos v0.4, Estocada e PE do Emanador sem atributo; se nenhuma regra de Evocador, Trilha, construtor ou orçamento foi criada; e se nenhuma alteração no principal, commit ou push foi realizada.

Caso um desvio tenha sido expressamente solicitado por Mizuki, registrar a autorização e o alcance, sem afirmar preservação que deixou de ocorrer.

## Empacotamento

Entregar os três arquivos acima em `RPG-JJK-Invocacoes-Retorno-pos-38.zip`, se houver capacidade de criar arquivos. Manter fontes históricas sem edição e distinguir claramente novas entregas. Se não houver essa capacidade, fornecer o conteúdo integral em texto e explicar a limitação.
