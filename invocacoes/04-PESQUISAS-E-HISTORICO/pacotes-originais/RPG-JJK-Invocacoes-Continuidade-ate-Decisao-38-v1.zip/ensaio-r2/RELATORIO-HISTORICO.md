# Ensaio e auditoria interna — revisão 2

**Resultado:** 107 verificações passaram, nenhuma falhou na execução final. São 49 verificações de regressão no modelo ampliado e 58 novas. Há 42 verificações de rejeição ou consulta que exigem ausência de mutação. São verificações de estados e sequências curtas, não 107 combates ou provas independentes de equilíbrio.

O caso R2-15 verifica explicitamente que faltar regra válida de queda produz indeterminação. Ele passar demonstra que a lacuna foi preservada, não que sua resolução foi inventada. A ficha do ensaio registra premissas e o que o modelo não cobre.

## Auditoria de contradições

| Relação auditada | Resultado e evidência delimitada |
|---|---|
| Básica × especial | Especial ocupa básica e não deixa outra. Emissão sem execução só investe Padrão; recursos próprios são pagos ao executar. Regressão 01–17; novos 25–30 e 56–58. |
| Substituição × entrada adicional | Só substituta direta recebe saldo possível e intenção incluída; entrada adicional mantém Bônus para tarefa e não cria básica. Regressão 21–32; novos 35–36 e 45–46. |
| Mesmo corpo × corpo novo | Reentrada não muda identidade nem restaura Movimento. Corpo fora por vários ciclos não se torna novo. Novos 01–06; corrigida uma formulação ambígua herdada no exemplo da seção 9.5. |
| Movimento × básica transferível | Movimento é saldo próprio, conservado durante ausência; básica antiga não é armazenada entre ciclos. Nova fronteira ausente encerra trava anterior sem gerar básica. Novos 01–06. |
| Coletiva e Guia 30 | Uma reserva; segunda resposta do Guia depende de renovação real e outro corpo, sem criar básica. Preparação termina se Golpe usar coletiva. Regressão 41–44; novos 53–54. |
| Preparar × ordem antecipada | Preparar gasta básica agora, expira e perde-se pela reserva gasta ou saída. Ordem antecipada aguarda requisito; perder coletiva por concorrência não a encerra. Novos 17–24 e 49–50. |
| Compromisso × escolha | Não se escolhe esperar mantendo ordem válida; escolher resposta concorrente é permitido, inclusive inconsciente. Não autoriza cancelar inconsciente. Novos 23–30, 56–58. |
| Intenção persistente × tarefa cumprida | Impedimento temporário conserva; cumprimento não inventa missão; autopreservação tem recursos e limites. Novos 31–36. Sem interpretação automática de instruções complexas. |
| Primeira intenção × recepção | Comunicação falha não desfaz transferência e não guarda orientação gratuita. Corpo retornando conserva intenção anterior válida. Novos 45–48 e 55. |
| Comunicação × autonomia | Perda do canal não apaga ordem anterior. Nova emissão/ajuste falho conserva gasto sem mudar instrução; cancelamento não recebido não cancela. Novos 37–44 e 51–52. |
| Duração × presença | Prazo passa fora; efeito independente continua; aura dependente não alcança campo; ausência não limpa indiscriminadamente. Novos 07–13. |
| PV × recolhimento | Dano persistente pode levar a zero em campo ou fora; reentrada não cura; consequência depende de regra válida e é indeterminada se ausente. Novos 14–16. |

Nenhuma contradição adicional foi identificada nos ramos exercitados após as correções descritas abaixo. Isso não demonstra exaustividade de interações ou equilíbrio.

## Correções durante a integração e auditoria

1. A r1 dizia, num exemplo, que um corpo que não entrou “naquele ciclo” teria Movimento novo. A redação r2 exige corpo realmente novo; retornar após ausência conserva apenas o restante. Corrige uma ambiguidade editorial diante da decisão expressa de Mizuki.
2. Foram removidas pendências já resolvidas nas seções de relógio, comando, Preparar, intenção e comunicação. Status [H]/[P] restantes foram preservados, inclusive Avançar e lacunas das regras gerais.
3. A primeira execução ampliada passou 99 verificações. A inspeção do código identificou que o caminho auxiliar de especial imediata precisava passar pela mesma checagem de recepção da emissão. Esse caminho foi unificado antes da execução final, e foram acrescentadas oito verificações sobre emissão imediata, Guia/Preparar, retorno com intenção, preterição e inconsciência.
4. A guarda herdada de preterir especial válida ainda retornava “fora do recorte”. A r2 passou a recusá-la conforme decisão autoral; os testes 56–57 verificam isso. Não foi adicionada uma regra de balanceamento para corrigir o programa.
5. Os efeitos temporais são aplicados nos roteiros sem escolher precedências ainda pendentes; nenhuma ordem de expiração/dano simultâneos virou regra por conveniência de implementação.

## Preservação e estado de integração

As 12 referências protegidas conferem byte a byte com a r1. O principal permanece em `ba1e0df6f05dad71659eed2abd06c43d22963834`, sem alterações locais na verificação. Não houve commit/push. A coleção v0.4, Estocada e PE do Emanador sem atributo permanecem preservados.

O material está pronto para continuar a integração delimitada e montar ensaios de mesa dos ramos definidos. Não há decisão autoral bloqueante para esse avanço. Regras completas de queda/retorno, parâmetros, vínculos e combinações ainda pendentes precisam de decisão quando um cenário depender delas; não se declara o subsistema inteiro fechado ou equilibrado.

Não foi criada nenhuma regra de Evocador, Trilha, construtor ou orçamento. O roteiro seguinte recomendado é fechar limites de intenções condicionais; não iniciar preços ou ficha definitiva para contornar essa pendência.
