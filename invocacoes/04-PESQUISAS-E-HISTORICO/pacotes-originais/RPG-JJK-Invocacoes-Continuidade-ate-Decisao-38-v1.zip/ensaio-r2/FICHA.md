# Ficha do ensaio — revisão 2

## Natureza

Ensaio simbólico de transições de estado; não é combate simulado, playtest humano, motor completo ou prova de equilíbrio. Os 49 casos antigos rodam com a classe de cena ampliada; 58 casos novos verificam as decisões recentes e seus cruzamentos. Nenhuma contagem histórica adicional é somada.

## Premissas

- Uma oportunidade básica identificada por corpo/ciclo é fixture para verificar conservação. Não define quantidade/progressão final.
- Movimento acompanha disponibilidade e, num caso, fração abstrata restante de 0,4. Essa fração não é regra, velocidade ou número de metros; testa que um saldo parcial não volta cheio.
- PV é estado simbólico. Um efeito de teste já autorizado pela cena pode fornecer o resultado zero, sem escolher dados, dano ou vida. Uma regra de queda pode ser fornecida como premissa; sem ela, a resposta é indeterminada.
- Padrão, Bônus e Reações são disponibilidade; custo próprio é evento de ativação e predicado de disponibilidade, sem preço ou quantidade de PE.
- Troca, recolhimento e entrada são eventos legais externos. Não se atribui ação/PE, posição ou autorização de manifestar a zero PV. O caso de entrada com PV zero só demonstra que uma entrada fornecida não cura; não prova que tal entrada seja legal no RPG.
- Alvos, percepção, alcance, comunicação, gatilhos válidos, área em campo e resultado de TR são entradas do roteiro. Falha oculta de recepção é conhecida pelo teste, não automaticamente pelo personagem.
- Cada roteiro chama a resolução na janela pertinente. Não existe busca automática de todas as oportunidades geométricas. O modelo recusa adiamento na janela válida e preterição por básica/autopreservação; não constitui escalonador completo de combate.
- Preparar usa uma ação básica e gatilho já legais na cena. A janela de Preparar não é equiparada à janela posterior à resolução da especial antecipada.
- Efeitos de início/fim são aplicados explicitamente. Não se decide precedência entre expiração e ocorrência simultâneas, nem dano/cura simultâneos. Os casos não combinam gatilhos sem ordem aprovada.
- As sondas do Guia 30 recebem cadeia, Aberturas, capacidades e elegibilidade válidas. Conferem reservas, corpos distintos e renovação real, não toda a ficha, Feitiço breve ou Avançar.

## Limites

Não implementa todos os momentos de aplicação/remoção de condições, todas as regras de existência, manobras, múltiplas básicas, custos antecipados específicos, ressurreição, morte do invocador, fontes de PE ou consequências definitivas de queda. Estados que precisam dessas regras não são aprovados pela ausência de erro no programa.

O modelo mantém separadas intenção, ordem antecipada e preparação. Um roteiro precisa informar se uma tarefa está temporariamente impedida ou realmente cumprida; o código não decide semanticamente se uma frase autoriza outra missão.

## Reprodução

Execute `python3 bancada_r2.py` nesta pasta. Regrava somente `resultados.json` e `execucao.json`. `base_r1.py` conserva a base histórica e os 49 casos reutilizados; o programa r2 substitui as classes utilizadas pela regressão por suas versões ampliadas antes de executá-la.
