# Auditoria da consolidação de leitura

## Alcance

Conferência documental da r2, registro integral §§1–38 e blocos 17–22. A r3 de leitura incorpora os §§31–38 por substituições localizadas nas seções 4, 6.8, 8.1, 9.5 e 11, mais cabeçalho/status. Não foi desenvolvido um novo motor de regras nem executado um novo ensaio mecânico.

## Relações conferidas no texto

| Relação | Resultado documental e limite |
|---|---|
| Básica × especial | Imediata/antecipada usam básica na execução; preparada usa básica ao preparar e não cobra outra no gatilho. |
| Preparada × antecipada | Prazo, custos e compromisso separados; conversão permanece pendente. Recusar conservando só foi aprovado para a preparada. |
| Limite de ordens | Uma especial pendente por corpo entre as duas modalidades; não uma por modalidade. Antecipada inviável + Preparar básica continua relação distinta. |
| Substituição × entrada adicional | Só a substituta direta recebe até uma básica não gasta e a orientação incluída. Entrada adicional não cria básica. |
| Mesmo corpo × novo | Identidade e gastos preservados; retorno não se torna nova manifestação para renovar Movimento. |
| Movimento × básica | Movimento próprio não é transferido; básica transmitida sai do saldo da origem e não pode ser copiada. |
| Preparação × saída | Retirada encerra a preparação; básica investida não é devolvida à substituta. Ordem antecipada também termina, mas sua emissão não gastou básica por si. |
| Coletiva | Reserva única; preparação exige coletiva até no turno do invocador; usá-la em outra resposta faz perder preparações. Antecipada sem coletiva espera. |
| Guia 30 | A segunda resposta dispensa somente Reação do Guia; respostas de criaturas ainda dependem da coletiva e de renovação real. Golpe não vira básica/especial/Sequência. |
| Ajustes | Antecipada usa Bônus. Preparada pode mudar conteúdo gratuitamente apenas no turno da emissão; não muda corpo/modalidade ou renova prazo. |
| Gatilho perdido/recusado | Não guarda ocorrência nem renova prazo; nova ocorrência válida é necessária. Não restaura preparação já encerrada. |
| Intenção persistente | Objetivo concreto permite meios autônomos pertinentes; troca de referência pelo invocador exige redirecionamento, inclusive por sinal. |
| Primeira intenção | Incluída somente na substituição direta; recepção falha não guarda crédito, não desfaz troca legal nem básica transferida. |
| Comunicação/inconsciência | Instruções anteriores não são apagadas pela mera perda de comunicação; instruções novas exigem recepção. Recusa do §38 exige invocador apto e não inventa comandos inconscientes. |
| Lacunas/números | Mantidos marcadores de pendência/hipótese em parâmetros, queda, manobras/TR, Avançar e conversões não decididas. |

Esta auditoria confere coerência documental nas relações listadas. Não demonstra ausência de todas as contradições, ausência de exploração ou equilíbrio. Situações que dependem de pendências devem continuar indeterminadas.

## Evidência de testes

Em `ensaio-r2/` estão as 107 verificações históricas: 49 regressões e 58 novas naquela revisão, zero falhas na execução registrada e 42 verificações de consulta/rejeição sem mutação. Não foram reexecutadas para este empacotamento. O resultado pertence à r2, até §30.

Os §§31–38 não estão implementados nessa bancada e não foram ensaiados neste pacote. Em particular, interpretação de frases, preparação especial, ajuste gratuito e recusa conservando ainda precisam de casos próprios. Uma verificação histórica de resultado indeterminado a zero PV não resolve a regra de queda ausente. Nenhum playtest humano novo foi realizado.

## Preservação

As 12 referências protegidas foram comparadas por hash com a r2 e copiadas sem edição. O ZIP r2 também é idêntico ao original. Registro e blocos foram copiados integralmente. A integridade dos arquivos e do ZIP novo será registrada no manifesto e na conferência de entrega.

O principal avançou desde a fotografia da r2: no início deste empacotamento estava no commit `a1ad1f0b17f57d6eba717d614098aa8e94383dcd`, com alterações locais já presentes em anti-domínios e materiais editoriais. Não atribuir a esta etapa o estado limpo ou commit antigo descritos nos relatórios históricos. O empacotamento não escreve no principal, não reverte trabalho externo e não realiza commit/push; o manifesto registra o estado observado.

Nenhuma regra de Evocador, Trilha, construtor ou orçamento foi criada. Nenhum valor novo de X, alcance, PE, PV, dados, aquisição, manifestação ou troca foi fixado. Os exemplos de Nue não criam ficha ou capacidade numérica.
