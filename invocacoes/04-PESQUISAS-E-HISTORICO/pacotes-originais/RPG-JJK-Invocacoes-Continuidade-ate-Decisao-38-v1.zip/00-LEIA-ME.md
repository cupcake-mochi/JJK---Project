# RPG-JJK / Projeto M — continuidade de Invocações até a decisão 38

Mizuki · 24/09/2026 · pacote de continuidade v1.

**Leitura corrente: v0.3 CANDIDATA — revisão 3 de leitura.** Reúne a r2 e as decisões posteriores §§31–38 em um texto autocontido. Essa consolidação textual não significa aprovação automática da candidata ou execução de novos ensaios. Nenhuma regra nova foi escolhida durante o empacotamento.

## Como usar no novo chat

Anexe o ZIP completo e cole `05-PROMPT-PARA-COLAR.md`. O prompt também está dentro do pacote. Modelo recomendado: GPT-5.6 Sol, alto na conversa comum e extra alto em auditoria concentrada. Para a integração posterior em arquivos e testes: GPT-6 Astra, alto. A escolha é recomendação de trabalho, não promessa de economia quantificada nem mudança automática de configuração.

Leia os documentos 00, 01, 02, 03, 04 e o registro integral `fontes/DECISOES-POSTERIORES.md`. As referências gerais/Caminhos e os blocos são consulta sob demanda. Não é necessário descompactar históricos aninhados para começar. Não presumir acesso à pasta local do projeto: este pacote contém as fontes necessárias ao recorte.

## Conteúdo e autoridade

- [Procedimentos consolidados](01-PROCEDIMENTOS-v0.3-CANDIDATA-r3-LEITURA.md): texto corrente até §38.
- [Alterações e autoridade](02-ALTERACOES-E-AUTORIDADE.md): o que mudou, o que substitui para leitura e como tratar fontes.
- [Pendências e próxima pauta](03-PENDENCIAS-E-PROXIMA-PAUTA.md): próxima discussão sobre conversão entre modalidades, ainda sem solução aprovada.
- [Auditoria e limites](04-AUDITORIA-E-LIMITES.md): conferência textual e integridade do pacote; distingue evidência histórica de validação nova.
- [Prompt para colar](05-PROMPT-PARA-COLAR.md): pedido completo para a nova conversa.
- [Modelo de retorno](06-MODELO-DE-RETORNO.md): formato para trazer decisões e proposta integral de volta à integração.
- `fontes/`: registro autoral até §38, pauta futura e blocos atuais, copiados integralmente sem edição.
- `referencias/`: quatro Caminhos v0.4, notas e regras pertinentes, com arquitetura antiga identificada.
- `ensaio-r2/`: bancada, resultados, ficha e relatório históricos. 107 verificações até §30; não cobrem §§31–38.
- `historico/`: ZIP r2 original intacto, incluindo o histórico anterior.
- `MANIFESTO.json`: inventário, hashes e estado de preservação.

As decisões autorais explícitas prevalecem sobre recomendações antigas. Pendências em seções antigas do registro são históricas quando resolvidas depois. Os documentos desta pasta principal indicam a pauta atual; não retomar a pergunta antiga da r2 sobre autorizar Preparar especiais ou delimitar intenções.

## Limites preservados

Primeiro Invocações, depois Evocador e Trilhas. Nenhum construtor, preço, orçamento, custo de substituição ou reserva própria de PE foi criado aqui. Não fixar parâmetros pendentes por exemplo numérico. Preservar Caminhos v0.4, Estocada e PE do Emanador sem atributo adicional.

O principal CLAUDE-2 continua somente para leitura. Não houve edição nele, nos Caminhos ou nas regras gerais, nem commit/push. Este pacote substitui leituras procedimentais anteriores para continuidade, sem apagar o histórico ou modificar o manual.

Pronto para a discussão delimitada no novo chat. A conversão entre modalidades ainda exige decisão quando um caso depender dela; ela não impede ler e auditar os ramos já definidos. O subsistema completo não foi declarado fechado ou equilibrado.
