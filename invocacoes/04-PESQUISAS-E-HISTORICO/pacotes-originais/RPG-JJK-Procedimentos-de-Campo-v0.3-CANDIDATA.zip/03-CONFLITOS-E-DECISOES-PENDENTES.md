# Conflitos e decisões pendentes

**v0.3 CANDIDATA · 24/09/2026**

## 1. Situação do material

**Pronto para continuar a integração do projeto principal como documento candidato.** Não falta decidir de novo autonomia, especial substitutiva, intenção posterior, relógio ou regra central de substituição.

**Ainda bloqueado para publicação como procedimento definitivo e para uma bancada completa sem hipóteses:** detalhes da ordem antecipada e primeira intenção sem substituição; casos de condições/janelas ou de ausência do campo também precisam de resolução quando forem incluídos. Não é necessário encerrar construtor ou preços para revisar o texto e ensaiar isoladamente os casos já determinados.

## 2. Lista curta de decisões realmente abertas

| ID | Decisão necessária | O que já está fechado | O que bloqueia |
|---|---|---|---|
| P1 | Comando antecipado: aprovar ou ajustar o procedimento candidato; definir próxima oportunidade sob impedimento, expiração, cancelamento, mudança de alvo/capacidade, substituição/acúmulo de ordens e destino na inconsciência/troca. Fixar timing/fonte dos custos sem antecipar seus preços. | Padrão paga na ordem; básica futura substituída; não há nova Padrão na execução. | Operação completa e ensaio desses ramos. Recomendações detalhadas estão em §6.2 da candidata. |
| P2 | Primeira intenção de entrada sem substituição e diretriz para ausência/cumprimento/impossibilidade da tarefa. | Gratuidade inicial restrita à substituta direta; intenção válida persiste. | Rotina de uma entrada adicional sem tarefa. Não presumir que pagar Bônus resolve automaticamente o procedimento inicial. |
| P3 | Colocação exata das janelas por corpo e validação das adaptações: básica ↔ Padrão para Atordoado, Preparar e turno conjunto para Avançar. | Iniciativa e renovação comuns, janelas individuais somente para início/fim, nenhuma iniciativa extra. | Casos em que a ordem dos efeitos muda a elegibilidade. |
| P4 | Estado fora de campo quando o texto da fonte não resolver: efeitos dependentes de presença e passagem de fronteira com o corpo ausente. | Troca não cura nem renova usos; identidade, gasto no ciclo e saldo transmitido são preservados. | Somente retornos/efeitos que dependam dessas circunstâncias. Não decidir que retirar congela ou limpa efeitos. |
| P5 | Parâmetros operacionais: quantidade de básicas, X, meio/alcance, legalidade/custos de entrada e valores/fonte de capacidades. | Repertório não multiplica execuções; nenhum custo ausente é zero. | Fichas definitivas e simulação numérica completa. Ensaios delimitados podem declarar hipóteses; não fixar números nesta entrega. |
| P6 | Lacunas de referência: manobras e TR/perícia ambíguos, somente quando usados. | Agarrar/Derrubar são opções gerais; Esquivar e Estudar não ganham correções implícitas. | Casos que dependam da resolução ausente. Não bloqueia testar as demais ações. |

P1 pode ser decidido sobre uma proposta concreta já escrita, sem retomar a arquitetura. A aprovação de uma bancada com hipóteses não equivale a aprovar essas regras para publicação.

## 3. Divergências confirmadas com o projeto atual

Projeto principal conferido em `main`, commit `ba1e0df6f05dad71659eed2abd06c43d22963834`, sem alterações locais. As 12 referências do registro anterior conservaram seus hashes. A conferência de conteúdo foi dirigida às dependências destes procedimentos; não foi auditoria integral do RPG.

| Fonte atual | Divergência | Tratamento nesta entrega |
|---|---|---|
| `sistema/05-material/livro/manual/60-invocacoes.md`, “Regra rápida do turno” e “Queda do dono” | Comando de Padrão a cada rodada; inércia sem comando e durante inconsciência. | Incompatível com a autonomia aprovada. Registrar para futura migração, sem mesclar as regras nem pedir que Mizuki decida a arquitetura novamente. |
| Mesmo capítulo, “Regra rápida” e “Amarra e alcance” | Ordem fixa logo depois do dono e inércia fora da amarra numérica antiga. | A candidata usa ordenação conjunta e preserva tarefa autônoma com meios reais. Não importar alcance nem inércia antigos como parâmetros silenciosos. |
| `sistema/03-mecanica/15-invocacoes.md`, §1 e Q2/Q3; manual 60, “Queda e morte/Voltar” | Rotina total repartida, Matilha de vida coletiva, orçamento/custos fixos e retorno com vida prescrita pertencem à arquitetura antiga. | Não são base automática desta folha de corpos e estados individuais. Recuperação de uma entidade derrotada fica fora; preservar estado em retirada comum não decide ressurreição. Validador antigo não valida a candidata. |
| `sistema/05-material/livro/manual/11-o-turno.md`, “Limites” | Referência à Trilha Torrente do Emanador; a coleção v0.4 tem Condutor Armado, Ressonante e Catalisador. | **Conflito entre regra geral e coleção registrado. Preservar v0.4.** Não restaurar Torrente nem usar sua exceção na resposta de Classe 0 do Guia. Correção futura da referência geral requer edição autorizada; não cria uma Trilha nova. |
| Manual 11, tabela de Esquivar; manual 10, “Testes de Resistência” | “TR de Destreza” versus quatro TR nomeados, com Físico baseado em FOR ou DEX. | P6: sem tradução automática. |
| Manual 11, “Agarrar e Derrubar” e “Vasculhar e Estudar” | Condições de manobras não bastam para resolver sua aplicação; tabela e explicação de Estudar usam listas de perícias diferentes. Empurrar não tem procedimento de combate fechado nas referências consultadas. | P6: isolar as tentativas dependentes; não importar regras de outro sistema. |

**Guia 30 não apresentou conflito que exija alterar o Caminho:** o cruzamento de ciclos foi aceito expressamente. A segunda resposta dispensa só a Reação do Guia. Não há razão para inventar teto reativo adicional.

**Nota editorial de proveniência:** o arquivo do Emanador dentro da coleção v0.4 traz internamente “Emanador v0.3”. Foi preservado byte a byte, identificado pelo arquivo/hash da coleção fornecida; não se procurou uma versão alternativa nem se editou o cabeçalho. Seus 6 PE por nível continuam sem atributo adicional.

## 4. Próximo ensaio necessário, ainda não executado

Depois da decisão mínima de P1 e P2 — ou de autorização específica para hipóteses — atualizar apenas a bancada separada:

1. Especial fora da intenção, resultado e orientação posterior para outro alvo; testar ausência de básica extra.
2. Comando antecipado que executa, falha requisito, expira, cancela ou muda alvo; concentração de especial antecipada com Padrão atual, sem duplicar a básica de um corpo.
3. Troca antes/depois do gasto, 1→vários, vários→1 e A→B→A; rastrear a mesma oportunidade transmitida e os Movimentos separados.
4. Entrada adicional sem básica criada; comparar Movimento de corpo novo com saldo do mesmo corpo ao retornar; registrar primeira intenção pela decisão escolhida.
5. Coletiva disputada por Preparar, Aparar/oportunidade e Guia; Guia 30 com e sem renovação entre gatilhos e com participantes distintos.
6. PV, condições e usos preservados; somente incluir ausência através da fronteira, consciência e efeitos dependentes de presença após explicitar suas hipóteses/decisões.

Sem preços, fichas completas ou novos números agora. Testes procedimentais conferem transições; depois, balanceamento exigirá experimentos próprios. Não avançar para Evocador, Trilhas, construtor ou orçamento.
