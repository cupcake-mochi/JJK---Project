# Auditoria interna — v0.3 CANDIDATA

**24/09/2026 · Revisão textual e rastreamento lógico de recursos.**

Não é playtest, simulação de combate ou execução de um novo motor de regras. Os 168 checks do ensaio anterior pertencem ao modelo v0.2 executado sob suas hipóteses. Não foram reapresentados como validação da candidata.

## 1. Critério

Confrontaram-se os oito documentos obrigatórios, as dependências efetivas das regras gerais e a coleção v0.4. Procuraram-se contradições entre os procedimentos e promoções indevidas de recomendações a decisões autorais. Exemplos abaixo acompanham uma oportunidade identificada, sem aprovar uma quantidade final de básicas por ciclo.

**Coerente:** o resultado decorre dos procedimentos e não exige inventar regra. **Condicional:** depende de adaptação expressamente candidata. **Aberto:** a fonte não fecha a execução; permanece pendência, não aprovação/falha de teste.

## 2. Casos revisados

| ID | Caso | Resultado da revisão | Status / seção da candidata |
|---|---|---|---|
| A01 | Corpo usa básica; recebe comando especial para executar no mesmo ciclo. | O comando comum não recupera a básica. Antecipar é opção distinta, para o futuro. | Coerente, §5–6 |
| A02 | Corpo executa especial; tenta básica adicional. | A oportunidade foi ocupada. Não há básica extra pelo comando. | Coerente, §5 |
| A03 | A executa especial; B ainda tem básica. | Somente a oportunidade de A foi substituída. | Coerente, §5 |
| A04 | Criatura conhece muitas capacidades. | Mais escolhas não significam mais execuções. | Coerente, §2 |
| A05 | Futura ficha tem múltiplas oportunidades. | Quantidade e compatibilização não resolvidas; não inferir básica + especial. | Aberto, §1 |
| A06 | Intenção é enfrentar A; especial atinge X; nova orientação aponta Y. | Padrão e básica para a especial; decisão sobre Y só após resultado, sem Bônus ou nova execução. | Coerente, §5 |
| A07 | Especial de A e orientação posterior pretendem mudar também B. | Benefício posterior se limita à destinatária; B precisa de fonte própria de mudança. | Coerente, §4–5 |
| A08 | Troca de básica dentro da tarefa; depois troca da tarefa. | Primeira não cobra microcomando; segunda usa redirecionamento salvo exceção expressa. | Coerente, §4 |
| A09 | A tarefa terminou ou ficou impossível. | Sem regra universal de nova tarefa/autopreservação; não inventar ordem automática. | Aberto, §4 |
| A10 | Emitir ordem antecipada depois de básica já usada. | Padrão agora; especial usa futura básica, sem nova Padrão naquele ciclo. | Coerente no núcleo, §6.1 |
| A11 | Especial antecipada e Padrão atual disponível. | Concentração temporal intencional; não contar como Padrão nunca paga. | Coerente no núcleo, §6.1 |
| A12 | Falta PE, alvo some ou condição impede na oportunidade esperada. | Requisitos não podem ser dispensados; prazo, consumo e perda da ordem seguem pendentes. | Aberto, §6.2 |
| A13 | Cancelar ou trocar alvo/capacidade da ordem. | Não usar recomendações de não reembolso/nova Padrão como decisões aprovadas. | Aberto, §6.2 |
| A14 | Ordem pendente durante inconsciência ou troca. | Autonomia básica/transferência não resolvem persistência nem destinatária da ordem. | Aberto, §6.2 e §10 |
| A15 | Preparar tratado como sinônimo de antecipar. | Separados: básica agora + coletiva no gatilho versus Padrão agora + básica futura. | Coerente na distinção; adaptação de Preparar condicional, §8.1 |
| A16 | Preparação guardada; outra entidade gasta coletiva. | Na adaptação proposta, perde-se a preparação; renovar depois não recupera o efeito expirado/perdido. | Condicional, §8.1 |
| A17 | Duas invocações tentam reagir sem renovação intermediária. | Um gasto esgota a única coletiva; a pessoal do invocador não paga a segunda. | Coerente, §7 |
| A18 | Coletiva gasta; novo Bloquear e Aparar. | Bloquear continua elegível; contra-ataque exige coletiva disponível. | Coerente, §7 |
| A19 | Uma criatura não pode reagir por condição; outra pode. | Impedimento não é gasto. A outra pode pagar a reserva ainda disponível. | Coerente, §7 |
| A20 | Resposta do Guia depois de básica ou especial. | Ataque comum por coletiva; sem básica nova, Sequência ou Ação Atacar. | Coerente, §8.2 |
| A21 | Guia 30, dois respondentes, sem renovação. | Segunda resposta não pode usar coletiva já gasta; dispensa só para o Guia não resolve. | Coerente, §8.3 |
| A22 | Guia 30 externo, renovação entre gatilhos da cadeia. | Segunda criatura distinta pode pagar a coletiva renovada, respeitados os demais limites. | Coerente, §8.3 |
| A23 | Mesmo corpo tenta as duas respostas do Guia 30. | A renovação da coletiva não apaga a proibição expressa do Guia. | Coerente, §8.3 |
| A24 | A ainda tem básica; B substitui e nunca gastou no ciclo. | Transfere no máximo uma oportunidade; debita A. | Coerente, §9.2 |
| A25 | A já gastou; B novo substitui. | Sem básica transferível; B tem Movimento próprio e intenção incluída. | Coerente, §9.2 |
| A26 | A sai; B e C entram. | Uma substituta direta recebe saldo possível e primeira intenção; demais sem os dois benefícios. Movimentos continuam individuais. | Coerente, §9.3 |
| A27 | Várias saídas para uma entrada. | Não fundir oportunidades; no máximo uma transferida. | Coerente, §9.3 |
| A28 | A transmite básica a B; A retorna alegando que não a executou. | Não conserva a básica transferida. Só pode usar saldo que ainda lhe pertença ou transmissão legal sem duplicação. | Coerente, §9.2–9.5 |
| A29 | A executou básica ou especial, saiu e retorna como substituto. | Histórico do corpo bloqueia receber outra básica no mesmo ciclo. | Coerente, §9.2–9.5 |
| A30 | A gastou Movimento; B novo entra; depois A retorna. | B traz seu Movimento; A conserva o gasto anterior. Não se herdam metros de A nem se reseta A. | Coerente, §9.5 |
| A31 | C novo entra sem substituir. | Movimento próprio disponível; sem básica criada, coletiva renovada ou primeira intenção grátis. Como atribuir a tarefa é pendente. | Coerente nos saldos; intenção aberta, §9.4 |
| A32 | Corpo sem básica recebe primeira intenção na substituição. | Orientação válida não gera execução. Benefício não depende de a saída deixar saldo. | Coerente, §9.2 |
| A33 | Rodada global vira ou janela individual começa. | Não renovam recursos novamente; a fronteira é a do invocador. | Coerente, §3 |
| A34 | Troca perto da fronteira, com oportunidade transferida. | Nova fronteira renova normalmente, mas não concede execução fora de janela legal. | Coerente, §3 e §9 |
| A35 | Corpo ferido/condicionado/com usos gastos sai e retorna. | Não cura, limpa condição ou restaura uso por troca. Efeitos dependentes de presença seguem sua fonte. | Coerente no estado; efeito sem texto é aberto, §9.5 |
| A36 | Corpo permanece fora quando o ciclo vira. | Não atribuir renovação à reentrada nem decidir duração de efeitos fora de campo sem texto. | Aberto, §9.5 |
| A37 | Usuário inconsciente; criatura existente e sustentada. | Rotina, Movimento e respostas possíveis continuam; novos comandos e acesso aos PE não são concedidos. | Coerente na rotina; PE/ordem pendente abertos, §10 |
| A38 | Atordoado ou efeito de início/fim muda elegibilidade. | Existência da janela é aprovada; colocação e equivalência da básica precisam da adaptação explícita. | Condicional/aberto, §3 e §7 |
| A39 | Agarrar/Derrubar/Empurrar ou TR de Esquivar. | Nenhuma resolução importada; caso permanece fora até decisão de referência. | Aberto, §2 e §8 |
| A40 | Números da antiga bancada reaparecem como parâmetros. | Candidata não fixa X, PE, dados, PV, alcance ou custos pendentes. Fórmula de Bloquear e limites já aprovados não são números de ficha novos. | Coerente, §1–11 |

## 3. Pontos ajustados ou explicitados durante a integração

1. **Saldo transmitido versus saldo conservado:** explicitado que a básica deixa o cedente. Isso impede duplicação na reentrada mesmo quando o cedente nunca a executou.
2. **Fronteira versus oportunidade:** mantida a renovação aprovada sem conceder atuação livre imediatamente antes/depois dela. Custos e janelas de troca continuam abertos.
3. **Quantidade futura versus veto de acúmulo:** mantida a proibição de obter básica + especial pelo comando comum; quantidade/progressão não foi usada para criar exceção.
4. **Prazo do antecipado:** “próxima oportunidade válida” aprovado foi separado de “expira ao fim da próxima oportunidade normal”, que é recomendação e pode exigir decisão sob impedimentos.
5. **Condições e Preparar:** a aprovação do relógio não foi usada como aprovação automática de todas as adaptações da bancada.
6. **Resposta do Guia:** Golpe permaneceu ataque comum, e a alternativa Feitiço breve permaneceu no Caminho, sem ser apagada ou convertida em especial de invocação.
7. **Efeitos persistentes:** conservar estado não foi traduzido como congelar durações fora de campo; ausência através da fronteira foi deixada visível quando não resolvida pela fonte.

## 4. Resultado e limites

Nenhuma contradição detectada no núcleo decidido ficou escondida como regra final: os casos dependentes de escolhas continuam condicionais ou abertos. Isso não é prova formal de completude. A folha é autocontida para conhecer o procedimento candidato e seus limites; não é um RPG inteiro nem uma ficha pronta para jogar.

As checagens de arquivos e hashes registradas no manifesto verificam preservação e empacotamento, **não regras de combate**. Não houve playtest com pessoas, nova comparação de equilíbrio, implementação no projeto principal, commit ou push.
