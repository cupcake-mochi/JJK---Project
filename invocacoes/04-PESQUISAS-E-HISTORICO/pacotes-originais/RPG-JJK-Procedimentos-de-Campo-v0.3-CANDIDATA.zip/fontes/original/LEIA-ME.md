# RPG-JJK — próxima conversa: procedimentos de campo

Anexe `RPG-JJK-Procedimentos-de-Campo-v1.zip` a um Chat comum e cole [PROMPT-PARA-COLAR.md](PROMPT-PARA-COLAR.md). O recorte pede conversa em etapas e decisões de Mizuki. A autorização para executar a bancada anterior não aprovou seus números.

## Leitura inicial

1. [Estado e pauta](01-ESTADO-E-PAUTA.md).
2. [Decisões explícitas do retorno v0.2](base-v0.2/01-RETORNO.md).
3. [Proposta integral v0.2 com status](base-v0.2/02-PROPOSTA-REVISADA-INTEGRAL.md).
4. [Resultados do ensaio](ensaio/RELATORIO.md) e [ficha com hipóteses](ensaio/FICHA-DO-ENSAIO.md).

O prompt começa por especial versus intenção persistente. Depois vêm relógio e entrada/troca. Não se deve reiniciar a arquitetura nem repetir as escolhas sobre autonomia, básica individual ou coletiva.

## Referências de consulta

- `regras-gerais/`: capítulos 10, 11 e 15 integrais do projeto.
- `caminhos-v0.4/`: os quatro Caminhos em Markdown e suas pendências. Não alterar Estocada nem acrescentar atributo aos PE do Emanador.
- `ensaio/`: o relatório e a ficha são leitura inicial; script, JSON, resumo de execução e manifesto são evidência opcional. Não é necessário carregar os registros completos para discutir. A reprodução automática original depende dos caminhos locais listados em `verificacao-fontes.json`; este pacote não presume acesso a eles, e não solicita nova execução no chat de discussão.
- `verificacao-fontes.json`: estado local e hashes verificados na tarefa de integração, como histórico de procedência.

As cópias mantêm seus textos originais. Caminhos absolutos e comandos de reprodução pertencem ao ambiente de origem; a estrutura acima é a referência de localização neste pacote. Não foram incluídos o repositório inteiro, a pesquisa de mercado nem os antigos protótipos A/B/C, pois não são necessários para reabrir escolhas que já foram feitas. Se surgir dependência indispensável não incluída, identificá-la sem presumir seu conteúdo.

## Retorno

Pedir que o chat preencha [MODELO-DE-RETORNO.md](MODELO-DE-RETORNO.md) e entregue a proposta operacional integral. Se gerar arquivos não estiver disponível, dois textos copiáveis bastam para voltar à tarefa de integração. Não trocar para Work apenas para empacotar a conversa.

`MANIFESTO.json` registra hashes/tamanhos dos arquivos, cópias de origem e textos novos. Os documentos originais não foram modificados para montar este pacote.
