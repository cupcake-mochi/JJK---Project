# Estado e pauta — procedimentos de campo

**Objetivo deste chat:** escolhas autorais sobre como executar a autonomia já escolhida. Não é uma nova pesquisa de arquitetura, uma simulação completa ou a criação do Evocador.

## Precedência

1. Pedidos e decisões explícitas de Mizuki nesta conversa.
2. Decisões explícitas do retorno v0.2, preservadas até alteração expressa; hipóteses contidas no mesmo retorno continuam hipóteses.
3. Quatro Caminhos da coleção v0.4 e regras gerais como referências. Não trocar pela versão antiga de Caminhos existente no repositório.
4. Resultado do ensaio como evidência limitada pelas premissas. Recomendações do relatório não são aprovações.

O pacote foi organizado após Mizuki perguntar se o próximo recorte deveria ocorrer em Chat comum e com arquivos. Isso autoriza a preparação do material, não resolve as escolhas abaixo.

## O que a bancada acrescentou

Foram executadas 168 checagens em 58 cenários/sondas, com 55 recusas esperadas e oito registros indeterminados. Esses números pertencem a um modelo limitado, sem playtest com pessoas ou orçamento aprovado.

- Ajudar pode superar o ataque básico. Com +5 contra Defesa fixa 16, usuário 3d6 + 2 e criatura 1d6 + 1: ataques separados rendem 9,20; usuário ajudado, 10,39875 de dano primário esperado.
- Especial substitutiva custa duas contribuições: Padrão do usuário e básica da destinatária. Uma especial de 5d6 + 1 ficou abaixo da rotina ajudada com uma entidade; com uma segunda ajudando a especial, chegou a 15,58125 contra 12,82375 da melhor rotina ofensiva examinada. Não existe dano mínimo universal dedutível desses casos.
- Bloquear pode mudar o ordenamento das opções. Sua média igual à Defesa fixa não torna as distribuições equivalentes.
- Esquivar da Sentinela não força o inimigo a atacá-la. Proteção, cobertura e escolha de alvo não são o mesmo benefício.
- Reação coletiva não é um limite de uma resposta dentro do ciclo de qualquer outro personagem. O caso Guia 30 foi executado com e sem renovação entre gatilhos.
- Trocar por uma reserva saudável amplia a vida disponível na cena mesmo sem curar o corpo retirado. O procedimento completo e os custos de troca continuam pendentes.

## Pauta delimitada

| Bloco | Questão ainda aberta | Base que não será reaberta |
|---|---|---|
| A — Comando e objetivo | Especial pontual versus mudança de intenção; possibilidade de ordem diferida e primeira intenção pertinente. | Padrão para especial; Bônus para redirecionar; especial ocupa básica disponível e não acontece após básica usada. |
| B — Relógio | Confirmar ou revisar H1/H2/H7 e explicitar durações, renovação e interação com o Guia. | Básicas individuais, Movimento próprio, reserva coletiva e autonomia funcional durante inconsciência. |
| C — Entrada/troca | Saldo de básica/Movimento na entrada, renovação, reação, retorno do mesmo corpo e persistência de estado. | Entidades distintas; nenhuma cura ou custo gratuito presumido; capacidade e preços ainda abertos. |

Alcance, comunicação e X só entram até onde forem necessários. A hipótese X = 3 do ensaio não foi aprovada; metade da Essência também não. A folha pode voltar com variáveis e dependências explícitas, sem forçar preço, número de corpos ou progressão antes do construtor.

## Critério de saída

Ao final, deve ser possível explicar um ciclo e uma resposta inimiga, indicar a fonte de cada recurso e reconhecer claramente o que ainda depende de regra futura. A entrega é uma folha operacional integral com status, decisões rastreáveis, mudanças em relação à v0.2, exemplos e pendências. Voltar à tarefa de integração nesse ponto, sem desenvolver Evocador/Trilhas nem pedir novamente escolhas já resolvidas.

## Fontes e acesso

O projeto principal verificado é `main` em `ba1e0df6f05dad71659eed2abd06c43d22963834`; as 12 referências comparadas ficaram idênticas ao pacote anterior. Estas cópias permitem a discussão sem acesso direto à pasta. Caminhos absolutos nos relatórios são rastreabilidade do ambiente de origem, não prova de acesso neste chat.
