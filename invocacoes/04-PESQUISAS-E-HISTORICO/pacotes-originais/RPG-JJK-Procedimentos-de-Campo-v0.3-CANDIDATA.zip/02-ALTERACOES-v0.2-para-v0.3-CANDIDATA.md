# Registro de alterações — v0.2 → v0.3 CANDIDATA

**24/09/2026 · Integração textual, sem aprovação automática da versão.**

Base histórica: `base-v0.2/01-RETORNO.md` e `base-v0.2/02-PROPOSTA-REVISADA-INTEGRAL.md`, no pacote original. Fonte das decisões posteriores: `MODELO-DE-RETORNO.md`, seção 2, e `PROPOSTA-OPERACIONAL-INTEGRAL.md`, com os status de cada seção. O pedido atual de Mizuki determina os limites desta integração e a identificação **v0.3 CANDIDATA**; orientações históricas dos documentos não substituem esse pedido.

## 1. Decisões aprovadas incorporadas

| Item | v0.2 | Decisão incorporada | Fonte posterior | Destino na candidata |
|---|---|---|---|---|
| Especial e intenção | Relação aberta. | Especial pode sair da intenção vigente sem Bônus adicional. | Proposta §3.2; retorno §2. | §5 |
| Orientação posterior | Sem procedimento fechado. | Após conhecer o resultado, conservar ou substituir a intenção da destinatária sem Bônus extra; pode apontar outro alvo. | Proposta §3.3; retorno §2. | §5 |
| Antecipar comando | Possibilidade levantada, não autorizada. | Padrão paga agora para próxima oportunidade válida quando a básica já foi usada; substitui básica futura sem nova Padrão. | Proposta §4.1. | §6.1 |
| Iniciativa e ciclo | Hipótese do ensaio. | Iniciativa conjunta; ciclo e renovação no início do turno do invocador; rodada global não renova. | Proposta §5.1–5.2. | §3 |
| Janelas por corpo | Adaptação ainda em discussão. | Janelas apenas para início/fim de turno e efeitos escritos; sem outra iniciativa ou recursos completos de personagem. | Proposta §5.3. | §3 |
| Guia 30 | Consequência observada no ensaio. | Preservar v0.4 e permitir dois gastos da coletiva se separados por renovação real dentro da cadeia. | Proposta §8.2; retorno §2. | §8.3 |
| Substituição | Esperar versus herdar eram hipóteses. | Pode transferir no máximo uma básica não gasta a substituta elegível. | Proposta §9.3–9.6. | §9.2–9.3 |
| Rotação | Procedimento aberto. | Corpo que já gastou básica no ciclo não recebe outra por retornar como substituto. | Proposta §9.4. | §9.2 e §9.5 |
| Uma saída, várias entradas | Não resolvido. | Uma substituta direta recebe o saldo possível e primeira intenção; demais não ganham esses benefícios. | Proposta §9.5. | §9.3 |
| Movimento na entrada | Ensaio comparava herança junto do saldo. | Movimento é próprio; corpo novo entra com o seu disponível, sem herdar metros. | Proposta §1.2 e §9; retorno §2. | §7 e §9 |
| Primeira intenção | Aberta para toda entrada. | Incluída sem Bônus somente para substituta direta. | Proposta §9.2–9.5. | §9 |
| Estado na saída/reentrada | Sem cura/troca definidas. | PV, condições, usos e demais estados não renovam pela simples saída/reentrada; mesmo corpo conserva histórico. | Proposta §9.7 e §10; pedido atual explícito. | §9.5 |

Permanecem as decisões da v0.2: atuação e Movimento individuais; intenção persistente; Bônus para tarefa nova comum dentro de X pendente; especial substitutiva; uma coletiva separada da pessoal; básicas funcionais durante inconsciência com sustentação válida; repertório sem multiplicar execuções; autonomia como parte do investimento. Nenhuma delas foi reaberta.

## 2. Redações esclarecidas, sem concessão nova

| Esclarecimento | Razão e limite |
|---|---|
| Transferência sai do saldo do cedente. | “Assumir o que sobrou” não pode copiar a mesma básica. Conservar recursos próprios não conserva uma oportunidade já transmitida. |
| Especial conta como gasto da básica para a trava de retorno. | A especial ocupa aquela oportunidade; não muda sua identidade para permitir recuperá-la por rotação. |
| Movimento é contabilizado por identidade do corpo. | Distingue chegada de criatura nova de reentrada da mesma criatura. Não cria renovação por mudança de posição ou nome. |
| Primeira intenção na substituição não depende de básica transferida. | A orientação incluída e o saldo são benefícios distintos; dar intenção não dá ação. |
| Entrada adicional não significa ausência eterna de básicas. | A entrada não cria uma; a fronteira normal aplica a disponibilidade prevista na ficha. Quantidade continua aberta. |
| Renovação não é janela de execução. | Troca perto da fronteira não concede ação fora do turno. A oportunidade precisa ser legal nos dois ciclos. |
| Condição impeditiva não gasta coletiva. | Uma criatura inelegível não impede por si outra criatura apta de pagar a reserva disponível. |
| Guia não concede nova básica. | Golpe é ataque comum; Feitiço breve continua a alternativa própria escrita no Guia. Nenhuma resposta vira comando especial, Ação Atacar ou Sequência por inferência. |
| Guia externo versus invocador-Guia. | O cruzamento entre ciclos depende de fronteiras distintas; dispensa da Reação do Guia não dispensa a coletiva. |
| Preparar versus ordem antecipada. | Preparar ocupa básica agora e cobra coletiva no gatilho. Antecipar paga Padrão antes e substitui básica futura. |
| Mesma intenção versus ordens vagas. | Escolher outra básica pertinente não exige Bônus; novas tarefas não surgem automaticamente só porque uma intenção se tornou impossível. A diretriz desse caso continua aberta. |
| Disponibilidade versus fonte. | Nenhum recurso, capacidade, PE, sentido ou ataque é herdado só por existir uma oportunidade para usá-lo. |

Esses esclarecimentos explicitam limites do núcleo aprovado; a redação final continua candidata. Se forem propostos comportamentos além dessas consequências, devem receber status próprio, não ser incluídos como simples revisão editorial.

## 3. Recomendações preservadas como recomendações

- **Comando antecipado (§6.2 da candidata):** custos próprios na execução, momento exato de consumir básica, checagem de requisitos, expiração ao fim da próxima oportunidade normal, cancelamento sem reembolso da Padrão, nova ordem para mudar alvo/capacidade e cancelamento ao usar a básica em outra coisa. Todos continuam candidatos, conforme §4.2 do retorno.
- **Janelas individuais:** existência aprovada; colocação exata ainda candidata.
- **Condições:** equivalência de básica à Padrão para Atordoado continua adaptação de integração, não aprovação deduzida do ensaio.
- **Preparar e Avançar:** aplicação ao relógio conjunto explicitada, sem transformar adaptação anterior em decisão autoral específica.
- **Comportamento sem intenção válida e conversões de ações da entidade:** não resolvidos por conveniência.

## 4. Pendências conservadas

Continuam abertos o procedimento completo da ordem antecipada, a primeira intenção sem substituição, a interação de estados/efeitos fora de campo quando o texto não resolver, a quantidade de básicas, X e comunicação. Custos de manifestação/troca, PE, PV, dados, alcance e demais parâmetros de ficha não foram definidos. Lacunas de Agarrar/Derrubar/Empurrar, Esquivar e Estudar não foram reparadas.

Construtor, preços, orçamento em fatias, catálogo, aquisição, progressão, recuperação definitiva, Evocador e Trilhas ficaram fora. Não foram criadas regras desses módulos.

## 5. O que deixa de ser referência operacional principal

Para **leitura corrente dos Procedimentos de Campo**, usar `01-PROCEDIMENTOS-DE-CAMPO-v0.3-CANDIDATA.md` em lugar de montar a regra a partir de:

1. `base-v0.2/02-PROPOSTA-REVISADA-INTEGRAL.md` do pacote original;
2. `PROPOSTA-OPERACIONAL-INTEGRAL.md` do retorno;
3. trechos procedimentais da pauta `01-ESTADO-E-PAUTA.md`, da ficha e do relatório do ensaio antigo, quando descrevem hipóteses posteriormente decididas — especialmente ausência de comando antecipado e Movimento tratado junto do saldo de troca.

`base-v0.2/01-RETORNO.md` e `MODELO-DE-RETORNO.md` continuam registros de decisões e autoria. `ensaio/RELATORIO.md`, `ensaio/FICHA-DO-ENSAIO.md`, código e resultados continuam evidências históricas **da versão executada**, sem passar a validar esta candidata. LEIA-ME, pauta e prompts antigos conservam sua função histórica de encaminhamento.

Nenhum arquivo foi apagado ou sobrescrito. Essa precedência de leitura **não substitui os Caminhos, as regras gerais nem o manual do projeto principal**; a futura migração depende de autorização e do tratamento dos conflitos registrados.
