# Procedimentos de Campo — pacote de integração

**RPG-JJK / Projeto M, de Mizuki · v0.3 CANDIDATA · 24/09/2026**

O núcleo anterior foi preservado. Foram incorporadas as decisões posteriores sobre especial fora da intenção, orientação após o resultado, comando antecipado em sua direção aprovada, relógio do invocador, consequência de Guia 30 e substituição com básica transferível, Movimento próprio e primeira intenção restrita à substituta.

**Esta é uma consolidação candidata, não aprovação da v0.3.** Recomendações e lacunas estão marcadas no próprio procedimento. Nenhum número pendente foi fixado.

## Arquivos da entrega

1. [Procedimentos de Campo — v0.3 CANDIDATA](01-PROCEDIMENTOS-DE-CAMPO-v0.3-CANDIDATA.md): leitura principal, autocontida.
2. [Alterações v0.2 → v0.3 candidata](02-ALTERACOES-v0.2-para-v0.3-CANDIDATA.md): decisões aprovadas, esclarecimentos, recomendações e pendências; inclui a precedência de leitura.
3. [Conflitos e decisões pendentes](03-CONFLITOS-E-DECISOES-PENDENTES.md): divergências reais com os arquivos atuais, bloqueios delimitados e próximo ensaio.
4. [Auditoria interna](04-AUDITORIA-INTERNA.md): 40 casos de revisão lógica/textual, sem simulação nem afirmação de equilíbrio.
5. `MANIFESTO.json`: hashes, comparação das fontes, estado do projeto e resultado das verificações de arquivos.
6. `fontes/`: cópias intactas dos dois ZIPs recebidos e dos documentos de leitura obrigatória, para preservar a proveniência. Os ZIPs guardam também o restante do histórico fornecido.

## Precedência e limites

A candidata passa a reunir a leitura corrente dos procedimentos antes distribuída entre a proposta integral v0.2 e a proposta operacional do retorno. Os retornos autorais e o ensaio continuam históricos; não foram apagados, reescritos ou retroativamente aprovados. Ver a lista detalhada de substituição para fins de leitura no registro de alterações, seção 5.

O pedido atual de Mizuki prevalece sobre instruções antigas dos pacotes. As decisões identificadas como aprovadas no retorno foram incorporadas; as recomendações do mesmo retorno não se tornaram regras por inferência.

**Nenhuma regra de Evocador, Trilha, construtor ou orçamento foi criada.** Não houve edição de Caminhos, regras gerais ou do projeto principal. Bastião, Vanguarda, Emanador e Guia da coleção v0.4, Estocada e Emanador sem atributo adicional nos PE foram preservados. Não houve commit nem push.

## Prontidão

Pronto para voltar ao trabalho de integração como **v0.3 CANDIDATA**. Para fechar a regra e executar todos os ramos sem hipóteses, ainda são necessárias decisões autorais sobre o procedimento mínimo do comando antecipado e a primeira intenção sem substituição, além das adaptações pontuais quando usadas. Isso não exige reabrir a arquitetura nem avançar aos módulos futuros.

O próximo passo é decidir esses campos a partir da proposta concreta já registrada e então atualizar a bancada separada. Os 168 checks antigos não validam esta versão; a auditoria entregue agora é textual e procedimental.
