# Procedimentos de Campo — Invocações

**RPG-JJK / Projeto M · Mizuki · v0.3 CANDIDATA · 24/09/2026**

Consolidação para leitura e integração. **Não é aprovação automática da v0.3, alteração do manual nem certificação de equilíbrio.** As decisões autorais já aprovadas permanecem aprovadas; a redação integrada e suas adaptações ainda são candidatas.

## 1. Status, escopo e vocabulário

- **[D] Decisão autoral:** aprovada por Mizuki na v0.2, no retorno posterior ou no pedido desta integração.
- **[R] Referência:** regra geral ou Caminho da coleção v0.4, preservado.
- **[E] Esclarecimento:** explicita uma consequência necessária das decisões, sem criar concessão.
- **[H] Recomendação/adaptação candidata:** solução operacional ainda não aprovada especificamente. Não usar como regra definitiva por estar nesta folha.
- **[P] Pendente:** não interpretar silêncio como gratuidade, permissão ou proibição.

Esta folha reúne os procedimentos de atuação, intenção, comando, relógio, reação, entrada e substituição. Não cria regras de Evocador, Trilha, construtor, catálogo, progressão, preços ou orçamento em fatias. Preserva Bastião, Vanguarda, Emanador e Guia da coleção v0.4, Estocada e os PE do Emanador sem acréscimo de atributo.

**Entidade/corpo:** a criatura individual, com identidade e estados próprios, mesmo depois de sair e retornar. **Conjunto:** invocador e suas entidades, na mesma iniciativa; a reserva coletiva pertence somente às entidades. **Ciclo:** do início de um turno do invocador ao início do próximo. **Básica disponível:** uma oportunidade de atuação básica ainda utilizável, não o nome de uma capacidade. **Substituta direta:** entidade escolhida no evento de troca para substituir a que sai; não é uma vaga permanente.

**[P] Quantidade final de básicas por ciclo e progressão:** não fixadas. Uma básica por corpo por ciclo foi hipótese da bancada v0.2. Esta folha não transforma esse número em regra final nem autoriza múltiplas execuções. Nos exemplos, acompanha-se apenas uma oportunidade identificada. A regra preservada impede usar o comando comum para acumular básica e especial no mesmo corpo no ciclo; uma futura ficha com várias oportunidades exigirá compatibilização explícita, não uma exceção inferida daqui.

## 2. Recursos e repertório

**[D]** O invocador conserva suas próprias ações. Cada entidade dispõe de atuação básica e Movimento próprios. Todas as entidades compartilham **uma Reação coletiva**, separada da Reação pessoal do invocador.

| Recurso | A quem pertence | O que não concede |
|---|---|---|
| Atuação básica | Cada entidade | Não dá outra execução por conhecer outra capacidade. |
| Movimento | Cada corpo | Não usa nem transfere os metros do invocador ou da criatura substituída. |
| Reação coletiva | Todas as entidades do mesmo invocador | Não há uma reserva por corpo; a Reação pessoal não a abastece. |
| Padrão/Bônus do invocador | Personagem | Não passam às criaturas quando ele deixa de usá-las. |

**[D]** O repertório pode conter ações gerais e kit próprio, inclusive entidades sem ataque. Ações gerais compatíveis com o corpo não ocupam escolhas personalizadas do kit, mas gastam o recurso correspondente. Anatomia, sentidos, conhecimentos, comunicação e circunstâncias continuam necessários. Não há mãos, fala, telepatia, percepção compartilhada ou ataque implícitos.

Distinga ações gerais, capacidades básicas próprias, especiais ativas comandadas, capacidades reativas e passivas/efeitos persistentes. Aprender uma especial não a torna básica; uma passiva não herda automaticamente o custo de uma especial. Um comando não autoriza repetição indefinida da capacidade.

**[R/E]** Atacar, Correr, Desengajar, Esquivar, Esconder, Ajudar, Vasculhar, Estudar e Usar objeto são opções conforme seus requisitos. Correr ocupa a atuação correspondente para ampliar deslocamento; não acompanha gratuitamente um ataque. Ajudar exige contribuição efetiva e beneficia a tentativa pertinente: vários ajudantes não acumulam vantagem no mesmo teste. A ajuda de outra entidade a uma especial consome a básica da ajudante.

**[P]** A tabela geral de ações não concede Conjurar autonomamente nem ataques adicionais do Caminho do invocador. Agarrar e Derrubar são opções de Atacar na referência, mas falta resolução completa; Empurrar também não recebeu procedimento. Não atribuir teste, CD ou custo por analogia. A ambiguidade de perícia em Estudar permanece registrada.

**[H/P]** A bancada não concedeu Bônus própria por entidade. Converter básica em opções gerais originalmente de Bônus, como Provocar e Ler o Ambiente, continua sem aprovação. Esta folha não concede uma árvore de conversões à criatura.

## 3. Relógio e oportunidades

**[D]** As entidades usam a iniciativa do invocador. O jogador organiza as atuações do conjunto, concluindo cada ação antes da seguinte. Não surgem iniciativas próprias por corpo.

O ciclo começa no **início do turno do invocador** e termina no início do próximo. Nessa fronteira renovam-se a disponibilidade básica conforme a ficha, o Movimento próprio e a Reação coletiva. Restrições e condições continuam aplicáveis. **Virar a rodada global não renova esses recursos.** Manifestar, recolher, substituir, redirecionar ou emitir comando também não os renova.

**[D/E]** Há janelas individuais dentro do turno conjunto apenas para efeitos escritos de início/fim do turno de cada criatura, inclusive TR de condições Pesadas ao fim do turno do alvo. Elas não criam outra iniciativa, outro conjunto de ações ou segunda renovação. A fronteira comum de recursos não se repete na janela individual.

**[H/P]** A colocação exata dessas janelas em relação às atuações ainda requer redação fina. Para ensaio, é possível propor início imediatamente antes da atuação daquele corpo e fim depois de concluída sua participação; isso não foi aprovado, sobretudo para entradas tardias ou corpos sem básica. Não escolher livremente múltiplos inícios/fins para repetir efeitos.

**[E]** Renovar um saldo não autoriza agir fora de uma oportunidade permitida. Uma troca perto da fronteira pode transmitir saldo do ciclo anterior e ser seguida da renovação normal, mas só permite duas atuações próximas se ambas tiverem janelas legais. Não cria uma básica fora do turno. Não foi aprovada uma carência adicional por ter acabado de entrar.

## 4. Intenção persistente e redirecionamento

**[D]** Uma tarefa continua valendo sem comando repetido. A entidade escolhe opções básicas e movimento coerentes com a intenção, o que percebe e o que consegue fazer. Trocar de opção dentro da tarefa não é automaticamente redirecionar.

“Proteja esta entrada” pode justificar aproximar-se, Ajudar, Esquivar ou atacar uma ameaça pertinente, se a ficha permitir. Não obriga o inimigo a atacar a criatura, não concede interceptação e não revela alvos que ela não percebe.

**[D] Redirecionar:** o invocador gasta **Ação Bônus** para atribuir a mesma nova intenção a até **X** destinatárias. Intenções distintas exigem comandos distintos na base. As criaturas podem escolher básicas e trajetos diferentes para cumprir a tarefa comum. O comando muda a tarefa, sem recuperar básica, Movimento ou coletiva, e não autoriza especial.

**[R]** A Padrão do personagem pode ser convertida em Bônus, e a Bônus em Movimento, nunca no sentido inverso. Assim, Bônus e Padrão convertida podem pagar redirecionamentos diferentes; a Padrão convertida já não está disponível para comandar especial.

**[P]** X, fórmula, meios e alcance de comunicação permanecem abertos. Não importar X = 3, metade da Essência ou o alcance do Guia como alcance do vínculo. Receber orientação depende de um meio válido; autonomia não equivale a comunicação ilimitada.

**[H/P]** Encerrar intenção por cumprimento ou impossibilidade e definir comportamento sem tarefa válida ainda precisa de diretriz. A persistência não obriga repetir uma tentativa impossível nem autoriza substituir silenciosamente a tarefa por outra. O desaparecimento do alvo não revela sua nova posição. A primeira intenção de entrada adicional é tratada na seção 9, sem presumir Bônus obrigatória nem gratuidade.

## 5. Especial imediata e orientação posterior

**[D]** O invocador paga **Ação Padrão** para comandar uma especial ativa de uma entidade que possa receber a ordem e executá-la. A especial ocupa a básica ainda disponível da destinatária e paga os custos próprios da capacidade. Não consome a básica das demais entidades.

Se a destinatária já gastou a básica do ciclo, o comando não lhe permite executar a especial naquele mesmo ciclo. Executar a especial também não deixa uma básica adicional para depois. Movimento e coletiva são recursos separados, salvo custo ou impedimento explicitamente escrito.

**[D]** A especial pode atuar fora da intenção vigente, sem Bônus adicional para essa intervenção. **Depois de conhecer o resultado**, o invocador escolhe conservar a intenção anterior ou atribuir uma nova à destinatária, também sem Bônus adicional. O alvo da nova intenção pode diferir do alvo da especial. Essa orientação não se espalha às outras entidades nem concede execução imediata.

Exemplo sem ficha numérica: Nue enfrenta A. O invocador paga Padrão para ordenar uma especial contra X; Nue ocupa sua básica disponível, satisfaz os requisitos e resolve a capacidade. Só então o invocador decide “foque em Y” ou mantém a intenção anterior. Nue não ganha outra básica; as demais criaturas mantêm suas tarefas e saldos.

**[E/P]** A comunicação necessária à ordem e à orientação posterior não é dispensada. Não há fonte de PE implícita. Duração e manutenção dependem do texto da capacidade; autorizar uma execução não autoriza reativá-la indefinidamente. A resolução específica de interrupções/custos depois de iniciar uma capacidade não foi criada aqui.

## 6. Comando especial antecipado

### 6.1 Núcleo aprovado

**[D]** Se a destinatária já usou a básica pertinente e não pode executar a especial agora, o invocador pode **pagar a Padrão ao emitir a ordem** para a próxima oportunidade válida da destinatária. Quando executada, a especial substitui uma básica futura disponível, **sem pagar outra Padrão de comando naquele momento**.

A Padrão paga antes pode deixar a Padrão do ciclo de execução livre. É deslocamento temporal intencional do custo, não recuperação da Padrão anterior ou criação de uma básica. Outra criatura pode receber um comando atual se os recursos e requisitos existirem; a ordem anterior não aumenta o saldo da primeira.

**[P]** A autorização expressa cobre o caso de básica já utilizada. Antecipar arbitrariamente apesar de poder executar agora, acumular ordens, ordenar substitutas ou manter uma fila indefinida não são permissões aprovadas por esta folha.

### 6.2 Procedimento proposto, ainda não aprovado

Todos os detalhes operacionais da coluna central abaixo são **[H]**, salvo a Padrão antecipada e a substituição futura já aprovadas. Eles constituem uma proposta explícita para validação, não regra publicada.

| Etapa | Procedimento candidato | Status e limite |
|---|---|---|
| Emitir ordem | Identificar destinatária, capacidade e alvo; pagar Padrão agora. | Pagamento [D]; registro e fixação da ordem [H]. Meio/alcance [P]. |
| Esperar | Conservar a intenção vigente; a ordem é para uma execução futura específica. | Persistência [D]; tratamento de fila e substituição de ordens [P]. |
| Abrir oportunidade | Verificar novamente presença/funcionalidade, alvo, alcance, percepção, condições, usos, recurso e básica elegível. | Exigência de requisitos [D/R]; momento detalhado da checagem [H]. |
| Pagar custos próprios | Pagar PE e demais custos na execução, salvo antecipação exigida pelo texto da capacidade. | [H]; fonte, preço e timing definitivo [P]. Não reservar nem descontar PE por inferência. |
| Começar especial | Ocupar a básica futura quando a execução efetivamente começar; não cobrar nova Padrão. | Substituição/ausência de nova Padrão [D]; fronteira exata do consumo [H]. |
| Resolver | Aplicar a capacidade, seus custos e requisitos. O comando não cria interrupção fora da oportunidade normal. | Capacidade [R]; definição fina de oportunidade e prazo [H/P]. |
| Orientar depois | Após o resultado, conservar ou mudar a intenção, se o invocador puder orientar a destinatária. | Escolha posterior [D]; sua aplicação sob impedimentos no diferimento [H/P]. |

**[H] Cancelamento:** recomenda-se que cancelar antes da execução não devolva a Padrão já paga; sem início da especial, não se gastariam a básica nem os custos de execução. O modo/custo de cancelar ainda não foi definido. Não estender essa recomendação a uma especial já iniciada.

**[H] Mudar alvo ou capacidade:** recomenda-se novo comando especial, com seu custo; a ordem antiga não serviria como crédito aberto. Falta fechar substituição/acúmulo de ordens e cancelar a anterior. Isso não restringe a decisão já aprovada de escolher outra intenção **depois** de uma especial resolvida.

**[H] Prazo e expiração:** recomenda-se a próxima oportunidade normal de atuação, sem interrupção, com expiração ao fim dela se a especial não puder ocorrer. Usar aquela básica para outra coisa cancelaria a ordem. A definição dessa oportunidade sob impedimentos precisa ser aprovada: “próxima válida” não foi convertida silenciosamente em espera ilimitada nem em perda imediata.

**[P] Falha de requisito:** alvo desaparecido, alcance/percepção perdidos, condição impeditiva, falta de PE ou uso esgotado não são ignorados. Ainda se deve decidir quando isso provoca expiração, espera ou cancelamento e quais custos já são irrecuperáveis. A recomendação acima oferece uma opção, não resolve o caso por autoridade própria.

**[P] Inconsciência e troca:** não está decidido se uma ordem pendente sobrevive à inconsciência do usuário, ao recolhimento/troca da destinatária ou à sua reentrada, nem se pode acessar PE do usuário inconsciente. Transferir uma básica não implica transferir a ordem especial. A continuidade da rotina autônoma não resolve essas questões. Orientação posterior requer possibilidade efetiva de comunicação; não há nova orientação consciente de um usuário inconsciente.

Não executar esses ramos como regras finais antes da decisão mínima. Uma bancada que adote recomendações deve identificá-las como hipóteses, com seus resultados condicionais.

## 7. Movimento, Reação e defesa

**[D]** Cada corpo usa seu Movimento por discernimento coerente com a tarefa; não exige ordem por passo e não consome Movimento do invocador. O recurso é individual. Seus valores não foram definidos aqui. Autonomia não concede movimento ilimitado ou acompanhamento fora do turno sem fonte escrita.

**[D/E]** No gatilho de uma capacidade reativa, uma criatura elegível pode responder autonomamente, pagando a coletiva e os demais custos escritos. Percepção, alcance, posição e condições continuam necessários. Uma resposta que gaste a coletiva impede outro gasto dela até a renovação. Troca de corpo não altera esse saldo. Uma condição pode impedir uma criatura de reagir sem gastar a reserva; outra criatura apta continua elegível.

**[R] Bloquear:** gratuito por ataque elegível; não gasta coletiva e não se aplica a TR. Usa a regra geral `2d10 + Defesa − 11`. Duplo 10 impede o acerto comum, mas não o 20 natural; o contra-ataque de Aparar exige Reação e usa o bônus de dano já escrito na regra geral. Duplo 1 permite Brecha, cujo ataque adicional é pago pela Reação do agressor. Se o agressor for uma invocação, a reserva pertinente é a coletiva.

Uma coletiva gasta não impede novos Bloquear elegíveis, mas impede o contra-ataque que exige Reação. Ter uma reserva disponível não fornece ataque a uma criatura sem ataque. Interceptação não é habilidade universal; o cartão da antiga bancada não integra esta regra.

**[R] Condições:** Incapacitado impede Bloquear e torna críticos os acertos corpo a corpo previstos em seu texto, sem eliminar automaticamente todas as ações. Atordoado tira uma Padrão, não todas quando houver várias, e impede reagir. Lento reduz deslocamento e impede Bônus; Agarrado e Impedido têm seus impedimentos próprios. Não importar efeitos de condições de outros jogos.

**[H] Adaptação de Atordoado:** tratar a básica como a atuação equivalente à Padrão para a perda imposta pela condição, sem criar uma básica tardia ao encerrá-la. Isso já foi ensaiado, mas sua equivalência definitiva ainda requer validação. Não usar o nome “básica” para contornar a condição. O impedimento do invocador não é automaticamente imposto às entidades; sem Padrão disponível ele não emite o comando especial comum.

## 8. Preparar, Esquivar e Guia v0.4

### 8.1 Preparar não é comando antecipado

**[R/H] Adaptação candidata:** Preparar ocupa a básica da criatura agora, especifica ação e gatilho visível/verificável e usa a coletiva quando o gatilho ocorre. A reserva não fica separada para a preparação. Gastá-la em outra resposta faz a preparação se perder; havendo várias, não sobrevivem como créditos para depois. A preparação expira no começo do próximo turno do invocador. A substituição da Padrão por básica e desse “turno próprio” pela fronteira comum são adaptações expressas, não nova aprovação autoral.

| Preparar pela entidade | Comando especial antecipado |
|---|---|
| Ocupa básica ao preparar. | Paga Padrão do invocador ao ordenar. |
| Executa por gatilho visível e exige coletiva. | Substitui básica futura na oportunidade válida; não recebe interrupção por gatilho. |
| Tem o prazo da regra geral, adaptado ao conjunto. | Detalhes de prazo e expiração continuam candidatos. |
| Não autoriza uma especial sem comando. | Autoriza a especial específica, respeitados os requisitos. |

Não combinar os dois procedimentos para dispensar comando, criar básica ou evitar o custo reativo de Preparar. A combinação de uma especial comandada com Preparar não recebeu procedimento próprio.

**[R + adaptação de relógio] Esquivar:** como básica elegível, impõe a desvantagem escrita aos ataques contra aquela criatura até o começo do próximo turno do invocador. Não protege outro alvo por si. O trecho sobre “TR de Destreza” permanece **[P]**, pois o projeto lista TR Físico, Vigor, Intelecto e Espírito. Não substituí-lo silenciosamente por TR Físico nem escolher beneficiários por atributo.

### 8.2 Respostas do Guia

**[R]** Mantém-se a coleção v0.4. Abrir Caminho fornece uma Abertura a aliado voluntário que satisfaça seus requisitos; a Abertura não fornece a ação necessária para aproveitá-la. O alcance e os PE escritos no Guia pertencem àquela habilidade, não ao vínculo.

Depois de resolver o uso da Abertura, Resposta Coordenada pode convidar um aliado elegível. Na resposta normal, **Guia e aliado pagam suas Reações**. A invocação paga a coletiva. O invocador ser o próprio Guia não funde as reservas: ele paga a pessoal e a criatura paga a coletiva.

**O Golpe concedido é um ataque comum: não é básica, especial, Ação Atacar ou etapa de Sequência.** Não renova básica, não permite uma especial tardia depois de básica já usada, não herda ataques adicionais e não desencadeia outra ação concedida. Pode ocorrer depois de básica ou de especial se houver gatilho, elegibilidade e coletiva disponíveis.

O Guia também possui a alternativa escrita **Feitiço breve**, um Classe 0 conhecido com requisitos e custos normais. Ela permanece no Caminho; não é convertida em Golpe nem concedida a uma criatura que não a conheça. Esta folha não cria uma especial do vínculo a partir dela. Respeita-se o limite geral de conjurações, sem importar exceções de Trilhas antigas ausentes da coleção v0.4.

**[R/H] Avançar:** no turno do beneficiário, usa o trecho concedido sem outra ação; fora dele, exige sua Reação. A aplicação ao turno conjunto mantém a adaptação da bancada: dentro do turno do invocador considera-se o turno da entidade para esse efeito; fora dele, a invocação paga a coletiva. A definição fina das janelas não pode criar Movimento livre fora da oportunidade concedida. Terreno e impedimentos permanecem.

### 8.3 Guia 30 e duas fronteiras

**[R/D]** Todos no Mesmo Plano mantém sua cadeia, participantes distintos, tipos de Abertura distintos, prazo e limites da v0.4. Na primeira resposta, o Guia paga sua Reação. A segunda dispensa **somente a Reação do Guia**; os aliados continuam pagando as suas e não pode ser a mesma criatura nas duas respostas.

O ciclo do Guia vai do início de um turno dele ao seguinte; o da coletiva acompanha o invocador. Portanto:

- **Sem renovação entre gatilhos:** a primeira invocação gasta a coletiva; outra do mesmo conjunto não consegue pagar a segunda resposta.
- **Com renovação real entre gatilhos:** a primeira invocação responde antes do começo do turno do invocador; a coletiva renova nessa fronteira; uma segunda criatura distinta pode pagar a segunda resposta, ainda dentro da cadeia válida do Guia.

Não impor “uma resposta por ciclo do Guia” ao conjunto. A exceção do nível 30 não cria duas coletivas e não renova a reserva. Quando Guia e invocador são a mesma pessoa, suas fronteiras coincidem; não se deve transportar automaticamente para esse caso a sequência que dependia de um Guia externo.

## 9. Entrada, substituição e retorno

### 9.1 Pré-condição e estados separados

**[P] Custo e legalidade de manifestação/recolhimento/troca:** ação, PE, posição de entrada, oportunidade e demais requisitos não foram fixados. As regras seguintes descrevem recursos **depois de uma entrada/troca legal**, sem torná-la gratuita nem permitir realizá-la em qualquer instante. Um corpo não recolhível pelas regras de seu vínculo não se torna portátil.

**[D/E]** Controle separadamente: identidade do corpo; básica disponível, gasta ou transferida neste ciclo; Movimento próprio restante; intenção; PV, condições, usos e demais estados; coletiva do conjunto. Registrar transferência não cria um inventário de vagas permanentes.

### 9.2 Substituição direta 1→1

**[D]** A sai e B entra substituindo A:

1. Identifique se A possui uma básica ainda não gasta e utilizável para transferência.
2. B só pode recebê-la se **ainda não tiver gasto uma básica naquele ciclo**. Uma especial que ocupou sua básica conta como gasto para essa trava.
3. Transfira **no máximo uma** oportunidade. Se A já a gastou, não há saldo a transferir. Se B já gastou, a troca não lhe recupera básica.
4. B recebe sua primeira intenção como parte dessa substituição, sem Bônus adicional. Essa orientação não depende de haver básica para agir imediatamente e não cria uma.
5. B usa o seu Movimento disponível. A coletiva conserva o saldo anterior.

**[E] Transferir não é copiar:** a oportunidade transmitida deixa de estar no saldo de A. Ao retornar, A não a conserva também sob o argumento de que não a executou. Se B a gastar ou a transmitir legalmente, existe sempre a mesma oportunidade, nunca uma cópia em cada corpo. Não há estorno automático ao recolher B.

**[D/E]** O histórico de uso pertence ao corpo. Mudar seu nome de posição, destinatária ou substituta não apaga a básica que ele já gastou naquele ciclo. Passar por vários corpos sem executar pode mudar quem usa o saldo, mas não multiplicá-lo. Esta regra não autoriza acumular várias básicas em um corpo nem fixa uma futura economia com múltiplas execuções.

### 9.3 Uma saída e várias entradas; várias saídas e uma entrada

**[D] 1→vários:** escolha uma entidade como substituta direta. Só ela pode receber a básica não gasta da que sai e a primeira intenção incluída. As demais são entradas adicionais: não ganham básica nem primeira intenção gratuita por esse evento. Cada corpo novo tem seu Movimento próprio disponível; um corpo que retorna conserva apenas seu saldo próprio.

**[E] Vários→1:** a substituta recebe no máximo uma oportunidade legalmente transmitida. Não somar as básicas das criaturas que saíram. A transferência é do evento de substituição, não de vagas permanentes que se acumulam.

### 9.4 Entrada que apenas acrescenta corpo

**[D/E]** Um corpo novo que entra sem substituir outro tem Movimento próprio disponível, mas sua entrada **não cria básica**, não renova a coletiva e não recebe a primeira intenção gratuita da substituição. Na próxima fronteira normal, a disponibilidade passa a seguir a ficha e seus impedimentos; a troca/entrada não antecipa essa renovação.

**[E]** A entidade pode usar uma coletiva ainda disponível se cumprir os requisitos da resposta escrita. Isso não lhe dá básica, ataque ou capacidade inexistentes. A ausência de primeira intenção gratuita não apaga a autonomia reativa aprovada, mas também não dispensa os requisitos da capacidade.

**[P]** Procedimento/custo da primeira intenção sem substituição permanece aberto. Não cobrar Bônus por inferência nem conceder uma tarefa grátis. A rotina orientada precisa de tarefa validamente estabelecida; movimento próprio disponível não resolve sozinho o que uma criatura sem tarefa decidirá fazer.

### 9.5 Mesmo corpo retornando

**[D/E]** Sair e retornar não renova básica, Movimento, coletiva, PV, condições, usos limitados ou demais estados próprios. O que ainda pertencia ao corpo e não foi gasto, perdido nem transferido continua registrado; o retorno não cria uma segunda cópia. Movimento gasto continua gasto, mesmo quando outro corpo teria entrado com Movimento novo.

Exemplos: A gastou a básica, saiu e volta substituindo B — A não recebe outra no mesmo ciclo. A transmitiu sua básica a B e sai — ela não reaparece no saldo de A ao retornar. C nunca entrou naquele ciclo — sua chegada legal traz Movimento próprio, independentemente dos metros que A gastou; isso não fornece básica a C.

**[P]** Efeitos dependentes de presença, existência ou manifestação seguem o próprio texto. Se ele não determinar o que ocorre na saída, o caso permanece aberto. Preservar condições não implica congelar durações ou tornar eterno um efeito que exige presença. Renovação de recursos de corpos que permaneceram fora durante a fronteira e duração de efeitos fora de campo precisam de especificação quando indispensáveis; não atribuir essa renovação à reentrada.

**[E]** Troca não cura. Uma reserva saudável pode aumentar a vida acessível ao longo da cena sem alterar os PV do corpo ferido. Esta folha reconhece o efeito, mas não lhe atribui preço, recuperação definitiva ou regra de ressurreição.

## 10. Inconsciência, sustentação e exploração

**[D]** A entidade já em campo e funcional continua sua rotina básica, Movimento e respostas autônomas se a sustentação permitir que permaneça existente. O usuário inconsciente não emite novos comandos nem cede suas ações não usadas. Zero PV não é automaticamente inconsciência: observar a situação efetiva e as regras de Insistir/Aguentar.

Autonomia integra o investimento do vínculo/entidade; não cobra taxa periódica apenas para repetir a rotina enquanto validamente manifestada. Isso não elimina custos particulares de duração, manifestação, manutenção e capacidades.

**[P]** Acesso a PE do usuário inconsciente, ordens antecipadas nessa situação, morte do usuário, perda de vínculo e manifestação de reservas permanecem abertos. Rotina autônoma e existência sustentada são condições diferentes.

**[E]** Fora do combate, tarefas continuam dependentes de meios e informação. Sob pressão de tempo, buscas e tentativas consomem sua atuação correspondente; mais corpos não permitem tentativas infinitas, compartilhamento instantâneo de sentidos ou ignorar regras de ajuda/testes de grupo.

## 11. Pendências e limite de uso

Para fechar a operação mínima ainda faltam: detalhes do comando antecipado; primeira intenção sem substituição; janelas individuais e adaptação de condições/ações. Persistência fora de campo só exige decisão quando o texto de um efeito ou a passagem de fronteira não a resolver. Quantidade de básicas, X, comunicação e custos/valores ainda abertos devem ser declarados em qualquer ensaio, sem publicação como números aprovados.

A divergência com o manual antigo é real: comando obrigatório a cada rodada e inércia na inconsciência não podem ser sobrepostos a esta autonomia. Para integrar o projeto principal, usar o registro de conflitos, mantendo as fontes intactas até autorização de edição. A coleção v0.4 prevalece nas referências de Caminho; não restaurar Trilhas antigas para acomodar a proposta.

**Pronta como consolidação candidata para continuar a integração. Ainda não pronta como procedimento definitivo inteiramente executável.** As lacunas não reabrem as decisões já fechadas. Não há nova regra de Evocador, Trilha, construtor ou orçamento, nem conclusão de equilíbrio.
