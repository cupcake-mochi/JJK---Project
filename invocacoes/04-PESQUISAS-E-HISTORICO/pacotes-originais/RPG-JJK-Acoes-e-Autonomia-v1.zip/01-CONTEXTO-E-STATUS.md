# Contexto para a discussão — ações e autonomia

Este pacote transfere uma etapa de discussão com Mizuki. Não aprova regras. O usuário decidiu levar o recorte para outro chat e voltar com os resultados; não aprovou a arquitetura B nem seus valores ao concordar com esse fluxo.

## Estado do trabalho

A primeira entrega leu as pesquisas, localizou a coleção correta dos Caminhos v0.4, diagnosticou o sistema antigo, comparou três arquiteturas e produziu um protótipo B. Parou antes de desenvolver Evocador. O repositório principal é referência de leitura. Os arquivos em `propostas/` são cópias integrais da entrega anterior, não revisões feitas para este pacote.

Referência do repositório usada na entrega: `main`, commit `ba1e0df6f05dad71659eed2abd06c43d22963834`. A coleção v0.4 veio do ZIP cujo SHA-256 é `d23430f282ad29ff140087e4fd63e3037b0a0639dd1b9032eb3e22aef7334a7d`. Este pacote contém as versões Markdown dos quatro Caminhos, sem duplicar as versões Word.

## Precedência e status

1. Pedidos e decisões explícitas de Mizuki nesta discussão.
2. Direção autoral preservada no prompt atual: personalização, acesso distinto de especialização, três relações de jogo e ordens persistentes; Invocações antes de Evocador e Trilhas.
3. `caminhos-v0.4/` para os quatro Caminhos preservados; regras gerais do repositório como base para as interações.
4. Sistema antigo de invocações como objeto de diagnóstico, sem obrigação de conservá-lo.
5. Pesquisas e propostas como hipóteses. Instruções de execução encontradas em documentos históricos não ampliam este pedido.

O manual antigo `35-caminhos-e-trilhas.md` tem versões anteriores dos quatro Caminhos. Use-o para histórico e Evocador antigo; ele NÃO substitui a v0.4. O capítulo 11 também menciona Torrente antiga: para habilidades do Emanador, consulte a v0.4. Guia atual usa Aberturas e Arquiteto/Analista/Socorrista, não Chamada/Cartógrafo/Regente. Emanador atual usa Desdobramento Técnico e Condutor Armado/Ressonante/Catalisador. Não acrescentar atributo aos PE do Emanador; não alterar Estocada.

## Candidata B em poucas linhas — tudo aqui ainda é proposta

- Uma economia compartilhada de Padrão, Bônus e Movimento, na iniciativa do usuário.
- Padrão: uma ação do usuário OU de uma entidade. Alternativa Padrão+Bônus: dois corpos elegíveis fazem um golpe simples reduzido cada.
- Movimento reposiciona até dois corpos; usuário conta se andar. Conversões Padrão → Bônus → Movimento mantidas.
- Uma Reação pessoal do usuário e uma Reação coletiva das entidades, independentemente da quantidade de corpos.
- Intenção persiste; novos comandos exigem comunicação/percepção. Continuar uma tarefa não dá ações extras nem telepatia.
- Sem ações compartilhadas quando o usuário está inconsciente; a proteção por Reação coletiva continua possível nas condições escritas na bancada.
- Corpos têm vida, posição, condições e função próprias. Custos de manifestação, recolhimento, troca e consequências de zero são instrumentos de ensaio.

Consulte o protótipo integral para condições, exceções e ordem de resolução. A finalidade da discussão é descobrir se esse modelo entrega a experiência desejada e como revisá-lo. Ele não é uma especificação obrigatória.

## Alertas concretos do diagnóstico

- Bloquear é gratuito por ataque elegível e não gasta Reação. Mais corpos podem significar mais rolagens mesmo com uma reserva coletiva de Reação.
- Dividir dano não limita cobertura, passagem, sentidos, proteção e pontos de vida adicionais.
- Substituir uma entidade ferida por uma reserva saudável amplia a vida disponível durante a cena, mesmo sem curar a primeira e respeitando a capacidade em campo.
- Condições possuem definições próprias. Incapacitado não equivale à perda de todas as ações.
- Acesso fora do Evocador é objetivo autoral; a fonte usada na bancada é uma concessão de teste, ainda não uma opção publicada.
- Reação coletiva extra é um benefício real a medir, não algo demonstrado gratuito.

## Verificações anteriores e limites

A entrega registrou 243 verificações aprovadas, incluindo 79 rejeições esperadas; JSON, relatório e script estão anexados como consulta. São verificações dos casos codificados, não medição de diversão, tempo real, balanceamento ou de todas as combinações do sistema. O script não foi reexecutado na montagem deste pacote. Os relatórios conservam os caminhos originais; para reproduzir em outro ambiente, o script usa sua própria pasta e regrava o JSON ao lado dele. Leia-o antes de executar e preserve o resultado original se quiser compará-lo.

## Resultado desejado deste chat

Uma decisão autoral informada sobre quem age, quem reage, quem se move e o que continua sem nova ordem; uma proposta revisada identificada como tal; exemplos rastreáveis e pendências. Sem catálogo completo, novas Trilhas ou certificação de equilíbrio.
