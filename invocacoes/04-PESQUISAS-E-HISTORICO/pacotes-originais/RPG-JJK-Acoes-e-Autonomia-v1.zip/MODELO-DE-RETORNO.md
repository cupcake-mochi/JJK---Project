# Retorno à tarefa de integração — Invocações

> MODELO EM BRANCO. Preencher somente com o que ocorreu na conversa. Não representa decisões já tomadas.

## 1. Identificação
- Data, versão e recorte trabalhado:
- Arquivos de base efetivamente consultados:
- Arquitetura inicial e arquitetura resultante:

## 2. Decisões explícitas de Mizuki
Para cada decisão: texto da decisão, mensagem ou trecho que confirma a aprovação e alcance. Não atribuir ao autor recomendações do assistente nem números que ele não aprovou. Se não houve aprovação, dizer isso.

## 3. Proposta revisada integral
Inserir texto suficiente para usar o procedimento sem reconstruí-lo por fragmentos da conversa: iniciativa; ações; conversões; movimento; reações e renovação; Bloquear/Aparar; intenção persistente; alcance/percepção; usuário e criatura sob condições; ações concedidas. Distinguir regra de referência, proposta, hipótese numérica e lacuna. Se um ponto não mudou, incluir sua redação ou referência exata à base.

## 4. Mudanças em relação ao protótipo v0.1
| Antes | Depois | Motivo | Status: aprovado/proposto/pendente |
|---|---|---|---|
| | | | |

## 5. Exemplos efetivamente discutidos
Para cada exemplo: composição, posição inicial, intenção vigente, ações e recursos, sequência de resolução, resposta inimiga, resultado e limitação. Registrar rolagens como ilustrativas quando não forem realmente sorteadas. Não inventar sessões de mesa.

## 6. Verificações realizadas
Separar análise de texto, contas, execução automatizada e teste com pessoas. Para execução: versão, comando ou procedimento, resultados e limitações. Não reapresentar os 243 testes antigos como se validassem a revisão.

## 7. Alternativas recusadas ou adiadas
Qual alternativa, por qual motivo e por decisão de quem. Não transformar adiamento em rejeição definitiva.

## 8. Pendências e impactos
Questões abertas, dependências do construtor/custos/vínculo e possíveis interações com os quatro Caminhos. Preservar dúvidas reais; não preencher lacunas com regras implícitas.

## 9. Próximo passo recomendado
Uma etapa delimitada para a integração. Identificar arquivos novos entregues e afirmar claramente se algum arquivo original foi alterado. Não modificar o projeto de origem para preparar este retorno.
