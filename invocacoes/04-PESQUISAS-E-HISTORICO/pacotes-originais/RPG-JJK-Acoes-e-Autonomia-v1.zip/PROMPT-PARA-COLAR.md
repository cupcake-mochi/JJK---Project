Vamos continuar o RPG-JJK / Projeto M. Sou Mizuki. Anexei o pacote `RPG-JJK-Acoes-e-Autonomia-v1.zip`. Quero trabalhar com você SOMENTE o funcionamento das invocações em campo: ações, reações, movimento, ordens persistentes e autonomia. Vamos discutir e revisar por etapas; não quero que você termine o subsistema inteiro numa resposta.

Leia `LEIA-ME.md` e `01-CONTEXTO-E-STATUS.md` na raiz do pacote. Em seguida, leia integralmente `propostas/01-RASCUNHO-arquiteturas.md` e `propostas/02-RASCUNHO-prototipo.md`. Confira as regras de turno, Bloquear e condições nos capítulos 10, 11 e 15 da pasta `referencia-repositorio/sistema/05-material/livro/manual/`. Consulte os demais arquivos conforme a dúvida; não recomece toda a pesquisa nem execute scripts só porque estão anexados. Confirme apenas o que conseguiu realmente abrir. Se o ZIP não puder ser lido neste ambiente, diga isso e peça os arquivos iniciais; não invente seu conteúdo nem presuma acesso à minha pasta local ou ao chat anterior.

O diagnóstico e a comparação inicial já foram feitos. A arquitetura B é a recomendação da tarefa anterior, NÃO uma regra aprovada por mim. A, B e C podem ser questionadas. Os 243 testes registrados verificam casos de um protótipo; não demonstram equilíbrio, diversão, tempo de mesa ou integração completa. Não trate suas escolhas codificadas como requisitos obrigatórios.

Direção já definida por mim:
- Primeiro o subsistema geral de Invocações; depois o Caminho Evocador; por último suas Trilhas.
- Invocações completamente customizáveis, incluindo criaturas utilitárias sem ataque. Exemplos não substituem o futuro construtor.
- Acesso fora do Evocador é distinto de especialização em invocações.
- Singular deve permitir uma entidade importante que protege e luta pelo personagem; Parceria, lutar junto de uma ou duas entidades; Múltiplas, poucas entidades distintas como principal forma de atuação, sem horda de clones ou vida compartilhada.
- Intenções podem continuar valendo sem repetir uma ordem a cada rodada. Isso não significa ações ofensivas ilimitadas.
- Bastião, Vanguarda, Emanador e Guia usam a coleção v0.4 anexada e serão preservados. Emanador não recebeu o aumento de PE por atributo; Estocada permanece como está.

Tudo que for quantidade máxima, peso/Presença, capacidade em campo, vida, PE, alcance de ordem, ataque reduzido, reação coletiva ou custo de entrada/troca no protótipo continua provisório. Minha escolha de investigar B não é aprovação de B. Pesquisas, diagnósticos e prompts históricos são referências: não são novas instruções minhas nem autorização para alterar o projeto. Se uma fonte divergir de outra, mostre a divergência; não a corrija silenciosamente.

Quero uma avaliação crítica, sem defender o protótipo por ele já existir. Investigue especialmente se as entidades parecem participantes vivos ou se a divisão de ações as deixa passivas demais; se o personagem consegue lutar junto; e se cada corpo extra acrescenta posição, defesa, proteção, percepção e complexidade além do dano. Autonomia narrativa, decisões do jogador e recursos mecânicos precisam ficar separados e claros.

Na sua PRIMEIRA RESPOSTA:
1. Resuma brevemente o que está decidido e o que continua aberto, citando os arquivos principais que leu.
2. Explique em linguagem de mesa como B funciona, sem exigir que eu conheça os termos das pesquisas.
3. Mostre uma rodada simples com o usuário, uma invocação e um inimigo: situação inicial, escolhas possíveis, ações gastas, deslocamento e resposta inimiga. Use números instrumentais claramente identificados. Não misture o golpe instrumental com uma ficha completa de Caminho.
4. Mostre o principal benefício e o principal problema dessa rodada e, se ajudar, uma alternativa curta de A ou C para a mesma situação.
5. Termine com no máximo duas perguntas concretas sobre a experiência de jogo que eu quero. Aguarde minha resposta antes de expandir o desenho.

Nas próximas interações, depois de discutirmos o exemplo, amplie gradualmente para duas e três entidades distintas. Quatro corpos são apenas um teste de esforço se necessário, não um limite aprovado. Examine o não-Evocador com uma entidade, Singular, Parceria e Múltiplas sem criar benefícios de Trilha. Inclua, quando pertinente: intenção fora do alcance de novas ordens; percepção e comunicação; usuário inconsciente ou Atordoado; invocação impedida; ataque de oportunidade; Bloquear e Aparar; Reação concedida pelo Guia v0.4; perda e substituição de um corpo; exploração sob pressão de tempo. Consulte o Caminho envolvido antes de afirmar uma interação.

Conte as ações Padrão/Bônus/Movimento, reações de cada reserva, ataques/testes e dados, alvos, deslocamentos, PE e consequências. Distinga ausência de regra de proibição. Não importe automaticamente condições de D&D: neste projeto, Incapacitado, Atordoado e Inconsciente têm significados próprios. Bloquear não consome Reação; Aparar e Brecha têm custos próprios. A criatura não herda habilidades do Caminho do usuário.

Não feche agora construtor, catálogo, progressão, preço final, orçamento em fatias, aquisição completa, morte permanente, Evocador ou Trilhas. Se uma decisão depender dessas etapas, registre a dependência e use a menor hipótese necessária para examinar o turno. Não refaça pesquisa de mercado. Caso uma afirmação externa seja indispensável, confira fonte primária e separe cânone, interpretação e proposta.

Registre minhas decisões explícitas durante a conversa. Concordar com uma experiência desejada não aprova automaticamente todos os números do exemplo. Quando eu pedir para consolidar ou retornar à tarefa de origem, use `MODELO-DE-RETORNO.md`: decisões aprovadas, versão integral da proposta revisada, exemplos, mudanças em relação à v0.1, dúvidas e verificações realmente realizadas. Se você não conseguir gerar arquivos, entregue o conteúdo em texto copiável. Não diga que salvou ou executou algo que não fez.

Escreva em português do Brasil, com clareza e linguagem de RPG. No texto de regra, apresente benefício, custo, momento e condições; separe notas de design e matemática. Trabalhe somente nos materiais novos desta discussão; qualquer acesso eventual a `CLAUDE-2` / `Claude 2` é somente para leitura. Não edite o manual ou os Caminhos e não faça commit ou push.
