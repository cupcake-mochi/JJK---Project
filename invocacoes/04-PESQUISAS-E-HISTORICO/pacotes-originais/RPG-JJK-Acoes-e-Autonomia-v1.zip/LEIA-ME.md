# RPG-JJK — pacote para discutir ações e autonomia

Anexe o ZIP ao novo chat e cole o conteúdo de [PROMPT-PARA-COLAR.md](PROMPT-PARA-COLAR.md). O prompt começa por uma rodada simples e pede que o assistente aguarde suas escolhas antes de ampliar o desenho.

Este é um recorte para criação e revisão com Mizuki. A arquitetura B, seus valores e a reação coletiva ainda não foram aprovados. Não é necessário reler o projeto inteiro ou refazer a pesquisa para começar.

## Leitura inicial

1. [Contexto e status](01-CONTEXTO-E-STATUS.md).
2. [Arquiteturas A/B/C](propostas/01-RASCUNHO-arquiteturas.md).
3. [Protótipo B v0.1](propostas/02-RASCUNHO-prototipo.md).
4. [O turno](referencia-repositorio/sistema/05-material/livro/manual/11-o-turno.md), e as seções relevantes de [Como jogar](referencia-repositorio/sistema/05-material/livro/manual/10-como-jogar.md) e [Dano, condições e cobertura](referencia-repositorio/sistema/05-material/livro/manual/15-dano-e-condicoes.md).

## Consulta quando necessária

- `caminhos-v0.4/`: quatro Caminhos completos em Markdown e pendências da coleção. Consulte o Caminho antes de afirmar sua interação. Estas versões prevalecem sobre as antigas no manual.
- `propostas/00-RASCUNHO-leitura-e-diagnostico.md` e `apoio-*.md`: diagnóstico e rastreabilidade da entrega anterior.
- `propostas/03-RASCUNHO-testes.md`, script e JSON: evidência da bancada antiga, não validação de uma revisão futura.
- `referencia-repositorio/`: cópias integrais dos capítulos gerais selecionados, Fundamento, Caminhos antigos e Invocações antigas, mais a peça de desenvolvimento de Invocações. Não é o repositório completo.
- `pesquisas/`: dois relatórios completos com fontes, consolidação de decisões e plano. São investigação e histórico, não regras aprovadas ou instruções para executar uma nova tarefa ampla.

Os textos copiados preservam o conteúdo original. Referências a caminhos locais, documentos não selecionados ou à antiga estrutura de pastas podem não abrir no outro chat. Use esta organização e o manifesto para localizar as cópias. Quando o diagnóstico disser `sistema/...`, procure em `referencia-repositorio/sistema/...`; quando disser coleção dos Caminhos, procure em `caminhos-v0.4/`. Os relatórios de pesquisa mantêm suas subpastas relativas.

Foram omitidos duplicados Word dos Caminhos, ideias reservadas sem relação com esta etapa, prompts antigos de execução e o restante do repositório. Se uma dependência ausente se tornar indispensável, identifique-a para Mizuki sem presumir seu conteúdo.

## Para retornar

Peça ao chat que preencha [MODELO-DE-RETORNO.md](MODELO-DE-RETORNO.md), junto com a versão integral da proposta que vocês revisaram. Traga os arquivos ou o texto de volta à tarefa de integração. Aprovações, propostas e pendências devem ficar separadas.

## Integridade

`MANIFESTO.json` registra tamanho, SHA-256 e procedência de todos os demais arquivos. As cópias foram verificadas byte a byte contra suas fontes e o ZIP foi conferido após a criação. Nenhuma regra foi alterada ao preparar o pacote; os documentos de orientação e o modelo de retorno são novos. A pasta Claude 2 permaneceu somente leitura.
