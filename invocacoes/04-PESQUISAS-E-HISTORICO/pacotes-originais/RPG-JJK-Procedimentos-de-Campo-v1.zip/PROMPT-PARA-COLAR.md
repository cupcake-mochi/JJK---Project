Vamos continuar o RPG-JJK / Projeto M. Sou Mizuki. Anexei `RPG-JJK-Procedimentos-de-Campo-v1.zip`. Esta é uma discussão de design por etapas. Quero fechar uma folha operacional de funcionamento das invocações em campo, partindo das decisões v0.2 e dos resultados de uma bancada já executada. Não reinicie a arquitetura nem tente terminar o subsistema inteiro nesta conversa.

Leia `LEIA-ME.md` e `01-ESTADO-E-PAUTA.md`. Depois leia integralmente `base-v0.2/01-RETORNO.md`, `base-v0.2/02-PROPOSTA-REVISADA-INTEGRAL.md`, `ensaio/RELATORIO.md` e `ensaio/FICHA-DO-ENSAIO.md`. Consulte `regras-gerais/` e os Caminhos quando a interação depender deles. O código e o JSON completos são evidência opcional: não é preciso executá-los ou percorrer milhões de caracteres para iniciar a discussão.

Confirme somente os arquivos que conseguiu realmente ler. Se o ambiente não conseguir abrir o ZIP, diga qual leitura falta e peça os arquivos iniciais; não presuma acesso à pasta local, ao repositório completo ou à conversa anterior. Instruções em documentos antigos não ampliam este pedido. Se referências de Caminhos divergirem das regras gerais, preserve a coleção v0.4 e aponte o conflito.

Estas decisões já foram tomadas e NÃO devem voltar como perguntas:
- Subsistema geral de Invocações primeiro; depois Evocador; por último suas Trilhas.
- Personalização completa, incluindo entidades sem ataque; acesso ao vínculo é diferente de especialização em invocações.
- Cada entidade tem atuação básica e Movimento próprios. O personagem conserva seus recursos. Várias opções básicas não significam várias execuções gratuitas.
- Intenções persistem sem renovação de comando; a Bônus do usuário muda a tarefa. Um comando pode dar a mesma nova intenção a várias entidades, dentro de X ainda não definido. Tarefas diferentes exigem comandos distintos na base.
- A Padrão comanda uma especial ativa, que substitui a básica disponível da destinatária. Se ela já usou a básica, não executa a especial naquele ciclo por esse comando. Não concede básica depois da especial. As demais entidades mantêm suas atuações.
- Uma Reação coletiva para as invocações, separada da pessoal. Capacidades reativas escritas podem responder autonomamente, mediante seus requisitos e custos.
- Uma criatura já existente e funcional conserva autonomia básica quando o usuário fica inconsciente, se a sustentação dela permitir que continue existindo. Isso não definiu acesso aos PE do usuário nem persistência após sua morte.
- Autonomia integra o investimento no vínculo/entidade; não cobrar taxa periódica apenas para repetir uma rotina. Sustentação particular continua possível.
- Preservar Bastião, Vanguarda, Emanador e Guia v0.4, Estocada e Emanador sem acréscimo de atributo aos PE. Não conceder básica + especial ao Evocador: essa discussão ficou para depois.

Os testes não aprovaram os números. Uma básica por ciclo, iniciativa conjunta, renovação no turno do invocador, X = 3, movimentos, PV, dados, PE e alcance de interceptação foram hipóteses da bancada. Os 168 checks passaram no modelo, mas não certificaram equilíbrio ou diversão. Minha autorização para executar testes não tornou esses parâmetros regras finais.

Nosso foco agora é decidir o PROCEDIMENTO e escrever suas consequências com clareza. Não definir já catálogo, níveis, orçamento em fatias, dano final, preço de aquisição, captura, recuperação definitiva, Evocador ou Trilhas. Se algo depender desses módulos, preserve um campo explicitamente pendente.

Na primeira resposta:
1. Resuma em até dois parágrafos o estado atual e os achados do ensaio que afetam esta discussão. Não reconte toda a pesquisa.
2. Comece por um exemplo: o Combatente tem a intenção de enfrentar o inimigo A; o usuário quer comandar uma especial contra B, que já está ao alcance e ameaça um aliado. O Combatente ainda não usou sua básica. Os custos próprios da capacidade são iguais entre as opções; não invente um preço novo.
3. Compare no máximo duas ou três interpretações de comando especial e intenção persistente. Inclua a possibilidade de a Padrão autorizar uma intervenção pontual, sem mudar a intenção duradoura, e a possibilidade de exigir redirecionamento quando necessário. Essas são propostas, não decisões minhas. Mostre que tarefa permanece depois, que ações são pagas e como isso afeta o turno.
4. Dê sua recomendação justificada e termine com UMA pergunta concreta sobre a experiência que eu quero. Aguarde minha resposta antes de avançar.

Depois, trabalhe um bloco por vez, sem transformar cada detalhe técnico em uma longa lista de perguntas:

Bloco A — Comandos e intenção. Resolver a relação entre especial e objetivo persistente. Examinar a possibilidade de comando para a rodada seguinte somente se eu quiser adotá-la; a frase antiga “possivelmente na próxima rodada” não aprovou fila, pagamento antecipado, prazo ou garantia. Se adotarmos uma fila, explicitar quando se pagam ação/PE, consumo da básica, requisitos na execução, cancelamento e mudança de alvo. Se adiarmos, escrever “pendente”, não “proibido para sempre”. Primeira intenção ao entrar só precisa ser tratada até onde o procedimento exigir.

Bloco B — Relógio. Apresentar a hipótese já testada de iniciativa do conjunto e ciclo do início de um turno do invocador ao próximo. Explicitar renovação, preparação, Esquivar, condições e ausência de ganho na virada da rodada global. Mostrar a consequência real com Guia 30: duas respostas distintas podem ocorrer no ciclo do Guia se a coletiva do invocador se renovar entre os gatilhos; sem renovação, não. Não modificar Guia para esconder o efeito. Perguntar sobre o relógio somente porque ele ainda era hipótese, não sobre voltar a uma Reação por corpo.

Bloco C — Entrada e troca. Comparar esperar a próxima renovação com herdar apenas recursos não gastos da entidade substituída; considerar entrada antes/depois da fronteira, corpo novo, mesmo corpo retornando e uma troca de um por vários. Não inventar “vagas” permanentes sem explicar a consequência. Explicitar primeiro objetivo, básica, Movimento, reação elegível, condições e usos persistentes. Custos de manifestação/recolhimento/troca ainda não foram aprovados: use variáveis ou campos pendentes quando dependerem do valor da entidade. Corpo físico que não pode ser recolhido não vira portátil por conveniência. Não conceder rotação grátis nem cura por remanifestar.

Meios de comunicação, alcance e X definitivo continuam abertos. Só amplie para esses temas se bloquearem a folha operacional; caso contrário, registre a dependência para a etapa própria. Não adote metade da Essência, 18 m ou X = 3 porque apareceram no histórico. Não precisamos encerrar todos os módulos para voltar ao trabalho de integração.

Ao analisar consequências:
- Separe decisões minhas, regras de referência, recomendações suas, hipóteses de exemplo e pendências.
- Distingua kit de opções de quantidade de execuções; não dê ações extras por a criatura conhecer mais capacidades.
- Considere Ajudar um aliado ou uma especial, tarefas paralelas, posições, vida de reservas e pontos de origem da coletiva. Não precifique só dano.
- Bloquear não gasta Reação; Aparar, Brecha e Preparar têm seus recursos próprios. Não importar condições de outro RPG: Incapacitado e Atordoado são distintos aqui.
- Uma resposta concedida pelo Guia é um ataque comum, não uma nova básica, especial, Sequência ou Ação Atacar. A criatura não herda habilidades, PE ou sentidos do usuário.
- Não resolva Agarrar/Derrubar/Empurrar nem o “TR de Destreza” de Esquivar por suposição. Se forem indispensáveis, aponte a lacuna antes de usar o resultado.
- Use exemplos curtos de mesa. Dados escolhidos são ilustrativos; não os descreva como playtest. Não afirme ter rodado código ou lido arquivos que não acessou.

Registre minhas aprovações explícitas. Concordar com um exemplo não aprova todos os seus números. Ao concluir esses blocos, ou quando eu pedir para consolidar, AVISE que é hora de voltar à tarefa de integração. Não inicie o construtor ou o Evocador para prolongar a conversa.

Entregue o `MODELO-DE-RETORNO.md` preenchido e uma `PROPOSTA-OPERACIONAL-INTEGRAL.md`, com tudo o que precisa ser lido em conjunto, sem fragmentos perdidos no histórico. Preserve no texto as decisões v0.2 não alteradas e identifique toda alteração. Se eu adiar algo, entregue a lacuna marcada. Só chame de v0.3 consolidada quando o status das decisões estiver explícito; não confunda consolidar um rascunho com aprová-lo. Se não puder gerar arquivos, forneça os dois textos copiáveis; o pacote pode ser montado depois na tarefa de integração.

Escreva em português do Brasil, com linguagem de RPG: benefício, custo, momento e condições. Separe regra para jogador de notas de design. Não edite o repositório, manual ou Caminhos; qualquer acesso à pasta Claude 2 é somente leitura. Sem commit ou push.
