# Retorno — procedimentos de campo das invocações

> MODELO EM BRANCO. Preencher apenas com decisões e trabalho efetivamente realizados. Não é uma aprovação.

## 1. Identificação
Data, recorte, fontes lidas, versão de partida e status da versão de saída.

## 2. Aprovações explícitas de Mizuki
Para cada decisão: redação, trecho/mensagem que confirma aprovação, alcance e pendências. Não atribuir a Mizuki a recomendação do assistente ou um número meramente usado em exemplo.

## 3. Alterações em relação à v0.2
| Regra/hipótese anterior | Resultado desta discussão | Motivo | Status |
|---|---|---|---|
| | | | |

## 4. Proposta operacional integral
Entregar em arquivo separado `PROPOSTA-OPERACIONAL-INTEGRAL.md`: recursos, ciclo/renovação, ordem e duração das atuações, intenção persistente, redirecionar, especial, eventual comando diferido, entrada/retorno/troca, estado e condições, Reação coletiva, Preparar, Bloquear e ações concedidas. Preservar decisões anteriores não alteradas. Usar campos pendentes quando não houve decisão. Nenhuma regra deve depender de procurar um fragmento não citado no histórico.

## 5. Exemplos discutidos
Descrever pelo menos os casos efetivamente trabalhados de especial contra outro alvo, fronteira de renovação/Guia e entrada/troca. Recursos antes/depois, intenção que permaneceu, executor e consequência. Não inventar exemplos testados; propostas novas devem ser rotuladas como tais.

## 6. Pendências e escolhas adiadas
Especial que muda intenção, fila, primeira ordem, comunicação/X, relógio, entrada/troca, energia, custos e outros temas: marcar o que foi resolvido, adiado ou permaneceu hipótese. Não converter adiamento em proibição.

## 7. Verificações realmente realizadas
Separar leitura, análise lógica, contas e execução de testes. Os 168 checks anteriores são da bancada anexada, não validação da nova redação. Se não executou testes novos, dizer isso. Não alegar playtest sem sessão com pessoas.

## 8. Solicitação para integração
Indicar o que deve ser revalidado no projeto, quais hipóteses mudaram e o próximo ensaio necessário. Evocador/Trilhas continuam fora. Listar arquivos entregues e declarar se houve qualquer alteração de fonte; a instrução desta etapa é não alterar originais.
