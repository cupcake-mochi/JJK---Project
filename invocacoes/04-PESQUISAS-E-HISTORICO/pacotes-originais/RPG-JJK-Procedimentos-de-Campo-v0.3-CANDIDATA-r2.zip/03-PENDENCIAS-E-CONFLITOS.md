# Pendências e conflitos — revisão 2

## Decisões autorais ainda necessárias quando o recorte depender delas

1. **Limites de intenções encadeadas:** distinguir um objetivo contínuo de várias missões condicionais numa mesma orientação. A regra atual permite escolher meios dentro da tarefa; não aprovou uma programação universal que dispense redirecionamentos. É o próximo ponto autoral recomendado.
2. **Composição de ações:** especial comandada combinada com Preparar; conversão de básica em opções gerais originalmente de Bônus; compatibilização futura de múltiplas básicas com comando e trava de rotação. Não conceder essas combinações pelo silêncio.
3. **Existência, queda e retorno:** consequências completas para cada vínculo/entidade, morte do invocador e perda de sustentação. A equivalência campo/reserva está fechada; não substitui a regra de queda que falta.
4. **Parâmetros e acesso:** quantidade/progressão de básicas, X, alcance/meios específicos, fonte/custos das capacidades e legalidade/posição/custos de entrada e troca. Custo de substituição e energia própria ficam na pauta futura solicitada, sem antecipar construtor.
5. **Conflitos gerais:** precedência de efeitos simultâneos além da coletiva; resolução de manobras; Esquivar e Estudar. Avançar do Guia ainda tem adaptação explicitamente marcada.

Nenhum desses pontos bloqueia continuar a integração delimitada dos ramos decididos. Eles bloqueiam os exemplos que necessitem precisamente da regra ausente, e uma publicação como subsistema totalmente fechado. Marcar esses resultados como indeterminados. Não reabrir como pendentes duração, Movimento da reserva, Preparar simples, emissão antecipada, intenção sem tarefa, recepção ou orientação incluída: já foram decididos.

## Conflitos reais preservados com o principal

- Manual 60 mantém comando obrigatório por rodada e inércia sem comando/inconsciência; conflitam com autonomia e ordens persistentes da candidata.
- Manual 60 e mecânica 15 mantêm estrutura, valores, barra de Matilha e retorno da arquitetura anterior. Seus custos, régua de morte e retorno com vida parcial não preenchem automaticamente a nova proposta.
- Manual 11 referencia Torrente do Emanador, divergindo da coleção v0.4 (Condutor Armado, Ressonante e Catalisador). Preservar a coleção; não importar a exceção antiga.
- Esquivar menciona TR de Destreza enquanto as referências gerais usam os quatro TR nomeados. Agarrar/Derrubar/Empurrar carecem de procedimento suficiente; Estudar conserva divergência de perícia entre trechos.
- A aplicação de Avançar do Guia ao turno conjunto continua marcada como adaptação. Nenhum texto do Caminho foi alterado para encaixar a proposta.

Os quatro Caminhos v0.4, o cabeçalho interno do Emanador, Estocada e PE do Emanador sem atributo foram preservados. As 12 referências protegidas conferem com os hashes da revisão anterior. O principal permanece no mesmo commit e sem alterações locais ao fim da verificação.

## Próxima pauta proposta, ainda sem aprovação

Uma intenção deve expressar um objetivo coerente. Pode admitir diferentes meios e respostas pertinentes (“proteja esta entrada”), mas uma sequência de objetivos independentes (“ataque X; depois vá buscar Y; depois proteja Z”) não deve receber gratuidade de vários redirecionamentos só por caber numa frase. O critério e suas fronteiras devem ser apresentados a Mizuki antes de entrar como regra.
