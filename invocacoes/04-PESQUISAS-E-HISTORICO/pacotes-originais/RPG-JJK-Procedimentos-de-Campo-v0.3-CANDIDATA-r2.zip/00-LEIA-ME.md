# Projeto M — Procedimentos de Campo

**v0.3 CANDIDATA — revisão 2 · Mizuki · 24/09/2026**

Esta revisão incorpora as decisões autorais até o §30 do registro, incluindo o limite da orientação gratuita que falhou. A versão inteira continua candidata; decisões aprovadas e hipóteses estão separadas. Não houve alteração do principal, Caminhos ou regras gerais, nem commit ou push.

## Leitura

1. [Procedimentos consolidados](01-PROCEDIMENTOS-DE-CAMPO-v0.3-CANDIDATA-r2.md): documento autocontido para leitura corrente.
2. [Alterações desde a v0.2](02-ALTERACOES-v0.2-para-v0.3-CANDIDATA-r2.md): decisões incorporadas, esclarecimentos e pendências.
3. [Pendências e conflitos](03-PENDENCIAS-E-CONFLITOS.md): limitações reais e pauta autoral seguinte.
4. [Ensaio e auditoria](04-RELATORIO-E-AUDITORIA.md): evidência e limites das 107 verificações.

As 107 verificações passaram: 49 de regressão executadas com o modelo ampliado e 58 novas. Uma verificação confirma que falta de regra de queda deve produzir indeterminação; isso não equivale a resolver a queda. Não é playtest humano ou prova de equilíbrio. Não foram definidos preços, PE, PV, dados, X ou alcance.

## Precedência e preservação

A consolidação r2 substitui **para leitura corrente dos procedimentos**, sem apagar o histórico:

- a proposta integral v0.2 e a proposta operacional do retorno, nos trechos procedimentais consolidados;
- a candidata original e a revisão 1;
- os blocos parciais 02 e 04–16 da pasta `continuidade-procedimentos-v0.3`.

O registro cronológico `fontes/DECISOES-POSTERIORES.md` continua fonte de autoria. Pendências antigas desse registro descrevem sua época e podem ter sido resolvidas por seções posteriores. A lista de pendências desta revisão é a leitura atual.

A revisão 1 foi preservada no ZIP de `fontes/`; esse pacote inclui o histórico anterior. Os blocos de trabalho também estão copiados em `fontes/blocos/`. Não é necessário abrir esses históricos para compreender os procedimentos correntes. Nenhum deles substitui Caminhos, regras gerais ou manual principal.

**Estado:** pronto para continuar a integração delimitada e ensaios de mesa dos ramos definidos. Não há decisão autoral bloqueante para esse recorte. Ramos que dependam das pendências listadas devem ser isolados e marcados como indeterminados, sem preencher lacunas. A migração para o principal continua dependendo de pedido expresso.

**Escopo preservado:** nenhuma regra de Evocador, Trilha, construtor ou orçamento foi criada. Bastião, Vanguarda, Emanador e Guia v0.4, Estocada e PE do Emanador sem atributo adicional permanecem preservados.
