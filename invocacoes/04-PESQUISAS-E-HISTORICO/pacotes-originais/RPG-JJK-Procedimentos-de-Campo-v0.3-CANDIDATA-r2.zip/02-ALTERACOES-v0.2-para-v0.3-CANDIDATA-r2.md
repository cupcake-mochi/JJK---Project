# Alterações — v0.2 → v0.3 CANDIDATA, revisão 2

**Consolidação cumulativa. Não aprova automaticamente a versão inteira.** O retorno operacional e as decisões autorais posteriores atualizam as hipóteses da v0.2. Histórico e citações estão preservados em `fontes/`.

## Decisões aprovadas incorporadas

| Tema | Evolução até a revisão 2 |
|---|---|
| Especial e intenção | Especial pode divergir da intenção vigente. Depois do resultado, pode conservar ou trocar a intenção da destinatária sem Bônus adicional. |
| Comando antecipado | Padrão na emissão; básica disponível e custos próprios na execução. Persistência até oportunidade válida, sem expiração pela passagem de turno; fora do turno também usa coletiva, após a resolução que abriu a janela. |
| Espera, ajuste e desistência | Enquanto inviável, pode usar outra básica sem apagar a ordem. Bônus ajusta alvo/capacidade. Desistência comunicada antes de começar não exige ação, encerra a ordem e não devolve Padrão. Execução falha mantém gastos e encerra a ordem. |
| Primeira oportunidade | Uma especial já válida deve executar ou ser legalmente cancelada. Não pode ficar guardada apenas por preferência de momento. Emissão com básica disponível é permitida se houver outro impedimento real; se tudo permitir, execução imediata. |
| Inconsciência | Ordem anterior continua e pode usar PE do invocador se ele já for a fonte normal da capacidade. Não concede novos comandos, ajustes ou cancelamentos. |
| Relógio | Ciclo no início do turno do invocador; efeitos individuais no início/fim comuns. Rodada global ou troca não renovam recursos. |
| Coletiva e Guia | Reserva única das entidades, distinta da pessoal. Jogador escolhe entre respostas elegíveis na mesma janela sem prioridade expressa, inclusive durante inconsciência. Guia 30 preservado, com dois gastos possíveis somente se houver renovação real entre eles e demais requisitos. |
| Substituição | No máximo uma básica ainda não gasta à substituta elegível, debitada da fonte. Corpo que já gastou no ciclo não recupera por rotação. Uma saída com várias entradas só inclui orientação/saldo na substituta direta. |
| Primeira intenção | Incluída na substituição direta; entrada adicional usa Bônus normal. Não cria básica. |
| Identidade e Movimento | Movimento pertence ao corpo. Corpo novo entra com o próprio disponível; reentrada conserva somente o saldo não gasto. Ausência através da fronteira não renova Movimento nem produz básicas em reserva; encerra a trava de gasto do ciclo anterior. |
| Recolhimento e efeitos | Durações passam; efeitos periódicos independentes de presença e TR de recuperação seguem seus momentos. Recolhida não ocupa posição do invocador nem projeta aura dependente de presença. Persistências independentes seguem o texto. Zero PV tem o mesmo critério aplicável em campo, sem criar regra completa de queda. |
| Preparar | Básica gasta ao preparar, coletiva ao executar, sem segunda básica. Expira na próxima fronteira e se perde com recolhimento ou gasto da coletiva em outra resposta. Sem devolução da básica investida. |
| Intenção sem execução | Impedimento temporário conserva a tarefa. Cumprimento definitivo não cria missão nova. Sem tarefa executável, autopreservação limitada com recursos normais, sem perseguição ou proteção gratuita de terceiros. |
| Comunicação | Nova mensagem precisa ser percebida/compreendida. Voz/gestos conforme meios reais; canal mental exige previsão. Perda de comunicação não apaga ordens anteriores nem significa perda do vínculo. |
| Tentativas falhas | Impedimento conhecido antes de emitir permite corrigir declaração sem gasto. Tentativa emitida com falha descoberta depois conserva gasto; recepção parcial só altera quem recebeu. Reenvio usa procedimento normal. |
| Orientação incluída | Terminada a ocasião sem recepção, não guarda crédito gratuito. Não desfaz troca/especial ou básica transferida. Mantém intenção anterior válida ou autopreservação, conforme o caso. |

### O que esta revisão acrescenta à r1

Os §§18–30 do registro cobrem, respectivamente: recursos fora de campo; durações; efeitos periódicos; relações espaciais; queda; Preparar; disputa da coletiva; compromisso com oportunidade válida; emissão com básica disponível; intenção impedida/cumprida/ausente; comunicação; tentativa falha/recepção parcial; orientação incluída sem crédito posterior. Esses trechos foram integrados nos lugares correspondentes, removendo rótulos de pendência já superados.

## Redações esclarecidas e correções editoriais

- “Corpo novo” significa corpo ainda não manifestado, não apenas corpo que ainda não entrou no ciclo atual. A formulação antiga do exemplo poderia sugerir renovação indevida de Movimento e foi corrigida.
- A fronteira renova básica/Movimento dos corpos em campo; o procedimento próprio da reserva não cria recursos fora de campo.
- Intenção não cumprida conserva básica não gasta. Preparar efetivamente gasta básica. Ordem antecipada investe Padrão, mas só ocupa básica ao executar. Os três estados estão separados.
- Escolher uma resposta concorrente não é novo comando do invocador inconsciente nem permissão de não executar nenhuma para guardar a ordem.
- Recepção e gratuidade são requisitos distintos. Dar primeira intenção e transferir básica também são operações distintas.
- Orientação posterior à especial continua escolhida depois do resultado; a falha não cria crédito para outro momento.
- Golpe do Guia continua ataque comum, nunca básica, especial, Ação Atacar ou Sequência.

## Pendências e recomendações preservadas

Não foram fixados valores de ficha, X, alcance, custos de entrada/troca, energia própria ou regras completas de queda/retorno. Avançar do Guia conserva seu status de adaptação onde não houver aprovação específica. Permanecem limites de intenções encadeadas, certas conversões da criatura e composição de especial com Preparar. Lacunas de manobras, Esquivar, Estudar e precedência geral de efeitos não foram resolvidas por inferência.

O antigo exemplo de Bônus para substituir continua ilustrativo: o custo está na pauta futura. A possibilidade de energia própria continua registrada sem reserva, fórmula, recarga ou preços. Nenhuma regra de Evocador, Trilha, construtor ou orçamento foi criada.

## Evidência e arquivos substituídos para leitura

A r2 executou 107 verificações de estado (49 de regressão no modelo ampliado e 58 novas), sem somar ensaios históricos à contagem. A candidata r2 substitui para leitura os procedimentos da v0.2, retorno operacional, candidata original, r1 e blocos parciais correspondentes; não apaga histórico, não transforma testes antigos em validação nova e não substitui manual/Caminhos do principal.
