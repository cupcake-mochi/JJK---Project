# Ensaio narrado 01 — Procedimentos de Campo

**Base: v0.3 CANDIDATA r4, decisões até §40.**

## Natureza e premissas

Aplicação narrada conduzida pelo assistente, com rastreio dos recursos pelo modelo r4. Não houve participantes humanos, rolagens de combate ou medição de tempo de mesa. As decisões táticas descritas são escolhas do roteiro, não decisões autorais novas. O modelo confere consistência interna dos estados; não funciona como árbitro independente da regra que implementa.

As entidades A, B, C e D são marcadores, não fichas novas de invocações. Para acompanhar conservação, o roteiro usa uma oportunidade básica identificada por corpo/ciclo, sem fixar a quantidade definitiva. Especial e ataque comum são capacidades já válidas fornecidas como premissa, sem dano, alcance ou preço. Requisitos de comunicação, existência e sustentação são atendidos nos trechos executados. Custos próprios de ativação estão disponíveis, sem fixar sua fonte ou quantidade.

Os ramos 2A/2B e 4A/4B são alternativas independentes; seus gastos não são somados numa mesma cena. Nenhuma Padrão extra foi concedida. Na cena 3, legalidade, oportunidade e custos das trocas são premissas externas: avaliam-se somente seus efeitos sobre saldos e identidade. Não se demonstra que todas essas trocas cabem num turno real.

## Cena 1 — A especial muda o plano

A protege a entrada; B protege a ponte. Ambas estão em campo e com básica disponível. O invocador tem Padrão e Bônus; a coletiva está disponível.

1. O invocador manda A usar uma especial contra X, fora de sua intenção atual. Paga Padrão; A usa sua básica e os custos próprios. Por ser execução imediata no turno do invocador, não paga coletiva por esse procedimento.
2. Depois de conhecer o resultado, comunica a A “proteja Y”. A nova intenção é recebida, sem Bônus adicional. B continua com sua tarefa.
3. A tenta uma básica para já cumprir a nova intenção: não pode, pois a oportunidade foi usada pela especial.
4. B ainda pode realizar sua própria básica coerente com a tarefa.

| Saldo final | Estado |
|---|---|
| Padrão do invocador | Gasta no comando |
| Bônus e coletiva | Disponíveis |
| Básica de A | Gasta pela especial |
| Básica de B | Gasta pela atuação própria posterior |
| Intenções | A protege Y; B mantém proteção da ponte |

**Resultado:** não foi necessário redirecionar antes da especial nem pagar Bônus pela orientação posterior. A nova tarefa não devolveu a básica. Base: seções 4.2 e 5. Essa cena reproduz precisamente o ponto que havia sido lido de forma errada no chat externo.

## Cena 2 — Recusar o gatilho e disputar a coletiva

O invocador manda A preparar uma especial para quando X entrar em alcance. Padrão e básica de A ficam gastas; coletiva permanece disponível. O turno termina. O gatilho é tratado em uma janela legal já fornecida pela cena; a relação com movimento ainda em resolução é examinada separadamente na cena 5.

X entra. O invocador percebe e comunica que não quer disparar nessa ocorrência. A preparação continua, mas a ocorrência é descartada. X permanece em alcance: isso não oferece outro disparo.

**Ramo 2A — conservar a coletiva.** Antes da expiração, X sai e entra novamente por movimentos legais fornecidos pela cena. Essa é uma nova ocorrência. A executa pagando coletiva e custos próprios, sem outra básica ou Padrão. A orientação após o resultado continua possível.

**Ramo 2B — usar a coletiva com B.** Antes de outra entrada, um Guia externo oferece a B um Golpe comum em uma resposta já elegível após Abertura resolvida. Os requisitos e a Reação do Guia estão disponíveis. B usa a coletiva; a preparação de A termina nesse momento. Uma entrada posterior de X não a recupera. O Golpe de B não gasta nem renova básica.

| Comparação | Ramo 2A | Ramo 2B |
|---|---|---|
| Uso da coletiva | Especial preparada de A | Golpe comum de B |
| Básica de A | Continua gasta | Continua gasta, apesar de A não executar |
| Preparação de A | Cumprida pela execução | Perdida pelo uso da coletiva |
| Básica de B | Não foi gasta nesta cena | Não foi gasta pelo Golpe |

**Resultado:** o conjunto escolhe qual resposta vale a coletiva. A preparação não reserva esse recurso e não protege o investimento contra essa escolha. Não se demonstrou qual opção causa mais dano ou é melhor: faltam fichas e situação completas. Base: seções 6.8, 8.1 e 8.2; §§34, 36, 38 e 40.

## Cena 3 — Trocar não copia básica nem cura

A está ferida, tem uma condição persistente e ainda não gastou a básica. C já gastou básica e Movimento no ciclo e foi recolhida. B e D são corpos novos, ainda não manifestados.

Fornecemos um evento legal em que A sai, B entra como substituta direta e D como entrada adicional. B recebe a básica identificada que pertencia a A e a intenção incluída “ataque Y”. D não recebe básica nem intenção gratuita; B e D têm seu Movimento próprio disponível. A condição e os PV de A continuam registrados.

B usa a básica recebida. Em outro evento legal fornecido, B sai e C retorna. C não recebe básica: B já a gastou, e C também conserva a trava de uso daquele ciclo. O Movimento gasto de C não é restaurado. A primeira intenção incluída na substituição não muda esses saldos.

**Resultado:** uma única oportunidade passou de A para B e foi consumida; D e C não ganharam cópias. O estado ferido de A não foi apagado. Base: seções 9.2–9.7.

**Limite explícito:** não decidimos se há ação, energia ou oportunidade suficientes para executar essa sequência de trocas num combate real. Esse trecho permanece condicionado à legalidade dos eventos, pois os custos de troca estão reservados para discussão futura.

## Cena 4 — Mudar a modalidade exige pagar novamente

**Ramo 4A.** No primeiro ciclo, o invocador paga Padrão para antecipar uma especial de A que está inviável. O impedimento continua até o próximo início do turno; nenhuma oportunidade válida foi recusada. A fronteira renova Padrão e básica. O invocador encerra a ordem anterior por comunicação válida e usa a Padrão nova para comandar uma preparação, investindo a básica disponível. Foram pagos dois comandos em dois ciclos; o primeiro não virou crédito.

**Ramo 4B.** Em outra situação, o invocador acaba de pagar Padrão e básica de A para preparar. Arrepende-se e encerra a preparação. Tenta emitir antecipada ainda naquele turno, mas não tem outra Padrão. O novo comando não pode ser emitido; Padrão e básica anteriores continuam gastas. A ordem antiga não retorna por a nova ser inviável.

**Resultado:** o §39 funciona sem criar conversão gratuita nem exigir um novo preço. Uma preparação encerrada pode deixar o jogador sem atuação básica daquele corpo no ciclo. Essa consequência já está aprovada; o ensaio não a apresenta como nova restrição ou erro de equilíbrio. Base: seção 8.1.5.

## Cena 5 — Onde o ensaio precisa parar

Declaração concreta: “A prepara a especial quando X cruzar a linha da porta.” X cruza a linha no meio de um deslocamento que pretende continuar para trás de uma cobertura.

O acontecimento é identificável e não é um estado continuamente verdadeiro. Mas a resolução completa requer determinar **em qual ponto do deslocamento o gatilho de Preparar é resolvido** e se o deslocamento prossegue depois da resposta. Isso pode mudar alcance, percepção e resultado da especial.

A referência geral de Preparar exige gatilho visível/verificável e usa exemplos de cruzamento. O procedimento antecipado tem sua própria janela posterior à resolução que tornou a execução possível, mas a consolidação expressamente não a transporta automaticamente para Preparar. As fontes consultadas não bastam para fechar esse caso intermediário sem interpretação adicional.

**Resultado: indeterminado nesse ponto.** Não executamos esse ramo no modelo como se o instante estivesse aprovado. Não escolhemos entre parar na passagem, esperar o fim do deslocamento inteiro ou outra granularidade. A dúvida é sobre janela de resolução, não sobre reabrir a recusa, o §40 ou os gastos da preparação.

## Achados e próxima discussão

1. **Orientação após especial:** o procedimento preservou a mudança gratuita de intenção depois do resultado e não gerou básica adicional.
2. **Preparação e coletiva:** o ramo alternativo deixou visível o custo de oportunidade de usar a coletiva em outro corpo. O investimento na preparação pode ser perdido sem executar.
3. **Substituição:** saldos e identidade são suficientes para impedir cópia da oportunidade no roteiro. A cena não valida o custo/frequência das trocas.
4. **Mudança de modalidade:** não houve reaproveitamento; recursos novos precisam estar realmente disponíveis. Arrependimento não restaura o investimento.
5. **Lacuna concreta a levar ao autor:** janela da especial preparada quando o acontecimento ocorre no meio de um deslocamento. Essa lacuna já pertence à categoria de janelas pendentes, mas agora existe um caso que exige tratá-la.

Sugestão editorial, ainda não aplicada ao livro: na apresentação aos jogadores, colocar ao lado da preparação dois lembretes curtos: “a básica é gasta ao preparar” e “qualquer outra resposta que use a coletiva perde a preparação”. Isso apenas apresenta regras aprovadas, sem acrescentar mecânica.

Nenhuma regra nova foi adotada. Nenhum §41 foi criado. Não há base para afirmar equilíbrio, facilidade percebida pelos jogadores, duração de turnos ou ausência de exploração. Este ensaio prepara uma aplicação humana posterior; não a substitui.

## Evidência e reprodução

`RASTRO.json` contém os 18 passos explicitamente registrados, com estados antes/depois. As 178 verificações da r4 não foram reexecutadas nem somadas a esse total; elas permanecem evidência anterior. Passos de montagem da cena e fatos fornecidos como premissa estão descritos neste relatório e no roteiro.

`roteiro.py` reproduz os passos usando a cópia preservada da bancada em `modelo/`. Execute `python3 roteiro.py` nesta pasta; escreve somente `RASTRO-REPRODUZIDO.json`. A cena 5 não é executada: sua indeterminação é registrada no relatório. O snapshot dos procedimentos usados está em `BASE-PROCEDIMENTOS-r4.md`.
