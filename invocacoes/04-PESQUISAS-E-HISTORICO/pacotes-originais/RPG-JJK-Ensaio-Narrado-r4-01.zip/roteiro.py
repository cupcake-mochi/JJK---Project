from pathlib import Path
import sys, copy, json
sys.dont_write_bytecode = True
sys.path.insert(0, str(Path(__file__).resolve().parent/'modelo'))
import bancada_r4 as m
traces = []
def snapshot(s):
    return dict(ciclo=s.ciclo, momento=s.momento, padrao=s.padrao, bonus=s.bonus,
        coletiva=s.coletiva, pessoal=s.pessoal,
        corpos={n:dict(em_campo=c.em_campo, basica=c.basica, gastou=c.gastou,
            movimento=c.movimento, intencao=c.intencao, antecipada=c.ordem,
            preparada=c.especial_preparada, pv=c.pv, condicoes=c.condicoes)
            for n,c in s.corpos.items()})
def step(scene, s, label, operation, expected):
    before = snapshot(s)
    actual = operation()
    s.invariantes()
    assert actual == expected, (scene, label, expected, actual)
    traces.append(dict(cena=scene, passo=label, resultado=actual,
        antes=before, depois=snapshot(s)))

# Cena 1: intenção distinta da intervenção e orientação posterior.
s=m.cena(('A','B')); s.corpos['A'].intencao='proteger entrada'; s.corpos['B'].intencao='proteger ponte'
step('1',s,'Comandar especial imediata de A contra X e orientar proteger Y após resultado',
    lambda:s.antecipar('A',alvo='X',nova_intencao='proteger Y'),'executada')
assert not s.padrao and s.bonus and s.coletiva and s.corpos['B'].basica
step('1',s,'A tenta outra básica',lambda:s.basica_normal('A'),'recusado:basica')
step('1',s,'B executa básica coerente com a própria tarefa',lambda:s.basica_normal('B'),'basica')

# Cena 2: mesmo começo, duas escolhas alternativas; não somar os ramos.
s=m.cena(('A','B'))
step('2-comum',s,'A prepara especial para entrada de X no alcance',
    lambda:s.preparar_especial('A',gatilho='entrada:alcance:X'),'especial-preparada')
s.fechar_turno(); s.observar_estado('alcance:X',True)
step('2-comum',s,'Invocador percebe e comunica recusa da primeira entrada',
    lambda:s.resolver_gatilho('A',recusar=True),'recusada:preparacao-conservada')
s.observar_estado('alcance:X',True)
step('2-comum',s,'X permanece em alcance; tenta-se usar a ocorrência passada',
    lambda:s.resolver_gatilho('A'),'recusado:sem-nova-ocorrencia')
kept=copy.deepcopy(s); used=copy.deepcopy(s)
kept.observar_estado('alcance:X',False); kept.observar_estado('alcance:X',True)
step('2A',kept,'Com coletiva preservada, uma nova entrada permite a especial',
    lambda:kept.resolver_gatilho('A',nova_intencao='proteger entrada'),'executada')
step('2B',used,'B aceita um Golpe elegível concedido por Guia externo',
    lambda:used.resposta_guia30('B'),'golpe-comum')
assert used.corpos['A'].especial_preparada is None and used.corpos['A'].gastou
used.observar_estado('alcance:X',False);used.observar_estado('alcance:X',True)
step('2B',used,'Nova entrada de X após coletiva gasta em outra resposta',
    lambda:used.resolver_gatilho('A'),'recusado:sem-preparacao-especial')

# Cena 3: somente consequências de eventos legais fornecidos; custos excluídos.
s=m.cena(('A','C'),reservas=('B','D'))
s.corpos['A'].pv='ferida previamente';s.corpos['A'].condicoes=['condicao persistente fornecida']
s.basica_normal('C');s.corpos['C'].movimento=False;s.recolher_apos_evento_legal('C')
token=s.corpos['A'].basica
step('3',s,'Evento legal: A sai; B substituta direta e D entrada adicional',
    lambda:s.substituir_apos_evento_legal(['A'],['B','D'],'B','atacar Y'),'substituida')
assert s.corpos['B'].basica==token and s.corpos['D'].basica is None
assert s.corpos['B'].intencao=='atacar Y' and s.corpos['D'].intencao is None
assert s.corpos['B'].movimento and s.corpos['D'].movimento
step('3',s,'B utiliza a básica recebida',lambda:s.basica_normal('B'),'basica')
step('3',s,'Outro evento legal: B sai e C retorna no mesmo ciclo',
    lambda:s.substituir_apos_evento_legal(['B'],['C'],'C','proteger entrada'),'substituida')
assert s.corpos['C'].basica is None and not s.corpos['C'].movimento
assert s.corpos['A'].pv=='ferida previamente' and s.corpos['A'].condicoes
step('3',s,'C tenta básica sem saldo',lambda:s.basica_normal('C'),'recusado:basica')

# Cena 4: nova Padrão obtida por fronteira real, sem conceder ação extra.
s=m.cena();s.corpos['A'].alvo_valido=False
step('4A',s,'No primeiro ciclo, antecipar a especial inviável',lambda:s.antecipar('A'),'ordenado')
s.fechar_turno();s.abrir_turno() # Impedimento ainda existe; não se pretere janela válida.
step('4A',s,'No ciclo seguinte, encerrar a antecipada por comunicação válida',lambda:s.desistir('A'),'desistiu')
step('4A',s,'Usar a Padrão renovada e básica disponível em novo comando de preparação',
    lambda:s.preparar_especial('A'),'especial-preparada')
assert len([e for e in s.eventos if e.startswith('P:')])==2
s=m.cena();s.preparar_especial('A')
step('4B',s,'Ainda no turno de emissão, encerrar a preparação',lambda:s.desistir_preparada('A'),'desistiu')
step('4B',s,'Tentar emitir antecipada sem outra Padrão',lambda:s.antecipar('A'),'recusado:comando')
assert s.corpos['A'].basica is None and not s.padrao and s.corpos['A'].ordem is None


Path(__file__).with_name('RASTRO-REPRODUZIDO.json').write_text(json.dumps(traces, ensure_ascii=False, indent=2)+'\n')
print(f'{len(traces)} passos registrados; nenhuma regra numérica nova.')
