# Relatório — ensaio procedimental da revisão 1

## Resultado

**49 casos verificados, 49 aprovados, 0 falhas na execução final.** Em **21 casos**, também se conferiu que uma tentativa recusada ou ainda inviável não alterou o estado. Cada caso registra estado anterior/posterior, retorno esperado/obtido e sua verificação; o JSON contém os registros completos.

São casos de um modelo simbólico delimitado. Não são 49 combates, provas independentes de equilíbrio ou aprovação automática das regras restantes. Os 168 checks do ensaio v0.2 e os 40 casos da auditoria textual original permanecem históricos e não foram somados a essa contagem.

## Resultados por interação

| Casos | Interação | Resultado no modelo |
|---|---|---|
| 01–02 | Especial imediata e orientação posterior | Ocupa básica e Padrão; orientação ocorre depois do resultado; não resta básica extra. |
| 03–08 | Emissão, fila, ciclo e resposta | Padrão paga antes; não reserva custo próprio; não acumula segunda ordem; rodada global não renova; fora do turno exige básica + coletiva e não interrompe resolução. |
| 09–15 | Espera, outra básica, ajuste e falha | Alvo/custos ausentes preservam a ordem; outra básica durante inviabilidade adia a execução; Bônus ajusta alvo/capacidade; execução falha encerra a ordem com gastos. |
| 16–17 | Desistência | Não devolve Padrão; na janela válida preserva os recursos da execução ainda não iniciada. |
| 18–20 | Inconsciência | Não permite ajustar/cancelar conscientemente; permite cumprir ordem prévia com custo autorizado, sem orientação posterior nova. |
| 21–24 | Troca e retorno | Ordem encerra na saída; saldo passa sem cópia; retorno não recria básica transmitida nem Movimento gasto; básica anterior executada não volta por cancelamento. |
| 25–28 | Divisão, reunião e identidade | Uma substituta recebe saldo/intenção em 1→vários; várias saídas não fundem básicas; corpo que já agiu não recupera oportunidade; PV, condições e usos permanecem. |
| 29–32 | Entrada adicional e intenção | Corpo novo tem Movimento, sem básica/ordem inicial/coletiva nova; Bônus atribui primeira intenção e pode orientar destinatárias com tarefa comum. Conversão P→B não deixa P disponível. |
| 33–37 | Atordoado e fim comum | Retira básica e impede aquela respondente; outra pode usar coletiva. Fim da condição não devolve básica ou reserva já gasta; permite reagir se a coletiva ainda estiver disponível. |
| 38–40 | Duas ordens, uma coletiva | A primeira resposta gasta a reserva; a outra conserva ordem e básica aguardando. Renovação permite executar sem nova Padrão. |
| 41–44 | Guia 30 externo | Golpe não recupera/consome básica; sem renovação não há segunda resposta paga pelo conjunto; com renovação, outra criatura pode responder; terceira resposta é recusada. |
| 45–49 | Limites de turno | Intenção/ordem persistentes não autorizam básicas comuns, ajustes por Bônus, redirecionamento, conversão ou emissão de comando fora do turno. |

## Auditoria dos registros e correções da bancada

Na primeira execução, 44 casos passaram. A revisão da instrumentação encontrou que operações comuns ainda não tinham todas as verificações de momento e que algumas cenas de resposta começavam com alvo já válido antes da janela pretendida. A bancada foi corrigida para não permitir ações comuns fora do turno e para tornar o alvo válido somente no acontecimento pertinente, sem presumir adiamento voluntário.

Foram acrescentados cinco casos dirigidos a esses limites. A execução final passou nos 49. Isso é correção de escopo/instrumentação, não mudança autoral de regra ou resultado de equilíbrio. Não houve repetição de baterias numéricas de dano, pois nenhum parâmetro desse tipo foi definido nesta etapa.

## Leitura prática

O cancelamento da ordem na troca e a transmissão de básica não se contradizem: a primeira encerra uma instrução, a segunda transfere uma oportunidade que não foi gasta. A Padrão paga pelo comando não é a básica da criatura.

A coletiva limita a quantidade de respostas pagas, sem apagar outras ordens que ainda aguardam. Atordoado limita a respondente e retira sua atuação, sem consumir a reserva de todas as criaturas. Esses estados separados foram importantes para a coerência dos casos.

O modelo acompanha identificadores de básicas para detectar duplicação e verifica ausência de mutação em tentativas inviáveis. Não há cálculo de PE, dano, risco, duração de combate ou tempo de mesa. Preparar e retorno após fronteira fora de campo foram excluídos por dependerem de integração adicional; não receberam comportamento presumido.

## Prontidão

Os procedimentos decididos estão suficientemente definidos para esta bateria e para continuar a integração. Não é necessário reabrir suas decisões por falta de preço de ficha. A publicação completa ainda depende dos campos listados em `03-PENDENCIAS-E-CONFLITOS.md`, e balanceamento exige ensaios próprios posteriores.

Não houve alteração no projeto principal, Caminhos ou regras gerais. Nenhuma regra de Evocador, Trilha, construtor ou orçamento foi criada. Não houve commit nem push.
