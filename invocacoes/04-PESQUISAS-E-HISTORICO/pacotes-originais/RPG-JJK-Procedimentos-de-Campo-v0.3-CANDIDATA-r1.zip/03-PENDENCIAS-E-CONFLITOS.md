# Estado das pendências e conflitos — revisão 1

## 1. O que está fechado

O procedimento principal do comando antecipado, primeira intenção adicional, equivalência de Atordoado e fronteiras de turno receberam decisões autorais. Não é necessário perguntar novamente sobre prazo persistente, Bônus para ajuste, desistência, execução fora do turno com coletiva, PE na inconsciência para ordem prévia ou encerramento da ordem na saída.

Esses casos estão prontos para ensaio delimitado, e a bateria entregue nesta revisão foi executada. Não significa que qualquer ficha, efeito ou troca já tenha custo e resolução completos.

## 2. Pendências reais restantes

| Recorte | O que falta | Impacto |
|---|---|---|
| Corpo fora de campo | Renovação de recursos ao atravessar a fronteira ausente; duração/efeitos dependentes de presença quando a fonte não resolver. | Bloqueia esses retornos específicos, não a troca dentro de um ciclo já definida. |
| Preparar | Fechar a adaptação para básicas e a situação de retirada depois de uma básica efetivamente gasta em preparar. Não confundir com intenção não cumprida. | Impede usar uma suposta devolução de básica preparada no ensaio como fato aprovado. |
| Casos adicionais de comando | Emitir antecipadamente apesar de poder executar agora; adiar voluntariamente sem desistir depois de oportunidade válida; prioridade de respondentes igualmente elegíveis. | Não foram concedidos por silêncio. O ensaio fornece uma ordem de avaliação e não prova prioridade universal. |
| Intenção e informação | Comportamento sem tarefa válida, tarefa cumprida/impossível; meio/alcance de comunicação. | Exige definição ao usar esses ramos. Primeira intenção adicional por Bônus já está fechada. |
| Valores e acesso | Quantidade/progressão de básicas, X, fontes/valores de capacidades, manifestação e legalidade de entrada/troca. | Impede fichas definitivas e preço/equilíbrio completos. No ensaio, a legalidade da troca é premissa, não custo zero. |
| Referências gerais | Agarrar/Derrubar/Empurrar, TR de Esquivar e perícia de Estudar; precedência de efeitos sem texto suficiente. | Isolar os casos dependentes e preservar o texto até decisão autorizada. |

**Pauta futura solicitada:** custo de substituição e possibilidade de energia própria das invocações. Não antecipar construtor, orçamento, Evocador ou Trilhas para resolver esses campos.

Não há bloqueio autoral para continuar testando os ramos já decididos. Para publicar um procedimento totalmente fechado, ainda faltam as definições pertinentes aos recortes acima. O próximo recorte autoral útil é estado/recursos de um corpo que permanece fora de campo através da fronteira; não exige reabrir a ordem especial, que já se encerra ao sair.

## 3. Conflitos com o projeto principal

Permanecem os conflitos confirmados na candidata original:

- Manual 60 exige comando por rodada e descreve inércia sem comando/inconsciência; a autonomia atual não pode ser sobreposta a essas restrições.
- Manual 60 fixa ordem de atuação, amarra, números e retorno da arquitetura antiga. Esses valores não preenchem campos pendentes desta revisão.
- Mecânica 15 conserva rotina repartida, estrutura de Matilha e orçamento antigos; seus validadores não verificam a arquitetura atual.
- Manual 11 referencia Torrente do Emanador, enquanto a coleção v0.4 tem Condutor Armado, Ressonante e Catalisador. Preservar v0.4, sem restaurar a Trilha antiga ou importar sua exceção.
- Esquivar nomeia TR de Destreza, mas a referência geral usa quatro TR nomeados. As referências de manobras e Estudar também continuam incompletas/ambíguas nos pontos já registrados.

Guia 30 mantém seu texto; o cruzamento entre seu ciclo e o do invocador não é corrigido com um teto reativo adicional. O cabeçalho interno do Emanador v0.3 dentro da coleção v0.4 continua preservado, assim como seus PE sem atributo adicional e Estocada.

Os caminhos e hashes das 12 referências protegidas constam do manifesto. Nenhum conflito foi resolvido editando o projeto principal.
