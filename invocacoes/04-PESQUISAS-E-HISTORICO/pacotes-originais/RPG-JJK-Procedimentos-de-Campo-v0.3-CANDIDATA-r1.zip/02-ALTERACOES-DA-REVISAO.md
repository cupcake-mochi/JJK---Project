# Alterações — candidata original → revisão 1

**v0.3 CANDIDATA — revisão 1.** O registro v0.2 → candidata original continua no pacote histórico. Este arquivo complementa aquela transição com decisões posteriores, sem reclassificar o histórico como erro ou como aprovação da versão inteira.

## 1. Decisões autorais incorporadas

| Tema | Candidata original | Revisão 1 | Registro posterior |
|---|---|---|---|
| Prazo | Expiração na próxima oportunidade normal era recomendação. | Aguarda a primeira oportunidade realmente válida; não expira apenas pela passagem de turno. | §1 |
| Fora do turno | Não havia procedimento aprovado de execução reativa. | Exige básica disponível + coletiva; ocorre depois da resolução que abriu a oportunidade. | §3 e §13 |
| Básica durante espera | Cancelar a ordem ao usar outra básica era recomendação. | Outra básica enquanto a especial estiver inviável conserva a ordem; seu gasto adia a especial. | §4 |
| Ajuste | Novo comando de Padrão era recomendação. | Bônus ajusta alvo/capacidade, aproveitando a Padrão já paga. | §5 |
| Desistência | Possível procedimento ainda candidato. | Comunicação antes de começar, sem nova ação e sem devolver Padrão; pode desistir na própria janela válida. | §6–7 e §13 |
| Custos da especial | Timing ainda candidato. | Paga ao começar, sem reserva prévia, salvo texto específico. Requisitos ausentes fazem esperar; execução falha encerra a ordem mantendo os gastos. | §7 |
| Inconsciência | Execução e acesso a PE estavam pendentes. | Ordem prévia pode executar e usar PE do invocador se ele for a fonte normal da capacidade; sem novos comandos ou orientação posterior. | §8 |
| Saída da destinatária | Destino da ordem pendente estava aberto. | Encerra a ordem; não guarda na reserva nem transmite à substituta. | §9–11 |
| Fila de ordens | Sem limite fechado. | Uma ordem especial antecipada pendente por criatura; ajuste não empilha. | §14 |
| Primeira intenção adicional | Custo/procedimento aberto. | Bônus pelo redirecionamento normal, podendo dar a mesma tarefa a outras destinatárias dentro de X pendente. | §15 |
| Atordoado | Equivalência básica/Padrão era adaptação candidata. | Retira uma básica e impede aquela criatura de usar a coletiva. Fim da condição não devolve a básica perdida no ciclo. | §16 |
| Efeitos de turno | Janelas individuais aprovadas, colocação fina aberta. | Início/fim comuns ao invocador; efeitos/testes individuais nesses momentos, mesmo sem a criatura agir. | §17 |

## 2. Esclarecimentos sem ação extra

- A Padrão investida em uma ordem não equivale a uma básica já executada. Se a especial não começou e existe básica não gasta, a substituta elegível pode receber esse saldo.
- Intenção persistente não cumprida não é automaticamente Preparar. “Atacar X” pode continuar como tarefa sem consumir uma básica impossível de executar; não cria ataque reativo por si.
- A coletiva continua pertencendo ao conjunto. Uma ordem por criatura não significa uma Reação por criatura nem limita o repertório a um único gatilho reativo.
- Desistir na oportunidade encerra a ordem. Não foi interpretado como permissão de ignorar uma oportunidade válida e guardar a ordem indefinidamente por escolha.
- Fronteiras comuns não renovam PV, usos por cena ou efeitos fora de seu próprio relógio. Não há renovação extra por corpo nem por rodada global.

## 3. Pendências preservadas e correções de interpretação

A Bônus de substituição citada no exemplo era ilustrativa: Mizuki pediu manter o custo para discussão futura (§12). Energia própria das invocações também foi solicitada como pauta futura (§8), sem atribuir reservas ou números agora.

A associação feita pelo assistente entre o exemplo de intenção não cumprida e uma básica gasta em Preparar foi excessiva. A revisão distingue os dois estados; não cria devolução de uma básica preparada por analogia. A adaptação de Preparar e sua interação exata com retirada seguem destacadas, sem reabrir a transmissão de básica realmente não gasta.

Fora de campo através da fronteira, efeitos dependentes de presença e colisões de gatilhos sem precedência escrita continuam por resolver quando necessários. Quantidade de básicas, X, comunicação, fontes/valores e custos de entrada não foram escolhidos.

## 4. Verificação nova

Foi executada uma bancada simbólica de 49 casos sobre os procedimentos decididos. É nova evidência limitada à revisão executada, sem incorporar os 168 checks antigos à contagem. O relatório descreve correções da instrumentação, premissas e cenários que ficaram fora.

## 5. Precedência para leitura

`01-PROCEDIMENTOS-DE-CAMPO-v0.3-CANDIDATA-r1.md` passa a ser a leitura consolidada corrente em lugar de:

- `01-PROCEDIMENTOS-DE-CAMPO-v0.3-CANDIDATA.md` do pacote anterior;
- blocos parciais `02-COMANDO-ANTECIPADO-EM-REVISAO.md`, `04-ENTRADA-E-PRIMEIRA-INTENCAO-EM-REVISAO.md` e `05-TURNO-E-CONDICOES-EM-REVISAO.md` da pasta de continuidade;
- recomendações antigas incompatíveis da v0.2 e do retorno, conforme já indicado na consolidação anterior.

O registro cronológico de decisões e suas citações continua fonte de autoria. Suas pendências locais descrevem o estado de cada momento; seções posteriores podem resolvê-las. Use a lista atual de pendências desta revisão para o estado corrente.

Nenhuma fonte foi apagada. Não há substituição automática de manual, Caminhos ou regras gerais do projeto principal.
