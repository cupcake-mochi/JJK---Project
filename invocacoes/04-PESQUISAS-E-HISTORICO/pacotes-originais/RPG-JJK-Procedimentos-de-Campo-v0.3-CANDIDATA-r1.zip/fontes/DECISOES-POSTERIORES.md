# Continuidade dos Procedimentos de Campo após a v0.3 CANDIDATA

Registro de decisões posteriores ao pacote consolidado. A candidata e seu ZIP permanecem como fotografia da entrega anterior; este registro ainda não é uma nova versão integrada.

## 1. Prazo do comando antecipado — decisão de Mizuki

Mensagem autoral:

> Acho q faz mais sentido que continue esperando a primeira oportunidade em que ela realmente possa executar. Uma ordem é uma ação, ent ela iria "preparar" a ação nesse caso, até ter o gatilho de conseguir executar, talvez custando sua reação caso seja fora do turno do invocador

**Decidido:** a ordem antecipada continua aguardando a primeira oportunidade em que a destinatária realmente possa executar. Não expira apenas porque terminou o próximo turno do invocador sem que essa oportunidade surgisse. Isso substitui a recomendação anterior de expiração ao fim da próxima oportunidade normal/turno seguinte.

**Ainda proposto, não aprovado como procedimento:** execução fora do turno do invocador mediante Reação. A palavra “talvez” mantém aberta essa escolha e seus custos/requisitos. A analogia com preparar uma ação não importa automaticamente a ação geral Preparar, seus custos ou seu prazo.

**Limites preservados:** Padrão paga ao emitir a ordem; especial substitui básica elegível; ordem não renova recursos nem permite contornar básica já gasta no ciclo. A Reação das invocações é coletiva. Não foi autorizada antecipação da renovação de básica por pagar Reação.

**Demais questões ainda abertas:** cancelamento, mudança de alvo/capacidade, acúmulo/substituição de ordens, uso da básica para outra atividade durante a espera, momento dos custos próprios, definição do gatilho/janela fora do turno, efeitos de inconsciência e recolhimento/troca. Esperar por uma oportunidade válida não resolve por si essas questões.

## 2. Preferência de acompanhamento

Mizuki pediu indicação de modelo e esforço sempre que for proposta continuidade de uma etapa. Para a discussão atual de decisões e interações dos procedimentos: GPT-6 Astra, esforço alto.

## 3. Execução fora do turno — decisão posterior de Mizuki

Proposta apresentada: durante o turno do invocador, a especial antecipada ocupa uma básica disponível e paga os custos próprios da capacidade; fora desse turno, exige também a Reação coletiva. A Padrão de comando já foi paga ao emitir a ordem. A Reação não permite usar uma básica já gasta nem antecipar sua renovação.

Resposta autoral:

> Eu acho bom adotar, fica uma alternativa boa para possibilidade de estrategias em momentos ruins, podemos continuar

**Aprovado:** a especial antecipada pode ser executada fora do turno do invocador, consumindo uma básica disponível da destinatária e a Reação coletiva, além dos custos próprios da capacidade. Durante o turno do invocador, esse procedimento não acrescenta custo de Reação. Não se paga outra Padrão para executar a ordem já emitida.

**Consequência preservada:** se a criatura gastou sua básica no ciclo, precisa aguardar sua renovação normal antes de poder ocupar uma básica com a especial. Uma coletiva disponível não contorna essa restrição. O uso da coletiva pela especial concorre com as demais respostas do conjunto.

Esta decisão resolve a possibilidade deixada aberta na seção 1; não aprova em bloco todos os detalhes de cancelamento, custos ou gatilho. Permanecem por resolver a janela exata da resposta fora do turno, o destino da ordem quando a criatura usa sua básica em outra atividade durante a espera, cancelamento, mudança de alvo/capacidade, acúmulo/substituição de ordens e inconsciência/troca. Os custos próprios continuam sem preço/fonte/timing definitivo fixados.

## 4. Outra básica durante a espera — decisão posterior de Mizuki

Proposta apresentada: permitir que a criatura use outra atividade básica enquanto a especial antecipada estiver inviável, mantendo a ordem pendente. Ao gastar a básica, a destinatária fica sem aquela oportunidade para a especial até a renovação normal; Reação coletiva sozinha não permite executá-la. A proposta revisa a recomendação antiga, ainda não aprovada, de cancelar a ordem ao usar outra básica.

Resposta autoral:

> Eu acho interessante manter a recomendação, que é justamente o ponto de ter possibilidades de estrategias

**Aprovado:** usar outra básica enquanto a especial não puder ser executada não cancela a ordem antecipada. A ordem continua aguardando; a especial ainda exige básica disponível e, fora do turno do invocador, também a Reação coletiva.

**Alcance:** a decisão cobre a espera enquanto a especial está inviável. Não concede outra básica, não recupera a já gasta, não dispensa requisitos e não aprova por inferência adiar voluntariamente uma especial cuja oportunidade válida já surgiu. Também não altera automaticamente o alvo/capacidade da ordem por a criatura realizar outra tarefa.

**Status das recomendações anteriores:** a recomendação de cancelamento automático pelo uso de outra básica deixa de valer para esse caso. As demais pendências permanecem abertas e serão tratadas separadamente.

## 5. Ajuste da ordem já paga — decisão posterior de Mizuki

Foi apresentada a escolha entre exigir uma nova Padrão para mudar alvo/capacidade da ordem antecipada ou permitir o ajuste por Bônus. Também foi proposta, separadamente, a possibilidade de cancelar antes da execução sem nova ação, mas sem devolver a Padrão paga.

Resposta autoral:

> Acredito que cancelar n fica legal e exigir uma ação extra poed acabar sendo pouco intuitivo, mesmo que funcional para balanceamento, então considerar que a bônus pode permitir ajustar a ordem já paga é interessante

**Aprovado no contexto da escolha apresentada:** a Ação Bônus pode ajustar o alvo ou a capacidade de uma ordem especial antecipada já paga. A alteração aproveita a Padrão anteriormente investida; não exige pagar outra Padrão apenas para substituir essa ordem.

**Consequências de integração:** o ajuste atualiza a ordem pendente, sem criar uma segunda execução, renovar básica ou Reação coletiva, dispensar requisitos da nova capacidade ou desfazer uma execução que já começou. Esta decisão não concede ajuste gratuito nem transfere automaticamente a ordem para outra destinatária.

**Substituição da recomendação anterior:** deixa de ser recomendação vigente exigir nova Padrão para cada mudança de alvo/capacidade da ordem pendente. A alternativa escolhida é o ajuste por Bônus.

**Cancelamento voluntário ainda por esclarecer:** “cancelar n fica legal” pode se referir a perder a ordem/Padrão ao mudar de plano ou à própria existência de uma opção de desistência. Não foi registrada proibição de cancelar, obrigação de executar nem aprovação do cancelamento gratuito proposto. Confirmar o alcance dessa fala antes de fechar a regra.

O ajuste da ordem não foi aprovado como um comando coletivo nem como mudança simultânea gratuita de intenções de outras criaturas. Permanecem as pendências de comunicação, timing dos custos próprios, janela de execução fora do turno, acúmulo/substituição de ordens distintas e inconsciência/troca.

## 6. Esclarecimento sobre desistência — decisão posterior de Mizuki

Ao ser perguntado se a rejeição ao cancelamento significava evitar perder a ordem paga ao mudar de plano ou proibir desistência, Mizuki escolheu expressamente:

> Essa: "Você não quer **perder a ordem já paga ao mudar de plano** — o ajuste por Bônus resolve isso, mas ainda seria possível simplesmente desistir da execução." perdão pela comunicação não tão clara
>
> pode continuar

**Esclarecido:** desistência voluntária da execução é permitida. A objeção anterior não proíbe cancelar nem obriga a criatura a executar uma ordem até que seja ajustada. Mudar de alvo/capacidade continua sendo ajuste por Bônus que aproveita o comando já pago; desistir é abandonar a execução.

**Limite do esclarecimento:** não concede estorno da Padrão, crédito para uma especial futura sem ordem nem desfaz uma capacidade já iniciada. O procedimento exato da desistência e o momento de pagar os custos próprios serão apresentados como parte do próximo bloco; recomendações não são promovidas automaticamente a decisões.

Esta seção resolve a ambiguidade de cancelamento registrada na seção 5. Não reabre o prazo persistente, a execução fora do turno ou o ajuste por Bônus.

## 7. Pagamento, desistência e resultado — decisão posterior de Mizuki

Foi proposto o seguinte conjunto: pagar a Padrão na emissão; não gastar nem reservar previamente os recursos próprios da especial; consumir básica, custos de ativação e, fora do turno do invocador, coletiva quando a especial começar; conservar a ordem e não consumir recursos da execução se faltar requisito; permitir desistência comunicada antes da execução sem nova ação e sem devolver a Padrão anterior; manter os gastos de uma capacidade executada que falhou, conforme suas regras.

Resposta autoral:

> Sim, aceito a recomendação, pode adotar a pratica

**Aprovado:** o conjunto acima passa a integrar o procedimento. Recursos ainda não gastos pela especial permanecem disponíveis para outros usos durante a espera; gastá-los pode tornar a especial inviável até que volte a poder pagar seus custos. Isso não cancela a ordem automaticamente.

Uma execução que falhe em seu ataque/teste ou não produza o resultado desejado ainda cumpre a ordem; ela não fica pendente para repetir gratuitamente. Distinga isso de uma execução que nem começou por ausência de requisito. Capacidades que escrevam exigências próprias de antecipação de custo, manutenção ou resolução continuam seguindo seus textos.

**Limites:** não foram fixados preços, fonte de PE, acesso a PE de usuário inconsciente, comunicação, janela exata da resposta fora do turno nem efeitos de retirada/retorno. A desistência aprovada depende de comunicar a ordem antes de a especial começar; não desfaz uma execução iniciada. Esta seção fecha o procedimento de desistência que permanecia aberto na seção 6.

## 8. Inconsciência e energia própria futura — decisão posterior de Mizuki

Foi proposto: conservar a ordem já recebida durante inconsciência do invocador; permitir sua execução por uma criatura existente e funcional, respeitando requisitos e sustentação; não permitir novos ajustes/orientação posterior do invocador inconsciente; conservar a intenção anterior depois da especial; permitir o gasto dos PE do invocador para cumprir a especial previamente ordenada quando ele já for a fonte normal desses custos, sem conceder acesso geral a sua energia.

Resposta autoral:

> Sim, pode adotar
>
> juntamente a isso, como a bola foi levantada, futuramente devemos ver a possibilidade de invocações terem energia. Já que algumas invocações tem técnica, como no caso de algumas maldições pegas pelo geto
>
> continue

**Aprovado:** o procedimento de inconsciência acima. A ordem antecipada não é cancelada pela inconsciência, e pode ser executada quando a destinatária continuar existente, funcional e capaz de pagar os requisitos. Se a capacidade normalmente usa PE do invocador, essa ordem prévia autoriza consumi-los mesmo enquanto ele estiver inconsciente. Isso não concede novas especiais autônomas, novos comandos, energia adicional ou dispensa de sustentação. Sem recursos suficientes, a ordem continua aguardando. Não há orientação posterior consciente do invocador inconsciente; conserva-se a intenção anterior.

**Pauta futura expressa, não regra aprovada:** examinar a possibilidade de invocações terem energia própria, inclusive para representar entidades com técnica. O exemplo das maldições capturadas por Geto é a motivação fornecida por Mizuki; não foi realizada pesquisa de cânone nesta etapa. Não se decidiu que todas, algumas ou determinadas categorias recebem PE, nem quantidade, recuperação, transferência, preço ou relação entre reservas. Desenvolver essa questão posteriormente, sem abrir agora construtor, orçamento, Evocador ou Trilhas.

Esta decisão fecha o acesso aos PE do invocador inconsciente para a execução previamente ordenada no alcance descrito; não resolve acesso para outros efeitos ou morte/perda do vínculo. A fonte energética normal de cada capacidade continua dependendo de sua futura definição.

## 9. Saída de campo e saldo da substituta — decisão e possibilidade de Mizuki

Ao escolher entre preservar ou encerrar a ordem na retirada da destinatária, Mizuki respondeu:

> Encerrá-la, mesmo que custe as possibilidades diversas, evita problemas maiores de balanceamento e é mais intuitivo
>
> uma possibilidade que já podemos registrar é que caso a invocação recolhida tenha tido sua "ação" usada na rodada, mas ela não está possibilitada de executar, ao ser removida de campo a ação é cancelada e a próxima invocação que vir a substituir pode agir normalmente, ja que a ação foi cancelada

**Aprovado:** a saída de campo da destinatária encerra sua ordem especial antecipada pendente. Recolher ou substituir a criatura não guarda essa ordem para sua volta e não a transmite à substituta. A motivação de controle de balanceamento foi registrada; não constitui resultado de teste de equilíbrio.

**Aplicação das decisões anteriores:** a Padrão já paga ao emitir a ordem não é devolvida. Se a especial ainda não começou, ela não consumiu básica, coletiva nem os custos de ativação que só seriam pagos ao começar, ressalvados textos próprios de capacidades. Sair encerra a ordem, sem por si renovar recursos.

**Possibilidade solicitada, com alcance por esclarecer:** permitir atuação da substituta quando a ordem da entidade retirada não chegou a ser executada. O termo “ação usada” pode significar a Padrão do invocador investida na ordem ou uma básica efetivamente gasta pela criatura. Não registrar automaticamente uma exceção que restaure básica já executada.

- Se somente a Padrão foi paga e a básica da criatura continua disponível no ciclo atual, a substituta elegível já pode receber no máximo uma básica não gasta pela regra aprovada de substituição. Não se trata de recuperar básica: ela não havia sido consumida pela especial.
- Se a criatura já executou uma básica naquele ciclo — inclusive antes de receber a ordem antecipada —, encerrar a ordem não devolve essa básica pelas regras até aqui aprovadas. Permitir uma básica nova à substituta nesse caso seria uma exceção adicional, ainda não consolidada a partir da palavra “possibilidade”.

A trava por identidade da substituta, os estados próprios e o relógio do ciclo do invocador continuam preservados. A regra não cria uma vaga com saldo guardado para uma entrada futura: a transmissão depende de um evento legal de substituição direta.

## 10. Padrão investida e possibilidade de básica aguardando — esclarecimento de Mizuki

Resposta autoral à distinção entre comando pago e básica executada:

> "Padrão investida na ordem que não chegou a ser executada", disse porque existe a possibilidade de até uma ação básica de ciclo não possa ser concluida, imagino que essa ação fica também engatilhada até ter a possibilidade de executar. Então acredito que deva entrar na mesma "regra"

**Esclarecido:** a possibilidade da seção 9 se referia à Padrão investida na ordem, não a devolver uma básica já realizada. Não foi solicitada uma básica extra para a substituta após execução da anterior. Se a especial não começou e ainda existe básica não gasta no ciclo, essa oportunidade pode ser transmitida à substituta elegível pela regra já aprovada; a saída encerra a ordem.

**Nova possibilidade a tratar expressamente:** Mizuki considera que uma básica cuja execução não foi possível também possa ficar aguardando oportunidade e entrar na mesma regra de substituição. A intenção está registrada; ainda é preciso distinguir uma escolha não iniciada, uma execução iniciada/interrompida e a ação geral Preparar, que possui procedimento próprio.

Não foi definido por essa fala que toda básica impedida ganha execução fora do turno, que oportunidades se acumulam entre ciclos ou que uma ação já iniciada e falha devolve recursos. A ordem especial antecipada tem regras de espera e execução reativa aprovadas; transportá-las para básicas exige explicitar o alcance dessa extensão. O critério de transferência já aprovado continua sendo básica efetivamente não gasta, no máximo uma e para substituta elegível.

## 11. Exemplo de intenção não cumprida e substituição — esclarecimento de Mizuki

Mensagem autoral:

> Exatamente, imagine que uma invocação na rodada teve sua "ordem básica" mudada para atacar alvo X, mas ela não consegue executar a ação nessa rodada, então fica engatilhado
>
> O jogador ao ver que essa invocação não consegue performar resolve trocar sua ação padrão por uma bônus (convertendo, o sistema tem essa mecanica simples de maior pra menor), e faz uma substituição e a nova ordem da invocação em campo se torna atacar Y
>
> Como a primeira invocação não teve sua ação usada, essa substituta tem a regra aplicada, podendo agir

**Resultado autoral explicitado:** uma criatura com intenção de atacar X, que não chegou a gastar sua básica no ciclo, pode ser substituída por uma criatura elegível; a substituta recebe a básica não gasta e sua primeira intenção de atacar Y, podendo agir na oportunidade legal. A orientação inicial de Y já está incluída na substituição, sem Bônus adicional só para essa intenção.

**Precisão de integração:** o exemplo descreve intenção persistente ainda não cumprida e básica não executada. Não depende de declarar a ação geral Preparar. A associação anterior do assistente com Preparar foi além do necessário para explicar esse caso. A intenção pode persistir entre ciclos, mas o saldo de básica obedece à renovação normal, sem acumular oportunidades de ciclos anteriores.

**Limite de inferência:** a palavra “engatilhado” não transforma, por si, essa intenção em uma ação reativa fora do turno. Se a criatura realmente tiver gasto sua básica na ação geral Preparar, trata-se de outro estado de recursos. Embora a mensagem comece com “Exatamente” em resposta à pergunta sobre Preparar, o exemplo concreto não o utiliza; não encerrar silenciosamente a exceção de recuperar/transmitir uma básica gasta em Preparar com base apenas nessa analogia. O caso confirmado acima já é atendido pela transferência de saldo não gasto.

**Custo mencionado no exemplo:** Mizuki descreve converter a Padrão em Bônus e realizar a substituição. A conversão Padrão → Bônus já existe nas regras gerais. Falta confirmar se a fala também fixa a Bônus como custo geral da substituição, que até então permanecia aberto. Não inferir dessa passagem PE, custo de manifestação inicial/recolhimento isolado ou gratuidade energética.

## 12. Custo da substituição — esclarecimento posterior de Mizuki

Resposta autoral:

> Achava que já estava definido para bônus, deixe isso na fila ainda iremos discutir futuramente, era um exemplo

**Esclarecido:** a Bônus no exemplo anterior era ilustrativa. O custo da substituição continua pendente e deverá ser discutido futuramente. A conversão Padrão → Bônus segue a regra geral, mas não fixa o custo da troca. O exemplo confirmou apenas a transmissão de básica não gasta e a primeira intenção da substituta, depois de uma substituição legal.

## 13. Janela fora do turno e desistência na oportunidade — decisão de Mizuki

Foi recomendado que a especial antecipada fora do turno seja executada depois de terminar a ação, movimento ou efeito que tornou sua execução possível, sem interromper essa resolução, consumindo básica disponível e coletiva.

Resposta autoral:

> sim, pode seguir a recomendação
>
> mas permitir o invocador cancelar a ação no momento que recebe a possibilidade é ideal, dando possibilidades pro invocador, mas sem quebrar nada, se arrepender é uma opção

**Aprovado:** a janela de execução fica depois da resolução da ação, movimento ou efeito que tornou a especial possível. Antes de começar a especial e pagar seus recursos, o invocador pode desistir na própria oportunidade recém-aberta. Não há obrigação de executar contra sua decisão de cancelamento.

**Aplicação do procedimento já aprovado de desistência:** comunicar o cancelamento antes do início não exige nova ação; encerra a ordem e não devolve a Padrão paga. Não consome básica, coletiva nem custos de ativação ainda não pagos. Custos próprios antecipados por exigência expressa de uma capacidade seguem seu texto. O recurso não gasto permanece disponível para outro uso legal, sem que o cancelamento conceda execução imediata ou ação extra.

**Limites preservados:** não interrompe nem desfaz o acontecimento que abriu a janela; não desfaz uma especial que já começou; desistência continua dependendo de possibilidade de comunicação do invocador. Sua inconsciência não concede novo comando de cancelamento. A escolha autoriza encerrar a ordem; ignorar uma oportunidade válida e conservar a ordem para outra ocasião não foi aprovado por inferência.

## 14. Uma ordem antecipada por criatura — decisão de Mizuki

Foi recomendado que cada invocação mantenha uma única ordem especial antecipada por vez; ajustar por Bônus altera a mesma ordem, sem criar fila. Criaturas diferentes podem manter suas próprias ordens, cada uma com seu comando pago. Se duas forem elegíveis fora do turno, a coletiva única impede pagar as duas sem uma renovação real intermediária.

Resposta autoral:

> Pode seguir a recomendação, a invocação só tem uma reação, n faz sentido ter multiplos gatilhos
>
> siga

**Aprovado:** uma ordem especial antecipada pendente por criatura, sem fila de várias especiais na mesma entidade. Ajustar a ordem não multiplica execuções nem guarda uma cópia da orientação anterior. O limite não proíbe ordens separadas para criaturas diferentes, desde que cada comando seja legal e pago.

**Precisão de integração:** a referência coloquial a “uma reação” preserva a decisão repetidamente aprovada de uma reserva coletiva para todas as invocações, separada da pessoal do invocador; não cria uma Reação individual por corpo. O limite aprovado é de ordens especiais pendentes, não de capacidades reativas conhecidas ou de tipos possíveis de gatilho no repertório. Uma criatura pode ter opções reativas escritas, mas suas utilizações continuam concorrendo pela coletiva quando a exigirem.

Se uma ordem fora do turno consumir a coletiva, outra ordem que precise dessa mesma reserva fica sem requisito de execução e continua aguardando. Não recebe Reação extra nem se perde automaticamente só porque outra criatura respondeu.

## 15. Primeira intenção de entrada sem substituição — decisão de Mizuki

Foi recomendado usar o procedimento normal de orientação por Bônus para uma criatura que entra sem substituir outra e precisa receber sua primeira intenção. Essa Bônus pode orientar também outras entidades com a mesma intenção, dentro do limite X ainda pendente. Não cria básica nem renova recursos; a primeira intenção da substituta direta continua incluída na troca. O custo de manifestação não foi definido pela proposta.

Resposta autoral:

> Concordo, perfeito pode continuar

**Aprovado:** atribuir a primeira intenção a uma entidade que entra sem substituir outra usa Ação Bônus, pelo procedimento de redirecionamento comum. O comando pode dar a mesma tarefa a outras destinatárias elegíveis, respeitando X quando ele for definido. Não é necessário criar uma categoria separada de comando inicial.

**Limites preservados:** a orientação não concede atuação básica imediata à entidade adicional, não renova Movimento ou coletiva e não fixa custo de entrada, troca ou PE. Na substituição direta, a primeira intenção permanece incluída sem outra Bônus. A decisão trata de atribuição da primeira intenção; não aprova números para X nem resolve meios/alcance de comunicação, comportamento sem tarefa ou todas as situações de intenção já cumprida/impossível.

## 16. Atordoado e atuação básica — decisão de Mizuki

Foi recomendado adaptar a perda de uma Ação Padrão de Atordoado para a perda de uma atuação básica da invocação, impedindo também aquela criatura de usar a coletiva enquanto estiver Atordoada. A condição não gasta a reserva e não impede outra entidade apta de usá-la. Encerrar a condição depois de retirar a básica não restitui essa oportunidade no ciclo. A condição pessoal do invocador não se transmite automaticamente às criaturas.

Resposta autoral:

> Concordo, faz sentido e é o ideal

**Aprovado:** a equivalência e suas consequências descritas acima. Se houver mais de uma atuação básica em uma futura ficha, a adaptação retira uma, seguindo a referência que não retira todas as Padrões de quem possui várias. A decisão não fixa a quantidade de básicas da ficha.

Uma especial antecipada não pode ocupar uma básica perdida por Atordoado. Sua ordem permanece aguardando oportunidade válida, respeitando os outros requisitos; o fim da condição não recria uma básica tardia. O invocador Atordoado respeita os impedimentos das próprias ações e não emite novo comando de Padrão sem esse recurso.

Esta decisão aprova a equivalência antes identificada como hipótese/adaptação candidata. Não altera Incapacitado, outras condições, a quantidade de recursos nem o relógio de renovação. O posicionamento fino dos efeitos de início/fim de turno continua sendo o próximo ponto de integração.

## 17. Fronteiras comuns de início e fim — decisão de Mizuki

Foi recomendado: no começo do turno do invocador, realizar a renovação comum e resolver os efeitos de início de turno das criaturas conforme seus textos e impedimentos; durante o turno, organizar as atuações do conjunto concluindo cada resolução; no fim do turno do invocador, resolver individualmente os efeitos de fim de turno de cada criatura, inclusive TR pertinentes, mesmo se ela não conseguiu agir. Os corpos compartilham esses momentos, sem pequenos turnos independentes conforme se movam ou ataquem.

Resposta autoral:

> Sim, concordo

**Aprovado:** as fronteiras comuns para efeitos de início e fim de turno. Os efeitos e testes continuam individuais, mas ocorrem nos momentos comuns do invocador. Não há renovação adicional em uma janela de cada corpo.

O exemplo aprovado mantém a básica retirada por Atordoado indisponível no ciclo mesmo depois de um TR de fim de turno encerrar a condição. A criatura volta a poder reagir quando os impedimentos cessarem, desde que a coletiva e os demais requisitos estejam disponíveis. Não recebe básica tardia.

Esta decisão não resolve por si efeitos de entidades fora de campo, colisões entre efeitos simultâneos sem precedência escrita nem custos de entrada/troca. A integração pode ensaiar os casos definidos sem inventar esses ramos.
