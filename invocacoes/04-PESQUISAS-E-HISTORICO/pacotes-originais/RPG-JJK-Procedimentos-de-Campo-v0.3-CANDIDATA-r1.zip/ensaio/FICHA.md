# Ficha do ensaio procedimental — revisão 1

## Recorte

Ensaio simbólico das transições de comando, recursos, troca e condições decididas por Mizuki. Não é ficha de personagem, simulação de missão, motor integral do RPG ou teste de equilíbrio.

Cada corpo acompanhado possui **uma oportunidade identificada no cenário**, com um identificador que pode ser transferido, gasto ou retirado. Isso é uma fixture para testar conservação, não aprovação de uma básica por ciclo para todas as fichas ou níveis. No começo de um ciclo do ensaio, corpos presentes recebem o identificador novo pertinente à fixture; oportunidades anteriores não se acumulam.

## Recursos e requisitos fornecidos

- Padrão, Bônus, Reação pessoal e coletiva são marcadas como disponíveis/gastas.
- Movimento é acompanhado apenas como disponível/gasto. Não há metros, trajetória, alcance ou custo de sacar.
- Disponibilidade de alvo, percepção, alcance e capacidade é representada por uma pré-condição da cena. Não se simulam geometrias ou sentidos.
- Custos próprios são registros de ativação. Um marcador informa se a cena permite pagá-los, sem quantidade de PE, cálculo de saldo, reserva ou preço. Nos casos de inconsciência, a fonte normal da capacidade é, por premissa, o invocador; verifica-se o acesso autorizado e o momento do pagamento, não uma contabilidade numérica de PE.
- Não há dano, dados, CD ou teste aleatório. Sucesso/falha da capacidade e sucesso no TR de fim de turno são entradas escolhidas para conferir o procedimento.
- PV, condições e usos próprios são marcadores opacos. Compará-los antes/depois da retirada detecta reset; não define seus valores ou durações.

## Trocas e entradas

São fornecidas como **eventos já legais**, sem simular custo de ação, PE, posição de chegada ou direito de recolher aquele vínculo. O nome da operação e os eventos registrados explicitam isso. Não foi adotada Bônus para trocar nem troca gratuita.

Os retornos testados ocorrem dentro do mesmo ciclo. Corpos que permaneceram fora durante a renovação ficam fora do modelo. A básica transmitida conserva identidade para detectar cópias. Casos de destino sem saldo anterior verificam no máximo uma oportunidade transferida; não se define acúmulo em uma ficha futura de múltiplas básicas.

## Turno e condições

Ações comuns e comandos respeitam o turno do invocador. A ordem antecipada pode executar fora dele pela janela aprovada, pagando coletiva. Desistência comunicada pode ocorrer nessa janela, antes de começar.

As cenas fora do turno mantêm a especial inviável durante o turno e só tornam o alvo válido depois. Assim, não presumem permissão para ignorar uma oportunidade anterior mantendo a ordem.

Atordoado presente na abertura retira a oportunidade da fixture. O encerramento por TR fornecido à cena ocorre no fim comum e não a restitui. Não são simulados todos os momentos possíveis de aplicação/cura, múltiplas Padrões de chefes, colisões de efeitos no início do turno ou efeitos de corpos ausentes.

## Guia e coletiva

As sondas de Guia 30 usam um Guia externo com uma cadeia válida já estabelecida. Aberturas, alvo, consentimento, alcance, capacidade de Golpe e seus requisitos são premissas. Testam-se reserva coletiva, respondentes distintos, dispensa apenas da Reação do Guia na segunda resposta e limite de respostas. Não se simula a ficha inteira nem a alternativa Feitiço breve.

No caso de duas ordens prontas, A é avaliada antes de B como configuração da cena. Isso testa que a segunda não usa a mesma coletiva, sem estabelecer regra universal de prioridade.

## Fora do modelo

Preparar e sua possível transferência; adiamento voluntário de ordem já viável; antecipação com execução imediata disponível; manifestações fora dos eventos legais fornecidos; morte/perda de vínculo; energia própria; custos, números e balanceamento; manobras sem resolução; TR de Esquivar; catálogo, construtor, Evocador e Trilhas.

Para reproduzir, execute `python3 bancada_procedimental.py` nesta pasta. O programa regrava somente seus próprios resultados e resumo ao lado do arquivo.
