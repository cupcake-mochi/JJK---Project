# Procedimentos de Campo — revisão 1

**RPG-JJK / Projeto M · v0.3 CANDIDATA — revisão 1 · 24/09/2026**

Integra as decisões de Mizuki posteriores ao primeiro pacote v0.3 CANDIDATA. Essas decisões estão aprovadas em seus alcances; a versão inteira continua candidata, com pendências explícitas e sem aprovação automática do subsistema.

## Leitura

1. [Procedimentos consolidados](01-PROCEDIMENTOS-DE-CAMPO-v0.3-CANDIDATA-r1.md): texto corrente, incluindo as decisões novas.
2. [Alterações e precedência](02-ALTERACOES-DA-REVISAO.md): o que mudou e quais textos anteriores passam a ser históricos para leitura operacional.
3. [Pendências e conflitos](03-PENDENCIAS-E-CONFLITOS.md): separa decisões fechadas, casos residuais e pautas futuras.
4. [Relatório do ensaio](04-RELATORIO-DO-ENSAIO.md): resultados, premissas e limitações.
5. [Ficha do ensaio](ensaio/FICHA.md), `ensaio/bancada_procedimental.py`, `ensaio/resultados.json` e `ensaio/execucao.json`: modelo simbólico e registros reproduzíveis.
6. `fontes/`: registro das decisões posteriores, pauta futura e cópia intacta do pacote original da candidata, que preserva os pacotes anteriores e a auditoria histórica.
7. `MANIFESTO.json`: integridade dos arquivos e comparação das referências protegidas.

## Resultado

**49 casos verificados, 49 aprovados, nenhuma falha na execução final do modelo.** Em 21 casos foi exigido também que uma tentativa recusada ou ainda inviável não alterasse o estado. O ensaio acompanha uma oportunidade identificada por corpo como fixture, sem escolher a quantidade final de básicas, números de ficha ou preços.

As trocas são eventos legais fornecidos à bancada, com custo fora do modelo. Isso não aprova troca gratuita, Bônus para trocar ou qualquer outro custo. Não houve playtest com pessoas nem demonstração de equilíbrio.

## Preservação e continuidade

Não foram alterados o projeto principal, regras gerais ou a coleção de Caminhos v0.4. Estocada e Emanador sem acréscimo de atributo aos PE permanecem preservados. Nenhuma regra de Evocador, Trilha, construtor ou orçamento foi criada. Não houve commit nem push.

Pronto para continuar a integração e ensaios delimitados. Os principais procedimentos de comando e primeira intenção deixaram de ser bloqueios. Ainda não há regra definitiva completa para efeitos/recursos fora de campo, todos os casos de Preparar ou os parâmetros de ficha. Energia própria e custo da substituição permanecem na pauta futura pedida por Mizuki.

Para a próxima revisão autoral e auditoria de interações, recomenda-se **GPT-6 Astra, esforço alto**, conforme a preferência de acompanhamento registrada. A escolha de modelo não altera o status das regras.
