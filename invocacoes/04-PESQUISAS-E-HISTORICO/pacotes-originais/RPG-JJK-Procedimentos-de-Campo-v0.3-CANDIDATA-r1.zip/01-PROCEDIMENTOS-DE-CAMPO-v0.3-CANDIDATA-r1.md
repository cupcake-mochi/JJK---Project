# Procedimentos de Campo — Invocações

**RPG-JJK / Projeto M · Mizuki · v0.3 CANDIDATA — revisão 1 · 24/09/2026**

Revisão integrada com as decisões posteriores registradas em `fontes/DECISOES-POSTERIORES.md`. A candidata original permanece histórica; esta revisão não altera o projeto principal.

Consolidação para leitura e integração. **Não é aprovação automática da v0.3, alteração do manual nem certificação de equilíbrio.** As decisões autorais já aprovadas permanecem aprovadas; a redação integrada e suas adaptações ainda são candidatas.

## 1. Status, escopo e vocabulário

- **[D] Decisão autoral:** aprovada por Mizuki na v0.2, no retorno posterior ou no pedido desta integração.
- **[R] Referência:** regra geral ou Caminho da coleção v0.4, preservado.
- **[E] Esclarecimento:** explicita uma consequência necessária das decisões, sem criar concessão.
- **[H] Recomendação/adaptação candidata:** solução operacional ainda não aprovada especificamente. Não usar como regra definitiva por estar nesta folha.
- **[P] Pendente:** não interpretar silêncio como gratuidade, permissão ou proibição.

Esta folha reúne os procedimentos de atuação, intenção, comando, relógio, reação, entrada e substituição. Não cria regras de Evocador, Trilha, construtor, catálogo, progressão, preços ou orçamento em fatias. Preserva Bastião, Vanguarda, Emanador e Guia da coleção v0.4, Estocada e os PE do Emanador sem acréscimo de atributo.

**Entidade/corpo:** a criatura individual, com identidade e estados próprios, mesmo depois de sair e retornar. **Conjunto:** invocador e suas entidades, na mesma iniciativa; a reserva coletiva pertence somente às entidades. **Ciclo:** do início de um turno do invocador ao início do próximo. **Básica disponível:** uma oportunidade de atuação básica ainda utilizável, não o nome de uma capacidade. **Substituta direta:** entidade escolhida no evento de troca para substituir a que sai; não é uma vaga permanente.

**[P] Quantidade final de básicas por ciclo e progressão:** não fixadas. Uma básica por corpo por ciclo foi hipótese da bancada v0.2. Esta folha não transforma esse número em regra final nem autoriza múltiplas execuções. Nos exemplos, acompanha-se apenas uma oportunidade identificada. A regra preservada impede usar o comando comum para acumular básica e especial no mesmo corpo no ciclo; uma futura ficha com várias oportunidades exigirá compatibilização explícita, não uma exceção inferida daqui.

## 2. Recursos e repertório

**[D]** O invocador conserva suas próprias ações. Cada entidade dispõe de atuação básica e Movimento próprios. Todas as entidades compartilham **uma Reação coletiva**, separada da Reação pessoal do invocador.

| Recurso | A quem pertence | O que não concede |
|---|---|---|
| Atuação básica | Cada entidade | Não dá outra execução por conhecer outra capacidade. |
| Movimento | Cada corpo | Não usa nem transfere os metros do invocador ou da criatura substituída. |
| Reação coletiva | Todas as entidades do mesmo invocador | Não há uma reserva por corpo; a Reação pessoal não a abastece. |
| Padrão/Bônus do invocador | Personagem | Não passam às criaturas quando ele deixa de usá-las. |

**[D]** O repertório pode conter ações gerais e kit próprio, inclusive entidades sem ataque. Ações gerais compatíveis com o corpo não ocupam escolhas personalizadas do kit, mas gastam o recurso correspondente. Anatomia, sentidos, conhecimentos, comunicação e circunstâncias continuam necessários. Não há mãos, fala, telepatia, percepção compartilhada ou ataque implícitos.

Distinga ações gerais, capacidades básicas próprias, especiais ativas comandadas, capacidades reativas e passivas/efeitos persistentes. Aprender uma especial não a torna básica; uma passiva não herda automaticamente o custo de uma especial. Um comando não autoriza repetição indefinida da capacidade.

**[R/E]** Atacar, Correr, Desengajar, Esquivar, Esconder, Ajudar, Vasculhar, Estudar e Usar objeto são opções conforme seus requisitos. Correr ocupa a atuação correspondente para ampliar deslocamento; não acompanha gratuitamente um ataque. Ajudar exige contribuição efetiva e beneficia a tentativa pertinente: vários ajudantes não acumulam vantagem no mesmo teste. A ajuda de outra entidade a uma especial consome a básica da ajudante.

**[P]** A tabela geral de ações não concede Conjurar autonomamente nem ataques adicionais do Caminho do invocador. Agarrar e Derrubar são opções de Atacar na referência, mas falta resolução completa; Empurrar também não recebeu procedimento. Não atribuir teste, CD ou custo por analogia. A ambiguidade de perícia em Estudar permanece registrada.

**[H/P]** A bancada não concedeu Bônus própria por entidade. Converter básica em opções gerais originalmente de Bônus, como Provocar e Ler o Ambiente, continua sem aprovação. Esta folha não concede uma árvore de conversões à criatura.

## 3. Relógio e oportunidades

**[D]** As entidades usam a iniciativa do invocador. O jogador organiza as atuações do conjunto, concluindo cada ação antes da seguinte. Não surgem iniciativas próprias por corpo.

O ciclo começa no **início do turno do invocador** e termina no início do próximo. Nessa fronteira renovam-se a disponibilidade básica conforme a ficha, o Movimento próprio e a Reação coletiva. Restrições e condições continuam aplicáveis. **Virar a rodada global não renova esses recursos.** Manifestar, recolher, substituir, redirecionar ou emitir comando também não os renova.

**[D]** No começo do turno do invocador, ocorre a renovação comum e resolvem-se os efeitos de início de turno de cada criatura conforme seus textos e impedimentos. Durante o turno, o jogador organiza as atuações, concluindo cada resolução. No fim do turno do invocador, cada criatura resolve seus efeitos de fim de turno, inclusive TR pertinentes, mesmo que não tenha conseguido agir.

Efeitos e testes continuam individuais, mas todos usam esses mesmos momentos de começo e fim. Não se abrem pequenos turnos conforme cada corpo se move ou ataca, nem se cria uma segunda renovação. Se Atordoado terminar no fim do turno, a criatura volta a poder reagir quando os requisitos permitirem; a básica retirada permanece indisponível naquele ciclo.

**[P]** Casos de efeitos fora de campo e precedência entre efeitos simultâneos sem texto suficiente continuam abertos. A fronteira comum não resolve essas situações por inferência.

**[E]** Renovar um saldo não autoriza agir fora de uma oportunidade permitida. Uma troca perto da fronteira pode transmitir saldo do ciclo anterior e ser seguida da renovação normal, mas só permite duas atuações próximas se ambas tiverem janelas legais. Não cria uma básica fora do turno. Não foi aprovada uma carência adicional por ter acabado de entrar.

## 4. Intenção persistente e redirecionamento

**[D]** Uma tarefa continua valendo sem comando repetido. A entidade escolhe opções básicas e movimento coerentes com a intenção, o que percebe e o que consegue fazer. Trocar de opção dentro da tarefa não é automaticamente redirecionar.

“Proteja esta entrada” pode justificar aproximar-se, Ajudar, Esquivar ou atacar uma ameaça pertinente, se a ficha permitir. Não obriga o inimigo a atacar a criatura, não concede interceptação e não revela alvos que ela não percebe.

**[D] Redirecionar:** o invocador gasta **Ação Bônus** para atribuir a mesma nova intenção a até **X** destinatárias. Intenções distintas exigem comandos distintos na base. As criaturas podem escolher básicas e trajetos diferentes para cumprir a tarefa comum. O comando muda a tarefa, sem recuperar básica, Movimento ou coletiva, e não autoriza especial.

**[R]** A Padrão do personagem pode ser convertida em Bônus, e a Bônus em Movimento, nunca no sentido inverso. Assim, Bônus e Padrão convertida podem pagar redirecionamentos diferentes; a Padrão convertida já não está disponível para comandar especial.

**[P]** X, fórmula, meios e alcance de comunicação permanecem abertos. Não importar X = 3, metade da Essência ou o alcance do Guia como alcance do vínculo. Receber orientação depende de um meio válido; autonomia não equivale a comunicação ilimitada.

**[H/P]** Encerrar intenção por cumprimento ou impossibilidade e definir comportamento sem tarefa válida ainda precisa de diretriz. A persistência não obriga repetir uma tentativa impossível nem autoriza substituir silenciosamente a tarefa por outra. O desaparecimento do alvo não revela sua nova posição. A primeira intenção de entrada adicional é tratada na seção 9, sem presumir Bônus obrigatória nem gratuidade.

## 5. Especial imediata e orientação posterior

**[D]** O invocador paga **Ação Padrão** para comandar uma especial ativa de uma entidade que possa receber a ordem e executá-la. A especial ocupa a básica ainda disponível da destinatária e paga os custos próprios da capacidade. Não consome a básica das demais entidades.

Se a destinatária já gastou a básica do ciclo, o comando não lhe permite executar a especial naquele mesmo ciclo. Executar a especial também não deixa uma básica adicional para depois. Movimento e coletiva são recursos separados, salvo custo ou impedimento explicitamente escrito.

**[D]** A especial pode atuar fora da intenção vigente, sem Bônus adicional para essa intervenção. **Depois de conhecer o resultado**, o invocador escolhe conservar a intenção anterior ou atribuir uma nova à destinatária, também sem Bônus adicional. O alvo da nova intenção pode diferir do alvo da especial. Essa orientação não se espalha às outras entidades nem concede execução imediata.

Exemplo sem ficha numérica: Nue enfrenta A. O invocador paga Padrão para ordenar uma especial contra X; Nue ocupa sua básica disponível, satisfaz os requisitos e resolve a capacidade. Só então o invocador decide “foque em Y” ou mantém a intenção anterior. Nue não ganha outra básica; as demais criaturas mantêm suas tarefas e saldos.

**[E/P]** A comunicação necessária à ordem e à orientação posterior não é dispensada. Não há fonte de PE implícita. Duração e manutenção dependem do texto da capacidade; autorizar uma execução não autoriza reativá-la indefinidamente. A resolução específica de interrupções/custos depois de iniciar uma capacidade não foi criada aqui.

## 6. Comando especial antecipado

**[D/E]** O procedimento abaixo incorpora as decisões autorais posteriores à candidata original e explicita suas consequências de recursos. Os limites ainda não decididos estão marcados como pendentes.

### 6.1. Emitir a ordem

Se a destinatária já gastou a básica pertinente e não pode executar a especial agora, o invocador pode gastar sua **Ação Padrão** para antecipar a ordem, indicando a criatura, a capacidade e o alvo. A destinatária precisa receber a orientação pelo meio válido do vínculo.

A ordem aguarda a primeira oportunidade em que a criatura realmente possa executar. Não expira apenas porque terminou o próximo turno do invocador. O comando não renova a básica e não autoriza a criatura a executar antes de ter uma básica elegível disponível.

**[P]** Antecipar voluntariamente quando a especial já poderia ser executada agora não foi definido por estas decisões.

### 6.2. Recursos durante a espera

Paga-se a Padrão na emissão. Os recursos próprios da especial não ficam gastos nem reservados: continuam disponíveis para outros usos. Requisitos específicos escritos na capacidade continuam aplicáveis.

Enquanto a especial estiver inviável, a criatura pode usar outra atividade básica e manter a ordem pendente. A básica gasta dessa maneira fica indisponível para a especial até a renovação normal; a Reação coletiva não substitui a básica.

O jogador não ganha novas execuções por manter uma ordem nem por a criatura conhecer outras capacidades. **[P]** Adiar voluntariamente uma especial cuja oportunidade válida já surgiu ainda precisa de tratamento expresso.

### 6.3. Ajustar ou desistir

O invocador pode gastar **Ação Bônus para ajustar o alvo ou a capacidade** da ordem antecipada já paga. Aproveita a Padrão investida e atualiza a mesma ordem; não cria outra execução. A alteração exige comunicação válida e não desfaz uma capacidade que já começou.

O ajuste não transfere automaticamente a ordem para outra criatura nem é um redirecionamento coletivo. Não altera automaticamente as intenções das outras entidades.

Antes de a especial começar, o invocador pode comunicar a **desistência sem nova ação**. A ordem é encerrada, sem devolução da Padrão paga e sem cobrança dos custos de uma especial que não começou. Desistir não cria um crédito para outra especial futura.

### 6.4. Executar

Quando houver uma oportunidade válida, verifique básica disponível, capacidade de agir, alvo, alcance, percepção, custos, usos e demais requisitos aplicáveis. A fonte e os preços dos recursos devem vir da capacidade/vínculo; não são concedidos por esta regra.

| Momento | Recursos consumidos quando a especial começa |
|---|---|
| Dentro do turno do invocador | Básica disponível da destinatária e custos próprios de ativação. |
| Fora do turno do invocador | Básica disponível da destinatária, **Reação coletiva** e custos próprios de ativação. |

Não se paga outra Padrão de comando na execução. A coletiva usada concorre com as demais respostas das invocações. A especial substitui a básica; não deixa uma básica adicional para depois nem ocupa as básicas das outras criaturas.

Se faltar um requisito, a especial não começa e a ordem continua esperando. Não se gastam básica ou coletiva pela tentativa inviável, nem os custos de ativação que só seriam pagos ao começar. Uma capacidade com exigência expressa de antecipação de custo continua seguindo seu próprio texto.

Fora do turno, a janela de execução ocorre depois de terminar a ação, movimento ou efeito que tornou a especial possível. Não se interrompe nem se desfaz essa resolução para executar a especial. Verificam-se os requisitos no estado resultante.

Antes de a especial começar, o invocador pode desistir na própria janela recém-aberta, comunicando o cancelamento conforme a seção 6.3. Não precisa consumir básica, coletiva ou custos de ativação antes de decidir. A desistência encerra a ordem; os recursos ainda não gastos continuam disponíveis para usos legais. Ela não concede ação imediata adicional nem devolve a Padrão usada para ordenar. Requisitos de comunicação continuam valendo, inclusive os impedimentos decorrentes da inconsciência descritos na seção 6.6.

### 6.5. Resolver e encerrar

Uma especial executada cumpre a ordem mesmo se errar, falhar num teste ou não alcançar o resultado esperado. Os gastos permanecem conforme a regra da capacidade. Não se conserva a ordem para repetir a execução gratuitamente.

Depois de conhecer o resultado, o invocador pode conservar a intenção anterior ou atribuir outra à destinatária sem Bônus adicional, conforme o benefício já aprovado para o comando especial. A nova intenção não concede outra básica. Se o invocador estiver inconsciente, aplica-se a seção seguinte; outros impedimentos de comunicação continuam sujeitos aos meios válidos do vínculo.

### 6.6. Inconsciência do invocador

A ordem recebida antes da inconsciência permanece válida. A criatura pode executá-la se continuar existente, funcional e cumprir os requisitos, inclusive sustentação e disponibilidade de básica e, fora do turno do invocador, coletiva.

Se a capacidade normalmente usa PE do invocador, a ordem prévia permite gastar esses PE mesmo enquanto ele estiver inconsciente. Esse acesso serve para cumprir a especial já ordenada; não concede à criatura acesso geral à energia para escolher novas especiais por conta própria. Não aumenta a reserva nem dispensa custos. Se faltar energia, a ordem continua aguardando.

O invocador inconsciente não emite novos comandos, não ajusta a ordem e não dá nova orientação depois do resultado. Depois da especial, a criatura conserva sua intenção anterior.

Essa regra trata de inconsciência; não decide morte do invocador, perda do vínculo ou acesso à energia para efeitos diferentes da especial previamente ordenada. Ter energia própria é pauta futura, ainda sem regra ou valor definido.

### 6.7. Saída de campo e substituição

A saída de campo da destinatária encerra a ordem antecipada pendente. A ordem não fica guardada para a reentrada da mesma criatura e não passa para sua substituta. A Padrão já paga não é devolvida.

Se a especial não começou, não consumiu a básica nem a coletiva ou os custos de ativação que só seriam pagos ao começar, ressalvadas exigências específicas da capacidade. A substituta elegível pode receber no máximo uma básica ainda disponível da criatura que sai, conforme a regra de substituição. O cancelamento da ordem não é a origem dessa básica; ela já precisava existir e estar não gasta.

Se a destinatária já havia executado sua básica no ciclo, encerrar a ordem pendente não a restaura. Mizuki esclareceu que a “ação usada” mencionada em sua proposta era a Padrão investida na ordem que não chegou a ser executada. Portanto, não há exceção à proibição de renovar básica pela troca: transmite-se somente a oportunidade que ainda não foi gasta.

A espera de uma intenção básica deve ser distinguida da ordem especial antecipada. No exemplo esclarecido por Mizuki, a entidade recebeu a intenção de atacar X, mas não chegou a gastar sua básica. Ao substituí-la, uma destinatária elegível pode receber essa básica não gasta e a primeira intenção de atacar Y, agindo na oportunidade legal. A intenção anterior estar pendente não consome por si a básica nem exige a ação geral Preparar.

A intenção persiste conforme sua regra; oportunidades básicas não se acumulam entre ciclos. Uma intenção pendente não concede automaticamente execução fora do turno. **[P]** Se houve uso efetivo da ação geral Preparar, a transferência daquela básica já comprometida exige tratamento separado; o exemplo de intenção não cumprida não basta para conceder recuperação de recurso gasto.

### 6.8. Limite de ordens e Reação coletiva

Cada criatura pode manter uma única ordem especial antecipada pendente. Ajustar por Bônus altera essa ordem; não acrescenta outra à fila nem conserva uma cópia da ordem anterior.

Criaturas diferentes podem ter suas próprias ordens, cada qual com seu comando legalmente emitido e pago. Todas continuam compartilhando uma única Reação coletiva. Se uma especial fora do turno a consumir, outra ordem que precise dela fica sem requisito e continua esperando; não ganha uma segunda Reação e não é cancelada apenas pelo gasto da primeira.

O limite de uma ordem antecipada não limita a criatura a conhecer uma única capacidade reativa ou um único tipo de gatilho. Essas opções seguem os textos das capacidades e concorrem pela coletiva quando a exigirem. Não há uma reserva de Reação por corpo.

## 7. Movimento, Reação e defesa

**[D]** Cada corpo usa seu Movimento por discernimento coerente com a tarefa; não exige ordem por passo e não consome Movimento do invocador. O recurso é individual. Seus valores não foram definidos aqui. Autonomia não concede movimento ilimitado ou acompanhamento fora do turno sem fonte escrita.

**[D/E]** No gatilho de uma capacidade reativa, uma criatura elegível pode responder autonomamente, pagando a coletiva e os demais custos escritos. Percepção, alcance, posição e condições continuam necessários. Uma resposta que gaste a coletiva impede outro gasto dela até a renovação. Troca de corpo não altera esse saldo. Uma condição pode impedir uma criatura de reagir sem gastar a reserva; outra criatura apta continua elegível.

**[R] Bloquear:** gratuito por ataque elegível; não gasta coletiva e não se aplica a TR. Usa a regra geral `2d10 + Defesa − 11`. Duplo 10 impede o acerto comum, mas não o 20 natural; o contra-ataque de Aparar exige Reação e usa o bônus de dano já escrito na regra geral. Duplo 1 permite Brecha, cujo ataque adicional é pago pela Reação do agressor. Se o agressor for uma invocação, a reserva pertinente é a coletiva.

Uma coletiva gasta não impede novos Bloquear elegíveis, mas impede o contra-ataque que exige Reação. Ter uma reserva disponível não fornece ataque a uma criatura sem ataque. Interceptação não é habilidade universal; o cartão da antiga bancada não integra esta regra.

**[R] Condições:** Incapacitado impede Bloquear e torna críticos os acertos corpo a corpo previstos em seu texto, sem eliminar automaticamente todas as ações. Atordoado tira uma Padrão, não todas quando houver várias, e impede reagir. Lento reduz deslocamento e impede Bônus; Agarrado e Impedido têm seus impedimentos próprios. Não importar efeitos de condições de outros jogos.

**[D] Adaptação de Atordoado:** a condição retira uma atuação básica da invocação e impede aquela criatura de usar a coletiva enquanto se aplicar. Não gasta a reserva: outra entidade apta pode utilizá-la. Se uma futura ficha tiver várias atuações, perde uma, sem fixar aqui a quantidade da ficha. Encerrar a condição depois da perda não restitui a básica no ciclo; uma ordem antecipada continua esperando oportunidade válida. A condição do invocador não é transmitida por associação às criaturas. Sem Padrão disponível, ele não emite o comando especial comum.

## 8. Preparar, Esquivar e Guia v0.4

### 8.1 Preparar não é comando antecipado

**[R/H] Adaptação candidata:** Preparar ocupa a básica da criatura agora, especifica ação e gatilho visível/verificável e usa a coletiva quando o gatilho ocorre. A reserva não fica separada para a preparação. Gastá-la em outra resposta faz a preparação se perder; havendo várias, não sobrevivem como créditos para depois. A preparação expira no começo do próximo turno do invocador. A fronteira comum já foi aprovada. O uso de Preparar pela básica permanece adaptação indicada; não se presume devolução de uma básica efetivamente gasta em Preparar ao recolher a criatura. O exemplo autoral de intenção não cumprida trata de básica que não foi gasta.

| Preparar pela entidade | Comando especial antecipado |
|---|---|
| Ocupa básica ao preparar. | Paga Padrão do invocador ao ordenar. |
| Executa por gatilho visível e exige coletiva. | Ocupa básica disponível; fora do turno exige também coletiva e ocorre depois da resolução que abriu a oportunidade. |
| Expira no começo do próximo turno, conforme a adaptação indicada. | Aguarda oportunidade válida, sem expirar pela simples passagem de turno; termina por execução, desistência ou saída da destinatária. |
| Não autoriza uma especial sem comando. | Autoriza a especial específica, respeitados os requisitos. |

Não combinar os dois procedimentos para dispensar comando, criar básica ou evitar o custo reativo de Preparar. A combinação de uma especial comandada com Preparar não recebeu procedimento próprio.

**[R + adaptação de relógio] Esquivar:** como básica elegível, impõe a desvantagem escrita aos ataques contra aquela criatura até o começo do próximo turno do invocador. Não protege outro alvo por si. O trecho sobre “TR de Destreza” permanece **[P]**, pois o projeto lista TR Físico, Vigor, Intelecto e Espírito. Não substituí-lo silenciosamente por TR Físico nem escolher beneficiários por atributo.

### 8.2 Respostas do Guia

**[R]** Mantém-se a coleção v0.4. Abrir Caminho fornece uma Abertura a aliado voluntário que satisfaça seus requisitos; a Abertura não fornece a ação necessária para aproveitá-la. O alcance e os PE escritos no Guia pertencem àquela habilidade, não ao vínculo.

Depois de resolver o uso da Abertura, Resposta Coordenada pode convidar um aliado elegível. Na resposta normal, **Guia e aliado pagam suas Reações**. A invocação paga a coletiva. O invocador ser o próprio Guia não funde as reservas: ele paga a pessoal e a criatura paga a coletiva.

**O Golpe concedido é um ataque comum: não é básica, especial, Ação Atacar ou etapa de Sequência.** Não renova básica, não permite uma especial tardia depois de básica já usada, não herda ataques adicionais e não desencadeia outra ação concedida. Pode ocorrer depois de básica ou de especial se houver gatilho, elegibilidade e coletiva disponíveis.

O Guia também possui a alternativa escrita **Feitiço breve**, um Classe 0 conhecido com requisitos e custos normais. Ela permanece no Caminho; não é convertida em Golpe nem concedida a uma criatura que não a conheça. Esta folha não cria uma especial do vínculo a partir dela. Respeita-se o limite geral de conjurações, sem importar exceções de Trilhas antigas ausentes da coleção v0.4.

**[R/H] Avançar:** no turno do beneficiário, usa o trecho concedido sem outra ação; fora dele, exige sua Reação. A aplicação ao turno conjunto mantém a adaptação da bancada: dentro do turno do invocador considera-se o turno da entidade para esse efeito; fora dele, a invocação paga a coletiva. A definição fina das janelas não pode criar Movimento livre fora da oportunidade concedida. Terreno e impedimentos permanecem.

### 8.3 Guia 30 e duas fronteiras

**[R/D]** Todos no Mesmo Plano mantém sua cadeia, participantes distintos, tipos de Abertura distintos, prazo e limites da v0.4. Na primeira resposta, o Guia paga sua Reação. A segunda dispensa **somente a Reação do Guia**; os aliados continuam pagando as suas e não pode ser a mesma criatura nas duas respostas.

O ciclo do Guia vai do início de um turno dele ao seguinte; o da coletiva acompanha o invocador. Portanto:

- **Sem renovação entre gatilhos:** a primeira invocação gasta a coletiva; outra do mesmo conjunto não consegue pagar a segunda resposta.
- **Com renovação real entre gatilhos:** a primeira invocação responde antes do começo do turno do invocador; a coletiva renova nessa fronteira; uma segunda criatura distinta pode pagar a segunda resposta, ainda dentro da cadeia válida do Guia.

Não impor “uma resposta por ciclo do Guia” ao conjunto. A exceção do nível 30 não cria duas coletivas e não renova a reserva. Quando Guia e invocador são a mesma pessoa, suas fronteiras coincidem; não se deve transportar automaticamente para esse caso a sequência que dependia de um Guia externo.

## 9. Entrada, substituição e retorno

### 9.1 Pré-condição e estados separados

**[P] Custo e legalidade de manifestação/recolhimento/troca:** ação, PE, posição de entrada, oportunidade e demais requisitos não foram fixados. As regras seguintes descrevem recursos **depois de uma entrada/troca legal**, sem torná-la gratuita nem permitir realizá-la em qualquer instante. Um corpo não recolhível pelas regras de seu vínculo não se torna portátil.

**[D/E]** Controle separadamente: identidade do corpo; básica disponível, gasta ou transferida neste ciclo; Movimento próprio restante; intenção; PV, condições, usos e demais estados; coletiva do conjunto. Registrar transferência não cria um inventário de vagas permanentes.

### 9.2 Substituição direta 1→1

**[D]** A sai e B entra substituindo A:

1. Identifique se A possui uma básica ainda não gasta e utilizável para transferência.
2. B só pode recebê-la se **ainda não tiver gasto uma básica naquele ciclo**. Uma especial que ocupou sua básica conta como gasto para essa trava.
3. Transfira **no máximo uma** oportunidade. Se A já a gastou, não há saldo a transferir. Se B já gastou, a troca não lhe recupera básica.
4. B recebe sua primeira intenção como parte dessa substituição, sem Bônus adicional. Essa orientação não depende de haver básica para agir imediatamente e não cria uma.
5. B usa o seu Movimento disponível. A coletiva conserva o saldo anterior.

**[E] Transferir não é copiar:** a oportunidade transmitida deixa de estar no saldo de A. Ao retornar, A não a conserva também sob o argumento de que não a executou. Se B a gastar ou a transmitir legalmente, existe sempre a mesma oportunidade, nunca uma cópia em cada corpo. Não há estorno automático ao recolher B.

**[D/E]** O histórico de uso pertence ao corpo. Mudar seu nome de posição, destinatária ou substituta não apaga a básica que ele já gastou naquele ciclo. Passar por vários corpos sem executar pode mudar quem usa o saldo, mas não multiplicá-lo. Esta regra não autoriza acumular várias básicas em um corpo nem fixa uma futura economia com múltiplas execuções.

### 9.3 Uma saída e várias entradas; várias saídas e uma entrada

**[D] 1→vários:** escolha uma entidade como substituta direta. Só ela pode receber a básica não gasta da que sai e a primeira intenção incluída. As demais são entradas adicionais: não ganham básica nem primeira intenção gratuita por esse evento. Cada corpo novo tem seu Movimento próprio disponível; um corpo que retorna conserva apenas seu saldo próprio.

**[E] Vários→1:** a substituta recebe no máximo uma oportunidade legalmente transmitida. Não somar as básicas das criaturas que saíram. A transferência é do evento de substituição, não de vagas permanentes que se acumulam.

### 9.4 Entrada que apenas acrescenta corpo

**[D/E]** Um corpo novo que entra sem substituir outro tem Movimento próprio disponível, mas sua entrada **não cria básica**, não renova a coletiva e não recebe a primeira intenção gratuita da substituição. Na próxima fronteira normal, a disponibilidade passa a seguir a ficha e seus impedimentos; a troca/entrada não antecipa essa renovação.

**[E]** A entidade pode usar uma coletiva ainda disponível se cumprir os requisitos da resposta escrita. Isso não lhe dá básica, ataque ou capacidade inexistentes. A ausência de primeira intenção gratuita não apaga a autonomia reativa aprovada, mas também não dispensa os requisitos da capacidade.

**[D]** Para atribuir a primeira intenção à entidade que entra sem substituir outra, o invocador usa **Ação Bônus**, pelo procedimento normal de redirecionamento. A mesma Bônus pode dar a mesma tarefa a outras destinatárias elegíveis dentro de X, ainda pendente. Não cria básica nem renova recursos. O custo de manifestação continua aberto e não é definido por esse gasto de orientação. Uma entidade sem tarefa não recebe, por essa regra, comportamento universal presumido.

### 9.5 Mesmo corpo retornando

**[D/E]** Sair e retornar não renova básica, Movimento, coletiva, PV, condições, usos limitados ou demais estados próprios. A ordem especial antecipada, especificamente, é encerrada na saída e não retorna com o corpo (seção 6.7). O que ainda pertencia ao corpo e não foi gasto, perdido nem transferido continua registrado; o retorno não cria uma segunda cópia. Movimento gasto continua gasto, mesmo quando outro corpo teria entrado com Movimento novo.

Exemplos: A gastou a básica, saiu e volta substituindo B — A não recebe outra no mesmo ciclo. A transmitiu sua básica a B e sai — ela não reaparece no saldo de A ao retornar. C nunca entrou naquele ciclo — sua chegada legal traz Movimento próprio, independentemente dos metros que A gastou; isso não fornece básica a C.

**[P]** Efeitos dependentes de presença, existência ou manifestação seguem o próprio texto. Se ele não determinar o que ocorre na saída, o caso permanece aberto. Preservar condições não implica congelar durações ou tornar eterno um efeito que exige presença. Renovação de recursos de corpos que permaneceram fora durante a fronteira e duração de efeitos fora de campo precisam de especificação quando indispensáveis; não atribuir essa renovação à reentrada.

**[E]** Troca não cura. Uma reserva saudável pode aumentar a vida acessível ao longo da cena sem alterar os PV do corpo ferido. Esta folha reconhece o efeito, mas não lhe atribui preço, recuperação definitiva ou regra de ressurreição.

## 10. Inconsciência, sustentação e exploração

**[D]** A entidade já em campo e funcional continua sua rotina básica, Movimento e respostas autônomas se a sustentação permitir que permaneça existente. O usuário inconsciente não emite novos comandos nem cede suas ações não usadas. Zero PV não é automaticamente inconsciência: observar a situação efetiva e as regras de Insistir/Aguentar.

Autonomia integra o investimento do vínculo/entidade; não cobra taxa periódica apenas para repetir a rotina enquanto validamente manifestada. Isso não elimina custos particulares de duração, manifestação, manutenção e capacidades.

**[D]** Uma ordem especial recebida antes da inconsciência continua válida. Se a capacidade normalmente usa PE do invocador, a ordem permite gastá-los para cumprir aquela execução mesmo enquanto ele estiver inconsciente. A criatura ainda precisa existir, funcionar e satisfazer os requisitos. Esse acesso não autoriza novas especiais escolhidas autonomamente. Depois de executar, conserva a intenção anterior se o invocador não puder orientar. Ver seção 6.6.

**[P]** Morte, perda do vínculo, manifestação de reservas e acesso à energia para outros efeitos continuam abertos. A possibilidade de energia própria das invocações foi registrada como pauta futura, sem concessão, quantidade ou regra de recuperação.

**[E]** Fora do combate, tarefas continuam dependentes de meios e informação. Sob pressão de tempo, buscas e tentativas consomem sua atuação correspondente; mais corpos não permitem tentativas infinitas, compartilhamento instantâneo de sentidos ou ignorar regras de ajuda/testes de grupo.

## 11. Pendências e limite de uso

O núcleo de comando antecipado, a primeira intenção da entrada adicional, a adaptação de Atordoado e as fronteiras comuns foram decididos. Não devem continuar sendo tratados como perguntas em aberto. A candidata incorpora essas decisões sem declarar o subsistema inteiro aprovado.

Permanecem: fonte e valores das capacidades, quantidade de básicas, X e comunicação; custos e legalidade de entrada/recolhimento/troca; efeitos fora de campo e colisões sem precedência escrita; comportamento quando não há tarefa válida; as lacunas das manobras, de Esquivar e de Estudar. Energia própria ficou expressamente para uma etapa futura. Não foi fixado nenhum desses números ou preços.

No comando antecipado, não foram autorizados por inferência o adiamento voluntário com conservação de uma ordem já executável nem sua emissão antecipada apesar de haver execução imediata possível. Respostas simultâneas continuam limitadas pela coletiva; prioridade entre opções igualmente elegíveis precisa da regra geral pertinente ou de adaptação explícita no ensaio. O exemplo da básica não executada não concede recuperação de uma básica efetivamente gasta em Preparar.

O ensaio desta revisão acompanha oportunidades e pagamentos simbólicos; não define quantidade final de básicas, PE ou custos de troca, não modela todas as condições e não é teste de equilíbrio. A aprovação dos procedimentos não aprova automaticamente os resultados do modelo ou os módulos futuros.

A divergência com o manual antigo permanece: comando obrigatório por rodada e inércia na inconsciência não podem ser sobrepostos à autonomia decidida. Preservar a coleção v0.4 e registrar conflitos, sem restaurar Trilhas antigas para encaixar a proposta.

**Pronta para ensaio e continuidade da integração como v0.3 CANDIDATA — revisão 1.** Não é publicação definitiva. Nenhuma regra de Evocador, Trilha, construtor ou orçamento foi criada. A consolidação original, os registros autorais e os ensaios anteriores permanecem históricos.
